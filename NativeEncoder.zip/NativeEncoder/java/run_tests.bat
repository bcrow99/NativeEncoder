@echo off
rem Regression test for the native pairs: NativeWriter / NativeReader and
rem NativePacketWriter / NativePacketReader (Windows): as run_tests.sh.
rem
rem   java\run_tests.bat <image> [out_dir]
rem
rem Compiles everything, then writes the image (test.Drive, Save's defaults)
rem and decodes it (test.Decode, which picks the reader by the file's format)
rem in twelve jobs: NativeWriter with the context aware coding in 1, 4 and 8
rem bands (n1, n4, n8), in 1 band with the Java's fit and coder (j1, -Dnative=false) and
rem in 4 bands with the average deltas (v4), NativeWriter with the Huffman
rem coding in 1, 4 and 8 bands (h1, h4, h8) and in 4 bands with the average deltas
rem (a4), NativeWriter with the Context tables coding in 4 bands (t4,
rem entropy_type=3), and NativePacketWriter with its defaults (p) and with the block map
rem (q, delta_type=13). All but j1 use the C if native has DeltaMapper.dll (see
rem the Makefile). For bluejay.jpg and scrubjay.jpg (bcrow99/TestImages) the
rem size and the decoded image's MD5 are checked; for others they're only
rem printed. Native methods must keep these the same.
rem The writer's windows show and close by themselves: leave them be.
rem What it prints also goes to out_dir\run_tests.log.
setlocal
set HERE=%~dp0.
set IMAGE=%~f1
set NAME=%~nx1
set OUT=%~2
if "%~1"=="" (
	echo usage: java\run_tests.bat ^<image^> [out_dir]
	echo Run it from a command prompt, with the image's path: opened from
	echo Explorer it has no image to work on.
	pause
	exit /b 1
)
if "%OUT%"=="" set OUT=out
if not exist "%IMAGE%" (echo No image %IMAGE% & exit /b 1)
rem Java 17 and later warn when a library is loaded unless native access is
rem enabled; Java 8 doesn't know the option, so it's only given if accepted.
set NA=
java --enable-native-access=ALL-UNNAMED -version >nul 2>&1 && set NA=--enable-native-access=ALL-UNNAMED
if not exist "%OUT%\classes" mkdir "%OUT%\classes"
javac --release 8 -nowarn -Xlint:-options -Xlint:-unchecked -encoding UTF-8 -d "%OUT%\classes" "%HERE%\src\*.java" "%HERE%\src\test\*.java"
if errorlevel 1 exit /b 1
cd /d "%OUT%"
set LOG=run_tests.log
echo Testing %IMAGE% > %LOG%
echo The writer's windows open and close by themselves, 10 s or more each.
set KNOWN=0
rem (bluejay's 295 rows allow 4 bands at most, NativeWriter.BAND_MIN_ROWS:
rem its 8-band jobs write the 4-band files.)
set KNOWN=0
if /i "%NAME%"=="bluejay.jpg" (
	set KNOWN=1
	set MD5=7c41049db7c073c7026278bcf58b15a5
	set MD5_p=08c60a8982b8932b8032652086773cb1
	set SIZE_n1=61174
	set SIZE_n4=62689
	set SIZE_n8=62689
	set SIZE_v4=67743
	set SIZE_h1=69095
	set SIZE_h4=70893
	set SIZE_h8=70893
	set SIZE_a4=76031
	set SIZE_t4=65338
	set SIZE_p=76209
	set SIZE_q=68830
)
if /i "%NAME%"=="scrubjay.jpg" (
	set KNOWN=1
	set MD5=0eec6e139a759db5d26da1d2ed031d94
	set MD5_p=f49ae237a0e3ea40abc7beb3e353296c
	set SIZE_n1=4075255
	set SIZE_n4=4080169
	set SIZE_n8=4086689
	set SIZE_v4=4356507
	set SIZE_h1=4453703
	set SIZE_h4=4454159
	set SIZE_h8=4453700
	set SIZE_a4=4765744
	set SIZE_t4=4149236
	set SIZE_p=4855085
	set SIZE_q=4465954
)
set FAIL=0
rem (PacketWriter resizes differently, so its jobs decode to another image.)
rem (Each value is quoted: for an image it doesn't know, the sizes and MD5s
rem are empty, and an empty value left unquoted would shift the rest.)
call :job n1 1 "%SIZE_n1%" NativeWriter       "%MD5%"   "bands=1"
call :job n4 4 "%SIZE_n4%" NativeWriter       "%MD5%"   "bands=4"
call :job n8 8 "%SIZE_n8%" NativeWriter       "%MD5%"   "bands=8"
call :job j1 1 "%SIZE_n1%" NativeWriter       "%MD5%"   "bands=1" "-Dnative=false"
call :job v4 4 "%SIZE_v4%" NativeWriter       "%MD5%"   "bands=4 delta_type=1"
call :job h1 1 "%SIZE_h1%" NativeWriter       "%MD5%"   "bands=1 entropy_type=1"
call :job h4 4 "%SIZE_h4%" NativeWriter       "%MD5%"   "bands=4 entropy_type=1"
call :job h8 8 "%SIZE_h8%" NativeWriter       "%MD5%"   "bands=8 entropy_type=1"
call :job a4 4 "%SIZE_a4%" NativeWriter       "%MD5%"   "bands=4 delta_type=1 entropy_type=1"
call :job t4 4 "%SIZE_t4%" NativeWriter       "%MD5%"   "bands=4 entropy_type=3"
call :job p  1 "%SIZE_p%"  NativePacketWriter "%MD5_p%" "delta_type=2"
call :job q  1 "%SIZE_q%"  NativePacketWriter "%MD5_p%" "delta_type=13"
if "%FAIL%"=="0" (call :say All passed.) else (call :say FAILED: see the logs in %CD%)
exit /b %FAIL%

rem :job name bands "expected_size" writer "expected_md5" "field=value ..." ["java option"]
rem -- one write and decode (the fields quoted: a batch file splits arguments at =)
:job
set JOB=%1
set BANDS=%2
set EXPECT=%~3
set WRITER=%4
set EXPECT_MD5=%~5
set FIELD=%~6
set OPT=%~7
set FIT=?
set SIZE=none
set GOT=none
set MS=?
set STATUS=ok
if exist %JOB%.bin del %JOB%.bin
java %NA% %OPT% -cp classes test.Drive %WRITER% "%IMAGE%" %JOB%.bin 2 %FIELD% > %JOB%.log 2>&1
if not exist %JOB%.bin (
	call :say %JOB%: writer failed, no %JOB%.bin, see %JOB%.log
	set FAIL=1
	goto :eof
)
for %%f in (%JOB%.bin) do set SIZE=%%~zf
for /f "tokens=3,*" %%a in ('findstr /b /c:"Fit and coder:" %JOB%.log') do set "FIT=%%b"
for /f "tokens=2,*" %%a in ('findstr /b /c:"Native methods:" %JOB%.log') do set "FIT=%%b"
java %NA% %OPT% -Djava.awt.headless=true -cp classes test.Decode %JOB%.bin > %JOB%.decode.log 2>&1
for /f "usebackq tokens=1,2,3" %%a in ("%JOB%.decode.log") do if "%%a"=="%JOB%.bin" (
	set GOT=%%b
	set MS=%%c
)
if "%GOT%"=="none" (
	call :say %JOB%: decoding failed, see %JOB%.decode.log
	set STATUS=FAILED: not decoded
	set FAIL=1
)
if not "%OPT%"=="-Dnative=false" goto known
if not "%FIT:~0,4%"=="Java" (
	set STATUS=FAILED: -Dnative=false did not give the Java
	set FAIL=1
)
:known
if "%KNOWN%"=="0" goto report
if not "%SIZE%"=="%EXPECT%" (
	set STATUS=FAILED: expected %EXPECT% bytes
	set FAIL=1
)
if not "%GOT%"=="%EXPECT_MD5%" (
	set STATUS=FAILED: decoded MD5 differs
	set FAIL=1
)
:report
call :say %JOB%  %BANDS% band(s)  %SIZE% bytes  %GOT%  %STATUS%  [decoded in %MS% ms; native: %FIT%]
goto :eof

rem :say text -- prints the text and adds it to the log
:say
echo %*
echo %* >> %LOG%
goto :eof
