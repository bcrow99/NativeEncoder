#!/bin/bash
# Regression test for the native pairs: NativeWriter / NativeReader and
# NativePacketWriter / NativePacketReader (Linux: needs xvfb-run).
#
#   java/run_tests.sh <image> [out_dir]
#
# Compiles everything, then writes the image (test.Drive, Save's defaults:
# Pixel Resolution 4, Color Resolution 3) and decodes it (test.Decode, which
# picks the reader by the file's format) in eleven jobs: NativeWriter with the
# mixed context coding in 1, 4 and 8 bands (n1, n4, n8), in 1 band with the Java's
# fit and coder (j1, -Dnative=false) and in 4 bands with the average deltas
# (v4: delta_type=1, Simple 2 format 3), NativeWriter with the Huffman coding
# (entropy_type=1) in 1, 4 and 8 bands (h1, h4, h8) and in 4 bands with the average
# deltas (a4: Huffman format 2), and
# NativePacketWriter with its defaults (p: average deltas, LZ77) and with the
# block map (q: delta_type=13). All but j1 use the C if native/ has the
# library DeltaMapper (see the Makefile). The size and the decoded image's
# MD5 are checked for the images it knows, bluejay.jpg and scrubjay.jpg
# (bcrow99/TestImages); for others it only prints them.
# Native methods must keep these the same: the files are byte for byte
# SimpleWriter2's, HuffmanWriter's and PacketWriter's (DeltaEncoder), all but
# v4's and a4's (formats Simple 3 and Huffman 2, which only the native readers
# read).
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
IMAGE="$1"; OUT="${2:-out}"
[ -n "$IMAGE" ] || { echo "usage: java/run_tests.sh <image> [out_dir]"; exit 1; }
[ -f "$IMAGE" ] || { echo "No image $IMAGE"; exit 1; }
# What the tests need, checked first, so a missing piece is named rather than
# showing up as every job failing.
command -v javac >/dev/null || { echo "No javac: install a JDK (e.g. sudo apt install openjdk-21-jdk)"; exit 1; }
command -v xvfb-run >/dev/null || { echo "No xvfb-run: install it (e.g. sudo apt install xvfb)"; exit 1; }
# The writers open a window (under xvfb-run), which a Java from a "headless"
# package (openjdk-NN-jdk-headless, all an upgrade may install) can't do.
JAVA_HOME_USED=$(java -XshowSettings:properties -version 2>&1 | sed -n 's/^ *java\.home = //p')
[ -e "$JAVA_HOME_USED/lib/libawt_xawt.so" ] || [ -e "$JAVA_HOME_USED/jre/lib/amd64/libawt_xawt.so" ] || {
	echo "The Java at $JAVA_HOME_USED can't open windows (a headless package?): the writers need it."
	echo "Install the full JDK (e.g. sudo apt install openjdk-21-jdk), or pick another with sudo update-alternatives --config java"
	exit 1; }
# Java 17 and later warn when a library is loaded unless native access is
# enabled; Java 8 doesn't know the option, so it's only given if accepted.
NA=; java --enable-native-access=ALL-UNNAMED -version >/dev/null 2>&1 && NA=--enable-native-access=ALL-UNNAMED
IMAGE="$(cd "$(dirname "$IMAGE")" && pwd)/$(basename "$IMAGE")"
mkdir -p "$OUT/classes"; OUT="$(cd "$OUT" && pwd)"
# Everything printed also goes to run_tests.log in the output folder.
exec > >(tee "$OUT/run_tests.log") 2>&1
echo "Java: $(java -version 2>&1 | grep -i version | head -1)"
javac --release 8 -nowarn -Xlint:-options -encoding UTF-8 -Xlint:-unchecked -d "$OUT/classes" "$HERE"/src/*.java "$HERE"/src/test/*.java
cd "$OUT"
known=1
case "$(basename "$IMAGE")" in
	# PacketWriter resizes differently, so its jobs decode to another image.
	# bluejay's 295 rows allow 4 bands at most (NativeWriter.BAND_MIN_ROWS):
	# its 8-band jobs write the 4-band files.
	bluejay.jpg)  declare -A SIZE=([n1]=61174 [n4]=62689 [n8]=62689 [v4]=67743 [h1]=69095 [h4]=70893 [h8]=70893 [a4]=76031 [p]=76209 [q]=68830)
	              declare -A MD5=([n]=7c41049db7c073c7026278bcf58b15a5 [p]=08c60a8982b8932b8032652086773cb1) ;;
	scrubjay.jpg) declare -A SIZE=([n1]=4075255 [n4]=4080169 [n8]=4086689 [v4]=4356507 [h1]=4453703 [h4]=4454159 [h8]=4453700 [a4]=4765744 [p]=4855085 [q]=4465954)
	              declare -A MD5=([n]=0eec6e139a759db5d26da1d2ed031d94 [p]=f49ae237a0e3ea40abc7beb3e353296c) ;;
	*) known=0 ;;
esac
fail=0
for job in n1 n4 n8 j1 v4 h1 h4 h8 a4 p q; do
	bands=${job#?}
	opt=; [ $job = j1 ] && opt=-Dnative=false
	writer=NativeWriter; key=n$bands; image=n; set_field=bands=$bands
	case $job in
		v4) key=v4; set_field="bands=4 delta_type=1" ;;
		h*) key=h$bands; set_field="bands=$bands entropy_type=1" ;;
		a4) key=a4; set_field="bands=4 delta_type=1 entropy_type=1" ;;
		p)  writer=NativePacketWriter; key=p; image=p; bands=1; set_field= ;;
		q)  writer=NativePacketWriter; key=q; image=p; bands=1; set_field=delta_type=13 ;;
	esac
	rm -f "$job.bin"
	xvfb-run -a java $NA $opt -cp classes test.Drive $writer "$IMAGE" "$job.bin" 2 $set_field > "$job.log" 2>&1 || {
		# The log's last "Caused by" or error line, which usually says why.
		why=$(grep -E '^(Caused by: |Exception|Error|.*command not found)' "$job.log" | tail -1)
		echo "$job: writer failed (see $job.log): $why"; fail=1; continue; }
	size=$(stat -c %s "$job.bin")
	# Decode's line for the file: name, MD5, time. (If it has none, the
	# decode failed: "|| true" keeps set -e from ending the script there,
	# silently, and the job is reported as failed instead.)
	md5=; ms=
	read -r _ md5 ms < <(java $NA $opt -Djava.awt.headless=true -cp classes test.Decode "$job.bin" 2> "$job.decode.log" | grep "^$job.bin ") || true
	status=ok
	[ -n "$md5" ] || { md5=-; ms=-; status="FAILED: no decoded image (see $job.decode.log)"; fail=1; }
	# What the writer used: its "Fit and coder:" (Simple and Huffman) or
	# "Native methods:" (Packet) line.
	fit=$(sed -n 's/^\(Fit and coder\|Native methods\): *//p' "$job.log" | tr -d '\r')
	if [ $job = j1 ] && [ "${fit#Java}" = "$fit" ]; then status="FAILED: -Dnative=false did not give the Java"; fail=1; fi
	if [ $known = 1 ]; then
		[ "$size" = "${SIZE[$key]}" ] || { status="FAILED: expected ${SIZE[$key]} bytes"; fail=1; }
		[ "$md5" = - ] || [ "$md5" = "${MD5[$image]}" ] || { status="FAILED: decoded MD5 $md5, expected ${MD5[$image]}"; fail=1; }
	fi
	printf '%-3s %2s band(s) %8d bytes  %s  %s  (decoded in %s ms; native: %s)\n' "$job" "$bands" "$size" "$md5" "$status" "$ms" "$fit"
done
exit $fail
