#!/bin/bash
# Regression test for NativeWriter / NativeReader and NativeWriter2 /
# NativeReader2 (Linux: needs xvfb-run).
#
#   java/run_tests.sh <image> [out_dir]
#
# Compiles everything, then writes the image (test.Drive, Save's defaults:
# Pixel Resolution 4, Color Resolution 3) and decodes it (test.Decode, which
# picks the reader by the file's format) in five jobs: NativeWriter in 1 and 4
# bands (n1, n4) and in 1 band with the Java's fit and coder (j1,
# -Dnative=false), and NativeWriter2 in 1 and 4 bands (h1, h4). All but j1
# use the C if native/ has the library DeltaMapper (see the Makefile). The
# size and the decoded image's MD5 are checked for the images it knows,
# bluejay.jpg and scrubjay.jpg (bcrow99/TestImages); for others it only
# prints them.
# Native methods must keep these the same: the files are byte for byte
# SimpleWriter2's (DeltaEncoder).
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
IMAGE="$1"; OUT="${2:-out}"
[ -n "$IMAGE" ] || { echo "usage: java/run_tests.sh <image> [out_dir]"; exit 1; }
[ -f "$IMAGE" ] || { echo "No image $IMAGE"; exit 1; }
# Java 17 and later warn when a library is loaded unless native access is
# enabled; Java 8 doesn't know the option, so it's only given if accepted.
NA=; java --enable-native-access=ALL-UNNAMED -version >/dev/null 2>&1 && NA=--enable-native-access=ALL-UNNAMED
IMAGE="$(cd "$(dirname "$IMAGE")" && pwd)/$(basename "$IMAGE")"
mkdir -p "$OUT/classes"; OUT="$(cd "$OUT" && pwd)"
javac --release 8 -nowarn -Xlint:-options -encoding UTF-8 -Xlint:-unchecked -d "$OUT/classes" "$HERE"/src/*.java "$HERE"/src/test/*.java
cd "$OUT"
known=1
case "$(basename "$IMAGE")" in
	bluejay.jpg)  declare -A SIZE=([n1]=61174 [n4]=62689 [h1]=69095 [h4]=70893);         MD5=7c41049db7c073c7026278bcf58b15a5 ;;
	scrubjay.jpg) declare -A SIZE=([n1]=4075255 [n4]=4080169 [h1]=4453703 [h4]=4454159); MD5=0eec6e139a759db5d26da1d2ed031d94 ;;
	*) known=0 ;;
esac
fail=0
for job in n1 n4 j1 h1 h4; do
	bands=${job#?}
	opt=; [ $job = j1 ] && opt=-Dnative=false
	writer=NativeWriter; key=n$bands
	case $job in h*) writer=NativeWriter2; key=h$bands ;; esac
	rm -f "$job.bin"
	xvfb-run -a java $NA $opt -cp classes test.Drive $writer "$IMAGE" "$job.bin" 2 bands=$bands > "$job.log" 2>&1 || { echo "$job: writer failed (see $job.log)"; fail=1; continue; }
	size=$(stat -c %s "$job.bin")
	read -r _ md5 ms < <(java $NA $opt -Djava.awt.headless=true -cp classes test.Decode "$job.bin" 2>/dev/null | grep "^$job.bin ")
	status=ok
	fit=$(sed -n 's/^Fit and coder: *//p' "$job.log" | tr -d '\r')
	if [ $job = j1 ] && [ "${fit#Java}" = "$fit" ]; then status="FAILED: -Dnative=false did not give the Java"; fail=1; fi
	if [ $known = 1 ]; then
		[ "$size" = "${SIZE[$key]}" ] || { status="FAILED: expected ${SIZE[$key]} bytes"; fail=1; }
		[ "$md5" = "$MD5" ] || { status="FAILED: decoded MD5 $md5, expected $MD5"; fail=1; }
	fi
	printf '%-3s %2s band(s) %8d bytes  %s  %s  (decoded in %s ms; fit and coder: %s)\n' "$job" "$bands" "$size" "$md5" "$status" "$ms" "$fit"
done
exit $fail
