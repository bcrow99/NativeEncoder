import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * How NativeWriter and NativeReader's speed grows with the number of bands
 * (so with the cores they can use), for one big frame: each coding (A
 * context aware, T Context tables, H Huffman, N Huffman tables, each with
 * the LS and the average deltas) in 1, 2, 4, 8, 16, 32 and 64 bands, and in the most the frame allows (bands of at
 * least NativeWriter.BAND_MIN_ROWS rows, at most NativeWriter.MAX_BANDS),
 * best of a few runs after one to warm up:
 * <ul>
 * <li>encode: what Save runs, without its decode check (the Decode Check
 *     item off: the coding alone);</li>
 * <li>decode: the reader's decoding of the file, from reading it to the
 *     finished image;</li>
 * <li>the file's size, and its bits a pixel.</li>
 * </ul>
 * To make a frame big enough for many bands, the image can be tiled: tile
 * 2 makes it 2 x 2 copies, every other one mirrored so the joins are smooth
 * (the copies look like the image to the coders: no new detail, but no
 * flat areas either). Pixel Resolution and Color Resolution are Save's
 * defaults (4 and 3) unless given: scrubjay.jpg (3518 x 2697) tiled 2 x 2
 * is coded 5630 x 4316, enough for 64 bands. Run it under taskset (Linux) or start /affinity
 * (Windows) to limit the cores it uses: it reports the processors Java sees
 * (the writer and reader make their threads for those). bands, a list such
 * as 1,4, times only those (for a run on one processor, which is slow);
 * codings, a list such as A,T, only those codings (all four if not given).
 *
 * <pre>
 * java ScaleBench image [tile quant shift runs bands codings]   (default 2 4 3 2, all bands, A,T,H,N)
 * </pre>
 *
 * Uses the C wherever the programs would (the library in native, if built).
 * The files are written to the system's temporary folder and deleted.
 */
public class ScaleBench
{
	/** Not made: main only. */
	private ScaleBench() { }

	/** The band counts tried (and the most the frame allows). */
	static final int[] BANDS = {1, 2, 4, 8, 16, 32, 64};

	/**
	 * Runs the benchmark.
	 *
	 * @param args the image, then optionally the tiling, Pixel Resolution,
	 *             Color Resolution, the number of timed runs and the band
	 *             counts (e.g. 1,4; all of BANDS that fit if not given)
	 * @throws Exception if the image can't be read or a step fails
	 */
	public static void main(String[] args) throws Exception
	{
		if(args.length < 1) { System.out.println("Usage: java ScaleBench image [tile quant shift runs bands codings]"); return; }
		int tile  = (args.length > 1) ? Integer.parseInt(args[1]) : 2;
		int quant = (args.length > 2) ? Integer.parseInt(args[2]) : 4;
		int shift = (args.length > 3) ? Integer.parseInt(args[3]) : 3;
		int runs  = (args.length > 4) ? Integer.parseInt(args[4]) : 2;
		String only = (args.length > 5 && !args[5].equals("all")) ? args[5] : null;
		String codings = (args.length > 6) ? args[6].toUpperCase() : "A,T,H,N";

		// The frame: the image, tiled.
		BufferedImage image = ViewerSupport.readImage(args[0]);
		int iw = image.getWidth(), ih = image.getHeight();
		int[] source = image.getRGB(0, 0, iw, ih, null, 0, iw);
		image = null;
		int xdim = iw * tile, ydim = ih * tile;
		int[] pixel = new int[xdim * ydim];
		for(int y = 0; y < ydim; y++)
		{
			int ty = y / ih, sy = y % ih;
			if(ty % 2 == 1) sy = ih - 1 - sy;   // every other row of copies mirrored top to bottom
			for(int x = 0; x < xdim; x++)
			{
				int tx = x / iw, sx = x % iw;
				if(tx % 2 == 1) sx = iw - 1 - sx;   // and every other column left to right
				pixel[y * xdim + x] = source[sy * iw + sx];
			}
		}
		source = null;

		// The channels Save codes (as Apply makes them).
		int[][] bgr = new int[3][pixel.length];
		for(int k = 0; k < pixel.length; k++) { bgr[0][k] = pixel[k] & 0xff; bgr[1][k] = (pixel[k] >> 8) & 0xff; bgr[2][k] = (pixel[k] >> 16) & 0xff; }
		pixel = null;
		int[] size = DeltaMapper.getQuantizedSize(xdim, ydim, quant);
		int w = size[0], h = size[1];
		int[][] q = new int[3][];
		for(int i = 0; i < 3; i++)
		{
			q[i] = DeltaMapper.quantizeChannel((quant != 0) ? ResizeMapper.resize2(bgr[i], xdim, w, h) : bgr[i], shift);
			bgr[i] = null;
		}
		int[] min6 = new int[6];
		int[][] qc = DeltaMapper.getCandidateChannels(q[0], q[1], q[2], min6);
		q = null;
		int[][] value = new int[3][];
		int[] min = new int[3];
		for(int i = 0; i < 3; i++) { value[i] = qc[NativeWriter.CHANNELS[i]]; min[i] = min6[NativeWriter.CHANNELS[i]]; }
		qc = null;

		int most = Math.max(1, Math.min(NativeWriter.MAX_BANDS, h / NativeWriter.BAND_MIN_ROWS));
		java.util.List<Integer> counts = new java.util.ArrayList<>();
		if(only != null)
			for(String b : only.split(",")) counts.add(Math.max(1, Math.min(most, Integer.parseInt(b.trim()))));
		else
		{
			for(int b : BANDS) if(b < most) counts.add(b);
			counts.add(most);
		}
		double raw = 3.0 * xdim * ydim;

		System.out.println(String.format("Scale benchmark (Java %s, %d processors seen, the C: %s)",
			System.getProperty("java.version"), Runtime.getRuntime().availableProcessors(), DeltaMapper.NATIVE_STATUS));
		System.out.println(String.format("%s tiled %d x %d: %d x %d (%,d bytes raw), Pixel Resolution %d, Color Resolution %d: %d x %d coded,",
			new File(args[0]).getName(), tile, tile, xdim, ydim, (long) raw, quant, shift, w, h));
		System.out.println(String.format("at most %d bands; best of %d runs", most, runs));
		System.out.println();
		System.out.println("coding          bands     encode     decode   enc+dec  speedup        bytes  bits/pixel");
		// Each coding asked for (A, T, H, N), with the LS and then the average deltas.
		String letters = "ATHN";
		int[] coding_type = {NativeWriter.ENTROPY_MIXED, NativeWriter.ENTROPY_TABLES, NativeWriter.ENTROPY_HUFFMAN, NativeWriter.ENTROPY_NEIGHBOUR};
		java.util.List<String> name = new java.util.ArrayList<>();
		java.util.List<Integer> delta = new java.util.ArrayList<>(), entropy = new java.util.ArrayList<>();
		for(String l : codings.split(","))
		{
			int at = letters.indexOf(l.trim());
			if(l.trim().length() != 1 || at < 0) { System.out.println("Unknown coding " + l + ": use A, T, H or N"); return; }
			name.add("LS-" + l.trim());  delta.add(NativeWriter.DELTA_LS);      entropy.add(coding_type[at]);
			name.add("Avg-" + l.trim()); delta.add(NativeWriter.DELTA_AVERAGE); entropy.add(coding_type[at]);
		}
		for(int c = 0; c < name.size(); c++)
		{
			double one = 0;
			for(int bands : counts)
			{
				double[] t = time(delta.get(c), entropy.get(c), bands, value, min, w, xdim, ydim, shift, quant, runs);
				double both = t[0] + t[1];
				if(one == 0) one = both;   // speedup: against the first band count timed (1, unless a list says)
				System.out.println(String.format("%-14s %6d %8.0f ms %7.0f ms %6.0f ms %7.2f %12.0f %10.3f",
					name.get(c), bands, t[0], t[1], both, one / both, t[2], 8 * t[2] / ((double) xdim * ydim)));
			}
			System.out.println();
		}
	}

	/**
	 * Times one coding in a number of bands: the writer's encode (without
	 * its decode check) and the reader's decoding of the file.
	 *
	 * @param delta_type   the deltas
	 * @param entropy_type the coding
	 * @param bands        the number of bands
	 * @param value        the channels
	 * @param min          their minimums
	 * @param w            the coded width
	 * @param xdim         the frame's width
	 * @param ydim         the frame's height
	 * @param shift        Color Resolution
	 * @param quant        Pixel Resolution
	 * @param runs         the timed runs
	 * @return {encode ms, decode ms, file bytes}
	 * @throws Exception if a step fails
	 */
	private static double[] time(int delta_type, int entropy_type, int bands, int[][] value, int[] min, int w, int xdim, int ydim,
	                             int shift, int quant, int runs) throws Exception
	{
		double encode = Double.MAX_VALUE, decode = Double.MAX_VALUE;
		byte[] file = null;
		for(int run = 0; run < runs + 1; run++)
		{
			ByteArrayOutputStream bytes = new ByteArrayOutputStream();
			long t0 = System.nanoTime();
			NativeWriter.encode(new DataOutputStream(bytes), value, min, w, xdim, ydim, shift, quant, bands, delta_type, entropy_type, false);
			long t1 = System.nanoTime();
			file = bytes.toByteArray();
			if(run >= 1) encode = Math.min(encode, (t1 - t0) / 1e6);
		}
		File temp = File.createTempFile("ScaleBench", ".bin");
		temp.deleteOnExit();
		try(FileOutputStream out = new FileOutputStream(temp)) { out.write(file); }
		// The reader is made without its window (as test.Decode does) and its
		// decoding called directly.
		Class<?> c = Class.forName("NativeReader");
		Field uf = Class.forName("sun.misc.Unsafe").getDeclaredField("theUnsafe");
		uf.setAccessible(true);
		Object unsafe = uf.get(null);
		Object reader = unsafe.getClass().getMethod("allocateInstance", Class.class).invoke(unsafe, c);
		Field mf = c.getDeclaredField("min");
		mf.setAccessible(true);
		mf.set(reader, new int[3]);
		Method header = c.getDeclaredMethod("readHeader", DataInputStream.class, String.class);
		Method decodeFile = c.getDeclaredMethod("decodeFile", String.class);
		header.setAccessible(true);
		decodeFile.setAccessible(true);
		try(DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(temp)))) { header.invoke(reader, in, temp.getPath()); }
		for(int run = 0; run < runs + 1; run++)
		{
			long t0 = System.nanoTime();
			decodeFile.invoke(reader, temp.getPath());
			long t1 = System.nanoTime();
			if(run >= 1) decode = Math.min(decode, (t1 - t0) / 1e6);
		}
		temp.delete();
		return new double[] {encode, decode, file.length};
	}
}
