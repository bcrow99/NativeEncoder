import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Arrays;

/**
 * Times NativeSimpleWriter / NativeSimpleReader against NativeHuffmanWriter / NativeHuffmanReader on
 * one image, as Save codes it (Pixel Resolution and Color Resolution as
 * given, Save's defaults 4 and 3), best of a few runs after two to warm up:
 * <ul>
 * <li>for 1 and 4 bands, each pair's encode (what Save runs: the coding and
 *     its decode check), the check alone, and the reader's decoding of the
 *     file (what the reader runs once the file is open);</li>
 * <li>for 1 band, the decoding's parts: NativeSimpleReader's decoder with its fit
 *     (all three channels at once, as the reader runs them), NativeHuffmanReader's
 *     Huffman decoding of the three channels, its fit rebuild from the
 *     deltas, and (with the library) the two at once, as the reader runs
 *     them; each with one helper thread per channel's fit, and with as many
 *     as the readers give it on this machine (DeltaMapper.fitHelpers);</li>
 * <li>NativeHuffmanReader's decoding of a 4-band file, a step at a time, with 0
 *     and 1 helper threads per channel's fit.</li>
 * </ul>
 * Uses the C wherever the programs would (the library in native, if built).
 * The files are written to the system's temporary folder and deleted.
 */
public class PairBench
{
	/** Not made: main only. */
	private PairBench() { }

	/**
	 * Runs the benchmark.
	 *
	 * @param args the image, then optionally Pixel Resolution, Color
	 *             Resolution and the number of timed runs (default 4 3 5)
	 * @throws Exception if the image can't be read or a step fails
	 */
	public static void main(String[] args) throws Exception
	{
		if(args.length < 1) { System.out.println("Usage: java PairBench image [quant shift runs]"); return; }
		int quant = (args.length > 1) ? Integer.parseInt(args[1]) : 4;
		int shift = (args.length > 2) ? Integer.parseInt(args[2]) : 3;
		int runs  = (args.length > 3) ? Integer.parseInt(args[3]) : 5;

		// The channels Save codes (as Apply makes them).
		BufferedImage image = ViewerSupport.readImage(args[0]);
		int xdim = image.getWidth(), ydim = image.getHeight();
		int[] pixel = image.getRGB(0, 0, xdim, ydim, null, 0, xdim);
		int[][] bgr = new int[3][pixel.length];
		for(int k = 0; k < pixel.length; k++) { bgr[0][k] = pixel[k] & 0xff; bgr[1][k] = (pixel[k] >> 8) & 0xff; bgr[2][k] = (pixel[k] >> 16) & 0xff; }
		int[] size = DeltaMapper.getQuantizedSize(xdim, ydim, quant);
		int w = size[0], h = size[1];
		int[][] q = new int[3][];
		for(int i = 0; i < 3; i++)
			q[i] = DeltaMapper.quantizeChannel((quant != 0) ? ResizeMapper.resize2(bgr[i], xdim, w, h) : bgr[i], shift);
		int[] min6 = new int[6];
		int[][] qc = DeltaMapper.getCandidateChannels(q[0], q[1], q[2], min6);
		int[][] value = new int[3][];
		int[] min = new int[3];
		for(int i = 0; i < 3; i++) { value[i] = qc[NativeSimpleWriter.CHANNELS[i]]; min[i] = min6[NativeSimpleWriter.CHANNELS[i]]; }

		System.out.println(String.format("Pair benchmark (Java %s, %d cores): %s, Pixel Resolution %d, Color Resolution %d: %d x %d coded, best of %d runs",
			System.getProperty("java.version"), Runtime.getRuntime().availableProcessors(), new File(args[0]).getName(), quant, shift, w, h, runs));
		System.out.println("The C: " + DeltaMapper.NATIVE_STATUS);
		System.out.println();
		System.out.println("                          encode      check     decode       file");
		for(int bands : new int[] {1, 4})
			for(int pair = 1; pair <= 2; pair++)
			{
				double[] t = timePair(pair, bands, value, min, w, xdim, ydim, shift, quant, runs);
				System.out.println(String.format("%-14s %d band%s %8.0f ms %7.0f ms %7.0f ms %10.0f bytes",
					(pair == 1) ? "NativeSimpleWriter" : "NativeHuffmanWriter", bands, (bands == 1) ? " " : "s", t[0], t[1], t[2], t[3]));
			}

		// The decoding's parts, 1 band.
		int[][] delta = new int[3][];
		int[] init = new int[3], radius = {NativeSimpleWriter.RADIUS, NativeSimpleWriter.RADIUS, NativeSimpleWriter.RADIUS};
		for(int i = 0; i < 3; i++)
		{
			delta[i] = DeltaMapper.getRowFitDeltas(value[i], (i > 0) ? value[i - 1] : null, w, h, NativeSimpleWriter.RADIUS, NativeSimpleWriter.EVERY);
			init[i] = value[i][0];
		}
		byte[][] coded = new byte[3][], huffman = new byte[3][];
		int[][] rank_value = new int[3][];
		for(int i = 0; i < 3; i++)
		{
			byte[] packed = DeltaMapper.packMixedDeltas(delta[i], value[i], Arrays.copyOf(delta, i), w, true);
			DeltaMapper.MixedDeltas md = DeltaMapper.readMixedDeltas(new DataInputStream(new ByteArrayInputStream(packed)));
			coded[i] = md.coded;
			rank_value[i] = md.value;
			huffman[i] = NativeHuffmanWriter.huffmanCode(delta[i]);
		}
		NativeHuffmanWriter.HuffmanChannel[] hc = new NativeHuffmanWriter.HuffmanChannel[3];
		for(int i = 0; i < 3; i++) hc[i] = NativeHuffmanWriter.huffmanRead(new DataInputStream(new ByteArrayInputStream(huffman[i])));
		// Each part with one helper thread per channel's fit, and with as
		// many as the readers give it here (DeltaMapper.fitHelpers).
		int many = DeltaMapper.fitHelpers(1);
		int[] counts = (many > 1) ? new int[] {0, 1, many} : new int[] {0, 1};
		double[] decoder = new double[3], rebuild = new double[3], both = new double[3];
		Arrays.fill(decoder, Double.MAX_VALUE); Arrays.fill(rebuild, Double.MAX_VALUE); Arrays.fill(both, Double.MAX_VALUE);
		double huff = Double.MAX_VALUE;
		boolean same = true;
		for(int run = 0; run < runs + 2; run++)
		{
			long t0 = System.nanoTime();
			int[][] d = new int[3][];
			ViewerSupport.parallel(3, i ->
			{
				try { d[i] = NativeHuffmanWriter.huffmanDecode(new DataInputStream(new ByteArrayInputStream(huffman[i])), w * h); }
				catch(java.io.IOException e) { throw new java.io.UncheckedIOException(e); }
			});
			long t1 = System.nanoTime();
			if(run >= 2) huff = Math.min(huff, (t1 - t0) / 1e6);
			for(int c = 0; c < counts.length; c++)
			{
				int helpers = counts[c];
				long s0 = System.nanoTime();
				if(DeltaMapper.NATIVE)
				{
					int[][] cd = new int[3][w * h], cv = new int[3][w * h];
					same &= DeltaMapper.decodeRowFitChannelsNative(coded, rank_value, w, h, init, radius, NativeSimpleWriter.EVERY, helpers, cd, cv) == 0;
				}
				else
				{
					@SuppressWarnings({"unchecked", "rawtypes"})
					java.util.concurrent.Future<DeltaMapper.MixedDeltas>[] f = new java.util.concurrent.Future[3];
					for(int i = 0; i < 3; i++)
						f[i] = java.util.concurrent.CompletableFuture.completedFuture(new DeltaMapper.MixedDeltas(rank_value[i], coded[i]));
					DeltaMapper.getValuesFromRowFitChannelsJava(f, w, h, init, radius, NativeSimpleWriter.EVERY);
				}
				long s1 = System.nanoTime();
				int[][] v = DeltaMapper.getValuesFromRowFitDeltas(d, w, h, init, radius, NativeSimpleWriter.EVERY, helpers);
				long s2 = System.nanoTime();
				for(int i = 0; i < 3; i++) same &= Arrays.equals(v[i], value[i]);
				long s3 = System.nanoTime();
				int[][] vb = NativeHuffmanWriter.rebuildHuffmanChannels(hc, w, h, init, radius, helpers);
				long s4 = System.nanoTime();
				if(vb != null) for(int i = 0; i < 3; i++) same &= Arrays.equals(vb[i], value[i]);
				if(run >= 2)
				{
					decoder[c] = Math.min(decoder[c], (s1 - s0) / 1e6);
					rebuild[c] = Math.min(rebuild[c], (s2 - s1) / 1e6);
					if(vb != null) both[c] = Math.min(both[c], (s4 - s3) / 1e6);
				}
			}
		}
		System.out.println();
		System.out.println("The decoding's parts, 1 band (all three channels), with each channel's fit on");
		System.out.println("0 helper threads (its own thread solves it), 1" + ((counts.length > 2) ? ", and " + many : "")
			+ " (NativeHuffmanReader runs it on " + many + " here, NativeSimpleReader on 1):");
		System.out.println("  NativeSimpleReader:  decoder and fit together   " + times(decoder, counts.length));
		System.out.println(String.format("  NativeHuffmanReader: Huffman decoding           %7.0f ms", huff));
		System.out.println("                 fit rebuild                " + times(rebuild, counts.length));
		if(both[0] != Double.MAX_VALUE)
			System.out.println("                 both at once, as it runs   " + times(both, counts.length));
		if(!same) System.out.println("  (The values DIFFER from the coded ones: something is wrong.)");

		fourBandParts(value, min, w, h, xdim, ydim, shift, quant, runs);
	}

	/**
	 * NativeHuffmanReader's decoding of a 4-band file, a step at a time, as its
	 * decode runs them: reading the file (the channels' Huffman coding, its
	 * code lengths inflated), one band decoded and rebuilt alone, the four
	 * one after another, the four at once (as the reader runs them), and
	 * the last steps (the C's getPixels, then the image's raster filled).
	 *
	 * @param value the channels
	 * @param min   their minimums
	 * @param w     the coded width
	 * @param h     the coded height
	 * @param xdim  the image's width
	 * @param ydim  the image's height
	 * @param shift Color Resolution
	 * @param quant Pixel Resolution
	 * @param runs  the timed runs
	 * @throws Exception if a step fails
	 */
	private static void fourBandParts(int[][] value, int[] min, int w, int h, int xdim, int ydim, int shift, int quant, int runs) throws Exception
	{
		if(!DeltaMapper.NATIVE) return;
		int bands = 4;
		ByteArrayOutputStream bytes = new ByteArrayOutputStream();
		NativeHuffmanWriter.encode(new DataOutputStream(bytes), value, min, w, xdim, ydim, shift, quant, bands);
		byte[] file = bytes.toByteArray();
		int[] radius = {NativeHuffmanWriter.RADIUS, NativeHuffmanWriter.RADIUS, NativeHuffmanWriter.RADIUS};
		int helpers = DeltaMapper.fitHelpers(bands);
		double read = Double.MAX_VALUE, serial = Double.MAX_VALUE, last = Double.MAX_VALUE;
		double[] one = {Double.MAX_VALUE, Double.MAX_VALUE}, parallel = {Double.MAX_VALUE, Double.MAX_VALUE};
		boolean same = true;
		for(int run = 0; run < runs + 2; run++)
		{
			// The file, as readHeader and decode read it.
			long t0 = System.nanoTime();
			DataInputStream in = new DataInputStream(new ByteArrayInputStream(file));
			in.readUnsignedByte(); in.readUnsignedByte(); in.readUnsignedShort(); in.readUnsignedShort(); in.readByte(); in.readByte();
			for(int i = 0; i < 3; i++) in.readInt();
			int nb = in.readUnsignedByte();
			int[] length = new int[nb];
			for(int b = 0; b < nb; b++) length[b] = in.readInt();
			int[][] init = new int[nb][3];
			NativeHuffmanWriter.HuffmanChannel[][] coded = new NativeHuffmanWriter.HuffmanChannel[nb][3];
			for(int b = 0; b < nb; b++)
			{
				byte[] band = new byte[length[b]];
				in.readFully(band);
				DataInputStream bi = new DataInputStream(new ByteArrayInputStream(band));
				for(int i = 0; i < 3; i++) { init[b][i] = bi.readInt(); coded[b][i] = NativeHuffmanWriter.huffmanRead(bi); }
			}
			long t1 = System.nanoTime();
			int b0 = NativeHuffmanWriter.bandStart(1, nb, h);
			double[] alone = new double[2], together = new double[2];
			int[][] channel = new int[3][w * h];
			for(int k = 0; k < 2; k++)
			{
				int hk = k;   // 0 or 1 helper
				long s0 = System.nanoTime();
				NativeHuffmanWriter.rebuildHuffmanChannels(coded[0], w, b0, init[0], radius, hk);
				long s1 = System.nanoTime();
				ViewerSupport.parallel(nb, b ->
				{
					int y0 = NativeHuffmanWriter.bandStart(b, nb, h), y1 = NativeHuffmanWriter.bandStart(b + 1, nb, h);
					int[][] v = NativeHuffmanWriter.rebuildHuffmanChannels(coded[b], w, y1 - y0, init[b], radius, hk);
					for(int i = 0; i < 3; i++) System.arraycopy(v[i], 0, channel[i], y0 * w, v[i].length);
				});
				long s2 = System.nanoTime();
				alone[k] = (s1 - s0) / 1e6;
				together[k] = (s2 - s1) / 1e6;
			}
			long t2 = System.nanoTime();
			for(int b = 0; b < nb; b++)
			{
				int y0 = NativeHuffmanWriter.bandStart(b, nb, h), y1 = NativeHuffmanWriter.bandStart(b + 1, nb, h);
				NativeHuffmanWriter.rebuildHuffmanChannels(coded[b], w, y1 - y0, init[b], radius, helpers);
			}
			long t3 = System.nanoTime();
			long t4 = t3;
			for(int i = 0; i < 3; i++) same &= Arrays.equals(channel[i], value[i]);
			int[] add = new int[3];
			for(int i = 0; i < 3; i++) if(NativeHuffmanWriter.CHANNELS[i] > 2) add[i] = min[i];
			int[][] col = (quant != 0) ? ResizeMapper.centredMap(w, xdim) : new int[2][];
			int[][] row = (quant != 0) ? ResizeMapper.centredMap(h, ydim) : new int[2][];
			int[] p = new int[xdim * ydim];
			BufferedImage image = new BufferedImage(xdim, ydim, BufferedImage.TYPE_INT_RGB);
			same &= DeltaMapper.getPixelsNative(NativeHuffmanWriter.SET_ID, channel, add, w, h, col[0], col[1], row[0], row[1], DeltaMapper.RESIZE2,
			                                    xdim, ydim, shift, p, Runtime.getRuntime().availableProcessors()) == 0;
			image.getRaster().setDataElements(0, 0, xdim, ydim, p);
			long t5 = System.nanoTime();
			if(run >= 2)
			{
				read     = Math.min(read, (t1 - t0) / 1e6);
				serial   = Math.min(serial, (t3 - t2) / 1e6);
				last     = Math.min(last, (t5 - t4) / 1e6);
				for(int k = 0; k < 2; k++) { one[k] = Math.min(one[k], alone[k]); parallel[k] = Math.min(parallel[k], together[k]); }
			}
		}
		System.out.println();
		System.out.println("NativeHuffmanReader's decoding of the 4-band file, a step at a time, with each channel's fit");
		System.out.println("on 0 helper threads and on 1 (the reader runs it on " + helpers + " here):");
		System.out.println(String.format("  reading the file                        %7.0f ms", read));
		System.out.println("  one band decoded and rebuilt, alone     " + times(one, 2));
		System.out.println("  the four at once, as the reader runs    " + times(parallel, 2));
		System.out.println(String.format("  the four, one after another (%d)         %7.0f ms", helpers, serial));
		System.out.println(String.format("  the last steps (getPixels, the raster)  %7.0f ms", last));
		if(!same) System.out.println("  (The values DIFFER from the coded ones: something is wrong.)");
	}

	/**
	 * Times in milliseconds, side by side.
	 *
	 * @param t the times
	 * @param n how many of them
	 * @return the line's columns
	 */
	private static String times(double[] t, int n)
	{
		StringBuilder b = new StringBuilder();
		for(int i = 0; i < n; i++) b.append(String.format("%7.0f ms", t[i]));
		return b.toString();
	}

	/**
	 * Times one pair in a number of bands: the writer's encode (with its
	 * decode check) and the reader's decoding of the file.
	 *
	 * @param pair   1 for NativeSimpleWriter / NativeSimpleReader, 2 for NativeHuffmanWriter / NativeHuffmanReader
	 * @param bands  the number of bands
	 * @param value  the channels
	 * @param min    their minimums
	 * @param w      the coded width
	 * @param xdim   the image's width
	 * @param ydim   the image's height
	 * @param shift  Color Resolution
	 * @param quant  Pixel Resolution
	 * @param runs   the timed runs
	 * @return {encode ms, check ms, decode ms, file bytes}
	 * @throws Exception if a step fails
	 */
	private static double[] timePair(int pair, int bands, int[][] value, int[] min, int w, int xdim, int ydim, int shift, int quant, int runs) throws Exception
	{
		double encode = Double.MAX_VALUE, check = Double.MAX_VALUE, decode = Double.MAX_VALUE;
		byte[] file = null;
		for(int run = 0; run < runs + 2; run++)
		{
			ByteArrayOutputStream bytes = new ByteArrayOutputStream();
			long t0 = System.nanoTime();
			long c = (pair == 1)
				? NativeSimpleWriter.encode(new DataOutputStream(bytes), value, min, w, xdim, ydim, shift, quant, bands)
				: NativeHuffmanWriter.encode(new DataOutputStream(bytes), value, min, w, xdim, ydim, shift, quant, bands);
			long t1 = System.nanoTime();
			file = bytes.toByteArray();
			if(run >= 2) { encode = Math.min(encode, (t1 - t0) / 1e6); check = Math.min(check, c / 1e6); }
		}
		File temp = File.createTempFile("PairBench", ".bin");
		temp.deleteOnExit();
		try(FileOutputStream out = new FileOutputStream(temp)) { out.write(file); }
		// The reader is made without its window (as test.Decode does) and its
		// decoding called directly.
		Class<?> c = Class.forName((pair == 1) ? "NativeSimpleReader" : "NativeHuffmanReader");
		Field uf = Class.forName("sun.misc.Unsafe").getDeclaredField("theUnsafe");
		uf.setAccessible(true);
		Object unsafe = uf.get(null);
		Object reader = unsafe.getClass().getMethod("allocateInstance", Class.class).invoke(unsafe, c);
		Field mf = c.getDeclaredField("min");
		mf.setAccessible(true);
		mf.set(reader, new int[3]);
		Method header = c.getDeclaredMethod("readHeader", DataInputStream.class, String.class);
		Method decodeFile = c.getDeclaredMethod("decodeFile", String.class);
		header.setAccessible(true);
		decodeFile.setAccessible(true);
		try(DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(temp)))) { header.invoke(reader, in, temp.getPath()); }
		for(int run = 0; run < runs + 2; run++)
		{
			long t0 = System.nanoTime();
			decodeFile.invoke(reader, temp.getPath());
			long t1 = System.nanoTime();
			if(run >= 2) decode = Math.min(decode, (t1 - t0) / 1e6);
		}
		temp.delete();
		return new double[] {encode, check, decode, file.length};
	}
}
