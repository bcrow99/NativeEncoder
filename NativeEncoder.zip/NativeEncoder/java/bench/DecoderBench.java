import java.io.File;

/**
 * The benchmark of the reader's decoding (DeltaMapper.getValuesFromRowFitChannels:
 * the mixed context decoder and the least-squares fit, row by row), the Java
 * against the C through JNI (decodeRowFitChannelsNative).
 * <p>
 * Quantizes an image as NativeSimpleWriter does, makes each channel's deltas and
 * codes them as Save does with one band, then decodes the three channels as
 * NativeSimpleReader does: in Java (getValuesFromRowFitChannelsJava), and, if the
 * library DeltaMapper is found (DeltaMapper.NATIVE), in C, checking the
 * deltas and values are the same as the Java's and the channels'. Each time
 * is the best of the runs after a warm-up; both decode the three channels at
 * the same time, as the reader does each band.
 *
 * <pre>
 * java -cp &lt;classes&gt; DecoderBench image [quant shift runs]
 * </pre>
 * The defaults are Save's (Pixel Resolution 4, Color Resolution 3) and 5 runs.
 */
public class DecoderBench
{
	/** Not instantiated: everything is static. */
	private DecoderBench() { }

	/**
	 * Runs the benchmark.
	 *
	 * @param args the image, then optionally the Pixel Resolution, the Color
	 *             Resolution and the number of runs
	 * @throws Exception if the image can't be read
	 */
	public static void main(String[] args) throws Exception
	{
		if(args.length < 1) { System.out.println("Usage: java DecoderBench image [quant shift runs]"); return; }
		int quant = (args.length > 1) ? Integer.parseInt(args[1]) : 4;
		int shift = (args.length > 2) ? Integer.parseInt(args[2]) : 3;
		int runs  = (args.length > 3) ? Integer.parseInt(args[3]) : 5;

		java.awt.image.BufferedImage image = ViewerSupport.readImage(args[0]);
		int xdim = image.getWidth(), ydim = image.getHeight();
		int[] pixel = image.getRGB(0, 0, xdim, ydim, null, 0, xdim);
		int[][] bgr = new int[3][pixel.length];
		for(int k = 0; k < pixel.length; k++) { bgr[0][k] = pixel[k] & 0xff; bgr[1][k] = (pixel[k] >> 8) & 0xff; bgr[2][k] = (pixel[k] >> 16) & 0xff; }
		int[] size = DeltaMapper.getQuantizedSize(xdim, ydim, quant);
		int w = size[0], h = size[1];
		int[][] q = new int[3][];
		for(int i = 0; i < 3; i++)
		{
			int[] c = (quant != 0) ? ResizeMapper.resize2(bgr[i], xdim, w, h) : bgr[i];
			q[i] = DeltaMapper.quantizeChannel(c, shift);
		}
		int[] min = new int[6];
		int[][] qc = DeltaMapper.getCandidateChannels(q[0], q[1], q[2], min);
		int[][] value = new int[3][], delta = new int[3][];
		for(int i = 0; i < 3; i++)
		{
			value[i] = qc[NativeSimpleWriter.CHANNELS[i]];
			delta[i] = DeltaMapper.getRowFitDeltas(value[i], (i > 0) ? value[i - 1] : null, w, h, NativeSimpleWriter.RADIUS, NativeSimpleWriter.EVERY);
		}
		int[][] previous = new int[0][];
		DeltaMapper.MixedDeltas[] md = new DeltaMapper.MixedDeltas[3];
		int[] init = new int[3], radius = {NativeSimpleWriter.RADIUS, NativeSimpleWriter.RADIUS, NativeSimpleWriter.RADIUS};
		for(int i = 0; i < 3; i++)
		{
			byte[] packed = DeltaMapper.packMixedDeltas(delta[i], value[i], java.util.Arrays.copyOf(delta, i), w, true);
			md[i] = DeltaMapper.readMixedDeltas(new java.io.DataInputStream(new java.io.ByteArrayInputStream(packed)));
			init[i] = value[i][0];
		}
		@SuppressWarnings({"unchecked", "rawtypes"})
		java.util.concurrent.Future<DeltaMapper.MixedDeltas>[] f = new java.util.concurrent.Future[3];
		for(int i = 0; i < 3; i++) f[i] = java.util.concurrent.CompletableFuture.completedFuture(md[i]);
		System.out.println(String.format("Decoder benchmark (Java %s, %d cores): %s, Pixel Resolution %d, Color Resolution %d: %d x %d, best of %d runs",
			System.getProperty("java.version"), Runtime.getRuntime().availableProcessors(), new File(args[0]).getName(), quant, shift, w, h, runs));
		System.out.println("The C through JNI: " + DeltaMapper.NATIVE_STATUS);
		double jt = Double.MAX_VALUE, ct = Double.MAX_VALUE;
		boolean java_right = true, same = true;
		for(int run = 0; run < runs + 2; run++)   // the first two warm up
		{
			long t0 = System.nanoTime();
			int[][][] dv = DeltaMapper.getValuesFromRowFitChannelsJava(f, w, h, init, radius, NativeSimpleWriter.EVERY);
			long t1 = System.nanoTime();
			for(int i = 0; i < 3; i++) java_right &= java.util.Arrays.equals(dv[0][i], delta[i]) && java.util.Arrays.equals(dv[1][i], value[i]);
			if(run >= 2) jt = Math.min(jt, (t1 - t0) / 1e9);
			if(!DeltaMapper.NATIVE) continue;
			byte[][] coded = new byte[3][];
			int[][] rank_value = new int[3][], cd = new int[3][w * h], cv = new int[3][w * h];
			for(int i = 0; i < 3; i++) { coded[i] = md[i].coded; rank_value[i] = md[i].value; }
			long t2 = System.nanoTime();
			int r = DeltaMapper.decodeRowFitChannelsNative(coded, rank_value, w, h, init, radius, NativeSimpleWriter.EVERY, 1, cd, cv);
			long t3 = System.nanoTime();
			same &= r == 0;
			for(int i = 0; i < 3; i++) same &= java.util.Arrays.equals(cd[i], delta[i]) && java.util.Arrays.equals(cv[i], value[i]);
			if(run >= 2) ct = Math.min(ct, (t3 - t2) / 1e9);
		}
		System.out.println(String.format("  Java %10.1f ms%s", jt * 1e3, java_right ? "" : "  (the Java's values are WRONG)"));
		if(DeltaMapper.NATIVE)
		{
			System.out.println(String.format("  C    %10.1f ms", ct * 1e3));
			System.out.println(same ? "The C's deltas and values are the same as the Java's." : "The C's deltas or values DIFFER from the Java's.");
		}
	}
}
