import java.io.File;

/**
 * The benchmark of the mixed context coder (DeltaMapper.packMixedDeltas),
 * the Java against the C through JNI (packMixedDeltasNative).
 * <p>
 * Quantizes an image as NativeWriter does (Pixel Resolution, centred
 * resizing, Color Resolution; the channels green, blue-green, red-green),
 * makes each channel's deltas from the least-squares fit as Save does, then
 * codes each channel as Save does with one band: in Java, and, if the
 * library DeltaMapper is found (DeltaMapper.NATIVE), in C, checking the
 * bytes are the same. Each time is the best of the runs after a warm-up, on
 * one thread (Save codes the channels and bands on as many threads as it has
 * jobs).
 *
 * <pre>
 * java -cp &lt;classes&gt; CoderBench image [quant shift runs]
 * </pre>
 * The defaults are Save's (Pixel Resolution 4, Color Resolution 3) and 5 runs.
 */
public class CoderBench
{
	/** Not instantiated: everything is static. */
	private CoderBench() { }

	/**
	 * Runs the benchmark.
	 *
	 * @param args the image, then optionally the Pixel Resolution, the Color
	 *             Resolution and the number of runs
	 * @throws Exception if the image can't be read
	 */
	public static void main(String[] args) throws Exception
	{
		if(args.length < 1) { System.out.println("Usage: java CoderBench image [quant shift runs]"); return; }
		int quant = (args.length > 1) ? Integer.parseInt(args[1]) : 4;
		int shift = (args.length > 2) ? Integer.parseInt(args[2]) : 3;
		int runs  = (args.length > 3) ? Integer.parseInt(args[3]) : 5;

		java.awt.image.BufferedImage image = ViewerSupport.readImage(args[0]);
		int xdim = image.getWidth(), ydim = image.getHeight();
		int[] pixel = image.getRGB(0, 0, xdim, ydim, null, 0, xdim);
		int[][] bgr = new int[3][pixel.length];
		for(int k = 0; k < pixel.length; k++) { bgr[0][k] = pixel[k] & 0xff; bgr[1][k] = (pixel[k] >> 8) & 0xff; bgr[2][k] = (pixel[k] >> 16) & 0xff; }
		int[] size = DeltaMapper.getQuantizedSize(xdim, ydim, quant);
		int w = size[0], h = size[1];
		int[][] q = new int[3][];
		for(int i = 0; i < 3; i++)
		{
			int[] c = (quant != 0) ? ResizeMapper.resize2(bgr[i], xdim, w, h) : bgr[i];
			q[i] = DeltaMapper.quantizeChannel(c, shift);
		}
		int[] min = new int[6];
		int[][] qc = DeltaMapper.getCandidateChannels(q[0], q[1], q[2], min);
		int[][] value = new int[3][], delta = new int[3][];
		for(int i = 0; i < 3; i++)
		{
			value[i] = qc[NativeWriter.CHANNELS[i]];
			delta[i] = DeltaMapper.getRowFitDeltas(value[i], (i > 0) ? value[i - 1] : null, w, h, NativeWriter.RADIUS, NativeWriter.EVERY);
		}
		System.out.println(String.format("Coder benchmark (Java %s, %d cores): %s, Pixel Resolution %d, Color Resolution %d: %d x %d, best of %d runs, 1 thread",
			System.getProperty("java.version"), Runtime.getRuntime().availableProcessors(), new File(args[0]).getName(), quant, shift, w, h, runs));
		System.out.println("The C through JNI: " + DeltaMapper.NATIVE_STATUS);

		String[] name = {"green", "blue-green", "red-green"};
		double[] jt = new double[3], c = new double[3];
		boolean same = true;
		System.out.println("  channel          Java           C   (ms)      bytes");
		for(int i = 0; i < 3; i++)
		{
			int[][] previous = java.util.Arrays.copyOf(delta, i);
			jt[i] = c[i] = Double.MAX_VALUE;
			byte[] packed = null;
			for(int run = 0; run < runs + 2; run++)   // the first two warm up
			{
				long t0 = System.nanoTime();
				packed = DeltaMapper.packMixedDeltasJava(delta[i], value[i], previous, w, true);
				long t1 = System.nanoTime();
				if(run >= 2) jt[i] = Math.min(jt[i], (t1 - t0) / 1e9);
				if(!DeltaMapper.NATIVE) continue;
				long t2 = System.nanoTime();
				byte[] p = DeltaMapper.packMixedDeltasNative(delta[i], value[i], previous, w, true);
				long t3 = System.nanoTime();
				same &= java.util.Arrays.equals(p, packed);
				if(run >= 2) c[i] = Math.min(c[i], (t3 - t2) / 1e9);
			}
			System.out.println(String.format("  %-10s %10.1f  %10.1f        %,10d", name[i], jt[i] * 1e3, DeltaMapper.NATIVE ? c[i] * 1e3 : Double.NaN, packed.length));
		}
		System.out.println(String.format("  %-10s %10.1f  %10.1f", "total", (jt[0] + jt[1] + jt[2]) * 1e3, DeltaMapper.NATIVE ? (c[0] + c[1] + c[2]) * 1e3 : Double.NaN));
		if(DeltaMapper.NATIVE) System.out.println(same ? "The C's bytes are the same as the Java's." : "The C's bytes DIFFER from the Java's.");
	}
}
