import java.util.*;

/**
 * The mappers NativeWriter and NativeReader use, trimmed from DeltaEncoder's
 * DeltaMapper to just those: the channel sets and quantizing; the
 * least-squares fit from the rows above (RowFit) and the decoder's
 * wavefront for it (RowWave); and the mixed context coding of the deltas
 * with the second opinions (MixedModels), whose opinions use the simple
 * predictors (blockPredictor, gap).
 * <p>
 * In source order: channels; the simple predictors; the least-squares fit
 * from the rows above; rank tables on disk; the context buckets; the mixed
 * context coding.
 * <p>
 * Some methods have C versions, in native/DeltaMapper.c, used when its
 * library (DeltaMapper.dll, libDeltaMapper.so) is found: see {@link #NATIVE}.
 * They give the same results, bit for bit.
 * <p>
 * Version 1.5 (1.0: DeltaEncoder's DeltaMapper, trimmed; 1.1: RowFit.plane in
 * C; 1.2: packMixedDeltas in C; 1.3: getValuesFromRowFitChannels in C; 1.4:
 * the reader's last steps in C, getPixelsNative; 1.5: Apply and the decode
 * check in C).
 */
public class DeltaMapper
{
	/** Not used: all of this class's methods are static. */
	public DeltaMapper() {}

	// =========================================================================
	// The C versions (native/DeltaMapper.c)
	// =========================================================================

	/**
	 * Whether the C versions are used: true when the library DeltaMapper is
	 * found, and is as new as the Java (see {@link #NATIVE_VERSION}), unless
	 * the program is run with {@code -Dnative=false}. It's looked for in a
	 * folder {@code native} in or above the folder the classes are in and
	 * the current folder (so the repository's native folder is found from
	 * java/bin and java/out/classes), then on java.library.path.
	 * {@link #NATIVE_STATUS} says which was used, and why. The C is used for
	 * RowFit.plane (the writer's fit), packMixedDeltas (the writer's coder),
	 * getValuesFromRowFitChannels (the reader's decoder and fit),
	 * getValuesFromRowFitDeltas (NativeReader2's fit), the reader's last
	 * steps (getPixelsNative), NativeWriter's Apply
	 * (applyQuantizeNative, applyPreviewNative) and its decode check
	 * (checkMixedDeltasNative); if a C call fails (out of memory), the Java
	 * does it.
	 */
	public static final boolean NATIVE;

	/** What {@link #NATIVE} found: the library's file, or why it's Java. */
	public static final String NATIVE_STATUS;

	static
	{
		String[] status = new String[1];
		NATIVE = loadNative(status);
		NATIVE_STATUS = status[0];
	}

	/**
	 * The version of the native methods this Java needs (DELTAMAPPER_NATIVE_VERSION
	 * in native/DeltaMapper.h): a library that reports another, or none (built
	 * before there was one), is older or newer than the Java and isn't used.
	 */
	static final int NATIVE_VERSION = 6;

	/**
	 * Loads the library DeltaMapper, as {@link #NATIVE} says: first from a
	 * folder native in or above the folder the classes are in, then the
	 * current folder, then java.library.path (on Windows, the PATH), so the
	 * repository's own library is the one found. It must report
	 * NATIVE_VERSION.
	 *
	 * @param status gets what was found
	 * @return whether it was loaded
	 */
	private static boolean loadNative(String[] status)
	{
		if("false".equalsIgnoreCase(System.getProperty("native")))
		{
			status[0] = "Java (-Dnative=false)";
			return false;
		}
		String name = System.mapLibraryName("DeltaMapper");
		java.util.List<java.io.File> start = new ArrayList<>();
		try { start.add(new java.io.File(DeltaMapper.class.getProtectionDomain().getCodeSource().getLocation().toURI())); }
		catch(Throwable e) { /* no code source */ }
		start.add(new java.io.File(System.getProperty("user.dir")));
		String where = null, failure = null;
		search:
		for(java.io.File dir : start)
			for(java.io.File d = dir.getAbsoluteFile(); d != null; d = d.getParentFile())
			{
				java.io.File lib = new java.io.File(new java.io.File(d, "native"), name);
				if(!lib.isFile()) continue;
				try { System.load(lib.getPath()); where = lib.getPath(); break search; }
				catch(Throwable e) { if(failure == null) failure = lib.getPath() + ": " + e.getMessage(); }
			}
		if(where == null)
			try { System.loadLibrary("DeltaMapper"); where = name + " on java.library.path"; }
			catch(Throwable e) { /* none there either */ }
		if(where == null)
		{
			status[0] = (failure != null) ? "Java (" + failure + ")" : "Java (no " + name + " found)";
			return false;
		}
		int version;
		try { version = nativeVersion(); }
		catch(Throwable e) { version = 0; }
		if(version != NATIVE_VERSION)
		{
			status[0] = "Java (" + where + " is " + ((version < NATIVE_VERSION) ? "older" : "newer") + " than the Java: rebuild the C)";
			return false;
		}
		status[0] = "C (" + where + ")";
		return true;
	}

	/**
	 * The library's version of the native methods.
	 *
	 * @return DELTAMAPPER_NATIVE_VERSION
	 */
	private static native int nativeVersion();

	/**
	 * RowFit.plane in C (RowFit_plane in native/DeltaMapper.c): the same
	 * predictions, into out.
	 *
	 * @param v       the channel
	 * @param ref     the previous channel, or null for the first
	 * @param xdim    the width
	 * @param ydim    the height
	 * @param radius  the window radius
	 * @param every   how often along a row the fit is solved
	 * @param out     gets the predictions (v.length)
	 * @param threads how many bands of rows to fit at a time
	 * @return 0, or -1 if the C ran out of memory
	 */
	static native int rowFitPlane(int[] v, int[] ref, int xdim, int ydim, int radius, int every, short[] out, int threads);

	/**
	 * packMixedDeltas in C (DeltaMapper_packMixedDeltas in native/DeltaMapper.c,
	 * with native/ArithmeticMapper.c's range coder): the same bytes.
	 *
	 * @param delta    the deltas
	 * @param values   the channel as the decoder rebuilds it
	 * @param previous the deltas of the channels coded before this one
	 * @param xdim     the row width
	 * @param opinions whether the contexts include the second opinions
	 * @return the coded bytes, or null if the C ran out of memory
	 */
	static native byte[] packMixedDeltasNative(int[] delta, int[] values, int[][] previous, int xdim, boolean opinions);

	/**
	 * NativeWriter's Apply, its first steps, in C (DeltaMapper_applyQuantize
	 * in native/DeltaMapper.c): each of src resized to w x h (resize2's
	 * maps, or none) and quantized (quantizeChannel) into q; then
	 * getCandidateChannels: diff gets blue - green, red - green and red -
	 * blue, each less its minimum, and min the six channels' minimums. The
	 * same values as the Java.
	 *
	 * @param src     blue, green and red (X * Y each)
	 * @param X       the image's width
	 * @param Y       the image's height
	 * @param w       the quantized width
	 * @param h       the quantized height
	 * @param ca      resize2's column map, first sources (null: no resizing)
	 * @param cb      its second sources
	 * @param ra      its row map, first sources
	 * @param rb      its second sources
	 * @param shift   the Color Resolution
	 * @param q       gets the quantized blue, green and red (w * h each)
	 * @param diff    gets the three differences (w * h each)
	 * @param min     gets the six minimums
	 * @param threads how many parts to do at once
	 * @return 0, or -1 if the C couldn't
	 */
	static native int applyQuantizeNative(int[][] src, int X, int Y, int w, int h, int[] ca, int[] cb, int[] ra, int[] rb, int shift, int[][] q, int[][] diff, int[] min, int threads);

	/**
	 * Apply's preview in C (DeltaMapper_applyPreview): each of q resized back
	 * (resize2's maps, or none), shifted up, moved towards src by correction
	 * / 10, packed into pixel as a TYPE_INT_RGB raster holds it (setRGB's
	 * result): the same image as the Java's.
	 *
	 * @param q          the quantized blue, green and red (w * h each)
	 * @param w          their width
	 * @param h          their height
	 * @param ca         resize2's column map, first sources (null: no resizing)
	 * @param cb         its second sources
	 * @param ra         its row map, first sources
	 * @param rb         its second sources
	 * @param X          the image's width
	 * @param Y          the image's height
	 * @param shift      the Color Resolution
	 * @param correction the Error Correction (0 to 10)
	 * @param src        the image's blue, green and red
	 * @param pixel      gets the preview (X * Y)
	 * @param threads    how many parts to do at once
	 * @return 0, or -1 if the C couldn't
	 */
	static native int applyPreviewNative(int[][] q, int w, int h, int[] ca, int[] cb, int[] ra, int[] rb, int X, int Y, int shift, int correction, int[][] src, int[] pixel, int threads);

	/**
	 * Save's decode check in C (DeltaMapper_checkMixedDeltas): whether packed
	 * decodes back to delta, as unpackMixedDeltas would.
	 *
	 * @param packed   packMixedDeltas' bytes
	 * @param delta    the deltas they should decode to
	 * @param values   the channel
	 * @param previous the deltas of the channels coded before this one
	 * @param xdim     the row width
	 * @return 1 if they do, 0 if not, -1 if the C couldn't tell
	 */
	static native int checkMixedDeltasNative(byte[] packed, int[] delta, int[] values, int[][] previous, int xdim);

	/**
	 * The reader's last steps in C (DeltaMapper_getPixels in
	 * native/DeltaMapper.c): min[i] added to channel[i]'s values (0: none),
	 * then blue, green and red rebuilt (getBlueGreenRed), resized (resize2's
	 * maps, or none) and packed (getPixel), into pixel, masked to 24 bits as
	 * a TYPE_INT_RGB image stores them (setRGB's result): the same image as
	 * the Java's. The channels aren't changed.
	 *
	 * @param set_id      the channel set
	 * @param channel     the three decoded channels (w * h each)
	 * @param min         what to add to each channel's values
	 * @param w           the channels' width
	 * @param h           the channels' height
	 * @param ca          resize2's column map, first sources (null: no resizing)
	 * @param cb          its second sources
	 * @param ra          its row map, first sources
	 * @param rb          its second sources
	 * @param xdim        the image's width
	 * @param ydim        the image's height
	 * @param pixel_shift the Color Resolution
	 * @param pixel       gets the pixels (xdim * ydim), as a TYPE_INT_RGB raster holds them
	 * @param threads     how many parts to do at once
	 * @return 0, or -1 if the C couldn't
	 */
	static native int getPixelsNative(int set_id, int[][] channel, int[] min, int w, int h, int[] ca, int[] cb, int[] ra, int[] rb, int xdim, int ydim, int pixel_shift, int[] pixel, int threads);

	/**
	 * getValuesFromRowFitChannels in C (DeltaMapper_decodeRowFitChannels in
	 * native/DeltaMapper.c), for coded bytes that have all arrived: the same
	 * deltas and values.
	 *
	 * @param coded      each channel's range-coded bytes
	 * @param rank_value each channel's delta value of each rank
	 * @param xdim       the width
	 * @param ydim       the height
	 * @param init       each channel's first value
	 * @param radius     each channel's window radius
	 * @param every      how often along a row the fit was solved
	 * @param delta      gets each channel's deltas (xdim * ydim each)
	 * @param value      gets each channel's values (xdim * ydim each)
	 * @return 0, or -1 if the C couldn't (out of memory, or out of threads)
	 */
	static native int decodeRowFitChannelsNative(byte[][] coded, int[][] rank_value, int xdim, int ydim, int[] init, int[] radius, int every, int[][] delta, int[][] value);

	/**
	 * getValuesFromRowFitDeltas in C (DeltaMapper_rebuildRowFitChannels in
	 * native/DeltaMapper.c): the same values.
	 *
	 * @param delta  each channel's deltas, in coding order (xdim * ydim each)
	 * @param xdim   the width
	 * @param ydim   the height
	 * @param init   each channel's first value
	 * @param radius each channel's window radius
	 * @param every  how often along a row the fit was solved
	 * @param value  gets each channel's values (xdim * ydim each)
	 * @return 0, or -1 if the C couldn't (out of memory, or out of threads)
	 */
	static native int rebuildRowFitChannelsNative(int[][] delta, int xdim, int ydim, int[] init, int[] radius, int every, int[][] value);

	// =========================================================================
	// Channels: colour sets, differences and quantizing
	// =========================================================================

	/**
	 * The candidate channels (0 blue, 1 green, 2 red, 3 blue-green, 4 red-green,
	 * 5 red-blue) of a channel set.
	 *
	 * @param set_id the channel set, 0 to 9
	 * @return its three channel ids, in coding order
	 */
	public static int[] getChannels(int set_id)
	{
		int[] channel = new int[3];
		if(set_id==0)      { channel[0]=0; channel[1]=1; channel[2]=2; }
		else if(set_id==1) { channel[0]=0; channel[1]=2; channel[2]=4; }
		else if(set_id==2) { channel[0]=0; channel[1]=2; channel[2]=3; }
		else if(set_id==3) { channel[0]=0; channel[1]=3; channel[2]=4; }
		else if(set_id==4) { channel[0]=0; channel[1]=3; channel[2]=5; }
		else if(set_id==5) { channel[0]=1; channel[1]=2; channel[2]=3; }
		else if(set_id==6) { channel[0]=2; channel[1]=3; channel[2]=4; }
		else if(set_id==7) { channel[0]=1; channel[1]=3; channel[2]=4; }
		else if(set_id==8) { channel[0]=1; channel[1]=4; channel[2]=5; }
		else if(set_id==9) { channel[0]=2; channel[1]=4; channel[2]=5; }
		return channel;
	}

	/**
	 * The six candidate channels: blue, green, red, then blue-green, red-green
	 * and red-blue. Each difference channel is shifted by its minimum so it
	 * starts at 0.
	 *
	 * @param blue  the blue channel
	 * @param green the green channel
	 * @param red   the red channel
	 * @param min   set to each channel's minimum (unshifted for the colours)
	 * @return the six channels
	 */
	public static int[][] getCandidateChannels(int[] blue, int[] green, int[] red, int[] min)
	{
		int[][] c = {blue, green, red, getDifference(blue, green), getDifference(red, green), getDifference(red, blue)};
		for(int i = 0; i < 6; i++)
		{
			int m = Integer.MAX_VALUE;
			for(int v : c[i]) if(v < m) m = v;
			min[i] = m;
			if(i > 2) for(int k = 0; k < c[i].length; k++) c[i][k] -= m;
		}
		return c;
	}

	/**
	 * Rebuilds blue, green and red from the three channels of set_id (see
	 * getChannels), with the difference channels' minimums already added back.
	 * The arrays passed in are not changed.
	 *
	 * @param set_id the channel set, 0 to 9
	 * @param c0     its first channel
	 * @param c1     its second
	 * @param c2     its third
	 * @return {blue, green, red}
	 * @throws IllegalArgumentException for another set_id
	 */
	public static int[][] getBlueGreenRed(int set_id, int[] c0, int[] c1, int[] c2)
	{
		int[] blue, green, red;
		switch(set_id)
		{
			case 0:  blue = c0; green = c1; red = c2; break;
			case 1:  blue = c0; red = c1; green = getDifference(red, c2); break;
			case 2:  blue = c0; red = c1; green = getDifference(blue, c2); break;
			case 3:  blue = c0; green = getDifference(blue, c1); red = getSum(c2, green); break;
			case 4:  blue = c0; green = getDifference(blue, c1); red = getSum(blue, c2); break;
			case 5:  green = c0; red = c1; blue = getSum(c2, green); break;
			case 6:  red = c0; green = getDifference(red, c2); blue = getSum(c1, green); break;
			case 7:  green = c0; blue = getSum(green, c1); red = getSum(green, c2); break;
			case 8:  green = c0; red = getSum(green, c1); blue = getDifference(red, c2); break;
			case 9:  red = c0; green = getDifference(red, c1); blue = getDifference(red, c2); break;
			default: throw new IllegalArgumentException("set_id " + set_id);
		}
		return new int[][] {blue, green, red};
	}

	/**
	 * src1 - src2, element by element.
	 *
	 * @param src1 a channel
	 * @param src2 another, the same length
	 * @return the difference
	 * @throws IllegalArgumentException if the lengths differ
	 */
	public static int[] getDifference(int src1[], int src2[])
	{
		int length = src1.length;
		if(src2.length != length)
			throw new IllegalArgumentException("getDifference: src1.length (" + length + ") != src2.length (" + src2.length + ")");

		int[] difference = new int[length];
		for(int i = 0; i < length; i++)
			difference[i] = src1[i] - src2[i];
		return(difference);
	}

	/**
	 * src1 + src2, element by element.
	 *
	 * @param src1 a channel
	 * @param src2 another, the same length
	 * @return the sum
	 * @throws IllegalArgumentException if the lengths differ
	 */
	public static int[] getSum(int src1[], int src2[])
	{
		int length = src1.length;
		if(src2.length != length)
			throw new IllegalArgumentException("getSum: src1.length (" + length + ") != src2.length (" + src2.length + ")");

		int[] sum = new int[length];
		for(int i = 0; i < length; i++)
			sum[i] = src1[i] + src2[i];
		return(sum);
	}

	/**
	 * Shifts every value: left for a positive shift, right (arithmetic) for a
	 * negative one.
	 *
	 * @param src   the values
	 * @param shift the bits to shift by
	 * @return the shifted values
	 */
	public static int[] shift(int src[], int shift)
	{
		int length = src.length;
		int[] shifted_value = new int[length];

		if(shift < 0)
		{
			for(int i = 0; i < src.length; i++)
				shifted_value[i] = src[i] >> -shift;
		}
		else
		{
			for(int i = 0; i < src.length; i++)
				shifted_value[i] = src[i] << shift;
		}

		return(shifted_value);
	}

	/**
	 * Smallest image the writers accept (the delta types need an interior).
	 */
	public static final int MIN_DIM = 4;

	/**
	 * Size after Pixel Resolution resizing. Images under MIN_DIM in either
	 * direction are not resized.
	 *
	 * @param xdim        the width
	 * @param ydim        the height
	 * @param pixel_quant 0 (none) to 10
	 * @return {width, height}
	 */
	public static int[] getQuantizedSize(int xdim, int ydim, int pixel_quant)
	{
		if(pixel_quant == 0 || xdim < MIN_DIM || ydim < MIN_DIM)
			return new int[] {xdim, ydim};
		double factor = pixel_quant / 10.0;
		return new int[] {xdim - (int)(factor * (xdim / 2 - 2)), ydim - (int)(factor * (ydim / 2 - 2))};
	}

	/**
	 * Right-shifts a channel by pixel_shift, rounding to nearest (clamped so the
	 * result never reconstructs past 255). Returns a new array: the channel
	 * passed in is often the stored source data and must not change.
	 *
	 * @param channel     the channel
	 * @param pixel_shift the bits to drop
	 * @return the quantized channel
	 */
	public static int[] quantizeChannel(int[] channel, int pixel_shift)
	{
		if(pixel_shift == 0) return channel.clone();
		int half = 1 << (pixel_shift - 1);
		int[] rounded = new int[channel.length];
		for(int k = 0; k < channel.length; k++)
			rounded[k] = Math.min(channel[k] + half, 255);
		return shift(rounded, -pixel_shift);
	}

	/**
	 * Packs three channels into int pixels, each value shifted up by pixel_shift
	 * (undoing the colour quantization): blue in bits 16-23, green 8-15, red 0-7.
	 *
	 * @param blue        the blue channel
	 * @param green       the green channel
	 * @param red         the red channel
	 * @param xdim        the width
	 * @param pixel_shift the colour quantization (bits)
	 * @return the pixels
	 */
	public static int[] getPixel(int[] blue, int[] green, int[] red, int xdim, int pixel_shift)
	{
		int ydim = blue.length / xdim;
		int[] pixel = new int[blue.length];

		int blue_shift  = pixel_shift + 16;
		int green_shift = pixel_shift + 8;
		int red_shift   = pixel_shift;

		int k = 0;
		for(int i = 0; i < ydim; i++)
		{
			for(int j = 0; j < xdim; j++)
			{
				pixel[k] = (blue[k] << blue_shift) + (green[k] << green_shift) + (red[k] << red_shift);
				k++;
			}
		}
		return pixel;
	}

	// =========================================================================
	// Simple predictors: the second opinions' (see the mixed context coding)
	// =========================================================================

	/**
	 * Primitives 0-27 from left a, above b, above-left c and above-right d
	 * (the second opinions use MED, 11); 22-27 are the selection predictors.
	 *
	 * @param id the primitive, 0 to 27
	 * @param a  left
	 * @param b  above
	 * @param c  above-left
	 * @param d  above-right
	 * @return the prediction
	 */
	public static int blockPredictor(int id, int a, int b, int c, int d)
	{
		switch(id)
		{
			case  0: return a;
			case  1: return b;
			case  2: return c;
			case  3: return d;
			case  4: return (a + b) >> 1;
			case  5: return (b + c) >> 1;
			case  6: return (a + c) >> 1;
			case  7: return (b + d) >> 1;
			case  8: return (c + d) >> 1;
			case  9: return (a + b + c + d + 2) >> 2;
			case 10: return a + b - c;
			case 11: if(c >= Math.max(a, b)) return Math.min(a, b); if(c <= Math.min(a, b)) return Math.max(a, b); return a + b - c;
			case 12: return (a * 3 + b + 2) >> 2;
			case 13: return (a + b * 3 + 2) >> 2;
			case 14: return (a * 3 + d + 2) >> 2;
			case 15: return (b * 3 + a + 2) >> 2;
			case 16: return (a + d) >> 1;
			case 17: return a + ((b - c) >> 1);
			case 18: return b + ((a - c) >> 1);
			case 19: return a + d - b;
			case 20: return (a + b + d + 1) / 3;
			case 21: return b + ((d - c) >> 1);
			// 22-27: selection predictors.
			case 22: { int p = a + b - c, pa = Math.abs(p - a), pb = Math.abs(p - b), pc = Math.abs(p - c);
			           return (pa <= pb && pa <= pc) ? a : (pb <= pc) ? b : c; }                 // Paeth (PNG)
			case 23: return median(a, b, c);
			case 24: return median(a, b, d);
			case 25: return median(a, d, a + d - b);                                           // MED along the up-right diagonal
			case 26: return (Math.abs(b - c) <= Math.abs(a - c)) ? a : b;                     // the flatter direction
			case 27: { int h = Math.abs(b - c), v = Math.abs(a - c), g = Math.abs(a - b);     // ... of three: left, up, up-right
			           return (h <= v && h <= g) ? a : (v <= g) ? b : d; }
			default: return b + ((d - c) >> 1);
		}
	}

	/**
	 * The median of three values.
	 *
	 * @param x a value
	 * @param y a value
	 * @param z a value
	 * @return the middle one
	 */
	private static int median(int x, int y, int z) { return Math.max(Math.min(x, y), Math.min(Math.max(x, y), z)); }

	/**
	 * JPEG-LS gradient levels: 0, then +-1 for 1-2, +-2 for 3-6, +-3 for 7-20, +-4
	 * beyond.
	 *
	 * @param g a gradient
	 * @return its level, -4 to 4
	 */
	private static int gradientLevel(int g)
	{
		int m = Math.abs(g), l = (m == 0) ? 0 : (m < 3) ? 1 : (m < 7) ? 2 : (m < 21) ? 3 : 4;
		return (g < 0) ? -l : l;
	}

	/**
	 * CALIC's gradient-adjusted predictor.
	 *
	 * @param w   left (a)
	 * @param ww  two to the left
	 * @param n   above (b)
	 * @param nn  two above
	 * @param nw  above-left (c)
	 * @param ne  above-right (d)
	 * @param nne above-right, one row higher
	 * @param t1  the largest threshold (80 for 8-bit values)
	 * @param t2  the middle one (32)
	 * @param t3  the smallest (8)
	 * @return the prediction
	 */
	private static int gap(int w, int ww, int n, int nn, int nw, int ne, int nne, int t1, int t2, int t3)
	{
		int dh = Math.abs(w - ww) + Math.abs(n - nw) + Math.abs(n - ne);
		int dv = Math.abs(w - nw) + Math.abs(n - nn) + Math.abs(ne - nne);
		if(dv - dh > t1) return w;
		if(dh - dv > t1) return n;
		int p = (2 * (w + n) + ne - nw) >> 2;
		if(dv - dh > t2)      p = (p + w) >> 1;
		else if(dv - dh > t3) p = (3 * p + w) >> 2;
		else if(dh - dv > t2) p = (p + n) >> 1;
		else if(dh - dv > t3) p = (3 * p + n) >> 2;
		return p;
	}

	// =========================================================================
	// Least squares from the rows above (the Simple 2 format)
	// =========================================================================

	/**
	 * Waits until channel j has rows decoded (or a channel failed).
	 *
	 * @param done   each channel's rows decoded
	 * @param failed the first failure, if any
	 * @param j      the channel
	 * @param rows   the rows needed
	 * @throws InterruptedException if interrupted while waiting
	 */
	private static void awaitRows(int[] done, Throwable[] failed, int j, int rows) throws InterruptedException
	{
		synchronized(done)
		{
			while(done[j] < rows && failed[0] == null) done.wait();
			if(failed[0] != null) throw new IllegalStateException("an earlier channel failed to decode", failed[0]);
		}
	}

	// RowFit is the least-squares primitive with a window of the rows above
	// only: no pixels of the pixel's own row. A row's fits then depend only on
	// the rows before it, so they can all be solved, in parallel, before the
	// row is decoded; decoding a row is left with the prediction from the
	// solved coefficients and the delta decoder. It costs a little compression
	// (the pixels just to the left are the closest training pixels).

	/**
	 * Least squares fitted from the rows above. At each interior pixel (y,
	 * x), the linear predictor (with a constant term) that best fits the
	 * pixels in the window -- the r rows above it (from row 1) and r columns
	 * either side (the interior columns) -- from 6 of the 8
	 * neighbours (W, N, NW, NE, WW and NNE: not NN and NEE, which cost a
	 * quarter of the run time for about a quarter of a percent of the file)
	 * and, after the first channel, the previous channel at the pixel, to its
	 * left and above. The fit is solved at every every-th pixel
	 * along a row, from column 1, and the pixels up to the next solved one
	 * use its solution; where it can't be solved (fewer than twice as many
	 * window pixels as unknowns, or a singular system) they are predicted by
	 * a, the pixel to the left. The prediction has the wide clamp (2 beyond
	 * the range of all 8 spatial neighbours). The window's sums are exact
	 * integers, kept per column as the rows go by; the solution (ridge 1, L
	 * D L^T) is in a fixed order, so the encoder (in bands of rows, each
	 * started on its own: start) and the decoder, and the Python version, get
	 * the same values.
	 * <p>
	 * Per row: moveTo(y) brings the columns to row y's window (adding row y -
	 * 1, dropping row y - 1 - r), solveRow(y) solves the row's fits, then
	 * predict(y, x) for each interior pixel. moveTo and solveRow split their
	 * work into tasks run at the same time when asked to (the decoder; the
	 * encoder runs bands of rows at the same time instead).
	 */
	static final class RowFit
	{
		/**
		 * The number of neighbours fitted: W, N, NW, NE, WW, NNE (features 0 to 5).
		 */
		static final int SPATIAL = 6;
		/**
		 * The channel (filled in as it decodes), and the previous channel (null for the first).
		 */
		final int[]  v, ref;
		/**
		 * The width, the number of features, their augmented length (features,
		 * 1, value), the number of products of the augmented vector, and the
		 * number of unknowns (features and the constant).
		 */
		final int    xdim, nf, m, nt, n;
		/**
		 * The window radius, and how often along a row the fit is solved.
		 */
		final int    r, every;
		/**
		 * The solved pixels per row (columns 1, 1 + every, ... up to xdim - 2).
		 */
		final int    points;
		/**
		 * Per column, the window rows' sums of products (r rows of products of
		 * at most about 520 * 520: an int holds them for any radius up to 255).
		 */
		final int[]  col;
		/**
		 * Each solved pixel's solution (n each), and whether its fit could be
		 * solved: two sets, row y's in set y &amp; 1, so that a decoder can solve
		 * the next row's fits while it decodes this one (RowWave).
		 */
		final double[][] coef;
		/**
		 * As coef: whether each solved pixel's fit could be solved, row y's in set y &amp; 1.
		 */
		final boolean[][] valid;
		/**
		 * The features of the pixel being predicted.
		 */
		final long[] z;
		/**
		 * The row whose window the columns hold (-1 for none yet).
		 */
		int row = -1;
		/**
		 * The last prediction (predict returns it too).
		 */
		int wide;

		/**
		 * The fit for a channel.
		 *
		 * @param v      the channel
		 * @param ref    the previous channel, or null for the first
		 * @param xdim   the width
		 * @param radius the window radius (at least 1)
		 * @param every  how often along a row the fit is solved (at least 1)
		 */
		RowFit(int[] v, int[] ref, int xdim, int radius, int every)
		{
			this.v = v; this.ref = ref; this.xdim = xdim; this.r = radius; this.every = every;
			nf     = (ref == null) ? SPATIAL : SPATIAL + 3;
			m      = nf + 2;
			nt     = m * (m + 1) / 2;
			n      = nf + 1;
			points = Math.max(0, (xdim - 2 + every - 1) / every);
			col    = new int[xdim * nt];
			coef   = new double[2][points * n];
			valid  = new boolean[2][points];
			z      = new long[m];
		}

		/**
		 * One task's working arrays.
		 */
		final class Work
		{
			/**
			 * A task's arrays, sized for this fit.
			 */
			Work() {}
			/**
			 * An augmented vector, and its products.
			 */
			final long[] zw = new long[m];
			/**
			 * The products of one pixel.
			 */
			final int[]  p  = new int[nt];
			/**
			 * addColumns' augmented vectors of the row it adds and the row it drops.
			 */
			final int[]  za = new int[m], zd = new int[m];
			/**
			 * A window's sums.
			 */
			final long[] win = new long[nt];
			/**
			 * The normal equations' matrix.
			 */
			final double[][] a = new double[n][n];
			/**
			 * Their right-hand side, and D of L D L^T.
			 */
			final double[] b = new double[n], dg = new double[n];
		}

		/**
		 * The value at (y, x), clamped to the image.
		 *
		 * @param y the row
		 * @param x the column
		 * @return the value
		 */
		private int at(int y, int x)
		{
			if(y < 0) y = 0;
			if(x < 0) x = 0; else if(x > xdim - 1) x = xdim - 1;
			return v[y * xdim + x];
		}

		/**
		 * Sets zz to the features of pixel (y, x), 1, and its value.
		 *
		 * @param y  the row
		 * @param x  the column
		 * @param zz where they go
		 */
		private void features(int y, int x, long[] zz)
		{
			zz[0] = at(y, x - 1);      // W
			zz[1] = at(y - 1, x);      // N
			zz[2] = at(y - 1, x - 1);  // NW
			zz[3] = at(y - 1, x + 1);  // NE
			zz[4] = at(y, x - 2);      // WW
			zz[5] = at(y - 2, x + 1);  // NNE
			if(ref != null)
			{
				int k = y * xdim + x;
				zz[6] = ref[k]; zz[7] = ref[k - 1]; zz[8] = ref[k - xdim];
			}
			zz[nf] = 1;
			zz[nf + 1] = v[y * xdim + x];
		}

		/**
		 * Pixel (y, x)'s products into w.p.
		 *
		 * @param y the row
		 * @param x the column
		 * @param w the task's arrays
		 */
		private void products(int y, int x, Work w)
		{
			long[] zz = w.zw;
			features(y, x, zz);
			int t = 0;
			for(int i = 0; i < m; i++)
			{
				long zi = zz[i];
				for(int j = i; j < m; j++) w.p[t++] = (int) (zi * zz[j]);
			}
		}

		/**
		 * Sets up the window as if the rows before y0 had been gone through
		 * (for a band of rows the encoder fits on its own).
		 *
		 * @param y0 the first row predicted
		 */
		void start(int y0)
		{
			Arrays.fill(col, 0);
			Work w = new Work();
			for(int ty = Math.max(1, y0 - r); ty <= y0 - 1; ty++)
				for(int tx = 1; tx < xdim - 1; tx++)
				{
					products(ty, tx, w);
					for(int t = 0, c = tx * nt; t < nt; t++) col[c + t] += w.p[t];
				}
			row = y0;
		}

		/**
		 * Brings the columns to row y's window: rows y - r .. y - 1 (from 1).
		 * After row y - 1, adds row y - 1 and drops row y - 1 - r; otherwise
		 * starts again (start).
		 *
		 * @param y        the row
		 * @param parallel whether to split the work into tasks run at the same time
		 */
		void moveTo(int y, boolean parallel)
		{
			if(row == y) return;
			if(row != y - 1) { start(y); return; }
			if(y - 1 >= 1 && xdim > 2)
			{
				int tasks = parallel ? tasks(xdim - 2, 128) : 1;
				runTasks(tasks, t -> addColumns(y, 1 + (int) ((long) t * (xdim - 2) / tasks), 1 + (int) ((long) (t + 1) * (xdim - 2) / tasks), new Work()));
			}
			row = y;
		}

		/**
		 * moveTo's work on columns c0 to c1 - 1 alone (of the interior): adds
		 * row y - 1 and drops row y - 1 - r (from row 1). Needs row y - 1
		 * through column c1 - 1 (and the rows above), and changes no other
		 * columns, so parts of a row can be done at different times.
		 *
		 * @param y  the row whose window the columns move to (row y - 1's was the last)
		 * @param c0 the first column
		 * @param c1 the column after the last
		 * @param w  the task's arrays
		 */
		void addColumns(int y, int c0, int c1, Work w)
		{
			int add = y - 1, drop = y - 1 - r;
			if(add < 1) return;
			int[] za = w.za, zd = w.zd;
			// Each column gains the added pixel's products and loses the dropped
			// one's, in one pass (the sums are ints, so the same in any order).
			for(int tx = c0; tx < c1; tx++)
			{
				int t = tx * nt;
				features(add, tx, za);
				if(drop >= 1)
				{
					features(drop, tx, zd);
					for(int i = 0; i < m; i++)
					{
						int ai = za[i], di = zd[i];
						for(int j = i; j < m; j++, t++) col[t] += ai * za[j] - di * zd[j];
					}
				}
				else
					for(int i = 0; i < m; i++)
					{
						int ai = za[i];
						for(int j = i; j < m; j++, t++) col[t] += ai * za[j];
					}
			}
		}

		/**
		 * As features(int, int, long[]), into ints (addColumns: the values and
		 * their products fit), with the neighbours read directly where none
		 * needs clamping to the image.
		 *
		 * @param y  the row
		 * @param x  the column
		 * @param zz where they go
		 */
		private void features(int y, int x, int[] zz)
		{
			int k = y * xdim + x;
			if(y >= 2 && x >= 2 && x <= xdim - 3)
			{
				int up = k - xdim, up2 = up - xdim;
				zz[0] = v[k - 1];   // W
				zz[1] = v[up];      // N
				zz[2] = v[up - 1];  // NW
				zz[3] = v[up + 1];  // NE
				zz[4] = v[k - 2];   // WW
				zz[5] = v[up2 + 1]; // NNE
			}
			else
			{
				zz[0] = at(y, x - 1);
				zz[1] = at(y - 1, x);
				zz[2] = at(y - 1, x - 1);
				zz[3] = at(y - 1, x + 1);
				zz[4] = at(y, x - 2);
				zz[5] = at(y - 2, x + 1);
			}
			if(ref != null) { zz[6] = ref[k]; zz[7] = ref[k - 1]; zz[8] = ref[k - xdim]; }
			zz[nf] = 1;
			zz[nf + 1] = v[k];
		}

		/**
		 * Solves row y's fits (the columns at row y's window: moveTo).
		 *
		 * @param y        the row
		 * @param parallel whether to split the work into tasks run at the same time
		 */
		void solveRow(int y, boolean parallel)
		{
			if(points == 0) return;
			int tasks = parallel ? tasks(points, 32) : 1;
			runTasks(tasks, t -> solvePoints(y, (int) ((long) t * points / tasks), (int) ((long) (t + 1) * points / tasks), new Work()));
		}

		/**
		 * solveRow's work on solved pixels p0 to p1 - 1 alone: uses the columns
		 * r either side of them (at row y's window), and changes nothing else
		 * but their solutions.
		 *
		 * @param y  the row
		 * @param p0 the first solved pixel
		 * @param p1 the one after the last
		 * @param w  the task's arrays
		 */
		void solvePoints(int y, int p0, int p1, Work w)
		{
			double[]  coef  = this.coef[y & 1];
			boolean[] valid = this.valid[y & 1];
			int lo = 0, hi = -1;   // the columns in w.win
			for(int p = p0; p < p1; p++)
			{
				int x = 1 + p * every;
				int nlo = Math.max(1, x - r), nhi = Math.min(xdim - 2, x + r);
				if(p == p0)
				{
					Arrays.fill(w.win, 0);
					for(int c = nlo; c <= nhi; c++) for(int s = 0, o = c * nt; s < nt; s++) w.win[s] += col[o + s];
				}
				else
				{
					for(int c = lo; c < nlo; c++)  for(int s = 0, o = c * nt; s < nt; s++) w.win[s] -= col[o + s];
					for(int c = hi + 1; c <= nhi; c++) for(int s = 0, o = c * nt; s < nt; s++) w.win[s] += col[o + s];
				}
				lo = nlo; hi = nhi;
				valid[p] = solve(w, p, coef);
			}
		}

		/**
		 * Solves the fit for w.win into solved pixel p's coefficients.
		 *
		 * @param w    the task's arrays (w.win the window's sums)
		 * @param p    the solved pixel
		 * @param coef the set of solutions it goes in
		 * @return whether it was solved
		 */
		private boolean solve(Work w, int p, double[] coef)
		{
			long[] win = w.win;
			double[][] a = w.a;
			double[] b = w.b, dg = w.dg;
			// Products of (i, j), i <= j < m: index i * m - i * (i - 1) / 2 + (j - i).
			long count = win[nf * m - nf * (nf - 1) / 2];
			if(count < 2 * n) return false;
			// The normal equations' lower triangle (ridge 1 on the diagonal), then
			// L D L^T: L unit lower triangular (in a's lower triangle), D in dg.
			for(int i = 0; i < n; i++)
			{
				int base = i * m - i * (i - 1) / 2;
				for(int j = i; j < n; j++) a[j][i] = (double) win[base + j - i];
				b[i] = (double) win[base + m - 1 - i];
				a[i][i] += 1.0;
			}
			for(int j = 0; j < n; j++)
			{
				double[] aj = a[j];
				double s = aj[j];
				for(int q = 0; q < j; q++) s -= aj[q] * aj[q] * dg[q];
				if(s < 1e-9) return false;
				dg[j] = s;
				for(int i = j + 1; i < n; i++)
				{
					double[] ai = a[i];
					double t = ai[j];
					for(int q = 0; q < j; q++) t -= ai[q] * aj[q] * dg[q];
					ai[j] = t / s;
				}
			}
			int o = p * n;
			for(int i = 0; i < n; i++)
			{
				double s = b[i];
				for(int q = 0; q < i; q++) s -= a[i][q] * coef[o + q];
				coef[o + i] = s;
			}
			for(int i = 0; i < n; i++) coef[o + i] /= dg[i];
			for(int i = n - 1; i >= 0; i--)
			{
				double s = coef[o + i];
				for(int q = i + 1; q < n; q++) s -= a[q][i] * coef[o + q];
				coef[o + i] = s;
			}
			return true;
		}

		/**
		 * The prediction at interior pixel (y, x), with the wide clamp (row y's
		 * fits solved: solveRow), also left in wide.
		 *
		 * @param y the row
		 * @param x the column
		 * @return the prediction
		 */
		int predict(int y, int x)
		{
			int p  = (x - 1) / every;
			int pa = at(y, x - 1), pb = at(y - 1, x), pc = at(y - 1, x - 1), pd = at(y - 1, x + 1);
			if(!valid[y & 1][p]) { wide = pa; return pa; }
			features(y, x, z);
			double[] coef = this.coef[y & 1];
			double s = 0;
			for(int i = 0, o = p * n; i < n; i++) s += coef[o + i] * z[i];
			// The clamp is over all 8 neighbours, the two not fitted (NN, NEE) too.
			int ww = (int) z[4], nne = (int) z[5], nn = at(y - 2, x), nee = at(y - 1, x + 2);
			int lo = Math.min(Math.min(pa, pb), Math.min(pc, pd)), hi = Math.max(Math.max(pa, pb), Math.max(pc, pd));
			lo = Math.min(Math.min(lo, ww), Math.min(Math.min(nne, nn), nee));
			hi = Math.max(Math.max(hi, ww), Math.max(Math.max(nne, nn), nee));
			double w = Math.max(lo - 2, Math.min(hi + 2, s));
			wide = (int) Math.floor(w + 0.5);
			return wide;
		}

		/**
		 * How many tasks to split work into: one per core, but no fewer than
		 * min items each.
		 *
		 * @param items the items of work
		 * @param min   the fewest items a task should have
		 * @return the number of tasks
		 */
		private static int tasks(int items, int min)
		{
			return Math.max(1, Math.min(Runtime.getRuntime().availableProcessors(), items / min));
		}

		/**
		 * Runs body(0 .. tasks - 1), the first in this thread and the rest in
		 * ROW_POOL, and waits for them.
		 *
		 * @param tasks the number of tasks
		 * @param body  the task
		 */
		private static void runTasks(int tasks, java.util.function.IntConsumer body)
		{
			if(tasks == 1) { body.accept(0); return; }
			java.util.concurrent.Future<?>[] f = new java.util.concurrent.Future<?>[tasks - 1];
			for(int t = 1; t < tasks; t++) { int ft = t; f[t - 1] = ROW_POOL.submit(() -> body.accept(ft)); }
			Throwable failed = null;
			try { body.accept(0); } catch(Throwable e) { failed = e; }
			for(java.util.concurrent.Future<?> g : f)
			{
				try { g.get(); }
				catch(java.util.concurrent.ExecutionException e) { if(failed == null) failed = e.getCause(); }
				catch(InterruptedException e) { Thread.currentThread().interrupt(); if(failed == null) failed = e; }
			}
			if(failed instanceof RuntimeException) throw (RuntimeException) failed;
			if(failed instanceof Error) throw (Error) failed;
			if(failed != null) throw new RuntimeException(failed);
		}

		/**
		 * The encoder's predictions for a whole channel, in bands of rows
		 * computed at the same time (each band started on its own).
		 *
		 * @param v      the channel
		 * @param ref    the previous channel, or null for the first
		 * @param xdim   the width
		 * @param ydim   the height
		 * @param radius the window radius
		 * @param every  how often along a row the fit is solved
		 * @return the prediction at each interior pixel (0 elsewhere)
		 */
		static short[] plane(int[] v, int[] ref, int xdim, int ydim, int radius, int every)
		{
			short[] out = new short[v.length];
			int threads = Runtime.getRuntime().availableProcessors();
			if(NATIVE && rowFitPlane(v, ref, xdim, ydim, radius, every, out, threads) == 0) return out;
			return planeJava(v, ref, xdim, ydim, radius, every, out, threads);
		}

		/**
		 * plane in Java (what plane does without the C).
		 *
		 * @param v       the channel
		 * @param ref     the previous channel, or null for the first
		 * @param xdim    the width
		 * @param ydim    the height
		 * @param radius  the window radius
		 * @param every   how often along a row the fit is solved
		 * @param out     gets the predictions (v.length, zeros)
		 * @param threads how many bands of rows to aim for
		 * @return out
		 */
		static short[] planeJava(int[] v, int[] ref, int xdim, int ydim, int radius, int every, short[] out, int threads)
		{
			java.util.Arrays.fill(out, (short) 0);
			int band = Math.max(4 * (radius + 1), (ydim - 1 + threads - 1) / threads);
			int bands = (ydim - 1 + band - 1) / band;
			java.util.stream.IntStream.range(0, bands).parallel().forEach(t ->
			{
				int y0 = 1 + t * band, y1 = Math.min(ydim, y0 + band);
				RowFit f = new RowFit(v, ref, xdim, radius, every);
				f.start(y0);
				for(int y = y0; y < y1; y++)
				{
					f.moveTo(y, false);
					f.solveRow(y, false);
					for(int x = 1; x < xdim - 1; x++) out[y * xdim + x] = (short) f.predict(y, x);
				}
			});
			return out;
		}
	}

	/**
	 * The threads RowFit's decoder tasks run in (their own: the tasks never
	 * wait for anything, so the pool can't block).
	 */
	static final java.util.concurrent.ExecutorService ROW_POOL = java.util.concurrent.Executors.newFixedThreadPool(
		Runtime.getRuntime().availableProcessors(), task -> { Thread t = new Thread(task, "RowFit"); t.setDaemon(true); return t; });

	/**
	 * A channel's deltas from the least-squares fit from the rows above
	 * (RowFit, the wide clamp).
	 *
	 * @param v      the channel
	 * @param ref    the previous channel, or null for the first
	 * @param xdim   the width
	 * @param ydim   the height
	 * @param radius the window radius
	 * @param every  how often along a row the fit is solved
	 * @return the deltas
	 */
	public static int[] getRowFitDeltas(int[] v, int[] ref, int xdim, int ydim, int radius, int every)
	{
		short[] p = RowFit.plane(v, ref, xdim, ydim, radius, every);
		int[]   d = new int[v.length];
		blockEdges(v, d, xdim, ydim);
		for(int y = 1; y < ydim; y++)
			for(int x = 1, k = y * xdim + 1; x < xdim - 1; x++, k++) d[k] = v[k] - p[k];
		return d;
	}

	/**
	 * A band's RowFit deltas -- what getRowFitDeltas gives for rows y0 to y1 -
	 * 1 alone, coded as an image of their own -- from the whole channel's.
	 * They differ only in the band's first radius + 2 rows (the band's top row
	 * is an edge, and the window's first row uses the row above it), so only
	 * those are fitted again; the sums are exact, so the rest are the same.
	 *
	 * @param whole  the whole channel's deltas (getRowFitDeltas, at this radius and every)
	 * @param v      the whole channel
	 * @param ref    the whole previous channel, or null for the first
	 * @param xdim   the width
	 * @param y0     the band's first row
	 * @param y1     the row after its last
	 * @param radius the window radius
	 * @param every  how often along a row the fit is solved
	 * @return the band's deltas
	 */
	public static int[] getRowFitBandDeltas(int[] whole, int[] v, int[] ref, int xdim, int y0, int y1, int radius, int every)
	{
		int   h = y1 - y0, k = Math.min(h, radius + 2);
		int[] d = new int[h * xdim];
		int[] top = getRowFitDeltas(Arrays.copyOfRange(v, y0 * xdim, (y0 + k) * xdim),
		                            (ref == null) ? null : Arrays.copyOfRange(ref, y0 * xdim, (y0 + k) * xdim), xdim, k, radius, every);
		System.arraycopy(top, 0, d, 0, k * xdim);
		System.arraycopy(whole, (y0 + k) * xdim, d, k * xdim, (h - k) * xdim);
		return d;
	}

	/**
	 * Rebuilds the channels from their mixed-coded deltas, fitting RowFit
	 * as the rows are decoded, for channels still being read: each channel's thread starts decoding
	 * once its coded deltas are there (md[i] done; init[i] set before it), so
	 * a reader can decode the channels read so far while it reads the rest.
	 *
	 * @param md     each channel's rank table and coded bytes, when read, in coding order
	 * @param xdim   the width
	 * @param ydim   the height
	 * @param init   each channel's first value (set before md[i] is done)
	 * @param radius each channel's window radius
	 * @param every  how often along a row the fit was solved
	 * @return {deltas, values}, each per channel
	 */
	public static int[][][] getValuesFromRowFitChannels(java.util.concurrent.Future<MixedDeltas>[] md, int xdim, int ydim, int[] init, int[] radius, int every)
	{
		if(NATIVE)
		{
			// The C decodes once a band's coded bytes have all arrived (the
			// Java starts on each channel as its bytes arrive).
			int n = md.length;
			byte[][] coded = new byte[n][];
			int[][] rank_value = new int[n][], delta = new int[n][xdim * ydim], value = new int[n][xdim * ydim];
			try
			{
				for(int i = 0; i < n; i++)
				{
					MixedDeltas m = md[i].get();
					if(m.arriving != null) m.arriving.awaitAll();
					coded[i] = m.coded;
					rank_value[i] = m.value;
				}
			}
			catch(InterruptedException e) { Thread.currentThread().interrupt(); throw new RuntimeException(e); }
			catch(java.util.concurrent.ExecutionException e) { throw new RuntimeException(e.getCause()); }
			if(decodeRowFitChannelsNative(coded, rank_value, xdim, ydim, init, radius, every, delta, value) == 0) return new int[][][] {delta, value};
		}
		return getValuesFromRowFitChannelsJava(md, xdim, ydim, init, radius, every);
	}

	/**
	 * getValuesFromRowFitChannels in Java (what it does without the C):
	 * each channel starts as soon as its coded bytes start to arrive.
	 *
	 * @param md     each channel's rank table and coded bytes, when read, in coding order
	 * @param xdim   the width
	 * @param ydim   the height
	 * @param init   each channel's first value (set before md[i] is done)
	 * @param radius each channel's window radius
	 * @param every  how often along a row the fit was solved
	 * @return {deltas, values}, each per channel
	 */
	public static int[][][] getValuesFromRowFitChannelsJava(java.util.concurrent.Future<MixedDeltas>[] md, int xdim, int ydim, int[] init, int[] radius, int every)
	{
		int n = md.length;
		int[][] delta = new int[n][xdim * ydim], value = new int[n][xdim * ydim];
		int[]   done  = new int[n];          // each channel's rows decoded (guarded by done)
		Throwable[] failed = new Throwable[1];
		Thread[] worker = new Thread[n];
		for(int c = 0; c < n; c++)
		{
			final int i = c;
			worker[i] = new Thread(() ->
			{
				try
				{
					MixedDecoder mix = new MixedDecoder(md[i].get(), Arrays.copyOf(delta, i), xdim, xdim * ydim, true);
					RowFit fit = new RowFit(value[i], (i > 0) ? value[i - 1] : null, xdim, radius[i], every);
					RowWave wave = new RowWave(fit, ydim);
					for(int y = 0; y < ydim; y++)
					{
						if(i > 0) awaitRows(done, failed, i - 1, Math.min(ydim, y + 2));
						wave.row(mix, delta[i], value[i], y, init[i]);
						synchronized(done) { done[i] = y + 1; done.notifyAll(); }
					}
				}
				catch(Throwable e) { synchronized(done) { if(failed[0] == null) failed[0] = e; done.notifyAll(); } }
			});
			worker[i].start();
		}
		for(Thread t : worker)
			try { t.join(); } catch(InterruptedException e) { Thread.currentThread().interrupt(); throw new RuntimeException(e); }
		if(failed[0] instanceof RuntimeException) throw (RuntimeException) failed[0];
		if(failed[0] instanceof Error) throw (Error) failed[0];
		if(failed[0] != null) throw new RuntimeException(failed[0]);
		return new int[][][] {delta, value};
	}

	/**
	 * A channel's RowFit fits for the decoder, solved a row ahead of the
	 * decoding and following it along the row (a wavefront). The interior
	 * columns are split into chunks (at least CHUNK and more than the window
	 * radius wide). Once the decoder has passed a chunk of row y, the chunk's
	 * columns are moved to row y + 1's window (RowFit.addColumns: they need
	 * only row y through the chunk), and once a chunk and the chunks either
	 * side of it have moved, the chunk's fits for row y + 1 are solved
	 * (RowFit.solvePoints: a fit's window reaches only into the chunks either
	 * side), into the other set of solutions from row y's. Before the decoder
	 * predicts in a chunk of row y + 1 it waits (seldom) for that chunk's
	 * fits. A chunk's columns move to row y + 2 only once the decoder has
	 * reached the chunk after it in row y + 1, by when the fits of row y + 1
	 * that use them are solved. Each task is handed to ROW_POOL only once what
	 * it needs is done, so the tasks never wait. The sums are exact and each
	 * fit is solved as before, so the predictions are the same as row by row
	 * (rowFitRow).
	 */
	static final class RowWave
	{
		/**
		 * The fewest columns in a chunk.
		 */
		static final int CHUNK = 128;
		/**
		 * The fit.
		 */
		final RowFit fit;
		/**
		 * The height.
		 */
		final int ydim;
		/**
		 * The number of chunks.
		 */
		final int chunks;
		/**
		 * Each chunk's first column (and, at chunks, the last interior column + 1).
		 */
		final int[] start;
		/**
		 * Each chunk's first solved pixel (and, at chunks, the number of them).
		 */
		final int[] first;
		/**
		 * Per chunk: the row whose window its columns hold, the row whose fits
		 * have been handed out to be solved, and the row whose fits are solved.
		 */
		final java.util.concurrent.atomic.AtomicIntegerArray moved, handed, solved;
		/**
		 * Each chunk's working arrays (a chunk's tasks never run at the same time).
		 */
		final RowFit.Work[] work;
		/**
		 * The first exception from a task, if any (the decoder throws it).
		 */
		volatile Throwable failed;

		/**
		 * The wavefront for a fit.
		 *
		 * @param fit  the fit (fresh)
		 * @param ydim the height
		 */
		RowWave(RowFit fit, int ydim)
		{
			this.fit  = fit;
			this.ydim = ydim;
			int inner = Math.max(0, fit.xdim - 2), width = Math.max(CHUNK, fit.r + 1);
			chunks = Math.max(1, inner / width);
			start  = new int[chunks + 1];
			first  = new int[chunks + 1];
			for(int t = 0; t <= chunks; t++)
			{
				start[t] = 1 + (int) ((long) t * inner / chunks);
				first[t] = Math.min(fit.points, (start[t] - 1 + fit.every - 1) / fit.every);   // the first solved pixel at or after start[t]
			}
			moved  = new java.util.concurrent.atomic.AtomicIntegerArray(chunks);
			handed = new java.util.concurrent.atomic.AtomicIntegerArray(chunks);
			solved = new java.util.concurrent.atomic.AtomicIntegerArray(chunks);
			work   = new RowFit.Work[chunks];
			for(int t = 0; t < chunks; t++) work[t] = fit.new Work();
		}

		/**
		 * Decodes row y of the channel's deltas and rebuilds it (rows in
		 * order), as rowFitRow, with the fits solved a row ahead: row 1's
		 * before it (rows 0 and 1 have nothing above them to wait for), the
		 * rest while the row before is decoded.
		 *
		 * @param mix   the delta decoder
		 * @param delta the deltas, filled in
		 * @param dst   the values, filled in (the fit's channel)
		 * @param y     the row
		 * @param init  the first value
		 */
		void row(MixedDecoder mix, int[] delta, int[] dst, int y, int init)
		{
			int xdim = fit.xdim;
			if(y == 0 || xdim <= 2 || fit.points == 0) { rowFitRow(mix, fit, delta, dst, xdim, y, init); return; }
			if(y == 1)
			{
				fit.moveTo(1, true);
				fit.solveRow(1, true);
				for(int t = 0; t < chunks; t++) { moved.set(t, 1); handed.set(t, 1); solved.set(t, 1); }
			}
			boolean ahead = y + 1 < ydim;   // whether to solve the next row's fits as this one decodes
			int k = y * xdim;
			mix.next(k, delta, dst);
			dst[k] = dst[k - xdim] + delta[k];
			for(int t = 0; t < chunks; t++)
			{
				await(t, y);
				// The decoder has passed chunk t - 1, and chunk t's fits (the
				// last to use chunk t - 1's columns) are solved.
				if(ahead && t > 0) move(t - 1, y + 1);
				for(int x = start[t]; x < start[t + 1]; x++)
				{
					k++;
					int p = fit.predict(y, x);
					mix.next(k, delta, dst, p);
					dst[k] = delta[k] + p;
				}
			}
			if(ahead) move(chunks - 1, y + 1);
			k++;
			mix.next(k, delta, dst);
			dst[k] = dst[k - 1] + delta[k];
		}

		/**
		 * Waits until chunk t's fits for row y are solved.
		 *
		 * @param t the chunk
		 * @param y the row
		 */
		private void await(int t, int y)
		{
			if(solved.get(t) != y)
				synchronized(this)
				{
					while(solved.get(t) != y && failed == null)
						try { wait(); } catch(InterruptedException e) { Thread.currentThread().interrupt(); throw new RuntimeException(e); }
				}
			Throwable e = failed;
			if(e instanceof RuntimeException) throw (RuntimeException) e;
			if(e instanceof Error) throw (Error) e;
			if(e != null) throw new RuntimeException(e);
		}

		/**
		 * Hands out moving chunk t's columns to row y's window, then the
		 * solving of the fits that then have all their columns.
		 *
		 * @param t the chunk
		 * @param y the row
		 */
		private void move(int t, int y)
		{
			ROW_POOL.execute(() ->
			{
				try
				{
					fit.addColumns(y, start[t], start[t + 1], work[t]);
					moved.set(t, y);
					for(int u = Math.max(0, t - 1); u <= Math.min(chunks - 1, t + 1); u++)
						if(movedAround(u, y) && handed.getAndSet(u, y) != y) solve(u, y);
				}
				catch(Throwable e) { fail(e); }
			});
		}

		/**
		 * Whether chunk u's columns and those of the chunks either side are at row y's window.
		 *
		 * @param u the chunk
		 * @param y the row
		 * @return whether they are
		 */
		private boolean movedAround(int u, int y)
		{
			for(int v = Math.max(0, u - 1); v <= Math.min(chunks - 1, u + 1); v++) if(moved.get(v) != y) return false;
			return true;
		}

		/**
		 * Hands out solving chunk u's fits for row y.
		 *
		 * @param u the chunk
		 * @param y the row
		 */
		private void solve(int u, int y)
		{
			ROW_POOL.execute(() ->
			{
				try
				{
					fit.solvePoints(y, first[u], first[u + 1], work[u]);
					solved.set(u, y);
					synchronized(this) { notifyAll(); }
				}
				catch(Throwable e) { fail(e); }
			});
		}

		/**
		 * Records a task's failure and wakes the decoder.
		 *
		 * @param e the failure
		 */
		private void fail(Throwable e)
		{
			synchronized(this) { if(failed == null) failed = e; notifyAll(); }
		}
	}

	/**
	 * The values of a band's channels from their RowFit deltas, all known
	 * (NativeReader2's: getRowFitDeltas undone, without decoding). As
	 * getValuesFromRowFitChannels rebuilds them: row 0 horizontal, column 0
	 * vertical, the last column horizontal, the interior from the fit, a row
	 * at a time (each row's fits solved on every core first). The channels
	 * are rebuilt at the same time, each a row behind the one before (the
	 * fit at row y uses the channel before's row y). In C when the library
	 * is there (rebuildRowFitChannelsNative: each channel's next row fitted
	 * by a helper thread, a chunk behind it, as the C decoder does).
	 *
	 * @param delta  each channel's deltas, in coding order
	 * @param xdim   the width
	 * @param ydim   the height
	 * @param init   each channel's first value
	 * @param radius each channel's window radius
	 * @param every  how often along a row the fit was solved
	 * @return each channel's values
	 */
	public static int[][] getValuesFromRowFitDeltas(int[][] delta, int xdim, int ydim, int[] init, int[] radius, int every)
	{
		int n = delta.length;
		int[][] value = new int[n][xdim * ydim];
		if(NATIVE && rebuildRowFitChannelsNative(delta, xdim, ydim, init, radius, every, value) == 0) return value;
		int[]   done  = new int[n];          // each channel's rows rebuilt (guarded by done)
		Throwable[] failed = new Throwable[1];
		Thread[] worker = new Thread[n];
		for(int c = 0; c < n; c++)
		{
			final int i = c;
			worker[i] = new Thread(() ->
			{
				try
				{
					int[] d = delta[i], v = value[i];
					RowFit fit = new RowFit(v, (i > 0) ? value[i - 1] : null, xdim, radius[i], every);
					for(int y = 0; y < ydim; y++)
					{
						if(i > 0) awaitRows(done, failed, i - 1, Math.min(ydim, y + 1));
						if(y == 0)
						{
							v[0] = init[i];
							for(int x = 1; x < xdim; x++) v[x] = v[x - 1] + d[x];
						}
						else
						{
							fit.moveTo(y, true);
							fit.solveRow(y, true);
							int k = y * xdim;
							v[k] = v[k - xdim] + d[k];
							for(int x = 1; x < xdim - 1; x++) { k++; v[k] = d[k] + fit.predict(y, x); }
							if(xdim > 1) { k++; v[k] = v[k - 1] + d[k]; }   // (a band 1 wide has only column 0)
						}
						synchronized(done) { done[i] = y + 1; done.notifyAll(); }
					}
				}
				catch(Throwable e) { synchronized(done) { if(failed[0] == null) failed[0] = e; done.notifyAll(); } }
			});
			worker[i].start();
		}
		for(Thread t : worker)
			try { t.join(); } catch(InterruptedException e) { Thread.currentThread().interrupt(); throw new RuntimeException(e); }
		if(failed[0] instanceof RuntimeException) throw (RuntimeException) failed[0];
		if(failed[0] instanceof Error) throw (Error) failed[0];
		if(failed[0] != null) throw new RuntimeException(failed[0]);
		return value;
	}

	/**
	 * Decodes row y of a channel's RowFit deltas and rebuilds it (rows in
	 * order): row 0 horizontal, column 0 vertical, the last column
	 * horizontal, the interior from the fit, its fits solved first.
	 *
	 * @param mix   the delta decoder
	 * @param fit   the fit (over dst)
	 * @param delta the deltas, filled in
	 * @param dst   the values, filled in
	 * @param xdim  the width
	 * @param y     the row
	 * @param init  the first value
	 */
	private static void rowFitRow(MixedDecoder mix, RowFit fit, int[] delta, int[] dst, int xdim, int y, int init)
	{
		if(y == 0)
		{
			mix.next(0, delta, dst);
			dst[0] = init;
			for(int x = 1; x < xdim; x++)
			{
				mix.next(x, delta, dst);
				dst[x] = dst[x - 1] + delta[x];
			}
			return;
		}
		fit.moveTo(y, true);
		fit.solveRow(y, true);
		int k = y * xdim;
		mix.next(k, delta, dst);
		dst[k] = dst[k - xdim] + delta[k];
		for(int x = 1; x < xdim - 1; x++)
		{
			k++;
			int p = fit.predict(y, x);
			mix.next(k, delta, dst, p);
			dst[k] = delta[k] + p;
		}
		k++;
		mix.next(k, delta, dst);
		dst[k] = dst[k - 1] + delta[k];
	}

	// ---- The edges ------------------------------------------------------------
	//
	// Row 0 horizontal, column 0 vertical and the last column horizontal.

	/**
	 * The block map's edges: row 0 horizontal, column 0 vertical, last column
	 * horizontal.
	 *
	 * @param src  the channel
	 * @param dst  the deltas, filled in at the edges
	 * @param xdim the width
	 * @param ydim the height
	 */
	private static void blockEdges(int[] src, int[] dst, int xdim, int ydim)
	{
		for(int x = 1; x < xdim; x++) dst[x] = src[x] - src[x - 1];
		for(int y = 1; y < ydim; y++)
		{
			dst[y * xdim]            = src[y * xdim] - src[(y - 1) * xdim];
			dst[y * xdim + xdim - 1] = src[y * xdim + xdim - 1] - src[y * xdim + xdim - 2];
		}
	}

	// =========================================================================
	// Rank tables on disk
	// =========================================================================

	/**
	 * Writes a StringMapper rank table: short length, then one unsigned byte per
	 * entry if the length is at most 255, otherwise one short per entry.
	 *
	 * @param out   the stream
	 * @param table the table
	 * @throws java.io.IOException if the stream fails
	 */
	public static void writeTable(java.io.DataOutputStream out, int[] table) throws java.io.IOException
	{
		out.writeShort(table.length);
		if(table.length <= 255) for(int v : table) out.writeByte(v);
		else                    for(int v : table) out.writeShort(v);
	}

	/**
	 * Reads a table {@link #writeTable} wrote.
	 *
	 * @param in the stream
	 * @return the table
	 * @throws java.io.IOException if the stream fails
	 */
	public static int[] readTable(java.io.DataInputStream in) throws java.io.IOException
	{
		int   n     = in.readShort();
		int[] table = new int[n];
		if(n <= 255) for(int k = 0; k < n; k++) table[k] = in.readUnsignedByte();
		else         for(int k = 0; k < n; k++) table[k] = in.readShort();
		return table;
	}

	// =========================================================================
	// Context coding of deltas
	// =========================================================================

	// The buckets the mixed models' contexts start from: how busy a pixel's
	// neighbourhood is -- |left| + |above| + |above-left| + |above-right| of
	// the deltas already coded, in 12 buckets -- and the size of the deltas at
	// the same pixel in the channels coded before it (5 buckets).

	/**
	 * Lower limits of the 12 activity buckets: |left| + |above| + |above-left| + |above-right| of the deltas already coded.
	 */
	private static final int[] ACTIVITY_LIMIT = {0, 1, 2, 3, 5, 7, 10, 14, 20, 28, 40, 60};

	/**
	 * Lower limits of the 5 buckets for the size of the deltas at the same pixel in the channels coded before.
	 */
	private static final int[] CROSS_LIMIT    = {0, 1, 3, 6, 12};

	/**
	 * The number of delta contexts.
	 */
	public  static final int   CONTEXTS       = ACTIVITY_LIMIT.length * CROSS_LIMIT.length;

	/**
	 * The bucket a value falls in.
	 *
	 * @param v     a value
	 * @param limit the buckets' lower limits (the first is 0)
	 * @return the last bucket whose lower limit v reaches
	 */
	private static int bucket(int v, int[] limit)
	{
		int b = 0;
		while(b + 1 < limit.length && v >= limit[b + 1]) b++;
		return b;
	}

	// =========================================================================
	// Mixed context coding (from DeltaEncoder's Block format 4)
	//
	// The deltas as ranks (most frequent value = 0), coded with a mixture of
	// adaptive context models. Each model is the context coder's (counts from
	// 1, +CONTEXT_INCREMENT, halved above CONTEXT_LIMIT), with its own context:
	//   0  activity (the buckets above) plus CALIC's gradients of this
	//      channel's values, dh + dv, halved; cross as the buckets above
	//   1  activity plus half the earlier channels' |deltas| to the E, SW, S
	//      and SE (those channels are fully known); cross as the buckets above
	//   2  activity; cross from the earlier channels' 3x3 neighbourhood, / 3
	// The first channel mixes model 0 and the plain activity and cross
	// context (models 1 and 2 would both equal that one).
	// Mixture: C_i(s) = cum_i(s) * 2^MIX_R_BITS / total_i,
	// M(s) = (sum_i w_i C_i(s)) >> MIX_W_BITS + s, out of 2^MIX_R_BITS +
	// the number of symbols (so every symbol has at least 1). The weights are
	// ints summing to 2^MIX_W_BITS, one set per channel, moved after each
	// symbol along the code-length gradient: w_i += w_i (q_i - q) / (q
	// MIX_RATE), at least MIX_WMIN, then rescaled (the remainder to the
	// largest, first on a tie). Cumulative counts by a linear scan from rank
	// 0 (ranks are most frequent first, so the scan is short). Model 0 needs
	// the values decoded so far, so the decoder decodes each delta as it
	// rebuilds the channel (MixedDecoder).
	// Measured on 10 test images: 1.0% smaller than a single context model.
	//
	// With second opinions (as Simple 2 codes): each model's context is
	// also split 9 ways by how far a simple predictor's value lies from the
	// block's prediction, signed (gradientLevel of opinion - prediction):
	// GAP/8 for model 0, MED for model 1 and a (left) for model 2. Where the
	// two disagree the delta tends to be larger and to take the opinion's
	// sign, which activity alone can't show. Only interior pixels have a
	// block prediction; the rest use the middle level. The decoder has the
	// prediction before it decodes the delta. Measured on 10
	// test images (lossless, Color Resolution 3, and Pixel Resolution 4 with
	// Color Resolution 3): 1.95% smaller, 3.06% at the writers' default
	// settings; a weighted predictor (JPEG XL's) as an opinion, or its error
	// as a context, did no better.
	// =========================================================================

	/**
	 * Each model's cumulative counts are scaled to 2<sup>MIX_R_BITS</sup>.
	 */
	static final int MIX_R_BITS = 16;

	/**
	 * The mixing weights sum to 2<sup>MIX_W_BITS</sup>.
	 */
	static final int MIX_W_BITS = 16;
	/**
	 * The symbols in a block of MixedModels' block sums (fb), and its log 2:
	 * decoding passes over whole blocks.
	 */
	static final int MIX_BLOCK_SHIFT = 3, MIX_BLOCK = 1 << MIX_BLOCK_SHIFT;
	/**
	 * MixedModels.rank_average's scale (log 2); above what (16 symbols on
	 * average) decode makes the block sums, and, once it has, above what (8)
	 * it passes over blocks first.
	 */
	static final int MIX_RANK_SHIFT = 5, MIX_BLOCKS_MAKE = 16 << MIX_RANK_SHIFT, MIX_BLOCKS_FIRST = 8 << MIX_RANK_SHIFT;

	/**
	 * The smallest a mixing weight can be.
	 */
	static final int MIX_WMIN   = 256;

	/**
	 * The weights move by 1 / MIX_RATE of the code-length gradient per symbol.
	 */
	static final int MIX_RATE   = 32;

	/**
	 * Each opinion's levels: gradientLevel's -4 to 4.
	 */
	static final int MIX_OPINION_LEVELS = 9;

	/**
	 * The activity bucket of each value 0 to 255 (larger values use the last).
	 */
	private static final int[] MIX_ACTIVITY_TABLE = bucketTable(ACTIVITY_LIMIT, 256);

	/**
	 * The cross bucket of each value 0 to 63 (larger values use the last).
	 */
	private static final int[] MIX_CROSS_TABLE    = bucketTable(CROSS_LIMIT, 64);

	/**
	 * The bucket of each value below size.
	 *
	 * @param limit the buckets' lower limits (the first is 0)
	 * @param size  the table size
	 * @return the table
	 */
	private static int[] bucketTable(int[] limit, int size)
	{
		int[] t = new int[size];
		for(int v = 0; v < size; v++) t[v] = bucket(v, limit);
		return t;
	}

	/**
	 * Ranks the delta values by count, most frequent first (ties: smaller value first).
	 *
	 * @param delta the deltas
	 * @param min   set to the smallest delta, in min[0]
	 * @return the rank of each value, indexed by value - min
	 */
	private static int[] rankTable(int[] delta, int[] min)
	{
		int lo = Integer.MAX_VALUE, hi = Integer.MIN_VALUE;
		for(int v : delta) { if(v < lo) lo = v; if(v > hi) hi = v; }
		int[] count = new int[hi - lo + 1];
		for(int v : delta) count[v - lo]++;
		Integer[] order = new Integer[count.length];
		for(int v = 0; v < count.length; v++) order[v] = v;
		Arrays.sort(order, (a, b) -> (count[a] != count[b]) ? count[b] - count[a] : a - b);
		int[] rank = new int[count.length];
		for(int r = 0; r < order.length; r++) rank[order[r]] = r;
		min[0] = lo;
		return rank;
	}

	/**
	 * The mixed coder's models, weights and contexts for one channel; used the
	 * same way to encode and decode.
	 */
	static final class MixedModels
	{
		/**
		 * The number of models: 3, or 2 for the first channel.
		 */
		final int m;
		/**
		 * The number of symbols (ranks).
		 */
		final int n_symbols;
		/**
		 * The row width.
		 */
		final int xdim;
		/**
		 * Counts by model, context and symbol.
		 */
		final int[][][] f;
		/**
		 * Each model's total count per context.
		 */
		final int[][] total;
		/**
		 * The counts summed by blocks of MIX_BLOCK symbols, by model and
		 * context, so that decode can pass over whole blocks of symbols: made
		 * once the decoded symbols have been large (most channels never do, and
		 * encoding never does), then kept by update.
		 */
		int[][][] fb;
		/**
		 * The number of blocks of symbols.
		 */
		final int blocks;
		/**
		 * The decoded symbols' running average, times 2<sup>MIX_RANK_SHIFT</sup>
		 * (only to choose how decode searches: any way finds the same symbol).
		 */
		long rank_average = 0;
		/**
		 * The bottom of the interval of the block passBlocks stopped at.
		 */
		long block_lo;
		/**
		 * The mixing weights (summing to 2<sup>MIX_W_BITS</sup>).
		 */
		final long[] w;
		/**
		 * Each model's context at the current pixel.
		 */
		final int[] ctx = new int[3];
		/**
		 * Each model's scaled count of the symbol just coded.
		 */
		final long[] q;
		/**
		 * Decoding scratch: each model's cumulative count, and its scaled
		 * cumulative count below and through the symbol being tried.
		 */
		final long[] cum, c0, c1;
		/**
		 * Per pixel, from the earlier channels: the cross bucket, the forward sum
		 * (E, SW, S, SE), and the 3x3 cross bucket; filled a row at a time as
		 * the pixels reach it (see earlierRows).
		 */
		final int[] cb, fwd, c9b;
		/**
		 * The deltas of the channels coded before this one.
		 */
		final int[][] previous;
		/**
		 * Per pixel, the sum of the earlier channels' |deltas|.
		 */
		final int[] cross;
		/**
		 * The rows of cross, and of cb, fwd and c9b, filled so far; and the
		 * pixel where the next row of cb, fwd and c9b is needed.
		 */
		int cross_rows = 0, earlier_rows = 0, earlier_end = 0;
		/**
		 * Whether the contexts include the second opinions (see the section comment).
		 */
		final boolean opinions;
		/**
		 * The block's prediction at the pixel being coded (interior pixels; set
		 * before encode or decode when opinions is true).
		 */
		int prediction;

		/**
		 * The models for a channel, with or without the second opinions.
		 *
		 * @param n_symbols the number of symbols
		 * @param previous  the deltas of the channels coded before this one
		 * @param xdim      the row width
		 * @param n         the number of deltas
		 * @param opinions  whether the contexts include the second opinions
		 */
		MixedModels(int n_symbols, int[][] previous, int xdim, int n, boolean opinions)
		{
			this.n_symbols = n_symbols;
			this.xdim      = xdim;
			this.opinions  = opinions;
			int contexts = opinions ? CONTEXTS * MIX_OPINION_LEVELS : CONTEXTS;
			m     = (previous.length == 0) ? 2 : 3;
			f     = new int[m][contexts][n_symbols];
			total = new int[m][contexts];
			for(int[][] fm : f) for(int[] fc : fm) Arrays.fill(fc, 1);
			for(int[] t : total) Arrays.fill(t, n_symbols);
			blocks = (n_symbols + MIX_BLOCK - 1) / MIX_BLOCK;
			w = new long[m];
			Arrays.fill(w, (1L << MIX_W_BITS) / m);
			w[0] += (1L << MIX_W_BITS) - (1L << MIX_W_BITS) / m * m;
			q = new long[m];
			cum = new long[m]; c0 = new long[m]; c1 = new long[m];
			cb = new int[n]; fwd = new int[n]; c9b = new int[n];
			this.previous = previous;
			cross = (m == 3) ? new int[n] : null;
			earlier_end = (m == 3) ? 0 : Integer.MAX_VALUE;
		}

		/**
		 * Fills cb, fwd and c9b from the earlier channels' deltas up to row y1
		 * (not included), which needs those deltas up to row y1 (included):
		 * done a row at a time as coding reaches it, so a decoder can decode
		 * this channel while the earlier ones are still being decoded, a row or
		 * two ahead (see getValuesFromRowFitChannels).
		 *
		 * @param y1 the row to fill to
		 */
		void earlierRows(int y1)
		{
			int ydim = cb.length / xdim, top = MIX_CROSS_TABLE.length - 1;
			y1 = Math.min(y1, ydim);
			for(int c1 = Math.min(ydim, y1 + 1); cross_rows < c1; cross_rows++)
				for(int k = cross_rows * xdim, end = k + xdim; k < end; k++)
				{
					int t = 0;
					for(int[] p : previous) t += Math.abs(p[k]);
					cross[k] = t;
				}
			for(int y = earlier_rows; y < y1; y++)
				for(int x = 0; x < xdim; x++)
				{
					int k = y * xdim + x, s9 = 0, sum = 0;
					for(int yy = Math.max(0, y - 1); yy < Math.min(ydim, y + 2); yy++)
						for(int xx = Math.max(0, x - 1); xx < Math.min(xdim, x + 2); xx++) s9 += cross[yy * xdim + xx];
					if(x + 1 < xdim) sum += cross[k + 1];
					if(y + 1 < ydim)
					{
						sum += cross[k + xdim];
						if(x > 0)        sum += cross[k + xdim - 1];
						if(x + 1 < xdim) sum += cross[k + xdim + 1];
					}
					cb[k]  = MIX_CROSS_TABLE[Math.min(cross[k], top)];
					c9b[k] = MIX_CROSS_TABLE[Math.min(s9 / 3, top)];
					fwd[k] = sum;
				}
			earlier_rows = Math.max(earlier_rows, y1);
			earlier_end  = (earlier_rows >= ydim) ? Integer.MAX_VALUE : earlier_rows * xdim;
		}

		/**
		 * Sets each model's context at pixel k.
		 *
		 * @param k the pixel
		 * @param d the deltas (read below k only)
		 * @param v the channel's values (read below k only)
		 */
		void contexts(int k, int[] d, int[] v)
		{
			if(k >= earlier_end) earlierRows(k / xdim + 1);
			int x = k % xdim, act = 0, g = 0, top = MIX_ACTIVITY_TABLE.length - 1;
			if(x > 0) act += Math.abs(d[k - 1]);
			if(k >= xdim)
			{
				act += Math.abs(d[k - xdim]);
				if(x > 0)        act += Math.abs(d[k - xdim - 1]);
				if(x < xdim - 1) act += Math.abs(d[k - xdim + 1]);
			}
			if(x >= 2 && k >= 2 * xdim && x < xdim - 1)
			{
				int W = v[k - 1], N = v[k - xdim], NW = v[k - xdim - 1], NE = v[k - xdim + 1];
				g = Math.abs(W - v[k - 2]) + Math.abs(N - NW) + Math.abs(N - NE)
				  + Math.abs(W - NW) + Math.abs(N - v[k - 2 * xdim]) + Math.abs(NE - v[k - 2 * xdim + 1]);
			}
			int c = cb[k];
			ctx[0] = MIX_ACTIVITY_TABLE[Math.min((act + g) >> 1, top)] * CROSS_LIMIT.length + c;
			if(m == 3)
			{
				ctx[1] = MIX_ACTIVITY_TABLE[Math.min(act + (fwd[k] >> 1), top)] * CROSS_LIMIT.length + c;
				ctx[2] = MIX_ACTIVITY_TABLE[Math.min(act, top)] * CROSS_LIMIT.length + c9b[k];
			}
			else ctx[1] = MIX_ACTIVITY_TABLE[Math.min(act, top)] * CROSS_LIMIT.length + c;
			if(opinions)
			{
				int mid = MIX_OPINION_LEVELS / 2, o0 = mid, o1 = mid, o2 = mid;
				if(k >= xdim && x >= 1 && x < xdim - 1)
				{
					int a = v[k - 1], b = v[k - xdim], cc = v[k - xdim - 1], dd = v[k - xdim + 1];
					boolean up2 = k >= 2 * xdim;
					int aa = (x >= 2) ? v[k - 2] : a, bb = up2 ? v[k - 2 * xdim] : b, nne = up2 ? v[k - 2 * xdim + 1] : dd;
					o0 = gradientLevel(gap(a, aa, b, bb, cc, dd, nne, 10, 4, 1) - prediction) + mid;
					o1 = gradientLevel(blockPredictor(11, a, b, cc, dd) - prediction) + mid;
					o2 = gradientLevel(a - prediction) + mid;
				}
				ctx[0] = ctx[0] * MIX_OPINION_LEVELS + o0;
				ctx[1] = ctx[1] * MIX_OPINION_LEVELS + o1;
				if(m == 3) ctx[2] = ctx[2] * MIX_OPINION_LEVELS + o2;
			}
		}

		/**
		 * After coding symbol s (with q set): moves the weights, then counts s.
		 *
		 * @param s the symbol
		 */
		void update(int s)
		{
			long qm = 0;
			for(int j = 0; j < m; j++) qm += w[j] * q[j];
			qm >>= MIX_W_BITS;
			if(qm < 1) qm = 1;
			long t = 0;
			for(int j = 0; j < m; j++)
			{
				w[j] += w[j] * (q[j] - qm) / (qm * MIX_RATE);
				if(w[j] < MIX_WMIN) w[j] = MIX_WMIN;
				t += w[j];
			}
			long t2 = 0;
			int  big = 0;
			for(int j = 0; j < m; j++)
			{
				w[j] = (w[j] << MIX_W_BITS) / t;
				t2  += w[j];
				if(w[j] > w[big]) big = j;
			}
			w[big] += (1L << MIX_W_BITS) - t2;
			for(int j = 0; j < m; j++)
			{
				int[] fc = f[j][ctx[j]];
				fc[s] += ArithmeticMapper.CONTEXT_INCREMENT;
				total[j][ctx[j]] += ArithmeticMapper.CONTEXT_INCREMENT;
				if(total[j][ctx[j]] > ArithmeticMapper.CONTEXT_LIMIT)
				{
					int u = 0;
					for(int i = 0; i < n_symbols; i++) { fc[i] = (fc[i] + 1) >> 1; u += fc[i]; }
					total[j][ctx[j]] = u;
					if(fb != null) blockSums(fc, fb[j][ctx[j]]);
				}
				else if(fb != null) fb[j][ctx[j]][s >> MIX_BLOCK_SHIFT] += ArithmeticMapper.CONTEXT_INCREMENT;
			}
		}

		/**
		 * Sums one model and context's counts by blocks.
		 *
		 * @param fc the counts
		 * @param bc their block sums
		 */
		void blockSums(int[] fc, int[] bc)
		{
			Arrays.fill(bc, 0);
			for(int i = 0; i < n_symbols; i++) bc[i >> MIX_BLOCK_SHIFT] += fc[i];
		}

		/**
		 * Codes symbol s at pixel k and updates the models.
		 *
		 * @param enc the encoder
		 * @param k   the pixel
		 * @param s   the symbol
		 * @param d   the deltas
		 * @param v   the channel's values
		 */
		void encode(ArithmeticMapper.RangeEncoder enc, int k, int s, int[] d, int[] v)
		{
			contexts(k, d, v);
			long a = 0, b = 0;
			for(int j = 0; j < m; j++)
			{
				int[] fc = f[j][ctx[j]];
				long  cs = 0;
				for(int i = 0; i < s; i++) cs += fc[i];
				long  t  = total[j][ctx[j]];
				long  c0 = (cs << MIX_R_BITS) / t, c1 = ((cs + fc[s]) << MIX_R_BITS) / t;
				a += w[j] * c0;
				b += w[j] * c1;
				q[j] = c1 - c0;
			}
			long lo = (a >> MIX_W_BITS) + s, hi = (b >> MIX_W_BITS) + s + 1;
			enc.encode(lo, hi - lo, (1L << MIX_R_BITS) + n_symbols);
			update(s);
		}

		/**
		 * Decodes the symbol at pixel k and updates the models.
		 *
		 * @param dec the decoder
		 * @param k   the pixel
		 * @param d   the deltas (filled below k)
		 * @param v   the channel's values (filled below k)
		 * @return the symbol
		 */
		int decode(ArithmeticMapper.RangeDecoder dec, int k, int[] d, int[] v)
		{
			contexts(k, d, v);
			long t  = dec.target((1L << MIX_R_BITS) + n_symbols);
			int  s  = 0;
			long lo = 0, hi;
			Arrays.fill(cum, 0);
			Arrays.fill(c1, 0);
			// The symbol is the first whose interval's top is above t (the tops
			// rise with the symbol), found a symbol at a time; but once the
			// block sums are made, while the symbols have been large, first
			// pass over whole blocks to the one holding it (passBlocks).
			if(fb != null && rank_average > MIX_BLOCKS_FIRST)
			{
				s  = passBlocks(t);
				lo = block_lo;
			}
			while(true)
			{
				long a = 0;
				for(int j = 0; j < m; j++)
				{
					c0[j]   = c1[j];
					cum[j] += f[j][ctx[j]][s];
					c1[j]   = (cum[j] << MIX_R_BITS) / total[j][ctx[j]];
					a      += w[j] * c1[j];
				}
				hi = (a >> MIX_W_BITS) + s + 1;
				if(t < hi || s == n_symbols - 1) break;
				lo = hi;
				s++;
			}
			for(int j = 0; j < m; j++) q[j] = c1[j] - c0[j];
			dec.decode(lo, hi - lo);
			update(s);
			rank_average += s - (rank_average >> MIX_RANK_SHIFT);
			if(fb == null && rank_average > MIX_BLOCKS_MAKE)
			{
				fb = new int[m][total[0].length][blocks];
				for(int j = 0; j < m; j++) for(int c = 0; c < fb[j].length; c++) blockSums(f[j][c], fb[j][c]);
			}
			return s;
		}

		/**
		 * For decode: passes over whole blocks of symbols while t is above
		 * their tops (from the block sums: the same numbers as a symbol at a
		 * time), never the last block (it ends the search), leaving cum and
		 * c1 as a symbol at a time would at the start of the block it stops at.
		 * Kept out of decode so that decode stays as small as before for the
		 * channels that never use it (most of them).
		 *
		 * @param t the target
		 * @return the first symbol of the block holding the symbol (its interval's bottom in block_lo)
		 */
		int passBlocks(long t)
		{
			int  s  = 0;
			long lo = 0;
			for(int b = 0; b < blocks - 1; b++)
			{
				int  e  = (b << MIX_BLOCK_SHIFT) + MIX_BLOCK - 1;
				long ab = 0;
				for(int j = 0; j < m; j++)
				{
					c0[j] = ((cum[j] + fb[j][ctx[j]][b]) << MIX_R_BITS) / total[j][ctx[j]];
					ab   += w[j] * c0[j];
				}
				long he = (ab >> MIX_W_BITS) + e + 1;
				if(t < he) break;
				for(int j = 0; j < m; j++) { cum[j] += fb[j][ctx[j]][b]; c1[j] = c0[j]; }
				lo = he;
				s  = e + 1;
			}
			block_lo = lo;
			return s;
		}
	}

	/**
	 * The deltas as ranks, mixed-context coded, with or without the second
	 * opinions (the prediction at each pixel is values - delta).
	 *
	 * @param delta    the deltas
	 * @param values   the channel as the decoder rebuilds it (before any minimum is added back)
	 * @param previous the deltas of the channels coded before this one
	 * @param xdim     the row width
	 * @param opinions whether the contexts include the second opinions
	 * @return the coded bytes
	 * @throws java.io.IOException never in practice (a byte stream)
	 */
	public static byte[] packMixedDeltas(int[] delta, int[] values, int[][] previous, int xdim, boolean opinions) throws java.io.IOException
	{
		if(NATIVE)
		{
			byte[] packed = packMixedDeltasNative(delta, values, previous, xdim, opinions);
			if(packed != null) return packed;
		}
		return packMixedDeltasJava(delta, values, previous, xdim, opinions);
	}

	/**
	 * packMixedDeltas in Java (what it does without the C).
	 *
	 * @param delta    the deltas
	 * @param values   the channel as the decoder rebuilds it (before any minimum is added back)
	 * @param previous the deltas of the channels coded before this one
	 * @param xdim     the row width
	 * @param opinions whether the contexts include the second opinions
	 * @return the coded bytes
	 * @throws java.io.IOException never in practice (a byte stream)
	 */
	public static byte[] packMixedDeltasJava(int[] delta, int[] values, int[][] previous, int xdim, boolean opinions) throws java.io.IOException
	{
		int[] min  = new int[1];
		int[] rank = rankTable(delta, min);
		MixedModels models = new MixedModels(rank.length, previous, xdim, delta.length, opinions);
		ArithmeticMapper.RangeEncoder enc = new ArithmeticMapper.RangeEncoder(delta.length / 2);
		for(int k = 0; k < delta.length; k++)
		{
			models.prediction = values[k] - delta[k];
			models.encode(enc, k, rank[delta[k] - min[0]], delta, values);
		}
		byte[] coded = enc.finish();

		java.io.ByteArrayOutputStream bytes = new java.io.ByteArrayOutputStream();
		java.io.DataOutputStream out = new java.io.DataOutputStream(bytes);
		out.writeInt(min[0]);
		writeTable(out, rank);
		out.writeInt(coded.length);
		out.write(coded);
		return bytes.toByteArray();
	}

	/**
	 * A channel's mixed-coded deltas as read, before decoding (which needs the
	 * channel's values as they are rebuilt: MixedDecoder).
	 */
	public static final class MixedDeltas
	{
		/**
		 * The delta value of each rank.
		 */
		final int[]  value;
		/**
		 * The coded bytes.
		 */
		final byte[] coded;
		/**
		 * The coded bytes as they arrive (readArrivingMixedDeltas), or null
		 * when they are all there.
		 */
		final ArithmeticMapper.Arriving arriving;

		/**
		 * Holds what {@link #readMixedDeltas} read.
		 *
		 * @param value the delta value of each rank
		 * @param coded the coded bytes
		 */
		MixedDeltas(int[] value, byte[] coded) { this.value = value; this.coded = coded; arriving = null; }

		/**
		 * Holds what {@link #readArrivingMixedDeltas} read: the coded bytes
		 * are still to arrive.
		 *
		 * @param value    the delta value of each rank
		 * @param arriving the coded bytes, as they arrive
		 */
		MixedDeltas(int[] value, ArithmeticMapper.Arriving arriving) { this.value = value; this.coded = arriving.bytes; this.arriving = arriving; }
	}

	/**
	 * Reads the start of deltas {@link #packMixedDeltas} wrote -- the rank
	 * table and the coded bytes' length -- but not the coded bytes: the
	 * caller reads them into arriving.bytes (in order) and says how many have
	 * arrived as it goes, and a decoder can start on them meanwhile.
	 *
	 * @param in the stream
	 * @return the rank table, and a buffer for the coded bytes
	 * @throws java.io.IOException if the stream fails
	 */
	public static MixedDeltas readArrivingMixedDeltas(java.io.DataInputStream in) throws java.io.IOException
	{
		int    min   = in.readInt();
		int[]  rank  = readTable(in);
		int    n     = in.readInt();
		if(n < 0) throw new java.io.IOException("a coded length of " + n + ".");
		int[] value = new int[rank.length];
		for(int v = 0; v < rank.length; v++) value[rank[v]] = v + min;
		return new MixedDeltas(value, new ArithmeticMapper.Arriving(n));
	}

	/**
	 * Reads deltas {@link #packMixedDeltas} wrote, without decoding them.
	 *
	 * @param in the stream
	 * @return the rank table and coded bytes
	 * @throws java.io.IOException if the stream fails
	 */
	public static MixedDeltas readMixedDeltas(java.io.DataInputStream in) throws java.io.IOException
	{
		int    min   = in.readInt();
		int[]  rank  = readTable(in);
		byte[] coded = new byte[in.readInt()];
		in.readFully(coded);
		int[] value = new int[rank.length];
		for(int v = 0; v < rank.length; v++) value[rank[v]] = v + min;
		return new MixedDeltas(value, coded);
	}

	/**
	 * Decodes packMixedDeltas' bytes, given the prediction at each pixel
	 * (for bytes coded with the second opinions; null for bytes coded
	 * without them).
	 *
	 * @param packed     what packMixedDeltas returned
	 * @param values     the channel's values
	 * @param previous   the deltas of the channels coded before this one
	 * @param xdim       the row width
	 * @param prediction the block's prediction at each pixel, or null
	 * @return the deltas
	 * @throws java.io.IOException if the bytes are short
	 */
	public static int[] unpackMixedDeltas(byte[] packed, int[] values, int[][] previous, int xdim, int[] prediction) throws java.io.IOException
	{
		MixedDeltas md = readMixedDeltas(new java.io.DataInputStream(new java.io.ByteArrayInputStream(packed)));
		MixedDecoder dec = new MixedDecoder(md, previous, xdim, values.length, prediction != null);
		int[] d = new int[values.length];
		for(int k = 0; k < d.length; k++) dec.next(k, d, values, (prediction != null) ? prediction[k] : 0);
		return d;
	}

	/**
	 * Decodes a channel's mixed-coded deltas one at a time, in order.
	 */
	static final class MixedDecoder
	{
		/**
		 * The models.
		 */
		final MixedModels models;
		/**
		 * The range decoder.
		 */
		final ArithmeticMapper.RangeDecoder dec;
		/**
		 * The delta value of each rank.
		 */
		final int[] value;

		/**
		 * A decoder at the first delta.
		 *
		 * @param md       the rank table and coded bytes
		 * @param previous the deltas of the channels decoded before this one
		 * @param xdim     the row width
		 * @param n        the number of deltas
		 * @param opinions whether the contexts include the second opinions
		 */
		MixedDecoder(MixedDeltas md, int[][] previous, int xdim, int n, boolean opinions)
		{
			models = new MixedModels(md.value.length, previous, xdim, n, opinions);
			dec    = (md.arriving != null) ? new ArithmeticMapper.RangeDecoder(md.arriving) : new ArithmeticMapper.RangeDecoder(md.coded);
			value  = md.value;
		}

		/**
		 * Decodes delta k into d[k].
		 *
		 * @param k the pixel (0, 1, 2, ... in turn)
		 * @param d the deltas (filled below k)
		 * @param v the channel's values (filled below k)
		 */
		void next(int k, int[] d, int[] v) { d[k] = value[models.decode(dec, k, d, v)]; }

		/**
		 * As {@link #next(int, int[], int[])}, given the block's prediction at
		 * the pixel (used only with the second opinions, at interior pixels).
		 *
		 * @param k          the pixel (0, 1, 2, ... in turn)
		 * @param d          the deltas (filled below k)
		 * @param v          the channel's values (filled below k)
		 * @param prediction the block's prediction at k
		 */
		void next(int k, int[] d, int[] v, int prediction) { models.prediction = prediction; next(k, d, v); }
	}

}
