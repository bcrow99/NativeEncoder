import java.awt.image.*;
import java.io.*;
import javax.swing.*;

// NativeReader version 1.0 (reads Simple 2 formats 2 and 3, and Huffman
// formats 1 and 2)
//
// Reads NativeWriter's files (and DeltaEncoder's SimpleWriter2's and
// HuffmanWriter's, Simple 2 format 2 and Huffman format 1): the channels
// green, blue-green and red-green (NativeWriter.SET_ID), in bands of rows
// decoded at the same time (with LS deltas, as many at once as the
// processors can run: bandsAtOnce), resized back with ResizeMapper.resize2
// (centred). The file's first byte says how its deltas were coded:
//
//   Simple 2 ('F', context aware): the file is read in stages: each band's
//   channels start decoding as soon as the start of them has been read, and
//   decode their coded bytes as they arrive, while the rest of the file is
//   read; a band's channels are decoded at the same time, each a couple of
//   rows behind the one before (its contexts use their deltas).
//
//   Huffman ('H'): the file is read, then each band's channels' deltas are
//   decoded (CodeMapper's regular Huffman code, then StringMapper's unary
//   strings) and the channels rebuilt from them, the bands at the same time
//   (LS: bandsAtOnce at a time).
//   With its library, the C decodes and rebuilds a band's channels in one
//   call (NativeWriter.rebuildHuffmanChannels: each channel decoded and
//   rebuilt in the same thread, so the first starts rebuilding while the
//   others are still decoding).
//
// The deltas: LS, every interior pixel predicted by the least-squares fit
// from the rows above (DeltaMapper.RowFit, window radius NativeWriter.RADIUS,
// solved at every NativeWriter.EVERY-th pixel along a row; a row's fits are
// solved at the same time, before the row is decoded), or, when the version
// says so, the delta type in the header: Avg, each pixel predicted from
// (left + above) / 2. Then blue, green and red are rebuilt, resized back and
// packed (in C with its library). See NativeWriter.encode for the layout.
/**
 * Reads NativeWriter's files (see the comment above).
 */
public class NativeReader
{
	/**
	 * The image's width and height, Color Resolution and Pixel Resolution.
	 */
	int xdim, ydim, pixel_shift, pixel_quant;
	/**
	 * The deltas' type: NativeWriter.DELTA_LS, or the one the header names.
	 */
	int delta_type;
	/**
	 * The coding: NativeWriter.ENTROPY_MIXED (Simple 2 format) or
	 * ENTROPY_HUFFMAN (Huffman format).
	 */
	int entropy_type;
	/**
	 * Each channel's minimum (added back to the difference channels), in
	 * coding order.
	 */
	int[] min = new int[3];
	/**
	 * The number of bands.
	 */
	int bands;
	/**
	 * Each band's length in bytes.
	 */
	int[] length;
	/**
	 * How long the last decodeFile took to read the file (while decoding).
	 */
	long read_time;

	/**
	 * The decoded image.
	 */
	BufferedImage decoded_image = null;
	/**
	 * The window.
	 */
	ViewerSupport view;

	/**
	 * Reads and shows a file.
	 *
	 * @param args the file
	 */
	public static void main(String[] args)
	{
		ViewerSupport.applyHiDpiFontScaleIfNeeded();
		if(args.length != 1) { System.out.println("Usage: java NativeReader <filename>"); System.exit(0); }
		new NativeReader(args[0]);
	}

	/**
	 * Reads a file's header, opens its window, then reads and decodes the
	 * file (twice, printing both times: the first includes compiling the
	 * code; see decode).
	 *
	 * @param filename the file
	 */
	public NativeReader(String filename)
	{
		try
		{
			try(DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(filename))))
			{
				readHeader(in, filename);
			}
			System.out.println("Image:        " + xdim + " x " + ydim);
			System.out.println("Deltas:       " + NativeWriter.DELTA_NAMES[delta_type]);
			System.out.println("Entropy:      " + NativeWriter.ENTROPY_NAMES[entropy_type]);
			if(bands > 1) System.out.println(NativeWriter.describeBands(bands, DeltaMapper.getQuantizedSize(xdim, ydim, pixel_quant)[1]));
			System.out.println();

			ViewerSupport.runOnEdt(() ->
			{
				view = new ViewerSupport("Native Reader  " + filename, xdim, ydim);
				view.frame.getJMenuBar().add(view.makeViewMenu());
				view.setStatus("decoding...");
				view.show();
			});

			// Read and decoded twice (ViewerSupport.printRunTimes: the first
			// decoding in this Java process includes the JIT's warm-up, so the
			// times are printed apart, the second as the run time). The image
			// shows after the first.
			long start = System.nanoTime(), all = start;
			decoded_image = decodeFile(filename);
			long first = System.nanoTime() - start, first_read = read_time;
			SwingUtilities.invokeLater(() -> { view.setImage(decoded_image); view.setStatus(null); view.fitAndShrink(); });
			start = System.nanoTime();
			BufferedImage again = decodeFile(filename);
			long second = System.nanoTime() - start, both = System.nanoTime() - all;
			int[] p = decoded_image.getRGB(0, 0, xdim, ydim, null, 0, xdim), q = again.getRGB(0, 0, xdim, ydim, null, 0, xdim);
			if(!java.util.Arrays.equals(p, q)) System.out.println("WARNING: the second decoding differs from the first.");
			System.out.println("Image rebuilt (" + xdim + " x " + ydim + "); the file read in " + ViewerSupport.formatDuration(first_read) + ", then "
				+ ViewerSupport.formatDuration(read_time) + ((entropy_type == NativeWriter.ENTROPY_MIXED) ? ", while decoding." : "."));
			System.out.println("Decoder and fit:                  " + DeltaMapper.NATIVE_STATUS);
			ViewerSupport.printRunTimes("NativeReader " + NativeWriter.DELTA_NAMES[delta_type] + " " + NativeWriter.ENTROPY_NAMES[entropy_type], first, second, both);
		}
		catch(Exception e)
		{
			String message = (e instanceof IOException && e.getMessage() != null) ? e.getMessage() : "Can't decode " + filename + ": " + e;
			if(view != null) SwingUtilities.invokeLater(() -> view.setStatus("decode failed"));
			ViewerSupport.showError(view != null ? view.frame : null, message);
			ViewerSupport.exitIfNoWindows();
		}
	}

	/**
	 * Reads the header: the format (so the coding), the image's size, the
	 * quantization, the delta type, the channels' minimums, the number of
	 * bands and their lengths.
	 *
	 * @param in       the file
	 * @param filename its name, for messages
	 * @throws IOException if it can't be read or isn't a file NativeWriter writes
	 */
	private void readHeader(DataInputStream in, String filename) throws IOException
	{
		int id = in.readUnsignedByte(), version = in.readUnsignedByte(), ls_version, type_version;
		if(id == NativeWriter.SIMPLE_ID)
		{
			entropy_type = NativeWriter.ENTROPY_MIXED;
			ls_version   = NativeWriter.SIMPLE_VERSION;
			type_version = NativeWriter.SIMPLE_VERSION_DELTA_TYPE;
		}
		else if(id == NativeWriter.HUFFMAN_ID)
		{
			entropy_type = NativeWriter.ENTROPY_HUFFMAN;
			ls_version   = NativeWriter.HUFFMAN_VERSION;
			type_version = NativeWriter.HUFFMAN_VERSION_DELTA_TYPE;
		}
		else throw new IOException(filename + " is neither a Simple 2 nor a Huffman file.");
		String format = (id == NativeWriter.SIMPLE_ID) ? "Simple 2" : "Huffman";
		if(version != ls_version && version != type_version)
			throw new IOException(filename + " is " + format + " format version " + version + "; this reader reads versions " + ls_version + " and "
			                      + type_version + " only.");
		xdim        = in.readUnsignedShort();
		ydim        = in.readUnsignedShort();
		pixel_shift = in.readByte();
		pixel_quant = in.readByte();
		delta_type  = (version == ls_version) ? NativeWriter.DELTA_LS : in.readUnsignedByte();
		if(delta_type != NativeWriter.DELTA_LS && delta_type != NativeWriter.DELTA_AVERAGE)
			throw new IOException(filename + ": unknown delta type " + delta_type + ".");
		for(int i = 0; i < 3; i++) min[i] = in.readInt();
		int h = DeltaMapper.getQuantizedSize(xdim, ydim, pixel_quant)[1];
		bands = in.readUnsignedByte();
		if(bands < 1 || h / bands < 2) throw new IOException(filename + ": " + bands + " bands of a " + h + "-row image.");
		length = new int[bands];
		for(int b = 0; b < bands; b++) length[b] = in.readInt();
	}

	/**
	 * Reads the file and decodes it, in stages (decode).
	 *
	 * @param filename the file
	 * @return the image
	 * @throws IOException if it can't be read
	 */
	private BufferedImage decodeFile(String filename) throws IOException
	{
		try(InputStream in = new FileInputStream(filename)) { return decode(in, filename); }
	}

	/**
	 * How many coded bytes are read at a time, saying each time that they
	 * have arrived.
	 */
	static final int CHUNK = 1 << 16;

	/**
	 * Reads the header again (decode), checking it's the one the
	 * constructor read.
	 *
	 * @param in   the file, at its start
	 * @param name its name, for messages
	 * @throws IOException if it can't be read or has changed
	 */
	private void checkHeader(DataInputStream in, String name) throws IOException
	{
		int xd = xdim, yd = ydim, nb = bands, dt = delta_type, et = entropy_type;
		int[] len = length;
		readHeader(in, name);
		if(xdim != xd || ydim != yd || bands != nb || delta_type != dt || entropy_type != et || !java.util.Arrays.equals(length, len))
			throw new IOException(name + " changed while it was read.");
	}

	/**
	 * Reads a file NativeWriter wrote from a stream and decodes it
	 * (decodeMixed or decodeHuffman, by its format), then rebuilds blue,
	 * green and red, resizes and shifts them. Leaves the time the reading
	 * took in read_time.
	 *
	 * @param raw  the stream (from the start of the file)
	 * @param name its name, for messages
	 * @return the image
	 * @throws IOException if it can't be read, or isn't the file the header was read from
	 */
	private BufferedImage decode(InputStream raw, String name) throws IOException
	{
		int[]   size = DeltaMapper.getQuantizedSize(xdim, ydim, pixel_quant);
		int     w = size[0];
		int[][] channel = new int[3][w * size[1]];
		if(entropy_type == NativeWriter.ENTROPY_MIXED) decodeMixed(raw, name, w, size[1], channel);
		else                                           decodeHuffman(raw, name, w, size[1], channel);

		// The minimums are added back to the difference channels, then blue,
		// green and red rebuilt, resized back and packed: in C if it's there
		// (all at once, on every core), else in Java.
		BufferedImage image = new BufferedImage(xdim, ydim, BufferedImage.TYPE_INT_RGB);
		if(DeltaMapper.NATIVE)
		{
			int[] add = new int[3];
			for(int i = 0; i < 3; i++) if(NativeWriter.CHANNELS[i] > 2) add[i] = min[i];
			int[][] col = (pixel_quant != 0) ? ResizeMapper.centredMap(w, xdim) : new int[2][];
			int[][] row = (pixel_quant != 0) ? ResizeMapper.centredMap(channel[0].length / w, ydim) : new int[2][];
			// The C writes the pixels straight into the image's own array (as
			// the raster holds them: what setRGB would store), on every core:
			// no array of its own, and no copy into the image afterwards (152
			// MB each, the copy on one thread, for a 7036 x 5394 frame).
			int[] p = ((DataBufferInt) image.getRaster().getDataBuffer()).getData();
			if(DeltaMapper.getPixelsNative(NativeWriter.SET_ID, channel, add, w, channel[0].length / w, col[0], col[1], row[0], row[1], DeltaMapper.RESIZE2,
			                               xdim, ydim, pixel_shift, p, Runtime.getRuntime().availableProcessors()) == 0)
				return image;
		}
		for(int i = 0; i < 3; i++) if(NativeWriter.CHANNELS[i] > 2) for(int k = 0; k < channel[i].length; k++) channel[i][k] += min[i];
		int[][] bgr = DeltaMapper.getBlueGreenRed(NativeWriter.SET_ID, channel[0], channel[1], channel[2]);
		if(pixel_quant != 0) ViewerSupport.parallel(3, c -> bgr[c] = ResizeMapper.resize2(bgr[c], w, xdim, ydim));
		image.setRGB(0, 0, xdim, ydim, DeltaMapper.getPixel(bgr[0], bgr[1], bgr[2], xdim, pixel_shift), 0, xdim);
		return image;
	}

	/**
	 * How many LS bands are decoded at the same time: one for each 6
	 * processors, rounded up. With more bands at once, their threads take
	 * turns on the same processors, each turn bringing another band's fits
	 * (about 2.5 MB a channel on a wide image) back into the caches, and
	 * waiting threads wake each other more often: with all of a 64-band
	 * file's bands at once, LS decoding was up to 3 times slower than in 1
	 * band (on 16 threads, Windows) and a quarter slower (on 4, Linux). The
	 * 6 came from trying 1 band for each 3, 6 and 12 processors on a Ryzen 7
	 * 5700G (8 cores, 16 threads), with 16 and with 8 processors (one a
	 * core): one for each 6 was fastest, or close, for both codings, Mixed
	 * LS (a band's 3 channels and their 3 fit helpers: 6 threads) and
	 * Huffman LS (3 threads a band, and fit helpers if there are processors
	 * to spare). (The average deltas have no fit, and all their bands are
	 * decoded at once: they decoded fastest that way.)
	 *
	 * @return the bands to decode at once
	 */
	private int bandsAtOnce()
	{
		int cores = Runtime.getRuntime().availableProcessors();
		return Math.max(1, Math.min(bands, (cores + 5) / 6));
	}

	/**
	 * Runs body(0), ..., body(bands - 1), at_once at a time, in order: each
	 * thread takes the next band when it's done with one.
	 *
	 * @param at_once the bands at a time
	 * @param body    what to do with a band
	 */
	private void forBands(int at_once, java.util.function.IntConsumer body)
	{
		java.util.concurrent.atomic.AtomicInteger next = new java.util.concurrent.atomic.AtomicInteger();
		ViewerSupport.parallel(at_once, t -> { for(int b = next.getAndIncrement(); b < bands; b = next.getAndIncrement()) body.accept(b); });
	}

	/**
	 * decode for a Simple 2 file (context aware): reads it and decodes it
	 * into channel, in stages. The bands decode in their own threads, all at
	 * once with the average deltas, bandsAtOnce() at a time, in order, with
	 * LS (each band's channels in threads of their own, each a couple
	 * of rows behind the one before: a channel's fit and contexts use the
	 * ones before it), and each channel starts as soon as this thread has
	 * read the start of it (its rank table), decoding its coded bytes as they
	 * arrive, a chunk at a time, while the rest are read
	 * (ArithmeticMapper.Arriving). Leaves the time the reading took in
	 * read_time.
	 *
	 * @param raw     the stream (from the start of the file)
	 * @param name    its name, for messages
	 * @param w       the quantized width
	 * @param h       the quantized height
	 * @param channel gets the channels (w * h each)
	 * @throws IOException if it can't be read, or isn't the file the header was read from
	 */
	private void decodeMixed(InputStream raw, String name, int w, int h, int[][] channel) throws IOException
	{
		int[]   radius = {NativeWriter.RADIUS, NativeWriter.RADIUS, NativeWriter.RADIUS};
		int[][] init = new int[bands][3];
		@SuppressWarnings({"unchecked", "rawtypes"})
		java.util.concurrent.CompletableFuture<DeltaMapper.MixedDeltas>[][] coded = new java.util.concurrent.CompletableFuture[bands][3];
		for(int b = 0; b < bands; b++) for(int i = 0; i < 3; i++) coded[b][i] = new java.util.concurrent.CompletableFuture<>();
		Throwable[] failed = new Throwable[1];
		// The bands' threads, started in order by launcher, at_once at a
		// time: each takes a place in room, and gives it back when done. (An
		// LS band's channels have a fit helper each, so 6 threads a band:
		// NativeReader keeps one, as its decoder, not the fit, sets its pace;
		// see DeltaMapper.fitHelpers.)
		int at_once = (delta_type == NativeWriter.DELTA_LS) ? bandsAtOnce() : bands;
		java.util.concurrent.Semaphore room = new java.util.concurrent.Semaphore(at_once);
		Thread[] worker = new Thread[bands];
		for(int b = 0; b < bands; b++)
		{
			int fb = b;
			worker[b] = new Thread(() ->
			{
				try
				{
					// (The band's values straight into the channels, at its
					// place: no copy afterwards.)
					int y0 = NativeWriter.bandStart(fb, bands, h), y1 = NativeWriter.bandStart(fb + 1, bands, h);
					if(delta_type == NativeWriter.DELTA_AVERAGE)
						DeltaMapper.getValuesFromAverageChannels(coded[fb], w, y1 - y0, init[fb], channel, y0 * w);
					else
						DeltaMapper.getValuesFromRowFitChannels(coded[fb], w, y1 - y0, init[fb], radius, NativeWriter.EVERY, 1, channel, y0 * w);
				}
				catch(Throwable e) { synchronized(failed) { if(failed[0] == null) failed[0] = e; } }
				finally { room.release(); }
			});
		}
		Thread launcher = new Thread(() -> { for(Thread t : worker) { room.acquireUninterruptibly(); t.start(); } });
		launcher.start();
		long start = System.nanoTime();
		java.util.List<ArithmeticMapper.Arriving> arriving = new java.util.ArrayList<>();
		long[] used = new long[1];   // the bytes read so far
		try
		{
			DataInputStream in = new DataInputStream(new FilterInputStream(new BufferedInputStream(raw, CHUNK))
			{
				@Override public int read() throws IOException { int c = super.read(); if(c >= 0) used[0]++; return c; }
				@Override public int read(byte[] b, int off, int len) throws IOException { int n = super.read(b, off, len); if(n > 0) used[0] += n; return n; }
			});
			checkHeader(in, name);
			for(int b = 0; b < bands; b++)
			{
				long end = used[0] + length[b];
				for(int i = 0; i < 3; i++)
				{
					init[b][i] = in.readInt();
					DeltaMapper.MixedDeltas md = DeltaMapper.readArrivingMixedDeltas(in);
					arriving.add(md.arriving);
					coded[b][i].complete(md);
					byte[] buf = md.arriving.bytes;
					for(int got = 0; got < buf.length; )
					{
						int n = in.read(buf, got, Math.min(CHUNK, buf.length - got));
						if(n < 0) throw new EOFException(name + " ends in band " + b + ", channel " + i + ".");
						got += n;
						md.arriving.arrived(got);
					}
				}
				if(used[0] != end) throw new IOException(name + ": band " + b + " is not the length its header says.");
			}
		}
		catch(Throwable e)   // any failure, an Error too (running out of memory, say): otherwise the band threads would wait forever for their bytes
		{
			for(int b = 0; b < bands; b++) for(int i = 0; i < 3; i++) coded[b][i].completeExceptionally(e);
			for(ArithmeticMapper.Arriving a : arriving) a.fail(e);
			// (The launcher first: a thread not yet started can't be waited for.)
			try { launcher.join(); } catch(InterruptedException x) { Thread.currentThread().interrupt(); }
			for(Thread t : worker) try { t.join(); } catch(InterruptedException x) { Thread.currentThread().interrupt(); }
			throw e;
		}
		read_time = System.nanoTime() - start;
		try
		{
			launcher.join();   // (first: a thread not yet started can't be waited for)
			for(Thread t : worker) t.join();
		}
		catch(InterruptedException e) { Thread.currentThread().interrupt(); throw new IOException(e); }
		if(failed[0] instanceof RuntimeException) throw (RuntimeException) failed[0];
		if(failed[0] instanceof Error) throw (Error) failed[0];
		if(failed[0] != null) throw new IOException(failed[0]);
	}

	/**
	 * decode for a Huffman file: reads it all, then decodes it into channel:
	 * every band's channels' deltas at the same time
	 * (NativeWriter.huffmanDecode), then rebuilds each band's channels from
	 * them (DeltaMapper.getValuesFromRowFitDeltas), bandsAtOnce() bands at
	 * a time. Leaves the time the reading took in read_time.
	 *
	 * @param raw     the stream (from the start of the file)
	 * @param name    its name, for messages
	 * @param w       the quantized width
	 * @param h       the quantized height
	 * @param channel gets the channels (w * h each)
	 * @throws IOException if it can't be read, or isn't the file the header was read from
	 */
	private void decodeHuffman(InputStream raw, String name, int w, int h, int[][] channel) throws IOException
	{
		int[]   radius = {NativeWriter.RADIUS, NativeWriter.RADIUS, NativeWriter.RADIUS};
		int[][] init = new int[bands][3];
		NativeWriter.HuffmanChannel[][] coded = new NativeWriter.HuffmanChannel[bands][3];
		long start = System.nanoTime();
		DataInputStream in = new DataInputStream(new BufferedInputStream(raw, CHUNK));
		checkHeader(in, name);
		for(int b = 0; b < bands; b++)
		{
			byte[] band = new byte[length[b]];
			in.readFully(band);
			DataInputStream bi = new DataInputStream(new ByteArrayInputStream(band));
			// Each channel: init, then huffmanCode's bytes.
			for(int i = 0; i < 3; i++)
			{
				init[b][i] = bi.readInt();
				coded[b][i] = NativeWriter.huffmanRead(bi);
			}
			if(bi.available() != 0) throw new IOException(name + ": band " + b + " is not the length its header says.");
		}
		read_time = System.nanoTime() - start;

		// The average deltas: every band's channels decoded (in C if it's
		// there) and rebuilt, each on its own, all at the same time.
		if(delta_type == NativeWriter.DELTA_AVERAGE)
		{
			ViewerSupport.parallel(bands * 3, job ->
			{
				int b = job / 3, i = job % 3;
				int y0 = NativeWriter.bandStart(b, bands, h), y1 = NativeWriter.bandStart(b + 1, bands, h);
				NativeWriter.huffmanAverage(coded[b][i], w, y1 - y0, init[b][i], channel[i], y0 * w);   // (straight into the channel)
			});
		}

		// The fit's deltas, bandsAtOnce() bands at a time (each band's
		// channels in threads of their own, with fit helpers if there are
		// processors to spare): in C, each band's channels decoded and
		// rebuilt at once (a channel starts rebuilding as soon as its deltas
		// are decoded); in Java, its channels' deltas decoded at the same
		// time, then the channels rebuilt.
		int at_once = bandsAtOnce(), helpers = DeltaMapper.fitHelpers(at_once);
		if(delta_type == NativeWriter.DELTA_LS) forBands(at_once, b ->
		{
			int y0 = NativeWriter.bandStart(b, bands, h), y1 = NativeWriter.bandStart(b + 1, bands, h);
			int[][] v = NativeWriter.rebuildHuffmanChannels(coded[b], w, y1 - y0, init[b], radius, helpers);
			if(v == null)
			{
				int[][] delta = new int[3][];
				ViewerSupport.parallel(3, i -> delta[i] = NativeWriter.huffmanDecode(coded[b][i], w * (y1 - y0)));
				v = DeltaMapper.getValuesFromRowFitDeltas(delta, w, y1 - y0, init[b], radius, NativeWriter.EVERY);
			}
			for(int i = 0; i < 3; i++) System.arraycopy(v[i], 0, channel[i], y0 * w, v[i].length);
		});
	}
}
