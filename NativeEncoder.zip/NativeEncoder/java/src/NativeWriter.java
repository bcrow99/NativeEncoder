import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import javax.swing.*;

// NativeWriter version 1.2 (writes Simple 2 formats 2 and 3, Huffman formats 3
// and 4, and Neighbour Huffman format 1)
//
// NativeSimpleWriter and NativeHuffmanWriter in one: the same image, the
// same Apply and the same deltas, with the coding chosen by the Entropy menu.
//
// One channel set, green, blue-green and red-green (SET_ID; the set
// DeltaEncoder's SimpleWriter's analysis picks most often, and within about
// 1% of its choice on the test images). Nothing is coded until Save. Pixel
// Resolution resizes with ResizeMapper.resize2 (centred). The Bands menu
// splits the image into up to MAX_BANDS bands of rows that a reader can
// decode at the same time, for a small cost per band boundary.
//
// The Delta menu chooses the deltas:
//   LS:  every interior pixel predicted by the least-squares fit from the rows
//        above (DeltaMapper.RowFit, the wide clamp: the window is the RADIUS
//        rows above, with none of the pixel's own row, so a reader solves a
//        whole row's fits at the same time before decoding it), solved at
//        every EVERY-th pixel along a row; a channel's fit uses the channel
//        before it. The default.
//   Avg: the classic average filter (DeltaMapper.getAverageDeltasFromValues:
//        each pixel from (left + above) / 2), no fit.
//
// The Entropy menu chooses the coding:
//   Context aware: the deltas context-aware coded with the second opinions
//        (DeltaMapper.packMixedDeltas; a channel's contexts use the deltas
//        of the channels before it). Simple 2 format: 2 with LS, the same
//        files as DeltaEncoder's SimpleWriter2; 3 with Avg (the delta type
//        after the Pixel Resolution). The default.
//   Huffman: each channel's deltas as unary strings by frequency rank
//        (StringMapper.getStringList, its bit-pair transform kept only if it
//        saves enough), then a canonical Huffman code over the strings'
//        bytes (CodeMapper's regular Huffman code), as DeltaEncoder's
//        DeltaWriter2 codes them; no contexts, so a channel's coding uses no
//        other channel. Huffman format: 3 with LS, the same files as
//        DeltaEncoder's HuffmanWriter; 4 with Avg (1 and 2 had the code
//        lengths Deflated: read, not written). Bigger files (on the test
//        photos 9-29% with LS), faster to decode.
//   Neighbour Huffman: each channel's deltas Huffman coded with tables chosen
//        from the neighbours, a run mode and pairs in the quiet parts
//        (NeighbourMapper.neighbourCode). Neighbour Huffman format ('N') 1,
//        the same files as DeltaEncoder's HuffmanWriter2.
//        No contexts across channels, as with Huffman; the format always
//        has the delta type, after the Pixel Resolution. Coded and decoded
//        in C with the library (NeighbourMapper.c).
//
// With its library (DeltaMapper.NATIVE; -Dnative=false for the Java's) the
// fit, the context aware coder and its check, Apply (quantizing, the
// candidates, the preview) and the Huffman strings and code are
// DeltaMapper.c's, StringMapper.c's and CodeMapper.c's: the same files. Save
// prints which was used. Files are read by NativeReader (formats 2 and 1 by
// DeltaEncoder's SimpleReader2 and HuffmanReader too).
/**
 * The native writer: LS or average deltas, context aware or Huffman coded
 * (see the comment above).
 */
public class NativeWriter
{
	/**
	 * A context aware coded file starts with SIMPLE_ID ('F' = Simple 2
	 * format) and its version: SIMPLE_VERSION for the LS deltas,
	 * SIMPLE_VERSION_DELTA_TYPE for the others. Bump them in the writer and
	 * reader together whenever the file layout or a coder's output changes.
	 */
	static final char SIMPLE_ID      = 'F';
	/**
	 * The Simple 2 format's version for the LS deltas: 2 (DeltaEncoder's
	 * SimpleWriter2's; 1 was the fit from 8 neighbours, solved at every 3rd
	 * pixel).
	 */
	static final int  SIMPLE_VERSION = 2;
	/**
	 * The Simple 2 format with the delta type: version 2 with a byte, the
	 * delta type (DELTA_LS or DELTA_AVERAGE), after the Pixel Resolution.
	 * Written for the average deltas.
	 */
	static final int  SIMPLE_VERSION_DELTA_TYPE = 3;
	/**
	 * A Huffman coded file starts with HUFFMAN_ID ('H' = Huffman format) and
	 * its version, as above.
	 */
	static final char HUFFMAN_ID      = 'H';
	/**
	 * The Huffman format's version for the LS deltas: 3 (DeltaEncoder's
	 * HuffmanWriter's), the code lengths coded compactly, with no Deflate
	 * (NeighbourMapper.packLengths).
	 */
	static final int  HUFFMAN_VERSION = 3;
	/**
	 * The Huffman format with the delta type: version 3 with a byte, the
	 * delta type, after the Pixel Resolution. Written for the average deltas.
	 */
	static final int  HUFFMAN_VERSION_DELTA_TYPE = 4;
	/**
	 * The Huffman format's versions before, the same with the code lengths
	 * Deflated (CodeMapper.packRegularTables): 1 for the LS deltas, 2 with
	 * the delta type. Read, not written.
	 */
	static final int  HUFFMAN_VERSION_DEFLATE = 1, HUFFMAN_VERSION_DEFLATE_DELTA_TYPE = 2;
	/**
	 * The entropy types (the Entropy menu): context aware coding
	 * (DeltaMapper.packMixedDeltas), the Simple 2 format.
	 */
	static final int  ENTROPY_MIXED = 0;
	/**
	 * The entropy types (the Entropy menu): Huffman coding (huffmanCode), the
	 * Huffman format.
	 */
	static final int  ENTROPY_HUFFMAN = 1;
	/**
	 * The entropy types (the Entropy menu): neighbour Huffman coding
	 * (NeighbourMapper.neighbourCode), the Neighbour Huffman format.
	 */
	static final int  ENTROPY_NEIGHBOUR = 2;
	/**
	 * The Entropy menu's names for them.
	 */
	static final String[] ENTROPY_NAMES = {"Context aware", "Huffman", "Neighbour Huffman"};
	/**
	 * The formats' ids by entropy type, for the ones after Huffman: the
	 * Neighbour Huffman format, 'N' (HuffmanWriter2's); its version is
	 * FORMAT_VERSION, with the delta type always after the Pixel Resolution.
	 */
	static final char[] FORMAT_IDS = {0, 0, 'N'};
	/**
	 * Its version: 1.
	 */
	static final int  FORMAT_VERSION = 1;
	/**
	 * The delta types (the Delta menu): the least-squares fit from the rows
	 * above (DeltaMapper.RowFit).
	 */
	static final int  DELTA_LS = 0;
	/**
	 * The delta types (the Delta menu): the average of the pixels left and
	 * above (DeltaMapper.getAverageDeltasFromValues).
	 */
	static final int  DELTA_AVERAGE = 1;
	/**
	 * The Delta menu's names for them.
	 */
	static final String[] DELTA_NAMES = {"LS", "Avg"};
	/**
	 * The channel set coded: green, blue-green, red-green (see
	 * DeltaMapper.getChannels).
	 */
	static final int  SET_ID = 7;
	/**
	 * Its channels, in coding order (DeltaMapper's channel ids).
	 */
	static final int[] CHANNELS = DeltaMapper.getChannels(SET_ID);
	/**
	 * The least-squares window radius, for every channel.
	 */
	static final int  RADIUS = 10;
	/**
	 * How often along a row the fit is solved: at every EVERY-th pixel, the
	 * pixels between using the last solution (DeltaMapper.RowFit).
	 */
	static final int  EVERY = 4;
	/**
	 * The most bands Save offers: enough for a reader to use about 96 cores
	 * (three channels' threads a band) on a big image. (The file holds the
	 * number in a byte: at most 255.)
	 */
	static final int  MAX_BANDS = 64;
	/**
	 * The fewest rows (of the quantized image) a band may have: smaller images
	 * get fewer bands.
	 */
	static final int  BAND_MIN_ROWS = 64;

	// ---- Image state --------------------------------------------------------
	/**
	 * The window.
	 */
	ViewerSupport view;
	/**
	 * The image as loaded.
	 */
	BufferedImage original_image;
	/**
	 * The preview.
	 */
	BufferedImage working_image;
	/**
	 * The image's file.
	 */
	String        filename;
	/** The file Save writes (ViewerSupport.DEFAULT_OUTPUT, "foo", unless another is given). */
	String        output_file;
	/**
	 * The image's width and height.
	 */
	int           image_xdim, image_ydim;
	/**
	 * Blue, green and red of the original.
	 */
	int[][]       source;

	// ---- Parameters ---------------------------------------------------------
	/**
	 * The Pixel Resolution (ResizeMapper.resize2's reduction).
	 */
	int pixel_quant = 4;
	/**
	 * The Color Resolution (bits dropped from each value).
	 */
	int pixel_shift = 3;
	/**
	 * The Error Correction (preview only).
	 */
	int correction  = 0;
	/**
	 * How many independently decodable bands Save writes; at most MAX_BANDS,
	 * and fewer if bands would have under BAND_MIN_ROWS rows.
	 */
	int bands       = 1;
	/**
	 * The deltas Save codes: DELTA_LS or DELTA_AVERAGE (the Delta menu).
	 */
	int delta_type  = DELTA_LS;
	/**
	 * The coding Save uses: ENTROPY_MIXED, ENTROPY_HUFFMAN or
	 * ENTROPY_NEIGHBOUR (the Entropy menu).
	 */
	int entropy_type = ENTROPY_MIXED;
	/**
	 * Whether Save checks its coding by decoding it back (the Decode Check
	 * item in the File menu): off unless switched on. The check decodes
	 * every band again, which takes about as long as decoding the file; off,
	 * Save is that much faster, and a file that doesn't decode right is
	 * found by its reader instead (then, with the check back on, Save says
	 * whether the writer or the reader is at fault).
	 */
	boolean decode_check = false;

	/**
	 * The Quantization sliders (Reset moves them).
	 */
	JSlider pquant_slider, pshift_slider, corr_slider;

	// ---- Results of the last Apply (read by Save) ---------------------------
	/**
	 * The channels as quantized, in coding order, each difference channel
	 * less its minimum: what Save codes.
	 */
	int[][]  value_list = new int[3][];
	/**
	 * Each channel's minimum (added back to the difference channels by the
	 * reader), in coding order.
	 */
	int[]    channel_min = new int[3];
	/**
	 * Their width.
	 */
	int      delta_xdim;

	/**
	 * The image file's length.
	 */
	long    file_length;
	/**
	 * The last Apply finished; Save needs it.
	 */
	boolean applied  = false;

	/**
	 * Opens the image named, or one chosen in a file dialog.
	 *
	 * @param args the image, or nothing
	 */
	public static void main(String[] args)
	{
		ViewerSupport.applyHiDpiFontScaleIfNeeded();
		// The image, and the file Save writes ("foo" if none is given).
		if(args.length >= 1) { new NativeWriter(args[0], (args.length > 1) ? args[1] : ViewerSupport.DEFAULT_OUTPUT); return; }
		FileDialog fd = new FileDialog((java.awt.Frame) null, "Open Image", FileDialog.LOAD);
		fd.setVisible(true);
		if(fd.getFile() != null) new NativeWriter(new File(fd.getDirectory(), fd.getFile()).getPath());
		else System.exit(0);
	}

	/**
	 * Loads an image and opens its window.
	 *
	 * @param _filename the image
	 */
	public NativeWriter(String _filename)
	{
		this(_filename, ViewerSupport.DEFAULT_OUTPUT);
	}

	/**
	 * Loads an image and opens its window; Save writes output_file.
	 *
	 * @param _filename    the image
	 * @param _output_file the file Save writes
	 */
	public NativeWriter(String _filename, String _output_file)
	{
		filename    = _filename;
		output_file = _output_file;
		try
		{
			file_length    = new File(filename).length();
			original_image = ViewerSupport.readImage(filename);
		}
		catch(IOException e)
		{
			ViewerSupport.showError(null, e.getMessage());
			ViewerSupport.exitIfNoWindows();
			return;
		}
		image_xdim = original_image.getWidth();
		image_ydim = original_image.getHeight();
		System.out.println(String.format("Loaded %s, %d x %d (%,d pixels)", filename, image_xdim, image_ydim, (long) image_xdim * image_ydim));

		int[] pixel = original_image.getRGB(0, 0, image_xdim, image_ydim, null, 0, image_xdim);
		source = new int[3][pixel.length];
		for(int i = 0; i < pixel.length; i++)
		{
			source[0][i] = (pixel[i] >> 16) & 0xff; source[1][i] = (pixel[i] >> 8) & 0xff; source[2][i] = pixel[i] & 0xff;
		}
		working_image = new BufferedImage(image_xdim, image_ydim, BufferedImage.TYPE_INT_RGB);
		working_image.setRGB(0, 0, image_xdim, image_ydim, pixel, 0, image_xdim);

		view = new ViewerSupport("Native Writer  " + filename, image_xdim, image_ydim);
		JFrame   frame    = view.frame;
		JMenuBar menu_bar = frame.getJMenuBar();

		JMenu file_menu = new JMenu("File");
		JMenuItem open_item = new JMenuItem("Open...");
		open_item.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, InputEvent.CTRL_DOWN_MASK));
		open_item.addActionListener(e -> { FileDialog fd = new FileDialog(frame, "Open Image", FileDialog.LOAD); fd.setVisible(true); if(fd.getFile() != null) new NativeWriter(fd.getDirectory() + fd.getFile()); });
		file_menu.add(open_item); file_menu.addSeparator();
		JMenuItem reset_item = new JMenuItem("Reset");
		reset_item.addActionListener(e -> { pixel_quant = 0; pixel_shift = 0; correction = 0; pquant_slider.setValue(0); pshift_slider.setValue(0); corr_slider.setValue(0); apply(); });
		file_menu.add(reset_item);
		JMenuItem save_item = new JMenuItem("Save"); save_item.addActionListener(new SaveHandler()); file_menu.add(save_item);
		JCheckBoxMenuItem check_item = new JCheckBoxMenuItem("Decode Check", decode_check);
		check_item.addActionListener(e -> decode_check = check_item.isSelected());
		file_menu.add(check_item);

		JMenu quant_menu = new JMenu("Quantization");
		JSlider[] ss = new JSlider[1];
		quant_menu.add(ViewerSupport.makeSliderDialog(frame, "Pixel Resolution", 0, 10, pixel_quant, v -> { pixel_quant = v; apply(); }, ss)); pquant_slider = ss[0];
		quant_menu.add(ViewerSupport.makeSliderDialog(frame, "Color Resolution", 0, 7, pixel_shift, v -> { pixel_shift = v; apply(); }, ss)); pshift_slider = ss[0];
		// Error Correction (below a separator) is not a quantizing step: it blends
		// the preview back toward the original by correction/10. Preview only;
		// the saved file is unaffected.
		quant_menu.addSeparator();
		quant_menu.add(ViewerSupport.makeSliderDialog(frame, "Error Correction", 0, 10, correction, v -> { correction = v; apply(); }, ss)); corr_slider = ss[0];

		// Bands menu: Save codes the image as this many bands of rows, each
		// decodable on its own (so a reader can decode them at the same time),
		// for a small cost per band boundary. Like Save itself, it never
		// changes the preview.
		JMenu bands_menu = new JMenu("Bands");
		JSlider[] bs = new JSlider[1];
		bands_menu.add(ViewerSupport.makeSliderDialog(frame, "Number of Bands", 1, MAX_BANDS, bands, v -> { bands = v; view.setStatus(bandText()); }, bs));

		// Delta menu: the least-squares fit or the average filter. Like Save
		// itself, it never changes the preview.
		JMenu delta_menu = new JMenu("Delta");
		ButtonGroup delta_group = new ButtonGroup();
		for(int t = 0; t < DELTA_NAMES.length; t++)
		{
			int type = t;
			JRadioButtonMenuItem item = new JRadioButtonMenuItem(DELTA_NAMES[t], t == delta_type);
			item.addActionListener(e -> delta_type = type);
			delta_group.add(item);
			delta_menu.add(item);
		}

		// Entropy menu: context aware, Huffman or neighbour Huffman coding. It
		// too only takes effect at Save.
		JMenu entropy_menu = new JMenu("Entropy");
		ButtonGroup entropy_group = new ButtonGroup();
		for(int t = 0; t < ENTROPY_NAMES.length; t++)
		{
			int type = t;
			JRadioButtonMenuItem item = new JRadioButtonMenuItem(ENTROPY_NAMES[t], t == entropy_type);
			item.addActionListener(e -> entropy_type = type);
			entropy_group.add(item);
			entropy_menu.add(item);
		}

		menu_bar.add(file_menu); menu_bar.add(view.makeViewMenu()); menu_bar.add(quant_menu); menu_bar.add(delta_menu); menu_bar.add(entropy_menu); menu_bar.add(bands_menu);

		view.setImage(original_image);
		view.show();
		SwingUtilities.invokeLater(this::apply);
	}

	// ---- Bands --------------------------------------------------------------

	/**
	 * The bands Save will write: bands, but no more than leave BAND_MIN_ROWS
	 * rows in each.
	 *
	 * @return the number of bands
	 */
	int bandsUsed()
	{
		int rows = DeltaMapper.getQuantizedSize(image_xdim, image_ydim, pixel_quant)[1];
		return Math.max(1, Math.min(bands, rows / BAND_MIN_ROWS));
	}

	/**
	 * A band's first row.
	 *
	 * @param b    the band (n for the end of the last)
	 * @param n    the number of bands
	 * @param rows the rows split into them
	 * @return the row
	 */
	static int bandStart(int b, int n, int rows) { return (int) ((long) b * rows / n); }

	/**
	 * The bands in words: "8 bands of 375 rows" (or "of 374 to 375 rows").
	 *
	 * @param n    the number of bands
	 * @param rows the rows split into them
	 * @return the description
	 */
	static String describeBands(int n, int rows)
	{
		int lo = rows / n, hi = (rows + n - 1) / n;
		return n + " bands of " + ((lo == hi) ? lo : lo + " to " + hi) + " rows";
	}

	/**
	 * The Bands dialog's status line.
	 *
	 * @return the bands Save will write, in words
	 */
	private String bandText()
	{
		int n = bandsUsed();
		if(n == 1) return (bands > 1) ? "1 band: the image is too small for more" : "1 band";
		return describeBands(n, DeltaMapper.getQuantizedSize(image_xdim, image_ydim, pixel_quant)[1]);
	}

	// ---- Apply --------------------------------------------------------------

	/**
	 * Blue, green and red, resized and quantized.
	 *
	 * @param size  the quantized size
	 * @param quant the Pixel Resolution
	 * @param shift the Color Resolution
	 * @return the channels
	 */
	int[][] quantizedChannels(int[] size, int quant, int shift)
	{
		int[][] q = new int[3][];
		ViewerSupport.parallel(3, i ->
		{
			int[] ch = source[i];
			if(quant != 0) ch = ResizeMapper.resize2(ch, image_xdim, size[0], size[1]);
			q[i] = DeltaMapper.quantizeChannel(ch, shift);
		});
		return q;
	}

	/**
	 * Quantizes (the channels Save codes), then rebuilds the image for the
	 * preview.
	 */
	void apply()
	{
		applied = false;
		try { applyImpl(); applied = true; }
		catch(Exception e) { System.out.println("Apply: " + e); e.printStackTrace(); }
	}

	/**
	 * Apply's work (apply catches its exceptions).
	 */
	private void applyImpl()
	{
		int[]   size = DeltaMapper.getQuantizedSize(image_xdim, image_ydim, pixel_quant);
		int     new_xdim = size[0];
		int     threads = Runtime.getRuntime().availableProcessors();
		int[]   min = new int[6];
		int[][] q = null, qc = null;
		// The quantized channels and the candidates: in C if it's there (on
		// every core), else in Java.
		if(DeltaMapper.NATIVE)
		{
			int[][] col = (pixel_quant != 0) ? ResizeMapper.centredMap(image_xdim, size[0]) : new int[2][];
			int[][] row = (pixel_quant != 0) ? ResizeMapper.centredMap(image_ydim, size[1]) : new int[2][];
			int[][] nq = new int[3][size[0] * size[1]], diff = new int[3][size[0] * size[1]];
			if(DeltaMapper.applyQuantizeNative(source, image_xdim, image_ydim, size[0], size[1], col[0], col[1], row[0], row[1],
			                                   pixel_shift, nq, diff, min, threads) == 0)
			{
				q  = nq;
				qc = new int[][] {nq[0], nq[1], nq[2], diff[0], diff[1], diff[2]};
			}
		}
		if(q == null)
		{
			q  = quantizedChannels(size, pixel_quant, pixel_shift);
			qc = DeltaMapper.getCandidateChannels(q[0], q[1], q[2], min);
		}
		int[][] v = new int[3][];
		int[]   m = new int[3];
		for(int i = 0; i < 3; i++) { v[i] = qc[CHANNELS[i]]; m[i] = min[CHANNELS[i]]; }
		value_list  = v;
		channel_min = m;
		delta_xdim  = new_xdim;

		// Like NativeReader: resize (centred: resize2), then shift. The reader
		// rebuilds blue, green and red exactly as quantized, so the preview
		// uses them as they are: no need to decode. In C if it's there (its
		// pixels are as the raster holds them, so they're copied in a row at
		// a time), else in Java.
		if(DeltaMapper.NATIVE)
		{
			int[][] col = (pixel_quant != 0) ? ResizeMapper.centredMap(new_xdim, image_xdim) : new int[2][];
			int[][] row = (pixel_quant != 0) ? ResizeMapper.centredMap(size[1], image_ydim) : new int[2][];
			int[] pixel = new int[image_xdim * image_ydim];
			if(DeltaMapper.applyPreviewNative(q, new_xdim, size[1], col[0], col[1], row[0], row[1], image_xdim, image_ydim,
			                                  pixel_shift, correction, source, pixel, threads) == 0)
			{
				working_image.getRaster().setDataElements(0, 0, image_xdim, image_ydim, pixel);
				view.setImage(working_image);
				return;
			}
		}
		int[][] bgr = q.clone();
		ViewerSupport.parallel(3, c ->
		{
			if(pixel_quant != 0) bgr[c] = ResizeMapper.resize2(bgr[c], new_xdim, image_xdim, image_ydim);
			if(pixel_shift != 0) bgr[c] = DeltaMapper.shift(bgr[c], pixel_shift);
		});

		int[] rgb = new int[image_xdim * image_ydim];
		double f = correction / 10.0;
		for(int i = 0; i < rgb.length; i++)
		{
			int b = bgr[0][i], g = bgr[1][i], r = bgr[2][i];
			if(correction != 0) { b += (int)((source[0][i] - b) * f); g += (int)((source[1][i] - g) * f); r += (int)((source[2][i] - r) * f); }
			rgb[i] = (b << 16) + (g << 8) + r;
		}
		working_image.setRGB(0, 0, image_xdim, image_ydim, rgb, 0, image_xdim);
		view.setImage(working_image);
	}

	// ---- Save ---------------------------------------------------------------

	/**
	 * File &gt; Save: codes the image (encode) into output_file ("foo" unless another is given), twice, and
	 * prints both times (the first includes compiling the code), without the
	 * decode check, and the check's time.
	 */
	class SaveHandler implements ActionListener
	{
		/**
		 * A handler for the Save item.
		 */
		SaveHandler() {}

		/**
		 * Saves.
		 *
		 * @param event the menu item's event
		 */
		public void actionPerformed(ActionEvent event)
		{
			if(!applied) apply();
			if(!applied) { ViewerSupport.showError(view.frame, "Nothing saved: the last Apply failed."); return; }
			// The image is coded twice (ViewerSupport.printRunTimes: the first
			// run of each coding's first Save includes the JIT's warm-up, so
			// its times are printed apart; after that, the two timed together,
			// halved). Both leave out the decode check (if it's on: the Decode
			// Check item), which is timed on its own. Both give the same bytes.
			File file = new File(output_file);
			long[] took = new long[2], check = new long[2];
			long   both;
			try
			{
				// Each run timed, and the two together (the decode checks taken
				// out of both); the bytes compared after them.
				byte[][] got = new byte[2][];
				long all = System.nanoTime();
				for(int pass = 0; pass < 2; pass++)
				{
					ByteArrayOutputStream bytes = new ByteArrayOutputStream();
					long start = System.nanoTime();
					check[pass] = encode(new DataOutputStream(bytes), value_list, channel_min, delta_xdim, image_xdim, image_ydim, pixel_shift, pixel_quant, bandsUsed(), delta_type, entropy_type, decode_check);
					took[pass] = System.nanoTime() - start - check[pass];
					got[pass] = bytes.toByteArray();
				}
				both = System.nanoTime() - all - check[0] - check[1];
				if(!Arrays.equals(got[0], got[1])) System.out.println("WARNING: the second coding differs from the first.");
				byte[] data = got[1];
				try(OutputStream out = new BufferedOutputStream(new FileOutputStream(file))) { out.write(data); }
			}
			catch(Exception e)
			{
				file.delete();
				ViewerSupport.showError(view.frame, "Save failed: " + e);
				e.printStackTrace();
				return;
			}
			int n = bandsUsed(), raw = image_xdim * image_ydim * 3, rows = value_list[0].length / delta_xdim;
			if(n > 1) System.out.println(String.format("Saved %s: %,d bytes (%s)", file.getName(), file.length(), describeBands(n, rows)));
			else      System.out.println(String.format("Saved %s: %,d bytes", file.getName(), file.length()));
			System.out.println(String.format("Coded %d x %d (%,d pixels), %s deltas, %s", delta_xdim, rows, (long) delta_xdim * rows, DELTA_NAMES[delta_type], ENTROPY_NAMES[entropy_type]));
			System.out.println("Fit and coder:                    " + DeltaMapper.NATIVE_STATUS);
			boolean averaged = ViewerSupport.printRunTimes("NativeWriter " + DELTA_NAMES[delta_type] + " " + ENTROPY_NAMES[entropy_type], took[0], took[1], both);
			long    check_time = averaged ? (check[0] + check[1]) / 2 : check[1];
			System.out.println("Decode check:                     " + (decode_check ? ViewerSupport.formatDuration(check_time) : "off"));
			System.out.println("Timeline (second run):            " + last_timeline);
			System.out.println("Original compression rate: " + String.format("%.4f", (double) file_length / raw));
			System.out.println("Output  compression rate:  " + String.format("%.4f", (double) file.length() / raw));
			System.out.println();
		}
	}

	/**
	 * The last encode's timeline (from its start: when each channel's fit
	 * ended, when each channel's coding ended, when all were coded), which
	 * Save prints.
	 */
	static volatile String last_timeline = "";

	/**
	 * Codes the channels and writes the file. Header: the format's id and
	 * version (SIMPLE_ID or HUFFMAN_ID: the version for LS, or the one with
	 * the delta type; or FORMAT_IDS[entropy_type] and FORMAT_VERSION), width,
	 * height (unsigned shorts), pixel_shift, pixel_quant, the delta type (an
	 * unsigned byte, only in the versions with it); per channel (coding order) int min; the number of bands n (an
	 * unsigned byte), n int lengths, and the n bands. Band b is rows
	 * bandStart(b) to bandStart(b + 1) of the quantized image, coded as an
	 * image of its own (the fit and the contexts start again at its top): per
	 * channel (green, blue-green, red-green), int init, then its deltas
	 * coded: context aware (DeltaMapper.packMixedDeltas, with the second
	 * opinions), or on its own (codeChannel: Huffman or neighbour Huffman;
	 * see there). The
	 * deltas: LS, from the least-squares fit from the rows above
	 * (DeltaMapper.RowFit: radius RADIUS, solved at every EVERY-th pixel
	 * along a row; channels 1 and 2 use the ones before them), or the
	 * average of the pixels left and above
	 * (DeltaMapper.getAverageDeltasFromValues). With the context aware coding
	 * a channel's contexts use the deltas of the channels before it, so a
	 * band's channels are decoded in order, each a couple of rows behind the
	 * one before; the bands can be decoded at the same time.
	 * <p>
	 * With LS, each channel is fitted once over the whole image (the fit
	 * splits itself across the cores); the bands' deltas come from it, with
	 * only each band's first rows fitted again
	 * (DeltaMapper.getRowFitBandDeltas). The average deltas are found a band
	 * at a time, all at once. A channel's coding needs only the deltas of
	 * the channels before it (context aware) or its own (Huffman), so its
	 * bands are coded while the next channel is fitted. Once everything is
	 * coded, each band's channels are checked by decoding them back, at the
	 * same time (unless check is false); the time that took is returned, so
	 * the coding can be timed without it.
	 *
	 * @param out          the stream
	 * @param value        the channels as quantized, in coding order (difference channels less their minimum)
	 * @param min          each channel's minimum, in coding order
	 * @param xdim         their width
	 * @param image_xdim   the image's width
	 * @param image_ydim   the image's height
	 * @param pixel_shift  the Color Resolution
	 * @param pixel_quant  the Pixel Resolution
	 * @param n            the number of bands
	 * @param delta_type   DELTA_LS or DELTA_AVERAGE
	 * @param entropy_type ENTROPY_MIXED, ENTROPY_HUFFMAN or ENTROPY_NEIGHBOUR
	 * @param check        whether to check the coding by decoding it back (the Decode Check menu item)
	 * @return the time the decode check took, in nanoseconds (0 without it)
	 * @throws IOException if the stream fails
	 */
	static long encode(DataOutputStream out, int[][] value, int[] min, int xdim, int image_xdim, int image_ydim, int pixel_shift, int pixel_quant, int n,
	                   int delta_type, int entropy_type, boolean check) throws IOException
	{
		boolean alone = entropy_type != ENTROPY_MIXED;   // each channel coded on its own
		long check_time = 0, start = System.nanoTime();
		long[] fit_done = new long[3], code_done = new long[3];   // when each channel's deltas, and its last band's coding, were done
		int rows = value[0].length / xdim;
		int[][][]  d = new int[n][3][];      // [band][channel]
		byte[][][] coded = new byte[n][3][];
		ExecutorService coder = Executors.newFixedThreadPool(Math.max(1, Math.min(3 * n, Runtime.getRuntime().availableProcessors())));
		ExecutorService fitter = Executors.newFixedThreadPool(3);
		java.util.List<Future<?>> jobs = new ArrayList<>();
		try
		{
			// The average deltas take no fit: they're found here, a band at a
			// time, all at once (each band's channel is a single pass).
			if(delta_type == DELTA_AVERAGE)
			{
				ViewerSupport.parallel(3 * n, job ->
				{
					int b = job / 3, i = job % 3;
					int y0 = bandStart(b, n, rows), y1 = bandStart(b + 1, n, rows);
					d[b][i] = new int[(y1 - y0) * xdim];
					DeltaMapper.getAverageDeltas(value[i], y0 * xdim, xdim, y1 - y0, d[b][i]);   // (straight from the channel: no copy of the band)
				});
				long now = System.nanoTime();
				for(int i = 0; i < 3; i++) fit_done[i] = now;
			}
			// The three channels' fits at the same time: each needs only its
			// channel and the one before, all known (each still splits into
			// bands of rows on every core). The coding of channel i waits only
			// for the fits of channels 0 to i (context aware: its contexts use
			// their deltas), or its own (Huffman).
			java.util.List<Future<int[]>> fits = new ArrayList<>();
			for(int i = 0; i < 3 && delta_type == DELTA_LS; i++)
			{
				int[] v = value[i], ref = (i > 0) ? value[i - 1] : null;
				int fi = i;
				fits.add(fitter.submit(() ->
				{
					int[] deltas = DeltaMapper.getRowFitDeltas(v, ref, xdim, rows, RADIUS, EVERY);
					fit_done[fi] = System.nanoTime();
					return deltas;
				}));
			}
			for(int i = 0; i < 3; i++)
			{
				int   fi = i;
				int[] ref = (i > 0) ? value[i - 1] : null;
				int[] whole = (delta_type == DELTA_LS) ? result(fits.get(i)) : null;
				// Each band's deltas from the whole channel's: only its first
				// rows fitted again, all the bands at the same time (one after
				// another, 64 bands took about half a second a channel).
				if(delta_type == DELTA_LS && n == 1) d[0][i] = whole;
				else if(delta_type == DELTA_LS)
					ViewerSupport.parallel(n, b ->
					{
						int y0 = bandStart(b, n, rows), y1 = bandStart(b + 1, n, rows);
						d[b][fi] = DeltaMapper.getRowFitBandDeltas(whole, value[fi], ref, xdim, y0, y1, RADIUS, EVERY);
					});
				for(int b = 0; b < n; b++)
				{
					int fb = b;
					jobs.add(coder.submit(() ->
					{
						if(alone) coded[fb][fi] = codeChannel(entropy_type, d[fb][fi], xdim);
						else
						{
							// (The band's values straight from the channel, at its
							// offset: no copy of the band.)
							int     y0 = bandStart(fb, n, rows);
							int[][] previous = Arrays.copyOf(d[fb], fi);
							coded[fb][fi] = DeltaMapper.packMixedDeltas(d[fb][fi], value[fi], y0 * xdim, previous, xdim, true);
						}
						long now = System.nanoTime();
						synchronized(code_done) { code_done[fi] = Math.max(code_done[fi], now); }
						return null;
					}));
				}
			}
			waitFor(jobs);
			// The check, once everything is coded (so its time can be told
			// apart): each band's channels decoded back, at the same time.
			long checked = System.nanoTime(), coded_all = checked;
			jobs.clear();
			for(int b = 0; b < n && check; b++)
				for(int i = 0; i < 3; i++)
				{
					int fb = b, fi = i;
					jobs.add(coder.submit(() ->
					{
						int[] dd = d[fb][fi];
						boolean same;
						if(alone)
						{
							int[] back = decodeChannel(entropy_type, readChannel(entropy_type, new DataInputStream(new ByteArrayInputStream(coded[fb][fi]))),
							                           xdim, dd.length / xdim);
							// (Delta 0 isn't coded: the band's first value, init, is written instead.)
							same = back.length == dd.length;
							for(int k = 1; k < dd.length && same; k++) same = back[k] == dd[k];
						}
						else
						{
							int y0 = bandStart(fb, n, rows), y1 = bandStart(fb + 1, n, rows);
							int[][] previous = Arrays.copyOf(d[fb], fi);
							int check_c = DeltaMapper.NATIVE ? DeltaMapper.checkMixedDeltasNative(coded[fb][fi], dd, value[fi], y0 * xdim, previous, xdim) : -1;
							if(check_c < 0)
							{
								int[] ch = (n == 1) ? value[fi] : Arrays.copyOfRange(value[fi], y0 * xdim, y1 * xdim);
								int[] p = new int[ch.length];
								for(int k = 0; k < p.length; k++) p[k] = ch[k] - dd[k];
								check_c = Arrays.equals(DeltaMapper.unpackMixedDeltas(coded[fb][fi], ch, previous, xdim, p), dd) ? 1 : 0;
							}
							same = check_c == 1;
						}
						if(!same)
							System.out.println("WARNING: band " + fb + " channel " + fi + " deltas do not decode back.");
						return null;
					}));
				}
			waitFor(jobs);
			check_time = check ? System.nanoTime() - checked : 0;
			last_timeline = String.format(((delta_type == DELTA_LS) ? "fits" : "deltas") + " done at %.0f, %.0f, %.0f ms; codings at %.0f, %.0f, %.0f ms; all coded at %.0f ms",
				(fit_done[0] - start) / 1e6, (fit_done[1] - start) / 1e6, (fit_done[2] - start) / 1e6,
				(code_done[0] - start) / 1e6, (code_done[1] - start) / 1e6, (code_done[2] - start) / 1e6, (coded_all - start) / 1e6);
		}
		finally { coder.shutdownNow(); fitter.shutdownNow(); }

		byte[][] band = new byte[n][];
		for(int b = 0; b < n; b++)
		{
			int y0 = bandStart(b, n, rows);
			ByteArrayOutputStream bytes = new ByteArrayOutputStream();
			DataOutputStream bo = new DataOutputStream(bytes);
			for(int i = 0; i < 3; i++) { bo.writeInt(value[i][y0 * xdim]); bo.write(coded[b][i]); }
			band[b] = bytes.toByteArray();
		}
		boolean with_type = delta_type != DELTA_LS;
		if(entropy_type == ENTROPY_HUFFMAN)    { out.writeByte(HUFFMAN_ID); out.writeByte(with_type ? HUFFMAN_VERSION_DELTA_TYPE : HUFFMAN_VERSION); }
		else if(entropy_type == ENTROPY_MIXED) { out.writeByte(SIMPLE_ID);  out.writeByte(with_type ? SIMPLE_VERSION_DELTA_TYPE  : SIMPLE_VERSION); }
		else                                   { out.writeByte(FORMAT_IDS[entropy_type]); out.writeByte(FORMAT_VERSION); with_type = true; }
		out.writeShort(image_xdim); out.writeShort(image_ydim);
		out.writeByte(pixel_shift); out.writeByte(pixel_quant);
		if(with_type) out.writeByte(delta_type);
		for(int i = 0; i < 3; i++) out.writeInt(min[i]);
		out.writeByte(n);
		for(int b = 0; b < n; b++) out.writeInt(band[b].length);
		for(int b = 0; b < n; b++) out.write(band[b]);
		return check_time;
	}

	// ---- Huffman coding -----------------------------------------------------

	// ---- The codings that code a channel on its own --------------------------

	/**
	 * A channel's deltas coded on their own: Huffman (huffmanCode) or neighbour
	 * Huffman (NeighbourMapper.neighbourCode); see there for the layouts.
	 *
	 * @param entropy_type the coding (not ENTROPY_MIXED)
	 * @param delta        the deltas
	 * @param xdim         their width
	 * @return the coded bytes
	 * @throws IOException never in practice (a byte stream)
	 */
	static byte[] codeChannel(int entropy_type, int[] delta, int xdim) throws IOException
	{
		switch(entropy_type)
		{
			case ENTROPY_HUFFMAN:         return huffmanCode(delta);
			case ENTROPY_NEIGHBOUR:       return neighbourCode(delta, xdim);
			default: throw new IllegalArgumentException("not a coding of a channel on its own: " + entropy_type);
		}
	}

	/**
	 * Reads a channel's coding codeChannel wrote (the coded bytes, read into
	 * the coding's own form, to be decoded by decodeChannel).
	 *
	 * @param entropy_type the coding (not ENTROPY_MIXED)
	 * @param in           the stream, at the start of it
	 * @return the coding
	 * @throws IOException if the stream fails or isn't what codeChannel writes
	 */
	static Object readChannel(int entropy_type, DataInputStream in) throws IOException
	{
		switch(entropy_type)
		{
			case ENTROPY_HUFFMAN:         return huffmanRead(in);
			case ENTROPY_NEIGHBOUR:       return NeighbourMapper.neighbourRead(in);
			default: throw new IllegalArgumentException("not a coding of a channel on its own: " + entropy_type);
		}
	}

	/**
	 * A channel's deltas from its coding (readChannel's).
	 *
	 * @param entropy_type the coding (not ENTROPY_MIXED)
	 * @param coding       readChannel's result
	 * @param xdim         the width
	 * @param ydim         the band's height
	 * @return the deltas (delta 0 is 0)
	 * @throws IOException if the coding isn't what codeChannel writes
	 */
	static int[] decodeChannel(int entropy_type, Object coding, int xdim, int ydim) throws IOException
	{
		switch(entropy_type)
		{
			case ENTROPY_HUFFMAN:         return huffmanDecode((HuffmanChannel) coding, xdim * ydim);
			case ENTROPY_NEIGHBOUR:       return neighbourDecode((NeighbourMapper.NeighbourChannel) coding, xdim, ydim);
			default: throw new IllegalArgumentException("not a coding of a channel on its own: " + entropy_type);
		}
	}

	// ---- Neighbour Huffman coding and decoding in C -----------------------

	/**
	 * A channel's deltas neighbour Huffman coded: in C when the library is
	 * there (neighbourCodeNative: the same bytes), else the Java's
	 * (NeighbourMapper.neighbourCode, see there for the layout).
	 *
	 * @param delta the deltas (not changed)
	 * @param xdim  their width
	 * @return the coded bytes
	 * @throws IOException never in practice (a byte stream)
	 */
	static byte[] neighbourCode(int[] delta, int xdim) throws IOException
	{
		if(DeltaMapper.NATIVE)
		{
			int[]  info = new int[2];
			byte[] code = neighbourCodeNative(delta, xdim, info);
			if(code != null)
			{
				ByteArrayOutputStream bytes = new ByteArrayOutputStream(code.length + 12);
				DataOutputStream out = new DataOutputStream(bytes);
				out.writeInt(info[0]);
				out.writeInt(info[1]);
				out.writeInt(code.length);
				out.write(code);
				return bytes.toByteArray();
			}
		}
		return NeighbourMapper.neighbourCode(delta, xdim);
	}

	/**
	 * NeighbourMapper.neighbourCode's bit stream in C (NeighbourMapper_code in
	 * native/NeighbourMapper.c): the same bytes.
	 *
	 * @param delta the deltas (delta 0 taken as 0)
	 * @param xdim  their width
	 * @param info  gets the smallest delta and the number of delta values
	 * @return the bit stream, or null if the C couldn't (out of memory)
	 */
	static native byte[] neighbourCodeNative(int[] delta, int xdim, int[] info);

	/**
	 * A channel's deltas from its neighbour Huffman coding. In C when the
	 * library is there (neighbourDecodeNative: the same deltas); the Java's
	 * (NeighbourMapper.neighbourDecode) if it isn't, or if the C finds
	 * something wrong (the Java then says what).
	 *
	 * @param h    the coding
	 * @param xdim the width
	 * @param ydim the band's height
	 * @return the deltas (delta 0 is 0)
	 * @throws IOException if the coding isn't what neighbourCode writes
	 */
	static int[] neighbourDecode(NeighbourMapper.NeighbourChannel h, int xdim, int ydim) throws IOException
	{
		int[] delta = new int[xdim * ydim];
		if(DeltaMapper.NATIVE && neighbourDecodeNative(h.code, h.lo, h.values, xdim, ydim, delta) == 0) return delta;
		return NeighbourMapper.neighbourDecode(h, xdim, ydim);
	}

	/**
	 * A band's channel neighbour Huffman decoded and rebuilt from its average
	 * deltas, into dst from offset on: in C when the library is there
	 * (neighbourAverageNative), else the Java's.
	 *
	 * @param h      the channel's coding
	 * @param xdim   the width
	 * @param ydim   the band's height
	 * @param init   its first value
	 * @param dst    gets the values
	 * @param offset where they start in dst
	 * @throws IOException if the coding isn't what neighbourCode writes
	 */
	static void neighbourAverage(NeighbourMapper.NeighbourChannel h, int xdim, int ydim, int init, int[] dst, int offset) throws IOException
	{
		if(DeltaMapper.NATIVE && neighbourAverageNative(h.code, h.lo, h.values, xdim, ydim, init, dst, offset) == 0) return;
		DeltaMapper.getValuesFromAverageDeltas(NeighbourMapper.neighbourDecode(h, xdim, ydim), xdim, ydim, init, dst, offset);
	}

	/**
	 * A band's channels decoded and rebuilt in C at once
	 * (rebuildNeighbourChannelsNative), else null: each channel's deltas
	 * neighbour Huffman decoded and the channel rebuilt from them in the same
	 * thread, so the first channel starts rebuilding while the others are
	 * still decoding (as rebuildHuffmanChannels does it for Huffman). The
	 * same values as neighbourDecode and DeltaMapper.getValuesFromRowFitDeltas.
	 *
	 * @param h       each channel's coding, in coding order
	 * @param xdim    the width
	 * @param ydim    the band's height
	 * @param init    each channel's first value
	 * @param radius  each channel's window radius
	 * @param helpers each channel's helper threads (DeltaMapper.fitHelpers)
	 * @return each channel's values, or null if the library isn't there or
	 *         the C couldn't (then decode and rebuild them in Java)
	 */
	static int[][] rebuildNeighbourChannels(NeighbourMapper.NeighbourChannel[] h, int xdim, int ydim, int[] init, int[] radius, int helpers)
	{
		if(!DeltaMapper.NATIVE) return null;
		int n = h.length;
		byte[][] code = new byte[n][];
		int[]    lo = new int[n], values = new int[n];
		int[][]  value = new int[n][xdim * ydim];
		for(int i = 0; i < n; i++) { code[i] = h[i].code; lo[i] = h[i].lo; values[i] = h[i].values; }
		return (rebuildNeighbourChannelsNative(code, lo, values, xdim, ydim, init, radius, EVERY, helpers, value) == 0) ? value : null;
	}

	/**
	 * NeighbourMapper.neighbourDecode in C (NeighbourMapper_decode in
	 * native/NeighbourMapper.c): the same deltas.
	 *
	 * @param code   the coding's bit stream
	 * @param lo     the smallest delta
	 * @param values the number of delta values
	 * @param xdim   the width
	 * @param ydim   the band's height
	 * @param delta  gets the deltas (xdim * ydim)
	 * @return 0, or -1 if the C couldn't (out of memory, or the bytes aren't
	 *         what neighbourCode writes)
	 */
	static native int neighbourDecodeNative(byte[] code, int lo, int values, int xdim, int ydim, int[] delta);

	/**
	 * neighbourAverage in C (NeighbourMapper_decode, then
	 * DeltaMapper_valuesFromAverageDeltas).
	 *
	 * @param code   the coding's bit stream
	 * @param lo     the smallest delta
	 * @param values the number of delta values
	 * @param xdim   the width
	 * @param ydim   the band's height
	 * @param init   its first value
	 * @param value  gets the values (xdim * ydim, from offset on)
	 * @param offset where they start in value
	 * @return 0, or -1 if the C couldn't (out of memory, or the bytes aren't
	 *         what neighbourCode writes)
	 */
	static native int neighbourAverageNative(byte[] code, int lo, int values, int xdim, int ydim, int init, int[] value, int offset);

	/**
	 * neighbourDecode and DeltaMapper.getValuesFromRowFitDeltas in C, a
	 * band's channels at once (DeltaMapper_rebuildRowFitChannels in
	 * native/DeltaMapper.c, its deltas from NeighbourMapper_decode): the same
	 * values.
	 *
	 * @param code    each channel's bit stream
	 * @param lo      each channel's smallest delta
	 * @param values  each channel's number of delta values
	 * @param xdim    the width
	 * @param ydim    the band's height
	 * @param init    each channel's first value
	 * @param radius  each channel's window radius
	 * @param every   how often along a row the fit was solved
	 * @param helpers each channel's helper threads (DeltaMapper.fitHelpers)
	 * @param value   gets each channel's values (xdim * ydim each)
	 * @return 0, or -1 if the C couldn't (out of memory or threads, or the
	 *         bytes aren't what neighbourCode writes)
	 */
	static native int rebuildNeighbourChannelsNative(byte[][] code, int[] lo, int[] values, int xdim, int ydim, int[] init, int[] radius, int every,
	                                                 int helpers, int[][] value);

	/**
	 * A channel's deltas Huffman coded, as DeltaWriter2 codes them: unary
	 * strings by frequency rank (StringMapper.getStringList, the bit-pair
	 * transform kept only if it saves enough), then a canonical Huffman code
	 * over the string's bytes (CodeMapper's regular Huffman code). Layout:
	 * int the deltas' minimum, int the unary string's bit length, its rank
	 * table (DeltaMapper.writeTable), int the (transformed) string's byte
	 * length, int and the Huffman code lengths (NeighbourMapper.packLengths:
	 * compactly, with no Deflate; the formats before had them Deflated,
	 * CodeMapper.packRegularTables), int and the code. Delta 0 isn't used (the band's first value is
	 * written instead). The strings and the code are made in C when the
	 * library is there (stringListNative, packRegularCodeNative; the same
	 * bytes); the code lengths and their table are always the Java's.
	 *
	 * @param delta the deltas (not changed)
	 * @return the coded bytes
	 * @throws IOException never in practice (a byte stream)
	 */
	static byte[] huffmanCode(int[] delta) throws IOException
	{
		int    min, bits;
		int[]  table;
		byte[] string;
		int[]   info = new int[2];
		int[][] rank = new int[1][];
		if(DeltaMapper.NATIVE && (string = stringListNative(delta, info, rank)) != null)
		{
			min = info[0]; bits = info[1]; table = rank[0];
		}
		else
		{
			ArrayList<?> list = StringMapper.getStringList(delta.clone(), true);
			min    = (int) list.get(0);
			bits   = (int) list.get(1);
			table  = (int[]) list.get(2);
			string = (byte[]) list.get(3);
		}
		int[]  frequency = new int[256];   // the string's byte counts (DeltaEncoder's ArithmeticMapper.getFrequency)
		for(byte b : string) frequency[b & 0xFF]++;
		byte[] lengths = CodeMapper.getRegularHuffmanLength(frequency);
		byte[] code    = DeltaMapper.NATIVE ? packRegularCodeNative(string, lengths) : null;
		if(code == null) code = CodeMapper.packRegularCode(string, lengths);
		byte[] tables  = NeighbourMapper.packLengths(lengths, CodeMapper.REGULAR_MAX_CODE_LENGTH);   // (no Deflate)
		ByteArrayOutputStream bytes = new ByteArrayOutputStream();
		DataOutputStream out = new DataOutputStream(bytes);
		out.writeInt(min);
		out.writeInt(bits);
		DeltaMapper.writeTable(out, table);
		out.writeInt(string.length);
		out.writeInt(tables.length); out.write(tables);
		out.writeInt(code.length);   out.write(code);
		return bytes.toByteArray();
	}

	/**
	 * A channel's Huffman coding as huffmanCode wrote it (read by
	 * huffmanRead, its code lengths unpacked).
	 */
	static final class HuffmanChannel
	{
		/** The deltas' minimum. */
		int    min;
		/** The untransformed string's bits. */
		int    bits;
		/** The (transformed) string's bytes. */
		int    length;
		/** The rank table. */
		int[]  table;
		/** Each byte value's code length (256 of them). */
		byte[] lengths;
		/** The Huffman code. */
		byte[] code;

		/** An empty one, for huffmanRead to fill in. */
		HuffmanChannel() { }
	}

	/**
	 * Reads a channel's coding huffmanCode wrote.
	 *
	 * @param in the stream, at the start of it
	 * @return the coding
	 * @throws IOException if the stream fails or isn't what huffmanCode writes
	 */
	static HuffmanChannel huffmanRead(DataInputStream in) throws IOException
	{
		return huffmanRead(in, false);
	}

	/**
	 * Reads a channel's coding huffmanCode wrote, or (deflated) the one the
	 * formats before wrote: the same, the code lengths Deflated
	 * (CodeMapper.packRegularTables).
	 *
	 * @param in       the stream, at the start of it
	 * @param deflated whether the code lengths are Deflated (a file of the formats before)
	 * @return the coding
	 * @throws IOException if the stream fails or isn't what huffmanCode writes
	 */
	static HuffmanChannel huffmanRead(DataInputStream in, boolean deflated) throws IOException
	{
		HuffmanChannel h = new HuffmanChannel();
		h.min    = in.readInt();
		h.bits   = in.readInt();
		h.table  = DeltaMapper.readTable(in);
		h.length = in.readInt();
		byte[] tables = new byte[in.readInt()]; in.readFully(tables);
		h.code   = new byte[in.readInt()]; in.readFully(h.code);
		if(!deflated) h.lengths = NeighbourMapper.unpackLengths(tables, 256, CodeMapper.REGULAR_MAX_CODE_LENGTH);
		else
		{
			try { h.lengths = CodeMapper.unpackRegularTables(tables, 1)[0]; }
			catch(java.util.zip.DataFormatException e) { throw new IOException("bad Huffman tables", e); }
		}
		return h;
	}

	/**
	 * Reads a channel's deltas huffmanCode wrote (huffmanRead, then
	 * huffmanDecode).
	 *
	 * @param in the stream, at the start of them
	 * @param n  how many deltas
	 * @return the deltas (delta 0 is 0)
	 * @throws IOException if the stream fails or isn't what huffmanCode writes
	 */
	static int[] huffmanDecode(DataInputStream in, int n) throws IOException
	{
		return huffmanDecode(huffmanRead(in), n);
	}

	/**
	 * A band's channel decoded (huffmanDecode) and rebuilt from its average
	 * deltas (DeltaMapper.getValuesFromAverageDeltas), into dst from offset
	 * on: in C if it's there (in one step, without the deltas going back to
	 * the Java), else in Java.
	 *
	 * @param h      the channel's Huffman coding
	 * @param xdim   the width
	 * @param ydim   the band's height
	 * @param init   its first value
	 * @param dst    gets the values
	 * @param offset where they start in dst
	 */
	static void huffmanAverage(HuffmanChannel h, int xdim, int ydim, int init, int[] dst, int offset)
	{
		if(DeltaMapper.NATIVE && huffmanAverageNative(h.code, h.lengths, h.length, h.table, h.bits, h.min, xdim, ydim, init, dst, offset) == 0) return;
		DeltaMapper.getValuesFromAverageDeltas(huffmanDecode(h, xdim * ydim), xdim, ydim, init, dst, offset);
	}

	/**
	 * huffmanAverage in C (huffman_decode, then DeltaMapper_valuesFromAverageDeltas).
	 *
	 * @param code    the Huffman code
	 * @param lengths each byte value's code length (256 of them)
	 * @param length  the string's bytes
	 * @param table   the rank table
	 * @param bits    the untransformed string's bits
	 * @param min     the deltas' minimum
	 * @param xdim    the width
	 * @param ydim    the band's height
	 * @param init    its first value
	 * @param value   gets the values (xdim * ydim, from offset on)
	 * @param offset  where they start in value
	 * @return 0, or -1 if the C couldn't (out of memory, or the bytes aren't
	 *         what huffmanCode writes)
	 */
	static native int huffmanAverageNative(byte[] code, byte[] lengths, int length, int[] table, int bits, int min, int xdim, int ydim, int init,
	                                       int[] value, int offset);

	/**
	 * A channel's deltas from its Huffman coding. In C when the library is
	 * there (huffmanDecodeNative: the same deltas); the Java's if it isn't,
	 * or if the C finds something wrong (the Java then says what).
	 *
	 * @param h the coding
	 * @param n how many deltas
	 * @return the deltas (delta 0 is 0)
	 */
	static int[] huffmanDecode(HuffmanChannel h, int n)
	{
		int[] delta = new int[n];
		if(DeltaMapper.NATIVE && huffmanDecodeNative(h.code, h.lengths, h.length, h.table, h.bits, h.min, delta) == 0) return delta;
		byte[] string = CodeMapper.unpackRegularCode(h.code, h.lengths, h.length);
		delta = StringMapper.unpackStrings(StringMapper.decompressStrings(string), h.table, n, h.bits);
		delta[0] = 0;
		for(int k = 1; k < delta.length; k++) delta[k] += h.min;
		return delta;
	}

	/**
	 * A band's channels decoded and rebuilt in C at once
	 * (rebuildHuffmanChannelsNative), else null: each channel's deltas
	 * Huffman decoded and the channel rebuilt from them in the same thread,
	 * so the first channel starts rebuilding while the others are still
	 * decoding. The same values as huffmanDecode and
	 * DeltaMapper.getValuesFromRowFitDeltas.
	 *
	 * @param h      each channel's coding, in coding order
	 * @param xdim   the width
	 * @param ydim   the band's height
	 * @param init   each channel's first value
	 * @param radius  each channel's window radius
	 * @param helpers each channel's helper threads (DeltaMapper.fitHelpers)
	 * @return each channel's values, or null if the library isn't there or
	 *         the C couldn't (then decode and rebuild them in Java)
	 */
	static int[][] rebuildHuffmanChannels(HuffmanChannel[] h, int xdim, int ydim, int[] init, int[] radius, int helpers)
	{
		if(!DeltaMapper.NATIVE) return null;
		int n = h.length;
		byte[][] code = new byte[n][], lengths = new byte[n][];
		int[][]  table = new int[n][], value = new int[n][xdim * ydim];
		int[]    length = new int[n], bits = new int[n], min = new int[n];
		for(int i = 0; i < n; i++)
		{
			code[i] = h[i].code; lengths[i] = h[i].lengths; table[i] = h[i].table;
			length[i] = h[i].length; bits[i] = h[i].bits; min[i] = h[i].min;
		}
		return (rebuildHuffmanChannelsNative(code, lengths, length, table, bits, min, xdim, ydim, init, radius, EVERY, helpers, value) == 0) ? value : null;
	}

	/**
	 * StringMapper.getStringList(delta, true) in C (StringMapper_getStringList
	 * in native/StringMapper.c): the same string and table; delta isn't
	 * changed.
	 *
	 * @param delta the deltas
	 * @param info  gets the minimum and the untransformed string's bits
	 * @param table gets the rank table (in table[0])
	 * @return the string, or null if the C couldn't (out of memory)
	 */
	static native byte[] stringListNative(int[] delta, int[] info, int[][] table);

	/**
	 * CodeMapper.packRegularCode in C (CodeMapper_packRegularCode in
	 * native/CodeMapper.c): the same bytes.
	 *
	 * @param data   the bytes to code
	 * @param length each byte value's code length (256 of them)
	 * @return the code, or null if the C couldn't (out of memory)
	 */
	static native byte[] packRegularCodeNative(byte[] data, byte[] length);

	/**
	 * huffmanDecode from the code lengths on, in C: CodeMapper.unpackRegularCode,
	 * StringMapper.decompressStrings and StringMapper.unpackStrings
	 * (CodeMapper_unpackRegularCode, StringMapper_decompressStrings,
	 * StringMapper_unpackStrings), then delta 0 set to 0 and the minimum
	 * added to the rest: the same deltas.
	 *
	 * @param code    the Huffman code
	 * @param lengths each byte value's code length (256 of them)
	 * @param length  the string's bytes
	 * @param table   the rank table
	 * @param bits    the untransformed string's bits
	 * @param min     the deltas' minimum
	 * @param delta   gets the deltas
	 * @return 0, or -1 if the C couldn't (out of memory, or the bytes aren't
	 *         what huffmanCode writes)
	 */
	static native int huffmanDecodeNative(byte[] code, byte[] lengths, int length, int[] table, int bits, int min, int[] delta);

	/**
	 * huffmanDecode and DeltaMapper.getValuesFromRowFitDeltas in C, a band's
	 * channels at once (DeltaMapper_rebuildRowFitChannels in
	 * native/DeltaMapper.c, its deltas from the Huffman decoding in
	 * native/DeltaMapper_jni.c): the same values.
	 *
	 * @param code    each channel's Huffman code
	 * @param lengths each channel's code lengths (256 each)
	 * @param length  each channel's string bytes
	 * @param table   each channel's rank table
	 * @param bits    each channel's untransformed string's bits
	 * @param min     each channel's deltas' minimum
	 * @param xdim    the width
	 * @param ydim    the band's height
	 * @param init    each channel's first value
	 * @param radius  each channel's window radius
	 * @param every   how often along a row the fit was solved
	 * @param helpers each channel's helper threads (DeltaMapper.fitHelpers)
	 * @param value   gets each channel's values (xdim * ydim each)
	 * @return 0, or -1 if the C couldn't (out of memory or threads, or the
	 *         bytes aren't what huffmanCode writes)
	 */
	static native int rebuildHuffmanChannelsNative(byte[][] code, byte[][] lengths, int[] length, int[][] table, int[] bits, int[] min,
	                                               int xdim, int ydim, int[] init, int[] radius, int every, int helpers, int[][] value);

	/**
	 * A job's result, waiting for it; if it failed, its failure is thrown
	 * as waitFor throws it.
	 *
	 * @param job the job
	 * @param <T> its result's type
	 * @return its result
	 * @throws IOException if it failed with one, or the wait was interrupted
	 */
	private static <T> T result(Future<T> job) throws IOException
	{
		try { return job.get(); }
		catch(InterruptedException e) { Thread.currentThread().interrupt(); throw new IOException(e); }
		catch(ExecutionException e)
		{
			Throwable c = e.getCause();
			if(c instanceof IOException) throw (IOException) c;
			if(c instanceof RuntimeException) throw (RuntimeException) c;
			if(c instanceof Error) throw (Error) c;
			throw new IOException(c);
		}
	}

	/**
	 * Waits for jobs, passing on the first one's failure.
	 *
	 * @param jobs the jobs
	 * @throws IOException if one failed with one, or was interrupted
	 */
	private static void waitFor(java.util.List<Future<?>> jobs) throws IOException
	{
		for(Future<?> f : jobs)
		{
			try { f.get(); }
			catch(InterruptedException e) { Thread.currentThread().interrupt(); throw new IOException(e); }
			catch(ExecutionException e)
			{
				Throwable c = e.getCause();
				if(c instanceof IOException) throw (IOException) c;
				if(c instanceof RuntimeException) throw (RuntimeException) c;
				if(c instanceof Error) throw (Error) c;
				throw new IOException(c);
			}
		}
	}
}
