import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import javax.swing.*;

// NativeWriter2 version 1.0 (writes Huffman format 1)
//
// NativeWriter2 is DeltaEncoder's HuffmanWriter with NativeWriter's native
// methods: NativeWriter (Simple 2 format 2) up to the entropy coding:
// the same channels (green, blue-green and red-green, SET_ID), the same
// least-squares fit from the rows above (DeltaMapper.RowFit: the window is
// the RADIUS rows above, solved at every EVERY-th pixel along a row), the
// same bands, Apply and Save. Then, in place of the mixed context coding,
// each band's channel's deltas are coded as DeltaWriter2 codes them: unary
// strings by frequency rank (StringMapper.getStringList), with StringMapper's
// bit-pair transform kept only if it saves enough (its rule), then a
// canonical Huffman code over the string's bytes, one per channel and band
// (CodeMapper's regular Huffman code, DeltaWriter's entropy type 1). No
// contexts, so a channel's coding uses no other channel. Less compression
// than Simple 2 (on the test photos the files are 9-29% bigger), faster to
// decode. The fit is DeltaMapper.c's when
// its library is found (DeltaMapper.NATIVE; -Dnative=false for the Java's),
// as in NativeWriter; Apply's too. The Huffman coding and its check are Java.
// Files are read by NativeReader2 (and DeltaEncoder's HuffmanReader).
/**
 * NativeWriter with Huffman coding in place of the mixed context coding
 * (see the comment above).
 */
public class NativeWriter2
{
	/**
	 * Every file starts with FORMAT_ID ('H' = Huffman format) and
	 * FORMAT_VERSION.
	 */
	static final char FORMAT_ID      = 'H';
	/**
	 * The file format's version: bump it in the writer and reader together
	 * whenever the file layout or a coder's output changes. 1: the first.
	 */
	static final int  FORMAT_VERSION = 1;
	/**
	 * The channel set coded: green, blue-green, red-green (see
	 * DeltaMapper.getChannels).
	 */
	static final int  SET_ID = 7;
	/**
	 * Its channels, in coding order (DeltaMapper's channel ids).
	 */
	static final int[] CHANNELS = DeltaMapper.getChannels(SET_ID);
	/**
	 * The least-squares window radius, for every channel.
	 */
	static final int  RADIUS = 10;
	/**
	 * How often along a row the fit is solved: at every EVERY-th pixel, the
	 * pixels between using the last solution (DeltaMapper.RowFit).
	 */
	static final int  EVERY = 4;
	/**
	 * The most bands Save offers.
	 */
	static final int  MAX_BANDS = 16;
	/**
	 * The fewest rows (of the quantized image) a band may have: smaller images
	 * get fewer bands.
	 */
	static final int  BAND_MIN_ROWS = 64;

	// ---- Image state --------------------------------------------------------
	/**
	 * The window.
	 */
	ViewerSupport view;
	/**
	 * The image as loaded.
	 */
	BufferedImage original_image;
	/**
	 * The preview.
	 */
	BufferedImage working_image;
	/**
	 * The image's file.
	 */
	String        filename;
	/**
	 * The image's width and height.
	 */
	int           image_xdim, image_ydim;
	/**
	 * Blue, green and red of the original.
	 */
	int[][]       source;

	// ---- Parameters ---------------------------------------------------------
	/**
	 * The Pixel Resolution (ResizeMapper.resize2's reduction).
	 */
	int pixel_quant = 4;
	/**
	 * The Color Resolution (bits dropped from each value).
	 */
	int pixel_shift = 3;
	/**
	 * The Error Correction (preview only).
	 */
	int correction  = 0;
	/**
	 * How many independently decodable bands Save writes; at most MAX_BANDS,
	 * and fewer if bands would have under BAND_MIN_ROWS rows.
	 */
	int bands       = 1;

	/**
	 * The Quantization sliders (Reset moves them).
	 */
	JSlider pquant_slider, pshift_slider, corr_slider;

	// ---- Results of the last Apply (read by Save) ---------------------------
	/**
	 * The channels as quantized, in coding order, each difference channel
	 * less its minimum: what Save codes.
	 */
	int[][]  value_list = new int[3][];
	/**
	 * Each channel's minimum (added back to the difference channels by the
	 * reader), in coding order.
	 */
	int[]    channel_min = new int[3];
	/**
	 * Their width.
	 */
	int      delta_xdim;

	/**
	 * The image file's length.
	 */
	long    file_length;
	/**
	 * The last Apply finished; Save needs it.
	 */
	boolean applied  = false;

	/**
	 * Opens the image named, or one chosen in a file dialog.
	 *
	 * @param args the image, or nothing
	 */
	public static void main(String[] args)
	{
		ViewerSupport.applyHiDpiFontScaleIfNeeded();
		if(args.length == 1) { new NativeWriter2(args[0]); return; }
		FileDialog fd = new FileDialog((java.awt.Frame) null, "Open Image", FileDialog.LOAD);
		fd.setVisible(true);
		if(fd.getFile() != null) new NativeWriter2(new File(fd.getDirectory(), fd.getFile()).getPath());
		else System.exit(0);
	}

	/**
	 * Loads an image and opens its window.
	 *
	 * @param _filename the image
	 */
	public NativeWriter2(String _filename)
	{
		filename = _filename;
		try
		{
			file_length    = new File(filename).length();
			original_image = ViewerSupport.readImage(filename);
		}
		catch(IOException e)
		{
			ViewerSupport.showError(null, e.getMessage());
			ViewerSupport.exitIfNoWindows();
			return;
		}
		image_xdim = original_image.getWidth();
		image_ydim = original_image.getHeight();
		System.out.println(String.format("Loaded %s, %d x %d (%,d pixels)", filename, image_xdim, image_ydim, (long) image_xdim * image_ydim));

		int[] pixel = original_image.getRGB(0, 0, image_xdim, image_ydim, null, 0, image_xdim);
		source = new int[3][pixel.length];
		for(int i = 0; i < pixel.length; i++)
		{
			source[0][i] = (pixel[i] >> 16) & 0xff; source[1][i] = (pixel[i] >> 8) & 0xff; source[2][i] = pixel[i] & 0xff;
		}
		working_image = new BufferedImage(image_xdim, image_ydim, BufferedImage.TYPE_INT_RGB);
		working_image.setRGB(0, 0, image_xdim, image_ydim, pixel, 0, image_xdim);

		view = new ViewerSupport("Native Writer 2  " + filename, image_xdim, image_ydim);
		JFrame   frame    = view.frame;
		JMenuBar menu_bar = frame.getJMenuBar();

		JMenu file_menu = new JMenu("File");
		JMenuItem open_item = new JMenuItem("Open...");
		open_item.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, InputEvent.CTRL_DOWN_MASK));
		open_item.addActionListener(e -> { FileDialog fd = new FileDialog(frame, "Open Image", FileDialog.LOAD); fd.setVisible(true); if(fd.getFile() != null) new NativeWriter2(fd.getDirectory() + fd.getFile()); });
		file_menu.add(open_item); file_menu.addSeparator();
		JMenuItem reset_item = new JMenuItem("Reset");
		reset_item.addActionListener(e -> { pixel_quant = 0; pixel_shift = 0; correction = 0; pquant_slider.setValue(0); pshift_slider.setValue(0); corr_slider.setValue(0); apply(); });
		file_menu.add(reset_item);
		JMenuItem save_item = new JMenuItem("Save"); save_item.addActionListener(new SaveHandler()); file_menu.add(save_item);

		JMenu quant_menu = new JMenu("Quantization");
		JSlider[] ss = new JSlider[1];
		quant_menu.add(ViewerSupport.makeSliderDialog(frame, "Pixel Resolution", 0, 10, pixel_quant, v -> { pixel_quant = v; apply(); }, ss)); pquant_slider = ss[0];
		quant_menu.add(ViewerSupport.makeSliderDialog(frame, "Color Resolution", 0, 7, pixel_shift, v -> { pixel_shift = v; apply(); }, ss)); pshift_slider = ss[0];
		// Error Correction (below a separator) is not a quantizing step: it blends
		// the preview back toward the original by correction/10. Preview only;
		// the saved file is unaffected.
		quant_menu.addSeparator();
		quant_menu.add(ViewerSupport.makeSliderDialog(frame, "Error Correction", 0, 10, correction, v -> { correction = v; apply(); }, ss)); corr_slider = ss[0];

		// Bands menu: Save codes the image as this many bands of rows, each
		// decodable on its own (so a reader can decode them at the same time),
		// for a small cost per band boundary. Like Save itself, it never
		// changes the preview.
		JMenu bands_menu = new JMenu("Bands");
		JSlider[] bs = new JSlider[1];
		bands_menu.add(ViewerSupport.makeSliderDialog(frame, "Number of Bands", 1, MAX_BANDS, bands, v -> { bands = v; view.setStatus(bandText()); }, bs));

		menu_bar.add(file_menu); menu_bar.add(view.makeViewMenu()); menu_bar.add(quant_menu); menu_bar.add(bands_menu);

		view.setImage(original_image);
		view.show();
		SwingUtilities.invokeLater(this::apply);
	}

	// ---- Bands --------------------------------------------------------------

	/**
	 * The bands Save will write: bands, but no more than leave BAND_MIN_ROWS
	 * rows in each.
	 *
	 * @return the number of bands
	 */
	int bandsUsed()
	{
		int rows = DeltaMapper.getQuantizedSize(image_xdim, image_ydim, pixel_quant)[1];
		return Math.max(1, Math.min(bands, rows / BAND_MIN_ROWS));
	}

	/**
	 * A band's first row.
	 *
	 * @param b    the band (n for the end of the last)
	 * @param n    the number of bands
	 * @param rows the rows split into them
	 * @return the row
	 */
	static int bandStart(int b, int n, int rows) { return (int) ((long) b * rows / n); }

	/**
	 * The bands in words: "8 bands of 375 rows" (or "of 374 to 375 rows").
	 *
	 * @param n    the number of bands
	 * @param rows the rows split into them
	 * @return the description
	 */
	static String describeBands(int n, int rows)
	{
		int lo = rows / n, hi = (rows + n - 1) / n;
		return n + " bands of " + ((lo == hi) ? lo : lo + " to " + hi) + " rows";
	}

	/**
	 * The Bands dialog's status line.
	 *
	 * @return the bands Save will write, in words
	 */
	private String bandText()
	{
		int n = bandsUsed();
		if(n == 1) return (bands > 1) ? "1 band: the image is too small for more" : "1 band";
		return describeBands(n, DeltaMapper.getQuantizedSize(image_xdim, image_ydim, pixel_quant)[1]);
	}

	// ---- Apply --------------------------------------------------------------

	/**
	 * Blue, green and red, resized and quantized.
	 *
	 * @param size  the quantized size
	 * @param quant the Pixel Resolution
	 * @param shift the Color Resolution
	 * @return the channels
	 */
	int[][] quantizedChannels(int[] size, int quant, int shift)
	{
		int[][] q = new int[3][];
		ViewerSupport.parallel(3, i ->
		{
			int[] ch = source[i];
			if(quant != 0) ch = ResizeMapper.resize2(ch, image_xdim, size[0], size[1]);
			q[i] = DeltaMapper.quantizeChannel(ch, shift);
		});
		return q;
	}

	/**
	 * Quantizes (the channels Save codes), then rebuilds the image for the
	 * preview.
	 */
	void apply()
	{
		applied = false;
		try { applyImpl(); applied = true; }
		catch(Exception e) { System.out.println("Apply: " + e); e.printStackTrace(); }
	}

	/**
	 * Apply's work (apply catches its exceptions).
	 */
	private void applyImpl()
	{
		int[]   size = DeltaMapper.getQuantizedSize(image_xdim, image_ydim, pixel_quant);
		int     new_xdim = size[0];
		int     threads = Runtime.getRuntime().availableProcessors();
		int[]   min = new int[6];
		int[][] q = null, qc = null;
		// The quantized channels and the candidates: in C if it's there (on
		// every core), else in Java.
		if(DeltaMapper.NATIVE)
		{
			int[][] col = (pixel_quant != 0) ? ResizeMapper.centredMap(image_xdim, size[0]) : new int[2][];
			int[][] row = (pixel_quant != 0) ? ResizeMapper.centredMap(image_ydim, size[1]) : new int[2][];
			int[][] nq = new int[3][size[0] * size[1]], diff = new int[3][size[0] * size[1]];
			if(DeltaMapper.applyQuantizeNative(source, image_xdim, image_ydim, size[0], size[1], col[0], col[1], row[0], row[1],
			                                   pixel_shift, nq, diff, min, threads) == 0)
			{
				q  = nq;
				qc = new int[][] {nq[0], nq[1], nq[2], diff[0], diff[1], diff[2]};
			}
		}
		if(q == null)
		{
			q  = quantizedChannels(size, pixel_quant, pixel_shift);
			qc = DeltaMapper.getCandidateChannels(q[0], q[1], q[2], min);
		}
		int[][] v = new int[3][];
		int[]   m = new int[3];
		for(int i = 0; i < 3; i++) { v[i] = qc[CHANNELS[i]]; m[i] = min[CHANNELS[i]]; }
		value_list  = v;
		channel_min = m;
		delta_xdim  = new_xdim;

		// Like NativeReader: resize (centred: resize2), then shift. The reader
		// rebuilds blue, green and red exactly as quantized, so the preview
		// uses them as they are: no need to decode. In C if it's there (its
		// pixels are as the raster holds them, so they're copied in a row at
		// a time), else in Java.
		if(DeltaMapper.NATIVE)
		{
			int[][] col = (pixel_quant != 0) ? ResizeMapper.centredMap(new_xdim, image_xdim) : new int[2][];
			int[][] row = (pixel_quant != 0) ? ResizeMapper.centredMap(size[1], image_ydim) : new int[2][];
			int[] pixel = new int[image_xdim * image_ydim];
			if(DeltaMapper.applyPreviewNative(q, new_xdim, size[1], col[0], col[1], row[0], row[1], image_xdim, image_ydim,
			                                  pixel_shift, correction, source, pixel, threads) == 0)
			{
				working_image.getRaster().setDataElements(0, 0, image_xdim, image_ydim, pixel);
				view.setImage(working_image);
				return;
			}
		}
		int[][] bgr = q.clone();
		ViewerSupport.parallel(3, c ->
		{
			if(pixel_quant != 0) bgr[c] = ResizeMapper.resize2(bgr[c], new_xdim, image_xdim, image_ydim);
			if(pixel_shift != 0) bgr[c] = DeltaMapper.shift(bgr[c], pixel_shift);
		});

		int[] rgb = new int[image_xdim * image_ydim];
		double f = correction / 10.0;
		for(int i = 0; i < rgb.length; i++)
		{
			int b = bgr[0][i], g = bgr[1][i], r = bgr[2][i];
			if(correction != 0) { b += (int)((source[0][i] - b) * f); g += (int)((source[1][i] - g) * f); r += (int)((source[2][i] - r) * f); }
			rgb[i] = (b << 16) + (g << 8) + r;
		}
		working_image.setRGB(0, 0, image_xdim, image_ydim, rgb, 0, image_xdim);
		view.setImage(working_image);
	}

	// ---- Save ---------------------------------------------------------------

	/**
	 * File &gt; Save: codes the image (encode) into the file "foo", twice, and
	 * prints both times (the first includes compiling the code), without the
	 * decode check, and the check's time.
	 */
	class SaveHandler implements ActionListener
	{
		/**
		 * A handler for the Save item.
		 */
		SaveHandler() {}

		/**
		 * Saves.
		 *
		 * @param event the menu item's event
		 */
		public void actionPerformed(ActionEvent event)
		{
			if(!applied) apply();
			if(!applied) { ViewerSupport.showError(view.frame, "Nothing saved: the last Apply failed."); return; }
			// The image is coded twice and the times of both printed: the first
			// includes compiling the code (the first time it runs in this JVM),
			// the second is the run time only. Both leave out the decode check,
			// which is timed on its own. Both give the same bytes.
			File file = new File("foo");
			long[] took = new long[2], check = new long[2];
			try
			{
				byte[] data = null;
				for(int pass = 0; pass < 2; pass++)
				{
					ByteArrayOutputStream bytes = new ByteArrayOutputStream();
					long start = System.nanoTime();
					check[pass] = encode(new DataOutputStream(bytes), value_list, channel_min, delta_xdim, image_xdim, image_ydim, pixel_shift, pixel_quant, bandsUsed());
					took[pass] = System.nanoTime() - start - check[pass];
					byte[] got = bytes.toByteArray();
					if(data != null && !Arrays.equals(data, got)) System.out.println("WARNING: the second coding differs from the first.");
					data = got;
				}
				try(OutputStream out = new BufferedOutputStream(new FileOutputStream(file))) { out.write(data); }
			}
			catch(Exception e)
			{
				file.delete();
				ViewerSupport.showError(view.frame, "Save failed: " + e);
				e.printStackTrace();
				return;
			}
			int n = bandsUsed(), raw = image_xdim * image_ydim * 3, rows = value_list[0].length / delta_xdim;
			if(n > 1) System.out.println(String.format("Saved %s: %,d bytes (%s)", file.getName(), file.length(), describeBands(n, rows)));
			else      System.out.println(String.format("Saved %s: %,d bytes", file.getName(), file.length()));
			System.out.println(String.format("Coded %d x %d (%,d pixels)", delta_xdim, rows, (long) delta_xdim * rows));
			System.out.println("Fit and coder:              " + DeltaMapper.NATIVE_STATUS);
			System.out.println("Run time plus compile time: " + ViewerSupport.formatDuration(took[0]));
			System.out.println("Run time only:              " + ViewerSupport.formatDuration(took[1]));
			System.out.println("Decode check:               " + ViewerSupport.formatDuration(check[1]));
			System.out.println("Timeline (run time only):   " + last_timeline);
			System.out.println("Original compression rate: " + String.format("%.4f", (double) file_length / raw));
			System.out.println("Output  compression rate:  " + String.format("%.4f", (double) file.length() / raw));
			System.out.println();
		}
	}

	/**
	 * The last encode's timeline (from its start: when each channel's fit
	 * ended, when each channel's coding ended, when all were coded), which
	 * Save prints.
	 */
	static volatile String last_timeline = "";

	/**
	 * Codes the channels and writes the file. Format 1. Header: FORMAT_ID,
	 * FORMAT_VERSION, width, height (unsigned shorts), pixel_shift,
	 * pixel_quant; per channel (coding order) int min; the number of bands n
	 * (an unsigned byte), n int lengths, and the n bands. Band b is rows
	 * bandStart(b) to bandStart(b + 1) of the quantized image,
	 * coded as an image of its own (the fit starts again at its top): per
	 * channel (green, blue-green, red-green), int init, then the deltas of
	 * the least-squares fit from the rows above (DeltaMapper.RowFit: radius
	 * RADIUS, solved at every EVERY-th pixel along a row) Huffman coded
	 * (huffmanCode, see there for the layout). Channels 1 and 2 use the ones
	 * before them in the fit (their values), so a band's channels are
	 * rebuilt in order, each a row behind the one before; the bands can be
	 * decoded at the same time.
	 * <p>
	 * Each channel is fitted once over the whole image (the fit splits itself
	 * across the cores); the bands' deltas come from it, with only each
	 * band's first rows fitted again (DeltaMapper.getRowFitBandDeltas).
	 * A channel's coding needs only its own deltas, so its bands are coded
	 * while the next channel is fitted. Once everything
	 * is coded, each band's channels are checked by decoding them back, at
	 * the same time; the time that took is returned, so the coding can be
	 * timed without it.
	 *
	 * @param out         the stream
	 * @param value       the channels as quantized, in coding order (difference channels less their minimum)
	 * @param min         each channel's minimum, in coding order
	 * @param xdim        their width
	 * @param image_xdim  the image's width
	 * @param image_ydim  the image's height
	 * @param pixel_shift the Color Resolution
	 * @param pixel_quant the Pixel Resolution
	 * @param n           the number of bands
	 * @return the time the decode check took, in nanoseconds
	 * @throws IOException if the stream fails
	 */
	static long encode(DataOutputStream out, int[][] value, int[] min, int xdim, int image_xdim, int image_ydim, int pixel_shift, int pixel_quant, int n) throws IOException
	{
		long check_time = 0, start = System.nanoTime();
		long[] fit_done = new long[3], code_done = new long[3];   // when each channel's fit, and its last band's coding, ended
		int rows = value[0].length / xdim;
		int[][][]  d = new int[n][3][];      // [band][channel]
		byte[][][] coded = new byte[n][3][];
		ExecutorService coder = Executors.newFixedThreadPool(Math.max(1, Math.min(3 * n, Runtime.getRuntime().availableProcessors())));
		ExecutorService fitter = Executors.newFixedThreadPool(3);
		java.util.List<Future<?>> jobs = new ArrayList<>();
		try
		{
			// The three channels' fits at the same time: each needs only its
			// channel and the one before, all known (each still splits into
			// bands of rows on every core). A channel's coding waits only for
			// its own fit.
			java.util.List<Future<int[]>> fits = new ArrayList<>();
			for(int i = 0; i < 3; i++)
			{
				int[] v = value[i], ref = (i > 0) ? value[i - 1] : null;
				int fi = i;
				fits.add(fitter.submit(() ->
				{
					int[] deltas = DeltaMapper.getRowFitDeltas(v, ref, xdim, rows, RADIUS, EVERY);
					fit_done[fi] = System.nanoTime();
					return deltas;
				}));
			}
			for(int i = 0; i < 3; i++)
			{
				int   fi = i;
				int[] ref = (i > 0) ? value[i - 1] : null;
				int[] whole = result(fits.get(i));
				for(int b = 0; b < n; b++)
				{
					int y0 = bandStart(b, n, rows), y1 = bandStart(b + 1, n, rows);
					d[b][i] = (n == 1) ? whole : DeltaMapper.getRowFitBandDeltas(whole, value[i], ref, xdim, y0, y1, RADIUS, EVERY);
				}
				for(int b = 0; b < n; b++)
				{
					int fb = b;
					jobs.add(coder.submit(() ->
					{
						coded[fb][fi] = huffmanCode(d[fb][fi]);
						long now = System.nanoTime();
						synchronized(code_done) { code_done[fi] = Math.max(code_done[fi], now); }
						return null;
					}));
				}
			}
			waitFor(jobs);
			// The check, once everything is coded (so its time can be told
			// apart): each band's channels decoded back, at the same time.
			long check = System.nanoTime(), coded_all = check;
			jobs.clear();
			for(int b = 0; b < n; b++)
				for(int i = 0; i < 3; i++)
				{
					int fb = b, fi = i;
					jobs.add(coder.submit(() ->
					{
						int[] dd = d[fb][fi], back = huffmanDecode(new DataInputStream(new ByteArrayInputStream(coded[fb][fi])), dd.length);
						// (Delta 0 isn't coded: the band's first value, init, is written instead.)
						boolean same = back.length == dd.length;
						for(int k = 1; k < dd.length && same; k++) same = back[k] == dd[k];
						if(!same)
							System.out.println("WARNING: band " + fb + " channel " + fi + " deltas do not decode back.");
						return null;
					}));
				}
			waitFor(jobs);
			check_time = System.nanoTime() - check;
			last_timeline = String.format("fits done at %.0f, %.0f, %.0f ms; codings at %.0f, %.0f, %.0f ms; all coded at %.0f ms",
				(fit_done[0] - start) / 1e6, (fit_done[1] - start) / 1e6, (fit_done[2] - start) / 1e6,
				(code_done[0] - start) / 1e6, (code_done[1] - start) / 1e6, (code_done[2] - start) / 1e6, (coded_all - start) / 1e6);
		}
		finally { coder.shutdownNow(); fitter.shutdownNow(); }

		byte[][] band = new byte[n][];
		for(int b = 0; b < n; b++)
		{
			int y0 = bandStart(b, n, rows);
			ByteArrayOutputStream bytes = new ByteArrayOutputStream();
			DataOutputStream bo = new DataOutputStream(bytes);
			for(int i = 0; i < 3; i++) { bo.writeInt(value[i][y0 * xdim]); bo.write(coded[b][i]); }
			band[b] = bytes.toByteArray();
		}
		out.writeByte(FORMAT_ID); out.writeByte(FORMAT_VERSION);
		out.writeShort(image_xdim); out.writeShort(image_ydim);
		out.writeByte(pixel_shift); out.writeByte(pixel_quant);
		for(int i = 0; i < 3; i++) out.writeInt(min[i]);
		out.writeByte(n);
		for(int b = 0; b < n; b++) out.writeInt(band[b].length);
		for(int b = 0; b < n; b++) out.write(band[b]);
		return check_time;
	}

	/**
	 * A channel's deltas Huffman coded, as DeltaWriter2 codes them: unary
	 * strings by frequency rank (StringMapper.getStringList, the bit-pair
	 * transform kept only if it saves enough), then a canonical Huffman code
	 * over the string's bytes (CodeMapper's regular Huffman code). Layout:
	 * int the deltas' minimum, int the unary string's bit length, its rank
	 * table (DeltaMapper.writeTable), int the (transformed) string's byte
	 * length, int and the Huffman code lengths (CodeMapper.packRegularTables),
	 * int and the code. Delta 0 isn't used (the band's first value is
	 * written instead). The strings and the code are made in C when the
	 * library is there (stringListNative, packRegularCodeNative; the same
	 * bytes); the code lengths and their table are always the Java's.
	 *
	 * @param delta the deltas (not changed)
	 * @return the coded bytes
	 * @throws IOException never in practice (a byte stream)
	 */
	static byte[] huffmanCode(int[] delta) throws IOException
	{
		int    min, bits;
		int[]  table;
		byte[] string;
		int[]   info = new int[2];
		int[][] rank = new int[1][];
		if(DeltaMapper.NATIVE && (string = stringListNative(delta, info, rank)) != null)
		{
			min = info[0]; bits = info[1]; table = rank[0];
		}
		else
		{
			ArrayList<?> list = StringMapper.getStringList(delta.clone(), true);
			min    = (int) list.get(0);
			bits   = (int) list.get(1);
			table  = (int[]) list.get(2);
			string = (byte[]) list.get(3);
		}
		int[]  frequency = new int[256];   // the string's byte counts (DeltaEncoder's ArithmeticMapper.getFrequency)
		for(byte b : string) frequency[b & 0xFF]++;
		byte[] lengths = CodeMapper.getRegularHuffmanLength(frequency);
		byte[] code    = DeltaMapper.NATIVE ? packRegularCodeNative(string, lengths) : null;
		if(code == null) code = CodeMapper.packRegularCode(string, lengths);
		byte[] tables  = CodeMapper.packRegularTables(new byte[][] {lengths}, java.util.zip.Deflater.BEST_COMPRESSION);
		ByteArrayOutputStream bytes = new ByteArrayOutputStream();
		DataOutputStream out = new DataOutputStream(bytes);
		out.writeInt(min);
		out.writeInt(bits);
		DeltaMapper.writeTable(out, table);
		out.writeInt(string.length);
		out.writeInt(tables.length); out.write(tables);
		out.writeInt(code.length);   out.write(code);
		return bytes.toByteArray();
	}

	/**
	 * Reads a channel's deltas huffmanCode wrote. The decoding from the code
	 * lengths on is C when the library is there (huffmanDecodeNative: the
	 * same deltas); the Java's if it isn't, or if the C finds something
	 * wrong (the Java then says what).
	 *
	 * @param in the stream, at the start of them
	 * @param n  how many deltas
	 * @return the deltas (delta 0 is 0)
	 * @throws IOException if the stream fails or isn't what huffmanCode writes
	 */
	static int[] huffmanDecode(DataInputStream in, int n) throws IOException
	{
		int    min    = in.readInt();
		int    bits   = in.readInt();
		int[]  table  = DeltaMapper.readTable(in);
		int    length = in.readInt();
		byte[] tables = new byte[in.readInt()]; in.readFully(tables);
		byte[] code   = new byte[in.readInt()]; in.readFully(code);
		byte[] lengths;
		try { lengths = CodeMapper.unpackRegularTables(tables, 1)[0]; }
		catch(java.util.zip.DataFormatException e) { throw new IOException("bad Huffman tables", e); }
		int[]  delta  = new int[n];
		if(DeltaMapper.NATIVE && huffmanDecodeNative(code, lengths, length, table, bits, min, delta) == 0) return delta;
		byte[] string = CodeMapper.unpackRegularCode(code, lengths, length);
		delta = StringMapper.unpackStrings(StringMapper.decompressStrings(string), table, n, bits);
		delta[0] = 0;
		for(int k = 1; k < delta.length; k++) delta[k] += min;
		return delta;
	}

	/**
	 * StringMapper.getStringList(delta, true) in C (StringMapper_getStringList
	 * in native/StringMapper.c): the same string and table; delta isn't
	 * changed.
	 *
	 * @param delta the deltas
	 * @param info  gets the minimum and the untransformed string's bits
	 * @param table gets the rank table (in table[0])
	 * @return the string, or null if the C couldn't (out of memory)
	 */
	static native byte[] stringListNative(int[] delta, int[] info, int[][] table);

	/**
	 * CodeMapper.packRegularCode in C (CodeMapper_packRegularCode in
	 * native/CodeMapper.c): the same bytes.
	 *
	 * @param data   the bytes to code
	 * @param length each byte value's code length (256 of them)
	 * @return the code, or null if the C couldn't (out of memory)
	 */
	static native byte[] packRegularCodeNative(byte[] data, byte[] length);

	/**
	 * huffmanDecode from the code lengths on, in C: CodeMapper.unpackRegularCode,
	 * StringMapper.decompressStrings and StringMapper.unpackStrings
	 * (CodeMapper_unpackRegularCode, StringMapper_decompressStrings,
	 * StringMapper_unpackStrings), then delta 0 set to 0 and the minimum
	 * added to the rest: the same deltas.
	 *
	 * @param code    the Huffman code
	 * @param lengths each byte value's code length (256 of them)
	 * @param length  the string's bytes
	 * @param table   the rank table
	 * @param bits    the untransformed string's bits
	 * @param min     the deltas' minimum
	 * @param delta   gets the deltas
	 * @return 0, or -1 if the C couldn't (out of memory, or the bytes aren't
	 *         what huffmanCode writes)
	 */
	static native int huffmanDecodeNative(byte[] code, byte[] lengths, int length, int[] table, int bits, int min, int[] delta);

	/**
	 * A job's result, waiting for it; if it failed, its failure is thrown
	 * as waitFor throws it.
	 *
	 * @param job the job
	 * @param <T> its result's type
	 * @return its result
	 * @throws IOException if it failed with one, or the wait was interrupted
	 */
	private static <T> T result(Future<T> job) throws IOException
	{
		try { return job.get(); }
		catch(InterruptedException e) { Thread.currentThread().interrupt(); throw new IOException(e); }
		catch(ExecutionException e)
		{
			Throwable c = e.getCause();
			if(c instanceof IOException) throw (IOException) c;
			if(c instanceof RuntimeException) throw (RuntimeException) c;
			if(c instanceof Error) throw (Error) c;
			throw new IOException(c);
		}
	}

	/**
	 * Waits for jobs, passing on the first one's failure.
	 *
	 * @param jobs the jobs
	 * @throws IOException if one failed with one, or was interrupted
	 */
	private static void waitFor(java.util.List<Future<?>> jobs) throws IOException
	{
		for(Future<?> f : jobs)
		{
			try { f.get(); }
			catch(InterruptedException e) { Thread.currentThread().interrupt(); throw new IOException(e); }
			catch(ExecutionException e)
			{
				Throwable c = e.getCause();
				if(c instanceof IOException) throw (IOException) c;
				if(c instanceof RuntimeException) throw (RuntimeException) c;
				if(c instanceof Error) throw (Error) c;
				throw new IOException(c);
			}
		}
	}
}
