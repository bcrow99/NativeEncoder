import java.io.*;
import java.util.*;
import java.util.zip.*;

// DeflateMapper: two codings of a channel's deltas with Deflate (LZ77 and
// Huffman coding, java.util.zip at BEST_COMPRESSION), GenericWriter's and
// NativeEncoder's NativeWriter's "Deflate (Strings)" and "Deflate", to
// compare with the Huffman and neighbour Huffman codings:
//
//   Deflate (Strings), stringsCode: the deltas as unary strings by frequency
//   rank (StringMapper.getStringList), without the bit-pair compression,
//   then the strings' bytes deflated.
//
//   Deflate, deltasCode: the deltas themselves, each as a byte (0, -1, 1,
//   -2, 2, ... as 0, 1, 2, 3, 4, ...; ESCAPE then two bytes for anything
//   from ESCAPE on), the bytes deflated.
//
// Deflate's output depends on the zlib that makes it (the bytes, not what
// they inflate to): Java's own, the same everywhere, but not, for one, the
// zlib-ng Python 3.14 uses on Windows.
/**
 * Two codings of a channel's deltas with Deflate (see the comment above).
 */
public class DeflateMapper
{
	/** Not made: static methods only. */
	private DeflateMapper() { }

	/**
	 * The Deflate level: the best compression.
	 */
	static final int LEVEL = Deflater.BEST_COMPRESSION;
	/**
	 * Deflate: a delta whose byte would be this or more is this, then the
	 * value in two bytes (most significant first).
	 */
	static final int ESCAPE = 255;

	// ---- Deflate (Strings) ------------------------------------------------

	/**
	 * A channel's deltas as unary strings (StringMapper.getStringList, the
	 * strings not compressed), deflated. Layout: int the smallest delta, int
	 * the strings' length in bits, the rank table (DeltaMapper.writeTable),
	 * int the strings' length in bytes, int the deflated length, and the
	 * deflated bytes. Delta 0 isn't coded (the band's first value is written
	 * instead).
	 *
	 * @param delta the deltas (not changed)
	 * @return the coded bytes
	 * @throws IOException never in practice (a byte stream)
	 */
	static byte[] stringsCode(int[] delta) throws IOException
	{
		ArrayList<?> list   = StringMapper.getStringList(delta.clone(), false);
		int          min    = (int) list.get(0);
		int          bits   = (int) list.get(1);
		int[]        table  = (int[]) list.get(2);
		byte[]       string = (byte[]) list.get(3);
		byte[]       zipped = CodeMapper.deflate(string, LEVEL);
		ByteArrayOutputStream bytes = new ByteArrayOutputStream(zipped.length + 64);
		DataOutputStream out = new DataOutputStream(bytes);
		out.writeInt(min);
		out.writeInt(bits);
		DeltaMapper.writeTable(out, table);
		out.writeInt(string.length);
		out.writeInt(zipped.length);
		out.write(zipped);
		return bytes.toByteArray();
	}

	/**
	 * A channel's coding as stringsCode wrote it (read by stringsRead).
	 */
	static final class StringsChannel
	{
		/** The smallest delta. */
		int    min;
		/** The strings' length in bits. */
		int    bits;
		/** The rank table. */
		int[]  table;
		/** The strings' length in bytes. */
		int    length;
		/** The deflated strings. */
		byte[] zipped;

		/** An empty one, for stringsRead to fill in. */
		StringsChannel() { }
	}

	/**
	 * Reads a channel's coding stringsCode wrote.
	 *
	 * @param in the stream, at the start of it
	 * @return the coding
	 * @throws IOException if the stream fails or isn't what stringsCode writes
	 */
	static StringsChannel stringsRead(DataInputStream in) throws IOException
	{
		StringsChannel h = new StringsChannel();
		h.min    = in.readInt();
		h.bits   = in.readInt();
		h.table  = DeltaMapper.readTable(in);
		h.length = in.readInt();
		int zipped = in.readInt();
		if(h.length < 0 || zipped < 0) throw new IOException("bad Deflate (Strings) coding");
		h.zipped = new byte[zipped];
		in.readFully(h.zipped);
		return h;
	}

	/**
	 * A channel's deltas from its Deflate (Strings) coding.
	 *
	 * @param h the coding
	 * @param n the number of deltas
	 * @return the deltas (delta 0 is 0)
	 * @throws IOException if the coding isn't what stringsCode writes
	 */
	static int[] stringsDecode(StringsChannel h, int n) throws IOException
	{
		byte[] string = inflate(h.zipped, h.length);
		int[]  delta  = StringMapper.unpackStrings(StringMapper.decompressStrings(string), h.table, n, h.bits);
		delta[0] = 0;
		for(int k = 1; k < delta.length; k++) delta[k] += h.min;
		return delta;
	}

	// ---- Deflate (the deltas) ---------------------------------------------

	/**
	 * A channel's deltas as bytes, deflated: each delta (from delta 1) mapped
	 * to 0, 1, 2, ... (0, -1, 1, -2, 2, ...), as a byte if that's under
	 * ESCAPE, else ESCAPE and the value in two bytes. Layout: int the bytes'
	 * length, int the deflated length, and the deflated bytes.
	 *
	 * @param delta the deltas
	 * @return the coded bytes
	 * @throws IOException never in practice (a byte stream)
	 */
	static byte[] deltasCode(int[] delta) throws IOException
	{
		int n = delta.length;
		byte[] raw = new byte[3 * Math.max(0, n - 1)];
		int m = 0;
		for(int k = 1; k < n; k++)
		{
			int z = (delta[k] << 1) ^ (delta[k] >> 31);
			if(z < ESCAPE) raw[m++] = (byte) z;
			else
			{
				if(z > 0xffff) throw new IOException("a delta too big for the Deflate coding: " + delta[k]);
				raw[m++] = (byte) ESCAPE;
				raw[m++] = (byte) (z >> 8);
				raw[m++] = (byte) z;
			}
		}
		raw = Arrays.copyOf(raw, m);
		byte[] zipped = CodeMapper.deflate(raw, LEVEL);
		ByteArrayOutputStream bytes = new ByteArrayOutputStream(zipped.length + 8);
		DataOutputStream out = new DataOutputStream(bytes);
		out.writeInt(raw.length);
		out.writeInt(zipped.length);
		out.write(zipped);
		return bytes.toByteArray();
	}

	/**
	 * A channel's coding as deltasCode wrote it (read by deltasRead).
	 */
	static final class DeltasChannel
	{
		/** The bytes' length. */
		int    length;
		/** The deflated bytes. */
		byte[] zipped;

		/** An empty one, for deltasRead to fill in. */
		DeltasChannel() { }
	}

	/**
	 * Reads a channel's coding deltasCode wrote.
	 *
	 * @param in the stream, at the start of it
	 * @return the coding
	 * @throws IOException if the stream fails or isn't what deltasCode writes
	 */
	static DeltasChannel deltasRead(DataInputStream in) throws IOException
	{
		DeltasChannel h = new DeltasChannel();
		h.length = in.readInt();
		int zipped = in.readInt();
		if(h.length < 0 || zipped < 0) throw new IOException("bad Deflate coding");
		h.zipped = new byte[zipped];
		in.readFully(h.zipped);
		return h;
	}

	/**
	 * A channel's deltas from its Deflate coding.
	 *
	 * @param h the coding
	 * @param n the number of deltas
	 * @return the deltas (delta 0 is 0)
	 * @throws IOException if the coding isn't what deltasCode writes
	 */
	static int[] deltasDecode(DeltasChannel h, int n) throws IOException
	{
		byte[] raw = inflate(h.zipped, h.length);
		int[] delta = new int[n];
		int at = 0;
		for(int k = 1; k < n; k++)
		{
			if(at >= raw.length) throw new IOException("bad Deflate coding: too few deltas");
			int z = raw[at++] & 0xff;
			if(z == ESCAPE)
			{
				if(at + 2 > raw.length) throw new IOException("bad Deflate coding: too few deltas");
				z = ((raw[at] & 0xff) << 8) | (raw[at + 1] & 0xff);
				at += 2;
			}
			delta[k] = (z >>> 1) ^ -(z & 1);
		}
		if(at != raw.length) throw new IOException("bad Deflate coding: too many deltas");
		return delta;
	}

	/**
	 * Inflates exactly n bytes (CodeMapper.inflate), its failure as an
	 * IOException.
	 *
	 * @param zipped the deflated bytes
	 * @param n      how many bytes they inflate to
	 * @return the bytes
	 * @throws IOException if they aren't valid Deflate or inflate to fewer
	 */
	private static byte[] inflate(byte[] zipped, int n) throws IOException
	{
		try { return CodeMapper.inflate(zipped, n); }
		catch(DataFormatException e) { throw new IOException("bad Deflate data: " + e.getMessage(), e); }
	}
}
