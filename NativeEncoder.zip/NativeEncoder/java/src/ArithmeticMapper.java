import java.util.*;

/**
 * The range coder NativeWriter and NativeReader use, trimmed from
 * DeltaEncoder's ArithmeticMapper to just that: RangeEncoder, RangeDecoder,
 * and Arriving (coded bytes read while they are decoded), with the count
 * steps of the context models (CONTEXT_INCREMENT, CONTEXT_LIMIT) that
 * DeltaMapper's mixed models use.
 * <p>
 * Version 4.0 (DeltaEncoder's ArithmeticMapper, trimmed).
 */
public class ArithmeticMapper
{
	/** Not used: all of this class's methods are static. */
	public ArithmeticMapper() {}

	// ---- Range coder --------------------------------------------------------
	//
	// Byte-oriented, with LZMA-style carry propagation. low holds the bottom
	// of the interval in its low 40 bits (plus a possible carry into bit 40);
	// range stays between 2^32 and 2^40, shifting out a byte when it drops
	// below 2^32. The top byte of low is held in `cache` until it can no
	// longer change, along with a count of following 0xFF bytes that a
	// carry would also change.

	/**
	 * The range coder's range starts just below 2<sup>40</sup>.
	 */
	private static final long RANGE_TOP    = 1L << 40;
	/**
	 * The range coder shifts out a byte when the range drops below 2<sup>32</sup>.
	 */
	private static final long RANGE_BOTTOM = 1L << 32;

	/**
	 * Byte-oriented range encoder, with LZMA-style carry propagation.
	 * <p>
	 * low holds the bottom of the interval in its low 40 bits (plus a possible
	 * carry into bit 40); range stays between 2<sup>32</sup> and 2<sup>40</sup>,
	 * shifting out a byte when it drops below 2<sup>32</sup>. The top byte of low
	 * is held in {@code cache} until it can no longer change, along with a count
	 * of following 0xFF bytes that a carry would also change.
	 */
	static final class RangeEncoder
	{
		/**
		 * The bytes written so far (grown as needed).
		 */
		byte[] out;
		/**
		 * The number of bytes in out.
		 */
		int    size = 0;
		/**
		 * The bottom of the interval, and its width.
		 */
		long   low = 0, range = RANGE_TOP - 1;
		/**
		 * The byte held back until a carry can no longer change it.
		 */
		int    cache = 0;
		/**
		 * The held byte plus the 0xFF bytes after it.
		 */
		long   cache_size = 1;

		/**
		 * An encoder with an empty interval [0, 2<sup>40</sup>).
		 *
		 * @param n the expected output size in bytes (a hint; the buffer grows)
		 */
		RangeEncoder(int n) { out = new byte[Math.max(16, n + n / 4 + 16)]; }

		/**
		 * Narrows the interval to [start, start + count) out of total.
		 *
		 * @param start the total count of the symbols below this one
		 * @param count this symbol's count (positive)
		 * @param total the total count (under 2<sup>30</sup>)
		 */
		void encode(long start, long count, long total)
		{
			long r = range / total;
			low  += start * r;
			range = count * r;
			while (range < RANGE_BOTTOM)
			{
				range <<= 8;
				shiftLow();
			}
		}

		/**
		 * Shifts the top byte of low out (into the cache, or the output once it can
		 * no longer change).
		 */
		void shiftLow()
		{
			if (low < 0xFF00000000L || low >= RANGE_TOP)
			{
				int carry = (int) (low >>> 40);
				int temp  = cache;
				do
				{
					put(temp + carry);
					temp = 0xFF;
				}
				while (--cache_size != 0);
				cache = (int) ((low >>> 32) & 0xFF);
			}
			cache_size++;
			low = (low & 0xFFFFFFFFL) << 8;
		}

		/**
		 * Appends a byte to the output, growing the buffer as needed.
		 *
		 * @param b the byte to write
		 */
		void put(int b)
		{
			if (size == out.length) out = Arrays.copyOf(out, out.length * 2);
			out[size++] = (byte) b;
		}

		/**
		 * Flushes the interval.
		 *
		 * @return the coded bytes
		 */
		byte[] finish()
		{
			for (int k = 0; k < 6; k++) shiftLow();
			return Arrays.copyOf(out, size);
		}
	}

	/**
	 * Coded bytes still arriving: a buffer of a known length that one thread
	 * fills in order, saying how much has arrived (arrived), while a
	 * RangeDecoder reads it, waiting when it gets ahead (await).
	 */
	static final class Arriving
	{
		/**
		 * The bytes (those below the count arrived).
		 */
		final byte[] bytes;
		/**
		 * How many have arrived (guarded by this).
		 */
		private int count;
		/**
		 * Why the rest won't arrive, if they won't (guarded by this).
		 */
		private Throwable failed;

		/**
		 * A buffer for bytes yet to arrive.
		 *
		 * @param length how many there will be
		 */
		Arriving(int length) { bytes = new byte[length]; }

		/**
		 * Says that the first count bytes have arrived.
		 *
		 * @param count how many
		 */
		synchronized void arrived(int count) { this.count = count; notifyAll(); }

		/**
		 * Says that the rest won't arrive.
		 *
		 * @param e why
		 */
		synchronized void fail(Throwable e) { if(failed == null) failed = e; notifyAll(); }

		/**
		 * Waits until all the bytes have arrived.
		 *
		 * @throws IllegalStateException if they didn't (the reading failed)
		 */
		void awaitAll() { if(bytes.length > 0) await(bytes.length - 1); }

		/**
		 * Waits until byte pos has arrived.
		 *
		 * @param pos the byte (below bytes.length)
		 * @return how many have arrived (more than pos)
		 */
		synchronized int await(int pos)
		{
			boolean interrupted = false;
			while(count <= pos && failed == null)
				try { wait(); } catch(InterruptedException e) { interrupted = true; }
			if(interrupted) Thread.currentThread().interrupt();
			if(count <= pos) throw new IllegalStateException("the coded bytes didn't all arrive", failed);
			return count;
		}
	}

	/**
	 * The decoder for {@link RangeEncoder}. Reads zeros past the end of its
	 * input. Its input can be still arriving (Arriving): then it waits for
	 * each byte it gets to before it has arrived.
	 */
	static final class RangeDecoder
	{
		/**
		 * The coded bytes.
		 */
		final byte[] in;
		/**
		 * The bytes as they arrive, or null when they are all there.
		 */
		final Arriving arriving;
		/**
		 * How many bytes of in can be read without looking for more.
		 */
		int  limit;
		/**
		 * The next byte to read; the first byte written is always the initial cache.
		 */
		int  pos = 1;             // the first byte written is always the initial cache
		/**
		 * The code's offset within the interval, the interval's width, and range/total from the last {@link #target}.
		 */
		long code = 0, range = RANGE_TOP - 1, r;

		/**
		 * A decoder reading the first five code bytes.
		 *
		 * @param in the coded bytes
		 */
		RangeDecoder(byte[] in)
		{
			this.in = in;
			arriving = null;
			limit = in.length;
			for (int k = 0; k < 5; k++) code = (code << 8) | next();
		}

		/**
		 * A decoder reading the first five code bytes, from bytes still
		 * arriving (waiting for them if need be).
		 *
		 * @param in the coded bytes, as they arrive
		 */
		RangeDecoder(Arriving in)
		{
			this.in = in.bytes;
			arriving = in;
			limit = 0;
			for (int k = 0; k < 5; k++) code = (code << 8) | next();
		}

		/**
		 * The next input byte.
		 *
		 * @return the next input byte, or 0 past the end
		 */
		int next() { return (pos < limit) ? (in[pos++] & 0xFF) : more(); }

		/**
		 * The next input byte, beyond those known to have arrived: 0 past the
		 * end, otherwise once it has arrived.
		 *
		 * @return the byte
		 */
		private int more()
		{
			if(pos >= in.length) return 0;
			limit = arriving.await(pos);
			return in[pos++] & 0xFF;
		}

		/**
		 * Where the code falls, as a count out of total. Must be followed by
		 * {@link #decode} with the interval that holds it.
		 *
		 * @param total the total count
		 * @return the position, 0 to total - 1
		 */
		int target(long total)
		{
			r = range / total;
			long t = code / r;
			return (int) Math.min(t, total - 1);
		}

		/**
		 * Narrows the interval to the symbol found.
		 *
		 * @param start the total count of the symbols below it
		 * @param count its count
		 */
		void decode(long start, long count)
		{
			code -= start * r;
			range = count * r;
			while (range < RANGE_BOTTOM)
			{
				range <<= 8;
				code = (code << 8) | next();
			}
		}
	}

	// ---- Context models' counts -----------------------------------------------
	//
	// Each context's counts start at 1, +CONTEXT_INCREMENT per symbol coded,
	// halved (keeping them >= 1) when a context's total passes CONTEXT_LIMIT.

	/**
	 * What each coded symbol adds to its count in the context-adaptive coder.
	 */
	public static final int CONTEXT_INCREMENT = 32;
	/**
	 * A context's total above which the context-adaptive coder halves its counts.
	 */
	public static final int CONTEXT_LIMIT     = 1 << 16;

}
