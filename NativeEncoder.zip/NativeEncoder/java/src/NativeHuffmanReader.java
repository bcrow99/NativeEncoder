import java.awt.image.*;
import java.io.*;
import javax.swing.*;

// NativeHuffmanReader version 1.0 (reads Huffman format 1 only)
//
// Reads NativeHuffmanWriter's files (and DeltaEncoder's HuffmanWriter's: the same
// format; this is DeltaEncoder's HuffmanReader with NativeSimpleReader's native
// methods): NativeSimpleReader with the Huffman decoding in place of the mixed
// context decoding. The bands are decoded at the same time. In each, a
// channel's deltas are decoded (CodeMapper's regular Huffman code, then
// StringMapper's unary strings) and the channel rebuilt from them with the
// least-squares fit from the rows above (the channels at the same time, each
// a row behind the one before). Then blue, green and red are rebuilt,
// resized back and packed as NativeSimpleReader does. With its library, the C does
// the decoding and the fit in one call per band
// (NativeHuffmanWriter.rebuildHuffmanChannels: each channel decoded and rebuilt in
// the same thread, so the first starts rebuilding while the others are
// still decoding), and the last steps; without it, the Java decodes a band's
// channels at the same time, then rebuilds them
// (DeltaMapper.getValuesFromRowFitDeltas).
// See NativeHuffmanWriter.encode and huffmanCode for the layout.
/**
 * Reads NativeHuffmanWriter's files (see the comment above).
 */
public class NativeHuffmanReader
{
	/**
	 * Every file starts with FORMAT_ID ('H' = Huffman format) and
	 * FORMAT_VERSION.
	 */
	static final char FORMAT_ID      = NativeHuffmanWriter.FORMAT_ID;
	/**
	 * The file format's version: bump it in the writer and reader together
	 * whenever the file layout or a coder's output changes. 2: the fit from 6
	 * neighbours, solved at every 4th pixel (1: 8 neighbours, every 3rd).
	 */
	static final int  FORMAT_VERSION = NativeHuffmanWriter.FORMAT_VERSION;

	/**
	 * The image's width and height, Color Resolution and Pixel Resolution.
	 */
	int xdim, ydim, pixel_shift, pixel_quant;
	/**
	 * Each channel's minimum (added back to the difference channels), in
	 * coding order.
	 */
	int[] min = new int[3];
	/**
	 * The number of bands.
	 */
	int bands;
	/**
	 * Each band's length in bytes.
	 */
	int[] length;
	/**
	 * How long the last decodeFile took to read the file (while decoding).
	 */
	long read_time;

	/**
	 * The decoded image.
	 */
	BufferedImage decoded_image = null;
	/**
	 * The window.
	 */
	ViewerSupport view;

	/**
	 * Reads and shows a file.
	 *
	 * @param args the file
	 */
	public static void main(String[] args)
	{
		ViewerSupport.applyHiDpiFontScaleIfNeeded();
		if(args.length != 1) { System.out.println("Usage: java NativeHuffmanReader <filename>"); System.exit(0); }
		new NativeHuffmanReader(args[0]);
	}

	/**
	 * Reads a file's header, opens its window, then reads and decodes the
	 * file (twice, printing both times: the first includes compiling the
	 * code). Reading and decoding overlap: each channel of each band starts
	 * decoding as soon as the start of it has been read, and decodes its
	 * coded bytes as they arrive (decode).
	 *
	 * @param filename the file
	 */
	public NativeHuffmanReader(String filename)
	{
		try
		{
			try(DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(filename))))
			{
				readHeader(in, filename);
			}
			System.out.println("Image:        " + xdim + " x " + ydim);
			if(bands > 1) System.out.println(NativeHuffmanWriter.describeBands(bands, DeltaMapper.getQuantizedSize(xdim, ydim, pixel_quant)[1]));
			System.out.println();

			ViewerSupport.runOnEdt(() ->
			{
				view = new ViewerSupport("Native Huffman Reader  " + filename, xdim, ydim);
				view.frame.getJMenuBar().add(view.makeViewMenu());
				view.setStatus("decoding...");
				view.show();
			});

			// Read and decoded twice, the times of both printed: the first
			// includes compiling the code (the first time it runs in this
			// JVM), the second is the run time only. The image shows after
			// the first.
			long start = System.nanoTime();
			decoded_image = decodeFile(filename);
			long first = System.nanoTime() - start, first_read = read_time;
			SwingUtilities.invokeLater(() -> { view.setImage(decoded_image); view.setStatus(null); view.fitAndShrink(); });
			start = System.nanoTime();
			BufferedImage again = decodeFile(filename);
			long second = System.nanoTime() - start;
			int[] p = decoded_image.getRGB(0, 0, xdim, ydim, null, 0, xdim), q = again.getRGB(0, 0, xdim, ydim, null, 0, xdim);
			if(!java.util.Arrays.equals(p, q)) System.out.println("WARNING: the second decoding differs from the first.");
			System.out.println("Image rebuilt (" + xdim + " x " + ydim + "); the file read in " + ViewerSupport.formatDuration(first_read) + ", then "
				+ ViewerSupport.formatDuration(read_time) + ".");
			System.out.println("Fit and last steps:         " + DeltaMapper.NATIVE_STATUS + " (the Huffman decoding: Java)");
			System.out.println("Run time plus compile time: " + ViewerSupport.formatDuration(first));
			System.out.println("Run time only:              " + ViewerSupport.formatDuration(second));
		}
		catch(Exception e)
		{
			String message = (e instanceof IOException && e.getMessage() != null) ? e.getMessage() : "Can't decode " + filename + ": " + e;
			if(view != null) SwingUtilities.invokeLater(() -> view.setStatus("decode failed"));
			ViewerSupport.showError(view != null ? view.frame : null, message);
			ViewerSupport.exitIfNoWindows();
		}
	}

	/**
	 * Reads the header: the image's size, the quantization, the channels'
	 * minimums, the number of bands and their lengths.
	 *
	 * @param in       the file
	 * @param filename its name, for messages
	 * @throws IOException if it can't be read or isn't a Huffman file
	 */
	private void readHeader(DataInputStream in, String filename) throws IOException
	{
		int id = in.readUnsignedByte(), version = in.readUnsignedByte();
		if(id != FORMAT_ID || version != FORMAT_VERSION)
			throw new IOException(id != FORMAT_ID
				? filename + " is not a Huffman file."
				: filename + " is Huffman format version " + version + "; this reader reads version " + FORMAT_VERSION + " only.");
		xdim        = in.readUnsignedShort();
		ydim        = in.readUnsignedShort();
		pixel_shift = in.readByte();
		pixel_quant = in.readByte();
		for(int i = 0; i < 3; i++) min[i] = in.readInt();
		int h = DeltaMapper.getQuantizedSize(xdim, ydim, pixel_quant)[1];
		bands = in.readUnsignedByte();
		if(bands < 1 || h / bands < 2) throw new IOException(filename + ": " + bands + " bands of a " + h + "-row image.");
		length = new int[bands];
		for(int b = 0; b < bands; b++) length[b] = in.readInt();
	}

	/**
	 * Reads the file and decodes it, in stages (decode).
	 *
	 * @param filename the file
	 * @return the image
	 * @throws IOException if it can't be read
	 */
	private BufferedImage decodeFile(String filename) throws IOException
	{
		try(InputStream in = new FileInputStream(filename)) { return decode(in, filename); }
	}

	/**
	 * The read buffer's size.
	 */
	static final int CHUNK = 1 << 16;

	/**
	 * Reads a Huffman file from a stream and decodes it: reads it all, then
	 * decodes every band's channels' deltas at the same time
	 * (NativeHuffmanWriter.huffmanDecode), then rebuilds each band's channels from
	 * them (DeltaMapper.getValuesFromRowFitDeltas), the bands at the same
	 * time; then blue, green and red are rebuilt, resized and shifted.
	 * Leaves the time the reading took in read_time.
	 *
	 * @param raw  the stream (from the start of the file)
	 * @param name its name, for messages
	 * @return the image
	 * @throws IOException if it can't be read, or isn't the file the header was read from
	 */
	private BufferedImage decode(InputStream raw, String name) throws IOException
	{
		int[]   size = DeltaMapper.getQuantizedSize(xdim, ydim, pixel_quant);
		int     w = size[0], h = size[1];
		int[]   radius = {NativeHuffmanWriter.RADIUS, NativeHuffmanWriter.RADIUS, NativeHuffmanWriter.RADIUS};
		int[][] channel = new int[3][w * h];
		int[][] init = new int[bands][3];
		NativeHuffmanWriter.HuffmanChannel[][] coded = new NativeHuffmanWriter.HuffmanChannel[bands][3];
		long start = System.nanoTime();
		DataInputStream in = new DataInputStream(new BufferedInputStream(raw, CHUNK));
		int xd = xdim, yd = ydim, nb = bands;
		int[] len = length;
		readHeader(in, name);
		if(xdim != xd || ydim != yd || bands != nb || !java.util.Arrays.equals(length, len)) throw new IOException(name + " changed while it was read.");
		for(int b = 0; b < bands; b++)
		{
			byte[] band = new byte[length[b]];
			in.readFully(band);
			DataInputStream bi = new DataInputStream(new ByteArrayInputStream(band));
			// Each channel: init, then huffmanCode's bytes.
			for(int i = 0; i < 3; i++)
			{
				init[b][i] = bi.readInt();
				coded[b][i] = NativeHuffmanWriter.huffmanRead(bi);
			}
			if(bi.available() != 0) throw new IOException(name + ": band " + b + " is not the length its header says.");
		}
		read_time = System.nanoTime() - start;

		// The bands at the same time: in C, each band's channels decoded and
		// rebuilt at once (a channel starts rebuilding as soon as its deltas
		// are decoded); in Java, its channels' deltas decoded at the same
		// time, then the channels rebuilt.
		int helpers = DeltaMapper.fitHelpers(bands);
		ViewerSupport.parallel(bands, b ->
		{
			int y0 = NativeHuffmanWriter.bandStart(b, bands, h), y1 = NativeHuffmanWriter.bandStart(b + 1, bands, h);
			int[][] v = NativeHuffmanWriter.rebuildHuffmanChannels(coded[b], w, y1 - y0, init[b], radius, helpers);
			if(v == null)
			{
				int[][] delta = new int[3][];
				ViewerSupport.parallel(3, i -> delta[i] = NativeHuffmanWriter.huffmanDecode(coded[b][i], w * (y1 - y0)));
				v = DeltaMapper.getValuesFromRowFitDeltas(delta, w, y1 - y0, init[b], radius, NativeHuffmanWriter.EVERY);
			}
			for(int i = 0; i < 3; i++) System.arraycopy(v[i], 0, channel[i], y0 * w, v[i].length);
		});

		// The minimums are added back to the difference channels, then blue,
		// green and red rebuilt, resized back and packed: in C if it's there
		// (all at once, on every core), else in Java.
		BufferedImage image = new BufferedImage(xdim, ydim, BufferedImage.TYPE_INT_RGB);
		if(DeltaMapper.NATIVE)
		{
			int[] add = new int[3];
			for(int i = 0; i < 3; i++) if(NativeHuffmanWriter.CHANNELS[i] > 2) add[i] = min[i];
			int[][] col = (pixel_quant != 0) ? ResizeMapper.centredMap(w, xdim) : new int[2][];
			int[][] row = (pixel_quant != 0) ? ResizeMapper.centredMap(channel[0].length / w, ydim) : new int[2][];
			int[] p = new int[xdim * ydim];
			if(DeltaMapper.getPixelsNative(NativeHuffmanWriter.SET_ID, channel, add, w, channel[0].length / w, col[0], col[1], row[0], row[1], DeltaMapper.RESIZE2,
			                               xdim, ydim, pixel_shift, p, Runtime.getRuntime().availableProcessors()) == 0)
			{
				// The C's pixels are as the raster holds them (what setRGB
				// would store), so they're copied in, a row at a time.
				image.getRaster().setDataElements(0, 0, xdim, ydim, p);
				return image;
			}
		}
		for(int i = 0; i < 3; i++) if(NativeHuffmanWriter.CHANNELS[i] > 2) for(int k = 0; k < channel[i].length; k++) channel[i][k] += min[i];
		int[][] bgr = DeltaMapper.getBlueGreenRed(NativeHuffmanWriter.SET_ID, channel[0], channel[1], channel[2]);
		if(pixel_quant != 0) ViewerSupport.parallel(3, c -> bgr[c] = ResizeMapper.resize2(bgr[c], w, xdim, ydim));
		image.setRGB(0, 0, xdim, ydim, DeltaMapper.getPixel(bgr[0], bgr[1], bgr[2], xdim, pixel_shift), 0, xdim);
		return image;
	}
}
