package test;

import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.MessageDigest;

/**
 * Regression harness for the readers: decodes files as NativeSimpleReader,
 * NativeHuffmanReader or NativePacketReader does (by the file's first byte),
 * without its window, and prints each one's MD5 (of the pixels' blue, green
 * and red bytes, row by row), then how long decoding it a second time took
 * (the first includes compiling the code), in milliseconds.
 *
 * <pre>
 * java -cp &lt;classes&gt; test.Decode &lt;file&gt;...
 * </pre>
 */
public class Decode
{
	/** Not instantiated: everything is static. */
	private Decode() { }

	/**
	 * Decodes each file and prints "file md5 ms".
	 *
	 * @param args the files
	 * @throws Exception when a file can't be read or decoded
	 */
	public static void main(String[] args) throws Exception
	{

		// The constructor opens a window, so the reader is made without it
		// and its header and decoding are called directly.
		Field uf = Class.forName("sun.misc.Unsafe").getDeclaredField("theUnsafe");
		uf.setAccessible(true);
		Object unsafe = uf.get(null);
		Method allocate = unsafe.getClass().getMethod("allocateInstance", Class.class);
		for(String file : args)
		{
			// The reader for the file's format: its first byte, 'F' (Simple 2,
			// NativeSimpleReader), 'H' (Huffman, NativeHuffmanReader) or 'P'
			// (Packet, NativePacketReader).
			int id;
			try(InputStream in = new FileInputStream(file)) { id = in.read(); }
			Object reader;
			Method decode;
			if(id == 'P')
			{
				// NativePacketReader has a constructor without the window.
				Class<?> c = Class.forName("NativePacketReader");
				java.lang.reflect.Constructor<?> make = c.getDeclaredConstructor();
				make.setAccessible(true);
				reader = make.newInstance();
				decode = c.getDeclaredMethod("decodeFile", String.class);
				decode.setAccessible(true);
			}
			else
			{
				Class<?> c = Class.forName((id == 'H') ? "NativeHuffmanReader" : "NativeSimpleReader");
				Method header = c.getDeclaredMethod("readHeader", DataInputStream.class, String.class);
				decode = c.getDeclaredMethod("decodeFile", String.class);
				header.setAccessible(true);
				decode.setAccessible(true);
				Field min = c.getDeclaredField("min");
				min.setAccessible(true);
				reader = allocate.invoke(unsafe, c);
				min.set(reader, new int[3]);
				try(DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(file)))) { header.invoke(reader, in, file); }
			}
			BufferedImage image = (BufferedImage) decode.invoke(reader, file);
			long start = System.nanoTime();
			decode.invoke(reader, file);
			double ms = (System.nanoTime() - start) / 1e6;
			int xdim = image.getWidth(), ydim = image.getHeight();
			int[] pixel = image.getRGB(0, 0, xdim, ydim, null, 0, xdim);
			MessageDigest md = MessageDigest.getInstance("MD5");
			for(int p : pixel) { md.update((byte) p); md.update((byte) (p >> 8)); md.update((byte) (p >> 16)); }
			StringBuilder hex = new StringBuilder();
			for(byte b : md.digest()) hex.append(String.format("%02x", b));
			System.out.println(file + " " + hex + " " + String.format("%.0f", ms));
		}
	}
}
