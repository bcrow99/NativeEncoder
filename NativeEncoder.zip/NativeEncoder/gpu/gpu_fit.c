/* gpu_fit: a first experiment with the GPU. The encoder's least-squares fit
   (RowFit_plane in native/DeltaMapper.c: a fit at every 4th pixel of each
   row from the rows above, and each pixel's prediction from it), run on the
   GPU through OpenCL (rowfit.cl) and on the CPU (the library's C, all its
   threads), timed, and the two predictions compared value by value: the
   GPU's must be the C's, bit for bit, to be of any use.

     gpu_fit image.ppm [radius every rows device]   (defaults 10 4 64 0)

   The image is a binary PPM (P6); ToPPM.java makes one from a JPEG or PNG.
   Two channels are fitted, as NativeWriter's first two: green alone (6
   features, 7 unknowns) and blue - green with green as its previous channel
   (9 features, 10 unknowns). rows is how many rows the GPU does at a time;
   device picks one if there are several (they're listed). OpenCL is loaded
   when the program runs (OpenCL.dll on Windows, from the graphics driver;
   libOpenCL.so.1 on Linux), so building needs only its headers. */
#define CL_TARGET_OPENCL_VERSION 120
#include <CL/cl.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef _WIN32
#include <windows.h>
#else
#include <dlfcn.h>
#include <unistd.h>
#endif

#include "DeltaMapper.h"   /* RowFit_plane, DeltaMapper_seconds */
#include "BlockPool.h"     /* last: the library's malloc and free */

/* ---- OpenCL, loaded at run time -------------------------------------------
   Each function used, as a pointer of its own type, found by name. */
#define CL_FUNCTIONS(X) X(clGetPlatformIDs) X(clGetPlatformInfo) X(clGetDeviceIDs) X(clGetDeviceInfo) \
	X(clCreateContext) X(clCreateCommandQueue) X(clCreateProgramWithSource) X(clBuildProgram)         \
	X(clGetProgramBuildInfo) X(clCreateKernel) X(clCreateBuffer) X(clSetKernelArg)                    \
	X(clEnqueueWriteBuffer) X(clEnqueueReadBuffer) X(clEnqueueNDRangeKernel) X(clFinish)              \
	X(clReleaseMemObject) X(clReleaseKernel) X(clReleaseProgram) X(clReleaseCommandQueue) X(clReleaseContext)
#define DECLARE(f) static __typeof__(&f) p_##f;
CL_FUNCTIONS(DECLARE)

static int load_opencl(void)
{
#ifdef _WIN32
	HMODULE lib = LoadLibraryA("OpenCL.dll");
#define FIND(f) if(!(p_##f = (__typeof__(&f)) (void *) GetProcAddress(lib, #f))) return -1;
#else
	void *lib = dlopen("libOpenCL.so.1", RTLD_NOW);
	if(!lib) lib = dlopen("libOpenCL.so", RTLD_NOW);
#define FIND(f) if(!(p_##f = (__typeof__(&f)) dlsym(lib, #f))) return -1;
#endif
	if(!lib) return -1;
	CL_FUNCTIONS(FIND)
	return 0;
}

#define CHECK(call) do { cl_int e_ = (call); if(e_ != CL_SUCCESS) { fprintf(stderr, "OpenCL error %d at line %d: %s\n", e_, __LINE__, #call); exit(1); } } while(0)

/* ---- The image ------------------------------------------------------------ */

static int read_token(FILE *f)
{
	int c, v = 0;
	while((c = fgetc(f)) != EOF)
	{
		if(c == '#') { while((c = fgetc(f)) != EOF && c != '\n') ; continue; }
		if(c >= '0' && c <= '9') break;
	}
	for(; c >= '0' && c <= '9'; c = fgetc(f)) v = v * 10 + (c - '0');
	return v;
}

static unsigned char *read_ppm(const char *name, int *xdim, int *ydim)
{
	FILE *f = fopen(name, "rb");
	if(!f) return NULL;
	if(fgetc(f) != 'P' || fgetc(f) != '6') { fclose(f); return NULL; }
	*xdim = read_token(f); *ydim = read_token(f);
	int maxval = read_token(f);   /* (the one whitespace after it is read) */
	size_t n = (size_t) *xdim * *ydim * 3;
	unsigned char *rgb = (maxval == 255 && n > 0) ? malloc(n) : NULL;
	if(rgb && fread(rgb, 1, n, f) != n) { free(rgb); rgb = NULL; }
	fclose(f);
	return rgb;
}

/* ---- The GPU's version ----------------------------------------------------- */

typedef struct Gpu
{
	cl_context ctx;
	cl_command_queue queue;
	cl_device_id device;
	char *source;
} Gpu;

static char *read_file(const char *name)
{
	FILE *f = fopen(name, "rb");
	if(!f) return NULL;
	fseek(f, 0, SEEK_END);
	long n = ftell(f);
	fseek(f, 0, SEEK_SET);
	char *s = malloc((size_t) n + 1);
	if(s && fread(s, 1, (size_t) n, f) != (size_t) n) { free(s); s = NULL; }
	if(s) s[n] = 0;
	fclose(f);
	return s;
}

/* The devices, listed; the one asked for (GPUs first) set up. */
static int gpu_open(Gpu *g, int want, const char *source_name)
{
	cl_platform_id plat[8];
	cl_uint np = 0;
	if(p_clGetPlatformIDs(8, plat, &np) != CL_SUCCESS || np == 0) { fprintf(stderr, "No OpenCL platforms.\n"); return -1; }
	cl_device_id dev[32];
	int nd = 0;
	for(int pass = 0; pass < 2; pass++)   /* GPUs, then the others */
		for(cl_uint p = 0; p < np; p++)
		{
			cl_uint n = 0;
			cl_device_id d[16];
			if(p_clGetDeviceIDs(plat[p], pass ? (CL_DEVICE_TYPE_ALL & ~CL_DEVICE_TYPE_GPU) : CL_DEVICE_TYPE_GPU, 16, d, &n) != CL_SUCCESS) continue;
			for(cl_uint i = 0; i < n && nd < 32; i++) dev[nd++] = d[i];
		}
	if(nd == 0) { fprintf(stderr, "No OpenCL devices.\n"); return -1; }
	for(int i = 0; i < nd; i++)
	{
		char name[256] = "", vendor[256] = "", ext[8192] = "";
		cl_uint units = 0, mhz = 0;
		cl_ulong mem = 0;
		p_clGetDeviceInfo(dev[i], CL_DEVICE_NAME, sizeof name, name, NULL);
		p_clGetDeviceInfo(dev[i], CL_DEVICE_VENDOR, sizeof vendor, vendor, NULL);
		p_clGetDeviceInfo(dev[i], CL_DEVICE_EXTENSIONS, sizeof ext, ext, NULL);
		p_clGetDeviceInfo(dev[i], CL_DEVICE_MAX_COMPUTE_UNITS, sizeof units, &units, NULL);
		p_clGetDeviceInfo(dev[i], CL_DEVICE_MAX_CLOCK_FREQUENCY, sizeof mhz, &mhz, NULL);
		p_clGetDeviceInfo(dev[i], CL_DEVICE_GLOBAL_MEM_SIZE, sizeof mem, &mem, NULL);
		printf("%s device %d: %s (%s), %u compute units, %u MHz, %.0f MB, doubles %s\n", (i == want) ? "*" : " ", i, name, vendor,
		       units, mhz, mem / 1048576.0, strstr(ext, "cl_khr_fp64") ? "yes" : "NO");
	}
	if(want < 0 || want >= nd) { fprintf(stderr, "No device %d.\n", want); return -1; }
	g->device = dev[want];
	char ext[8192] = "";
	p_clGetDeviceInfo(g->device, CL_DEVICE_EXTENSIONS, sizeof ext, ext, NULL);
	if(!strstr(ext, "cl_khr_fp64")) { fprintf(stderr, "That device has no doubles (cl_khr_fp64): the fit can't be done on it.\n"); return -1; }
	cl_int e;
	g->ctx = p_clCreateContext(NULL, 1, &g->device, NULL, NULL, &e);
	CHECK(e);
	g->queue = p_clCreateCommandQueue(g->ctx, g->device, 0, &e);
	CHECK(e);
	g->source = read_file(source_name);
	if(!g->source) { fprintf(stderr, "Can't read %s.\n", source_name); return -1; }
	return 0;
}

/* The program built for one channel kind (nf 6 or 9). */
static cl_program gpu_build(Gpu *g, int nf, int radius, int every)
{
	cl_int e;
	const char *src = g->source;
	cl_program prog = p_clCreateProgramWithSource(g->ctx, 1, &src, NULL, &e);
	CHECK(e);
	char opt[128];
	snprintf(opt, sizeof opt, "-D NF=%d -D R=%d -D EVERY=%d", nf, radius, every);   /* (no -cl-mad-enable or fast math: exact results) */
	if(p_clBuildProgram(prog, 1, &g->device, opt, NULL, NULL) != CL_SUCCESS)
	{
		size_t n = 0;
		p_clGetProgramBuildInfo(prog, g->device, CL_PROGRAM_BUILD_LOG, 0, NULL, &n);
		char *log = malloc(n + 1);
		p_clGetProgramBuildInfo(prog, g->device, CL_PROGRAM_BUILD_LOG, n, log, NULL);
		log[n] = 0;
		fprintf(stderr, "Build failed:\n%s\n", log);
		exit(1);
	}
	return prog;
}

/* The prediction plane on the GPU, rows rows at a time: columns, solve and
   predict for each chunk (out's row 0 and first and last columns stay 0, as
   the C's). */
static void gpu_plane(Gpu *g, cl_program prog, const int32_t *v, const int32_t *ref, int xdim, int ydim, int radius, int every,
                      int rows, int16_t *out)
{
	(void) radius;
	int nf = ref ? 9 : 6, m = nf + 2, nt = m * (m + 1) / 2, n = nf + 1;
	int points = (xdim - 2 + every - 1) / every;
	size_t plane = (size_t) xdim * ydim;
	cl_int e;
	cl_mem bv   = p_clCreateBuffer(g->ctx, CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR, plane * 4, (void *) v, &e); CHECK(e);
	cl_mem bref = p_clCreateBuffer(g->ctx, CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR, plane * 4, (void *) (ref ? ref : v), &e); CHECK(e);
	cl_mem bcol = p_clCreateBuffer(g->ctx, CL_MEM_READ_WRITE, (size_t) rows * nt * xdim * 4, NULL, &e); CHECK(e);
	cl_mem bcf  = p_clCreateBuffer(g->ctx, CL_MEM_READ_WRITE, (size_t) rows * points * n * 8 + 8, NULL, &e); CHECK(e);
	cl_mem bok  = p_clCreateBuffer(g->ctx, CL_MEM_READ_WRITE, (size_t) rows * points + 1, NULL, &e); CHECK(e);
	memset(out, 0, plane * sizeof *out);
	cl_mem bout = p_clCreateBuffer(g->ctx, CL_MEM_WRITE_ONLY | CL_MEM_COPY_HOST_PTR, plane * 2, out, &e); CHECK(e);
	cl_kernel kc = p_clCreateKernel(prog, "columns", &e); CHECK(e);
	cl_kernel ks = p_clCreateKernel(prog, "solve", &e);   CHECK(e);
	cl_kernel kp = p_clCreateKernel(prog, "predict", &e); CHECK(e);
	CHECK(p_clSetKernelArg(kc, 0, sizeof bv, &bv));   CHECK(p_clSetKernelArg(kc, 1, sizeof bref, &bref));
	CHECK(p_clSetKernelArg(kc, 2, sizeof xdim, &xdim)); CHECK(p_clSetKernelArg(kc, 4, sizeof bcol, &bcol));
	CHECK(p_clSetKernelArg(ks, 0, sizeof bcol, &bcol)); CHECK(p_clSetKernelArg(ks, 1, sizeof xdim, &xdim));
	CHECK(p_clSetKernelArg(ks, 2, sizeof points, &points)); CHECK(p_clSetKernelArg(ks, 3, sizeof bcf, &bcf));
	CHECK(p_clSetKernelArg(ks, 4, sizeof bok, &bok));
	CHECK(p_clSetKernelArg(kp, 0, sizeof bv, &bv));   CHECK(p_clSetKernelArg(kp, 1, sizeof bref, &bref));
	CHECK(p_clSetKernelArg(kp, 2, sizeof xdim, &xdim)); CHECK(p_clSetKernelArg(kp, 4, sizeof points, &points));
	CHECK(p_clSetKernelArg(kp, 5, sizeof bcf, &bcf)); CHECK(p_clSetKernelArg(kp, 6, sizeof bok, &bok));
	CHECK(p_clSetKernelArg(kp, 7, sizeof bout, &bout));
	if(xdim > 2)
		for(int y0 = 1; y0 < ydim; y0 += rows)
		{
			int r = (ydim - y0 < rows) ? ydim - y0 : rows;
			CHECK(p_clSetKernelArg(kc, 3, sizeof y0, &y0));
			CHECK(p_clSetKernelArg(kp, 3, sizeof y0, &y0));
			size_t gc[2] = { (size_t) xdim - 2, (size_t) r }, gs[2] = { (size_t) points, (size_t) r };
			CHECK(p_clEnqueueNDRangeKernel(g->queue, kc, 2, NULL, gc, NULL, 0, NULL, NULL));
			CHECK(p_clEnqueueNDRangeKernel(g->queue, ks, 2, NULL, gs, NULL, 0, NULL, NULL));
			CHECK(p_clEnqueueNDRangeKernel(g->queue, kp, 2, NULL, gc, NULL, 0, NULL, NULL));
		}
	CHECK(p_clEnqueueReadBuffer(g->queue, bout, CL_TRUE, 0, plane * 2, out, 0, NULL, NULL));
	p_clReleaseKernel(kc); p_clReleaseKernel(ks); p_clReleaseKernel(kp);
	p_clReleaseMemObject(bv); p_clReleaseMemObject(bref); p_clReleaseMemObject(bcol);
	p_clReleaseMemObject(bcf); p_clReleaseMemObject(bok); p_clReleaseMemObject(bout);
}

/* ---- The comparison --------------------------------------------------------- */

static int processors(void)
{
#ifdef _WIN32
	SYSTEM_INFO si;
	GetSystemInfo(&si);
	return (int) si.dwNumberOfProcessors;
#else
	long n = sysconf(_SC_NPROCESSORS_ONLN);
	return (n > 0) ? (int) n : 1;
#endif
}

int main(int argc, char **argv)
{
	if(argc < 2) { fprintf(stderr, "usage: gpu_fit image.ppm [radius every rows device]\n"); return 1; }
	int radius = (argc > 2) ? atoi(argv[2]) : 10, every = (argc > 3) ? atoi(argv[3]) : 4;
	int rows   = (argc > 4) ? atoi(argv[4]) : 64, want  = (argc > 5) ? atoi(argv[5]) : 0;
	int xdim, ydim;
	unsigned char *rgb = read_ppm(argv[1], &xdim, &ydim);
	if(!rgb) { fprintf(stderr, "Can't read %s as a binary PPM (P6, maxval 255).\n", argv[1]); return 1; }
	size_t plane = (size_t) xdim * ydim;
	int32_t *green = malloc(plane * 4), *blue_green = malloc(plane * 4);
	for(size_t k = 0; k < plane; k++)
	{
		green[k]      = rgb[3 * k + 1];
		blue_green[k] = rgb[3 * k + 2] - rgb[3 * k + 1] + 255;   /* (kept positive, as NativeWriter's less its minimum) */
	}
	free(rgb);
	printf("%s: %d x %d; radius %d, a fit every %d pixels, %d rows at a time on the GPU\n", argv[1], xdim, ydim, radius, every, rows);

	/* The two channels: green alone, blue - green after green. */
	const int32_t *chan[2] = { green, blue_green }, *refs[2] = { NULL, green };
	const char *label[2] = { "green (7 unknowns)", "blue - green (10 unknowns)" };
	int16_t *cpu = malloc(plane * 2), *gpu = malloc(plane * 2);
	int threads = processors();

	if(load_opencl()) { fprintf(stderr, "Can't load OpenCL (OpenCL.dll / libOpenCL.so.1): is a graphics driver with OpenCL installed?\n"); return 1; }
	Gpu g;
	memset(&g, 0, sizeof g);
	char source[1024];
	const char *slash = strrchr(argv[0], '/'), *back = strrchr(argv[0], '\\');
	if(back > slash) slash = back;
	snprintf(source, sizeof source, "%.*srowfit.cl", slash ? (int) (slash - argv[0] + 1) : 0, argv[0]);
	if(gpu_open(&g, want, source)) return 1;

	for(int c = 0; c < 2; c++)
	{
		double t0 = DeltaMapper_seconds();
		cl_program prog = gpu_build(&g, refs[c] ? 9 : 6, radius, every);
		double built = DeltaMapper_seconds() - t0;
		double best_cpu = 1e9, best_gpu = 1e9;
		for(int run = 0; run < 3; run++)
		{
			double a = DeltaMapper_seconds();
			if(RowFit_plane(chan[c], refs[c], xdim, ydim, radius, every, cpu, threads, NULL)) { fprintf(stderr, "Out of memory.\n"); return 1; }
			double b = DeltaMapper_seconds();
			gpu_plane(&g, prog, chan[c], refs[c], xdim, ydim, radius, every, rows, gpu);
			double d = DeltaMapper_seconds();
			if(b - a < best_cpu) best_cpu = b - a;
			if(d - b < best_gpu) best_gpu = d - b;
		}
		size_t differ = 0, first = 0;
		for(size_t k = 0; k < plane; k++) if(cpu[k] != gpu[k]) { if(!differ) first = k; differ++; }
		printf("\n%s:\n  CPU (the C, %d threads) %.1f ms; GPU %.1f ms (program built in %.0f ms, once)\n", label[c], threads, best_cpu * 1e3, best_gpu * 1e3, built * 1e3);
		if(differ == 0) printf("  the predictions are the same, all %zu\n", plane);
		else printf("  %zu predictions differ, the first at row %zu, column %zu: CPU %d, GPU %d\n", differ, first / xdim, first % xdim, cpu[first], gpu[first]);
		p_clReleaseProgram(prog);
	}
	p_clReleaseCommandQueue(g.queue);
	p_clReleaseContext(g.ctx);
	return 0;
}
