/* rowfit.cl: RowFit_plane (native/DeltaMapper.c) on the GPU, in OpenCL C.
   The least-squares fit from the rows above at every EVERY-th pixel, and
   each interior pixel's prediction from it, the same as the C's bit for
   bit: the window sums are exact integers, and the solve and the
   prediction do the C's double operations in the C's order, with no fused
   multiply-adds (FP_CONTRACT OFF, as the C's -ffp-contract=off).

   Three kernels, for a chunk of rows y0 <= y < y0 + rows at a time:
     columns  each column's sums over its window rows (int, as the C's col)
     solve    each point's window sums (long) and its fit (double)
     predict  each pixel's prediction (short)
   Built with -D NF=6 (a channel alone: W, N, NW, NE, WW, NNE) or NF=9 (with
   the previous channel's value here, left and above), -D R (the window
   radius) and -D EVERY. */

#pragma OPENCL EXTENSION cl_khr_fp64 : enable
#pragma OPENCL FP_CONTRACT OFF

#define M  (NF + 2)              /* the features, the constant 1 and the value */
#define NT (M * (M + 1) / 2)     /* their products, i <= j */
#define N  (NF + 1)              /* the unknowns */

/* The value at (y, x), clamped to the image (the C's at()). */
static int at(__global const int *v, int xdim, int y, int x)
{
	if(y < 0) y = 0;
	if(x < 0) x = 0; else if(x > xdim - 1) x = xdim - 1;
	return v[y * xdim + x];
}

/* The C's features(): W, N, NW, NE, WW, NNE (clamped), the previous
   channel's here, left and above (NF 9), then 1 and the value. */
static void features(__global const int *v, __global const int *ref, int xdim, int y, int x, int *z)
{
	z[0] = at(v, xdim, y, x - 1);
	z[1] = at(v, xdim, y - 1, x);
	z[2] = at(v, xdim, y - 1, x - 1);
	z[3] = at(v, xdim, y - 1, x + 1);
	z[4] = at(v, xdim, y, x - 2);
	z[5] = at(v, xdim, y - 2, x + 1);
#if NF == 9
	int k = y * xdim + x;
	z[6] = ref[k]; z[7] = ref[k - 1]; z[8] = ref[k - xdim];
#endif
	z[NF]     = 1;
	z[NF + 1] = v[y * xdim + x];
}

/* Column x (1 to xdim - 2) of row y0 + i: the products' sums over the
   window rows, max(1, y - R) to y - 1, into col[(i * NT + t) * xdim + x]. */
__kernel void columns(__global const int *v, __global const int *ref, int xdim, int y0, __global int *col)
{
	int x = get_global_id(0) + 1, i = get_global_id(1), y = y0 + i;
	int sum[NT];
	for(int t = 0; t < NT; t++) sum[t] = 0;
	int ty = y - R;
	if(ty < 1) ty = 1;
	for(; ty <= y - 1; ty++)
	{
		int z[M];
		features(v, ref, xdim, ty, x, z);
		int t = 0;
		for(int a = 0; a < M; a++)
			for(int b = a; b < M; b++, t++) sum[t] += z[a] * z[b];
	}
	for(int t = 0; t < NT; t++) col[(i * NT + t) * xdim + x] = sum[t];
}

/* Point p (at column 1 + p * EVERY) of row y0 + i: its window's sums
   (columns x - R to x + R, clamped to 1 and xdim - 2), then the C's solve():
   the normal equations with ridge 1 on the diagonal, L D L^T, and the two
   triangular solves. coef gets the N coefficients, valid whether it could
   be solved. */
__kernel void solve(__global const int *col, int xdim, int points, __global double *coef, __global uchar *valid)
{
	int p = get_global_id(0), i = get_global_id(1);
	int x = 1 + p * EVERY, lo = max(x - R, 1), hi = min(x + R, xdim - 2);
	long win[NT];
	for(int t = 0; t < NT; t++)
	{
		__global const int *c = col + (i * NT + t) * xdim;
		long s = 0;
		for(int k = lo; k <= hi; k++) s += c[k];
		win[t] = s;
	}
	__global double *out = coef + ((size_t) i * points + p) * N;
	__global uchar *ok = valid + (size_t) i * points + p;
	long count = win[NF * M - NF * (NF - 1) / 2];
	if(count < 2 * N) { *ok = 0; return; }
	double a[N][N], b[N], dg[N], c[N];
	for(int r = 0; r < N; r++)
	{
		int base = r * M - r * (r - 1) / 2;
		for(int j = r; j < N; j++) a[j][r] = (double) win[base + j - r];
		b[r] = (double) win[base + M - 1 - r];
		a[r][r] += 1.0;
	}
	for(int j = 0; j < N; j++)
	{
		double s = a[j][j];
		for(int q = 0; q < j; q++) s -= a[j][q] * a[j][q] * dg[q];
		if(s < 1e-9) { *ok = 0; return; }
		dg[j] = s;
		for(int r = j + 1; r < N; r++)
		{
			double t = a[r][j];
			for(int q = 0; q < j; q++) t -= a[r][q] * a[j][q] * dg[q];
			a[r][j] = t / s;
		}
	}
	for(int r = 0; r < N; r++)
	{
		double s = b[r];
		for(int q = 0; q < r; q++) s -= a[r][q] * c[q];
		c[r] = s;
	}
	for(int r = 0; r < N; r++) c[r] /= dg[r];
	for(int r = N - 1; r >= 0; r--)
	{
		double s = c[r];
		for(int q = r + 1; q < N; q++) s -= a[q][r] * c[q];
		c[r] = s;
	}
	for(int r = 0; r < N; r++) out[r] = c[r];
	*ok = 1;
}

/* Pixel x (1 to xdim - 2) of row y0 + i: the C's RowFit_predict, from its
   point's fit (or the value to the left if it couldn't be solved), clamped
   to 2 beyond its 8 neighbours' range, rounded. */
__kernel void predict(__global const int *v, __global const int *ref, int xdim, int y0, int points,
                      __global const double *coef, __global const uchar *valid, __global short *out)
{
	int x = get_global_id(0) + 1, i = get_global_id(1), y = y0 + i;
	int p = (x - 1) / EVERY;
	int pa = at(v, xdim, y, x - 1), pb = at(v, xdim, y - 1, x), pc = at(v, xdim, y - 1, x - 1), pd = at(v, xdim, y - 1, x + 1);
	if(!valid[(size_t) i * points + p]) { out[y * xdim + x] = (short) pa; return; }
	int z[M];
	features(v, ref, xdim, y, x, z);
	__global const double *cf = coef + ((size_t) i * points + p) * N;
	double s = 0;
	for(int r = 0; r < N; r++) s += cf[r] * (double) z[r];
	int ww = z[4], nne = z[5], nn = at(v, xdim, y - 2, x), nee = at(v, xdim, y - 1, x + 2);
	int l = min(min(pa, pb), min(pc, pd)), h = max(max(pa, pb), max(pc, pd));
	l = min(min(l, ww), min(min(nne, nn), nee));
	h = max(max(h, ww), max(max(nne, nn), nee));
	double hd = (double) (h + 2), ld = (double) (l - 2);
	double t = (s <= hd) ? s : hd;
	double w = (ld >= t) ? ld : t;
	out[y * xdim + x] = (short) (int) floor(w + 0.5);
}
