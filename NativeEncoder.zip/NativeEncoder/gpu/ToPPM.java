import java.awt.image.BufferedImage;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import javax.imageio.ImageIO;

/**
 * Writes an image (JPEG, PNG, anything ImageIO reads) as a binary PPM (P6),
 * for gpu_fit:
 * <pre>
 * java ToPPM.java image.jpg image.ppm
 * </pre>
 */
public class ToPPM
{
	/** Not made: main only. */
	private ToPPM() { }

	/**
	 * Converts the image.
	 *
	 * @param args the image, then the PPM to write
	 * @throws IOException if either can't be read or written
	 */
	public static void main(String[] args) throws IOException
	{
		if(args.length < 2) { System.out.println("Usage: java ToPPM.java image ppm"); return; }
		BufferedImage image = ImageIO.read(new File(args[0]));
		if(image == null) { System.out.println("Can't read " + args[0]); return; }
		int w = image.getWidth(), h = image.getHeight();
		int[] rgb = image.getRGB(0, 0, w, h, null, 0, w);
		try(OutputStream out = new BufferedOutputStream(new FileOutputStream(args[1])))
		{
			out.write(("P6\n" + w + " " + h + "\n255\n").getBytes("US-ASCII"));
			for(int p : rgb) { out.write(p >> 16); out.write(p >> 8); out.write(p); }
		}
		System.out.println("Wrote " + args[1] + ": " + w + " x " + h);
	}
}
