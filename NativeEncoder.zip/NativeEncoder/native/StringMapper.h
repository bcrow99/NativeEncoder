/*
 * StringMapper.h -- StringMapper's unary strings in C: the parts of
 * StringMapper.java that NativeWriter2 and NativeReader2 use, under the same
 * names, giving the same bytes and values as the Java.
 *
 * A string is a bit string (bits in each byte from the low bit up) followed
 * by one data byte: the number of unused bits in the last byte (top 3 bits),
 * and the bit-pair transform's type and iterations (low 5 bits; see
 * setData in the Java).
 */
#ifndef STRINGMAPPER_H
#define STRINGMAPPER_H

#include <stddef.h>
#include <stdint.h>

/* StringMapper.getStringList(value, true), without changing value: the
   values unary-coded by frequency rank (packStrings), then the bit-pair
   transform if it saves enough (compressStrings). Sets *min (the smallest
   value), *bitlength (the untransformed string's bits), *table (each value's
   rank, value - min; *range entries) and *string (*length bytes, data byte
   included). *table and *string are malloc'd: the caller frees them.
   Returns 0, or -1 if out of memory (nothing is left allocated). */
int StringMapper_getStringList(const int32_t *value, int n, int32_t *min, int32_t *bitlength,
                               int32_t **table, int *range, uint8_t **string, size_t *length);

/* StringMapper.decompressStrings: string (length bytes) with the bit-pair
   transform undone, into *out (*out_length bytes, malloc'd: the caller frees
   it; a copy if it wasn't transformed). Returns 0, or -1 if out of memory. */
int StringMapper_decompressStrings(const uint8_t *string, size_t length, uint8_t **out, size_t *out_length);

/* StringMapper.unpackStrings: the size values of an untransformed string
   (length bytes) packed with table (n entries) and bitlength bits, into dst.
   Returns 0, or -1 if out of memory. */
int StringMapper_unpackStrings(const uint8_t *src, size_t length, const int32_t *table, int n,
                               int size, int bitlength, int32_t *dst);

#endif
