/*
 * CodeMapper.h -- CodeMapper's regular (canonical) Huffman code in C: the
 * parts of CodeMapper.java that NativeHuffmanWriter and NativeHuffmanReader use, under
 * the same names, giving the same bytes as the Java. The code lengths come
 * from the Java (getRegularHuffmanLength; 256 of them, 0 for unused bytes,
 * at most CODEMAPPER_MAX_CODE_LENGTH).
 */
#ifndef CODEMAPPER_H
#define CODEMAPPER_H

#include <stddef.h>
#include <stdint.h>

/* CodeMapper.REGULAR_MAX_CODE_LENGTH */
#define CODEMAPPER_MAX_CODE_LENGTH 24

/* CodeMapper.packRegularCode: data (n bytes) Huffman coded with length,
   each code from its high bit, into *code (*code_length bytes, malloc'd:
   the caller frees it; nothing if at most one byte value is used). Returns 0,
   or -1 if out of memory. */
int CodeMapper_packRegularCode(const uint8_t *data, size_t n, const uint8_t length[256], uint8_t **code, size_t *code_length);

/* CodeMapper.unpackRegularCode: n bytes decoded from src (src_length bytes)
   with length, into dst. Returns 0, or -1 if src ends early or holds a code
   that isn't one (where the Java throws). */
int CodeMapper_unpackRegularCode(const uint8_t *src, size_t src_length, const uint8_t length[256], size_t n, uint8_t *dst);

#endif
