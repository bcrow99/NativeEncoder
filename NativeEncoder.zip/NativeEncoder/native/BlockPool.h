/*
 * BlockPool.h -- the library's memory, kept for reuse: large blocks (1 MB
 * and more) that are freed aren't given back to the system but kept, and
 * handed out again for later requests of about their size.
 *
 * Why: blocks that big come straight from the system, and go straight back
 * to it when freed, so every frame's buffers (the channels copied from Java,
 * the deltas, the models, the fits: some hundreds of MB for a big frame)
 * were fresh memory, each page of it supplied and cleared by the system the
 * first time it was touched. That costs more on Windows than on Linux. Kept
 * blocks have their pages in place already: from the second frame on, a
 * program that keeps running doesn't pay for them again. (Measured on Linux,
 * with the blocks kept: a fifth of the page faults' cost gone, and LS
 * decoding in 1 band a fifth faster.)
 *
 * Every C file of the library includes this header last, which turns its
 * malloc, calloc, realloc and free into the pool's, so all the library's
 * memory comes from the pool and goes back to it. (A block from the pool must
 * be freed by the pool: no pointer goes between the library and other code.)
 *
 * The pool keeps at most a quarter of the computer's memory, and at most 2
 * GB; when a block can't be kept, the smallest kept ones are given back
 * first. BlockPool_release gives everything back.
 */
#ifndef BLOCKPOOL_H
#define BLOCKPOOL_H

#include <stddef.h>
#include <stdlib.h>

/* malloc, calloc, realloc and free, with large blocks kept for reuse.
   Blocks under 1 MB are the system's, as before (with a few bytes more). */
void *BlockPool_malloc(size_t n);
void *BlockPool_calloc(size_t count, size_t size);
void *BlockPool_realloc(void *p, size_t n);
void  BlockPool_free(void *p);

/* Gives every kept block back to the system. */
void BlockPool_release(void);

#ifndef BLOCKPOOL_IMPLEMENTATION
#define malloc(n)     BlockPool_malloc(n)
#define calloc(c, s)  BlockPool_calloc(c, s)
#define realloc(p, n) BlockPool_realloc(p, n)
#define free(p)       BlockPool_free(p)
#endif

#endif
