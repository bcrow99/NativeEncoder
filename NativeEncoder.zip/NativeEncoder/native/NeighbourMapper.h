/* NeighbourMapper: the neighbour Huffman coding and decoding
   (NeighbourMapper.java's neighbourCode and neighbourDecode) in C, for
   NativeWriter and NativeReader: the same bytes from the same deltas, and
   the same deltas from the same bytes. */
#ifndef NEIGHBOURMAPPER_H
#define NEIGHBOURMAPPER_H

#include <stddef.h>
#include <stdint.h>

/* A channel's deltas from its neighbour Huffman coding: code (code_length
   bytes, the bit stream neighbourCode wrote after its three ints), lo (the
   smallest delta), values (the number of delta values), flip (1 if the
   single deltas' signs are flipped where their neighbours' is negative:
   version 2 of the coding; 0 for version 1), for an image xdim by ydim.
   delta gets xdim * ydim deltas (delta[0] is 0). Returns 0, or -1 if out of
   memory or the bytes aren't what neighbourCode writes. */
int NeighbourMapper_decode(const uint8_t *code, size_t code_length, int lo, int values, int flip, int xdim, int ydim, int32_t *delta);

/* A channel's deltas neighbour Huffman coded, version 2 of the coding (the
   single deltas' signs flipped where their neighbours' is negative) (n of
   them, xdim wide; delta[0] is taken as 0): *code gets the bit stream (malloc'd: the caller frees it,
   with the library's free), *code_length its bytes, *lo the smallest delta
   and *values the number of delta values (the three ints neighbourCode
   writes before the bit stream: lo, values, the length). Returns 0, or -1 if
   out of memory. */
int NeighbourMapper_code(const int32_t *delta, int n, int xdim, int *lo, int *values, uint8_t **code, size_t *code_length);

#endif
