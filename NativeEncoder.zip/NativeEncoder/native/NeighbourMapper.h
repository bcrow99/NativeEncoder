/* NeighbourMapper: the neighbour Huffman coding and decoding
   (NeighbourMapper.java's neighbourCode, neighbourDecode and
   NeighbourDecoder) in C, for NativeWriter and NativeReader: the same bytes
   from the same deltas, and the same deltas from the same bytes. */
#ifndef NEIGHBOURMAPPER_H
#define NEIGHBOURMAPPER_H

#include <stddef.h>
#include <stdint.h>

/* A channel's deltas from its neighbour Huffman coding of version 1 or 2:
   code (code_length bytes, the bit stream neighbourCode wrote after its
   three ints), lo (the smallest delta), values (the number of delta
   values), flip (1 if the single deltas' signs are flipped where their
   neighbours' is negative: version 2 of the coding; 0 for version 1), for
   an image xdim by ydim. delta gets xdim * ydim deltas (delta[0] is 0).
   Returns 0, or -1 if out of memory or the bytes aren't what neighbourCode
   writes. */
int NeighbourMapper_decode(const uint8_t *code, size_t code_length, int lo, int values, int flip, int xdim, int ydim, int32_t *delta);

/* A channel's deltas neighbour Huffman coded, version 3 of the coding (with
   the second opinions) (n of them, xdim wide; delta[0] is taken as 0), with
   the channel's values from the deltas' first (value; the predictions are
   value - delta): *code gets the bit stream (malloc'd: the caller frees it,
   with the library's free), *code_length its bytes, *lo the smallest delta
   and *values the number of delta values (the three ints neighbourCode
   writes before the bit stream: lo, values, the length). Returns 0, or -1 if
   out of memory. */
int NeighbourMapper_code(const int32_t *delta, const int32_t *value, int n, int xdim, int *lo, int *values, uint8_t **code, size_t *code_length);

/* Version 3's decoder, a pixel at a time inside the rebuilding
   (NeighbourMapper.NeighbourDecoder). */
typedef struct NeighbourDecoder NeighbourDecoder;

/* A decoder at the start of a channel's coding (code, code_length, lo and
   values as for NeighbourMapper_decode; code is read as the decoding goes,
   so it must stay there till then), xdim wide. NULL if out of memory or
   the tables aren't what neighbourCode writes. */
NeighbourDecoder *NeighbourDecoder_new(const uint8_t *code, size_t code_length, int lo, int values, int xdim);

/* Decodes delta k (0, 1, 2, ... in turn) into d[k], given the deltas and
   the values (v, from the deltas' first) below k, and the rebuilding's
   prediction at k (used inside the image only). A PixelDecoder
   (DeltaMapper.h), arg the decoder. Returns 0, or -1 if a code was bad. */
int NeighbourDecoder_next(void *arg, int k, int32_t *d, const int32_t *v, int prediction);

/* After the last delta: 0, or -1 if a code was bad or the coding ended too
   soon. */
int NeighbourDecoder_finish(const NeighbourDecoder *nd);

void NeighbourDecoder_free(NeighbourDecoder *nd);

/* A band's channel decoded (version 3) and rebuilt from its average deltas
   (NeighbourMapper.neighbourAverage): value gets xdim * ydim values, init
   first. Returns 0, or -1 if out of memory or the bytes aren't what
   neighbourCode writes. */
int NeighbourMapper_average(const uint8_t *code, size_t code_length, int lo, int values, int xdim, int ydim, int init, int32_t *value);

/* A band's channel's deltas decoded (version 3) with its values (from the
   band's first) and the deltas it was coded from (for the predictions,
   value - delta) known (NeighbourMapper.neighbourDecodeKnown: the writer's
   check). out gets xdim * ydim deltas (out[0] is 0). Returns 0, or -1 as
   NeighbourMapper_average. */
int NeighbourMapper_decodeKnown(const uint8_t *code, size_t code_length, int lo, int values, int xdim, int ydim,
                                const int32_t *value, const int32_t *delta, int32_t *out);

#endif
