/*
 * DeltaMapper.c -- C versions of DeltaMapper.java's methods (NativeEncoder).
 * See DeltaMapper.h. Each function follows the Java method of the same name;
 * the comments say where they differ in form (not in result).
 */
#include "DeltaMapper.h"
#include "ArithmeticMapper.h"

#include <math.h>
#include <stdlib.h>
#include <string.h>

#ifdef _WIN32
#include <windows.h>
#else
#include <pthread.h>
#include <time.h>
#endif

/* ---- Least squares from the rows above (RowFit) ------------------------- */

static inline int imin(int a, int b) { return (a < b) ? a : b; }
static inline int imax(int a, int b) { return (a > b) ? a : b; }

int RowFit_init(RowFit *f, const int32_t *v, const int32_t *ref, int xdim, int radius, int every)
{
	memset(f, 0, sizeof *f);
	f->v = v; f->ref = ref; f->xdim = xdim; f->r = radius; f->every = every;
	f->nf     = (ref == NULL) ? ROWFIT_SPATIAL : ROWFIT_SPATIAL + 3;
	f->m      = f->nf + 2;
	f->nt     = f->m * (f->m + 1) / 2;
	f->n      = f->nf + 1;
	f->points = (xdim - 2 + every - 1) / every;
	if(f->points < 0) f->points = 0;
	f->row    = -1;
	f->col    = calloc((size_t) xdim * f->nt, sizeof *f->col);
	f->wsum   = calloc((size_t) f->points * f->nt + ROWFIT_LANES, sizeof *f->wsum);
	f->grp    = calloc((size_t) xdim + 2 * radius + 2, sizeof *f->grp);
	f->fa     = calloc((size_t) xdim * f->m, sizeof *f->fa);
	f->fd     = calloc((size_t) xdim * f->m, sizeof *f->fd);
	for(int i = 0; i < 2; i++)
	{
		f->coef[i]  = calloc((size_t) f->points * f->n + 1, sizeof *f->coef[i]);
		f->valid[i] = calloc((size_t) f->points + 1, 1);
	}
	if(!f->col || !f->wsum || !f->grp || !f->fa || !f->fd || !f->coef[0] || !f->coef[1] || !f->valid[0] || !f->valid[1]) { RowFit_free(f); return -1; }
	return 0;
}

void RowFit_free(RowFit *f)
{
	free(f->col); free(f->wsum); free(f->grp); free(f->fa); free(f->fd);
	for(int i = 0; i < 2; i++) { free(f->coef[i]); free(f->valid[i]); }
	memset(f, 0, sizeof *f);
}

/* The value at (y, x), clamped to the image (rows above 0 read row 0). */
static inline int32_t at(const RowFit *f, int y, int x)
{
	if(y < 0) y = 0;
	if(x < 0) x = 0; else if(x > f->xdim - 1) x = f->xdim - 1;
	return f->v[(size_t) y * f->xdim + x];
}

/* RowFit.features(int, int, int[]): the features of (y, x), then 1 and its
   value, read directly where none needs clamping to the image. (The Java's
   long version, used by start and predict, gives the same values.) */
static inline void features(const RowFit *f, int y, int x, int32_t *zz)
{
	const int32_t *v = f->v;
	int xdim = f->xdim;
	size_t k = (size_t) y * xdim + x;
	if(y >= 2 && x >= 2 && x <= xdim - 3)
	{
		size_t up = k - xdim, up2 = up - xdim;
		zz[0] = v[k - 1];    /* W   */
		zz[1] = v[up];       /* N   */
		zz[2] = v[up - 1];   /* NW  */
		zz[3] = v[up + 1];   /* NE  */
		zz[4] = v[k - 2];    /* WW  */
		zz[5] = v[up2 + 1];  /* NNE */
	}
	else
	{
		zz[0] = at(f, y, x - 1);
		zz[1] = at(f, y - 1, x);
		zz[2] = at(f, y - 1, x - 1);
		zz[3] = at(f, y - 1, x + 1);
		zz[4] = at(f, y, x - 2);
		zz[5] = at(f, y - 2, x + 1);
	}
	if(f->ref) { zz[6] = f->ref[k]; zz[7] = f->ref[k - 1]; zz[8] = f->ref[k - xdim]; }
	zz[f->nf]     = 1;
	zz[f->nf + 1] = v[k];
}

/* The features of row y's pixels c0 <= x < c1, as rows: feature i at x into
   out[i * xdim + x]; the same values as features(). Where no pixel needs
   clamping they're copies of the rows above, shifted. */
static void feature_rows(const RowFit *f, int y, int c0, int c1, int32_t *out)
{
	int xdim = f->xdim, nf = f->nf;
	int i0 = (y >= 2) ? imax(c0, 2) : c1, i1 = (y >= 2) ? imin(c1, xdim - 2) : c1;   /* the interior */
	if(i0 > i1) i0 = i1 = c1;
	int32_t z[ROWFIT_M_MAX];
	for(int x = c0; x < i0; x++) { features(f, y, x, z); for(int i = 0; i < f->m; i++) out[(size_t) i * xdim + x] = z[i]; }
	for(int x = i1; x < c1; x++) { features(f, y, x, z); for(int i = 0; i < f->m; i++) out[(size_t) i * xdim + x] = z[i]; }
	if(i0 >= i1) return;
	const int32_t *row = f->v + (size_t) y * xdim, *up = row - xdim, *up2 = up - xdim;
	const int32_t *src[ROWFIT_M_MAX] = { row - 1, up, up - 1, up + 1, row - 2, up2 + 1 };
	if(f->ref)
	{
		const int32_t *rr = f->ref + (size_t) y * xdim;
		src[6] = rr; src[7] = rr - 1; src[8] = rr - xdim;
	}
	for(int i = 0; i < nf; i++) memcpy(out + (size_t) i * xdim + i0, src[i] + i0, (size_t) (i1 - i0) * sizeof *out);
	int32_t *one = out + (size_t) nf * xdim;
	for(int x = i0; x < i1; x++) one[x] = 1;
	memcpy(out + (size_t) (nf + 1) * xdim + i0, row + i0, (size_t) (i1 - i0) * sizeof *out);
}

/* RowFit.start for columns c0 <= x < c1 only (the others are left as
   they are): each column's sums depend only on its own pixels, so a strip
   of columns can be fitted on its own. */
static void start_columns(RowFit *f, int y0, int c0, int c1)
{
	int m = f->m, xdim = f->xdim;
	for(int t = 0; t < f->nt; t++) memset(f->col + (size_t) t * xdim + c0, 0, (size_t) (c1 - c0) * sizeof *f->col);
	int ty = y0 - f->r;
	if(ty < 1) ty = 1;
	for(; ty <= y0 - 1; ty++)
	{
		feature_rows(f, ty, c0, c1, f->fa);
		int32_t *c = f->col;
		for(int i = 0; i < m; i++)
			for(int j = i; j < m; j++, c += xdim)
			{
				const int32_t *ai = f->fa + (size_t) i * xdim, *aj = f->fa + (size_t) j * xdim;
				for(int x = c0; x < c1; x++) c[x] += ai[x] * aj[x];
			}
	}
}

void RowFit_start(RowFit *f, int y0)
{
	memset(f->col, 0, (size_t) f->xdim * f->nt * sizeof *f->col);
	if(f->xdim > 2) start_columns(f, y0, 1, f->xdim - 1);
	f->row = y0;
}

/* RowFit.moveTo, one task (the decoder's tasks are Java's for now). */
void RowFit_moveTo(RowFit *f, int y)
{
	if(f->row == y) return;
	if(f->row != y - 1) { RowFit_start(f, y); return; }
	if(y - 1 >= 1 && f->xdim > 2)
	{
		RowFitWork w;
		RowFit_addColumns(f, y, 1, f->xdim - 1, &w);
	}
	f->row = y;
}

void RowFit_addColumns(RowFit *f, int y, int c0, int c1, RowFitWork *w)
{
	int add = y - 1, drop = y - 1 - f->r, m = f->m, xdim = f->xdim;
	(void) w;
	if(add < 1 || c0 >= c1) return;
	/* Each column gains the added pixel's products and loses the dropped
	   one's, in one pass, a product at a time along the row. */
	feature_rows(f, add, c0, c1, f->fa);
	if(drop >= 1) feature_rows(f, drop, c0, c1, f->fd);
	int32_t *c = f->col;
	for(int i = 0; i < m; i++)
		for(int j = i; j < m; j++, c += xdim)
		{
			const int32_t *ai = f->fa + (size_t) i * xdim, *aj = f->fa + (size_t) j * xdim;
			if(drop >= 1)
			{
				const int32_t *di = f->fd + (size_t) i * xdim, *dj = f->fd + (size_t) j * xdim;
				for(int x = c0; x < c1; x++) c[x] += ai[x] * aj[x] - di[x] * dj[x];
			}
			else
				for(int x = c0; x < c1; x++) c[x] += ai[x] * aj[x];
		}
}

/* RowFit.solve: the fit at point p from the window's sums (w->win), into
   coef; 0 if it can't be solved. */
static int solve(const RowFit *f, RowFitWork *w, int p, double *coef)
{
	const int64_t *win = w->win;
	int nf = f->nf, m = f->m, n = f->n;
	double (*a)[ROWFIT_N_MAX] = w->a;
	double *b = w->b, *dg = w->dg;
	/* Products of (i, j), i <= j < m: index i * m - i * (i - 1) / 2 + (j - i). */
	int64_t count = win[nf * m - nf * (nf - 1) / 2];
	if(count < 2 * n) return 0;
	/* The normal equations' lower triangle (ridge 1 on the diagonal), then
	   L D L^T: L unit lower triangular (in a's lower triangle), D in dg. */
	for(int i = 0; i < n; i++)
	{
		int base = i * m - i * (i - 1) / 2;
		for(int j = i; j < n; j++) a[j][i] = (double) win[base + j - i];
		b[i] = (double) win[base + m - 1 - i];
		a[i][i] += 1.0;
	}
	for(int j = 0; j < n; j++)
	{
		double *aj = a[j];
		double s = aj[j];
		for(int q = 0; q < j; q++) s -= aj[q] * aj[q] * dg[q];
		if(s < 1e-9) return 0;
		dg[j] = s;
		for(int i = j + 1; i < n; i++)
		{
			double *ai = a[i];
			double t = ai[j];
			for(int q = 0; q < j; q++) t -= ai[q] * aj[q] * dg[q];
			ai[j] = t / s;
		}
	}
	int o = p * n;
	for(int i = 0; i < n; i++)
	{
		double s = b[i];
		for(int q = 0; q < i; q++) s -= a[i][q] * coef[o + q];
		coef[o + i] = s;
	}
	for(int i = 0; i < n; i++) coef[o + i] /= dg[i];
	for(int i = n - 1; i >= 0; i--)
	{
		double s = coef[o + i];
		for(int q = i + 1; q < n; q++) s -= a[q][i] * coef[o + q];
		coef[o + i] = s;
	}
	return 1;
}

/* ---- Solving several points at once ---------------------------------------
   solve() above, for ROWFIT_LANES points side by side: each array has a lane
   per point, innermost, so the compiler does each step for all the points in
   one vector instruction (SSE2: 2 a time; AVX: 4; AVX-512: 8). Each lane does
   exactly solve's operations in solve's order, so each point's coefficients
   are the same, bit for bit, as solve's. A lane solve gives up on (count too
   small, a pivot below 1e-9) is marked and carries on with meaningless
   values, which are then dropped; the other lanes aren't affected. With the
   size fixed (7 unknowns without a previous channel, 10 with) the loops'
   bounds are constants, so the compiler unrolls them. */


#define LANES for(int l = 0; l < ROWFIT_LANES; l++)

#define DEFINE_SOLVE_LANES(N)                                                          \
static void solve_lanes_##N(const int64_t *win0, size_t P, int lanes,                  \
                            double *coef, unsigned char *valid, int p0)                \
{                                                                                      \
	const int m = N + 1, nf = N - 1;                                                    \
	double a[N][N][ROWFIT_LANES], b[N][ROWFIT_LANES], dg[N][ROWFIT_LANES];               \
	double c[N][ROWFIT_LANES];                                                         \
	int    bad[ROWFIT_LANES];                                                          \
	LANES bad[l] = (l >= lanes) || win0[(size_t) (nf * m - nf * (nf - 1) / 2) * P + l] < 2 * N;          \
	for(int i = 0; i < N; i++)                                                         \
	{                                                                                  \
		int base = i * m - i * (i - 1) / 2;                                              \
		for(int j = i; j < N; j++) LANES a[j][i][l] = (double) win0[(size_t) (base + j - i) * P + l];     \
		LANES b[i][l] = (double) win0[(size_t) (base + m - 1 - i) * P + l];                               \
		LANES a[i][i][l] += 1.0;                                                         \
	}                                                                                  \
	for(int j = 0; j < N; j++)                                                         \
	{                                                                                  \
		double s[ROWFIT_LANES];                                                          \
		LANES s[l] = a[j][j][l];                                                         \
		for(int q = 0; q < j; q++) LANES s[l] -= a[j][q][l] * a[j][q][l] * dg[q][l];     \
		LANES bad[l] |= !(s[l] >= 1e-9);                                                 \
		LANES dg[j][l] = s[l];                                                           \
		for(int i = j + 1; i < N; i++)                                                   \
		{                                                                                \
			double t[ROWFIT_LANES];                                                        \
			LANES t[l] = a[i][j][l];                                                       \
			for(int q = 0; q < j; q++) LANES t[l] -= a[i][q][l] * a[j][q][l] * dg[q][l];   \
			LANES a[i][j][l] = t[l] / s[l];                                                \
		}                                                                                \
	}                                                                                  \
	for(int i = 0; i < N; i++)                                                         \
	{                                                                                  \
		double s[ROWFIT_LANES];                                                          \
		LANES s[l] = b[i][l];                                                            \
		for(int q = 0; q < i; q++) LANES s[l] -= a[i][q][l] * c[q][l];                   \
		LANES c[i][l] = s[l];                                                            \
	}                                                                                  \
	for(int i = 0; i < N; i++) LANES c[i][l] /= dg[i][l];                              \
	for(int i = N - 1; i >= 0; i--)                                                    \
	{                                                                                  \
		double s[ROWFIT_LANES];                                                          \
		LANES s[l] = c[i][l];                                                            \
		for(int q = i + 1; q < N; q++) LANES s[l] -= a[q][i][l] * c[q][l];               \
		LANES c[i][l] = s[l];                                                            \
	}                                                                                  \
	for(int l = 0; l < lanes; l++)                                                     \
	{                                                                                  \
		valid[p0 + l] = (unsigned char) !bad[l];                                         \
		if(!bad[l]) for(int i = 0; i < N; i++) coef[(size_t) (p0 + l) * N + i] = c[i][l]; \
	}                                                                                  \
}

DEFINE_SOLVE_LANES(7)
DEFINE_SOLVE_LANES(10)

/* RowFit.solveRow, one task. */
void RowFit_solveRow(RowFit *f, int y, RowFitWork *w)
{
	if(f->points > 0) RowFit_solvePoints(f, y, 0, f->points, w);
}

/* Points p0 <= p < p1's window sums, product by product, into f->wsum:
   point p's window is columns x - r to x + r (x = 1 + p * every), clamped
   to 1 and xdim - 2. Exact integers, so any order of adding gives the
   same. Where a window isn't clamped it's q groups of every columns, which
   start every columns apart from one point to the next, plus rest columns:
   the groups' sums are made once per row and each window adds q of them. */
static void window_sums(RowFit *f, int p0, int p1, int64_t *g)
{
	int nt = f->nt, r = f->r, xdim = f->xdim, every = f->every, points = f->points;
	int len = 2 * r + 1, q = len / every, rest = len - q * every;
	/* The points whose windows aren't clamped: 1 <= x - r and x + r <= xdim - 2. */
	int a = (r + every - 1) / every;                      /* least p with 1 + p * every - r >= 1 */
	int b = (xdim - 3 - r >= 0) ? (xdim - 3 - r) / every + 1 : 0;   /* past the greatest with x + r <= xdim - 2 */
	a = imax(a, p0); b = imin(b, p1);
	if(a >= b) a = b = p1;   /* none */
	/* Group g covers columns s0 + g * every to s0 + g * every + every - 1, s0 = 1 - r + a * every. */
	int s0 = 1 - r + a * every, groups = (b > a) ? (b - a) + q - 1 : 0;
	for(int t = 0; t < nt; t++)
	{
		const int32_t *c = f->col + (size_t) t * xdim;
		int64_t *out = f->wsum + (size_t) t * points;
		/* The clamped windows, directly. */
		for(int p = p0; p < p1; p++)
		{
			if(p == a) { p = b - 1; continue; }
			int x = 1 + p * every, lo = imax(x - r, 1), hi = imin(x + r, xdim - 2);
			int64_t sum = 0;
			for(int k = lo; k <= hi; k++) sum += c[k];
			out[p] = sum;
		}
		if(a >= b) continue;
		/* Loops over the groups and the points innermost, so they vectorize. */
		const int32_t *cs = c + s0;
		for(int j = 0; j < groups; j++) g[j] = 0;
		for(int k = 0; k < every; k++)
			for(int j = 0; j < groups; j++) g[j] += cs[j * every + k];
		int64_t *o = out + a;
		int n = b - a;
		for(int j = 0; j < n; j++) o[j] = 0;
		for(int k = 0; k < q; k++)
			for(int j = 0; j < n; j++) o[j] += g[j + k];
		for(int k = 0; k < rest; k++)
			for(int j = 0; j < n; j++) o[j] += cs[j * every + q * every + k];
	}
}

/* RowFit_solvePoints with grp (xdim + 2 * radius + 2 of them) for the group
   sums: so that several threads can solve different points of a row at the
   same time, each with its own (everything else they write is the points'
   own). */
static void solve_points(RowFit *f, int y, int p0, int p1, RowFitWork *w, int64_t *grp)
{
	double        *coef  = f->coef[y & 1];
	unsigned char *valid = f->valid[y & 1];
	if(p0 >= p1) return;
	window_sums(f, p0, p1, grp);
	if(f->n == 7 || f->n == 10)
	{
		/* A batch of points at a time, the window sums of product t, point
		   first + l at wsum[t * points + first + l]. In the last batch the
		   lanes past p1 read other sums (wsum has a batch's padding at the
		   end): ordinary integers, and their results are dropped. */
		size_t P = (size_t) f->points;
		for(int first = p0; first < p1; first += ROWFIT_LANES)
		{
			int in = imin(ROWFIT_LANES, p1 - first);
			if(f->n == 7) solve_lanes_7(f->wsum + first, P, in, coef, valid, first);
			else          solve_lanes_10(f->wsum + first, P, in, coef, valid, first);
		}
	}
	else
		for(int p = p0; p < p1; p++)
		{
			for(int t = 0; t < f->nt; t++) w->win[t] = f->wsum[(size_t) t * f->points + p];
			valid[p] = (unsigned char) solve(f, w, p, coef);
		}
}

void RowFit_solvePoints(RowFit *f, int y, int p0, int p1, RowFitWork *w)
{
	solve_points(f, y, p0, p1, w, f->grp);
}

int RowFit_predict(const RowFit *f, int y, int x)
{
	int p  = (x - 1) / f->every, n = f->n;
	int pa = at(f, y, x - 1), pb = at(f, y - 1, x), pc = at(f, y - 1, x - 1), pd = at(f, y - 1, x + 1);
	if(!f->valid[y & 1][p]) return pa;
	int32_t z[ROWFIT_M_MAX];
	features(f, y, x, z);
	const double *coef = f->coef[y & 1] + (size_t) p * n;
	double s = 0;
	for(int i = 0; i < n; i++) s += coef[i] * (double) z[i];
	/* The clamp is over all 8 neighbours, the two not fitted (NN, NEE) too. */
	int ww = z[4], nne = z[5], nn = at(f, y - 2, x), nee = at(f, y - 1, x + 2);
	int lo = imin(imin(pa, pb), imin(pc, pd)), hi = imax(imax(pa, pb), imax(pc, pd));
	lo = imin(imin(lo, ww), imin(imin(nne, nn), nee));
	hi = imax(imax(hi, ww), imax(imax(nne, nn), nee));
	/* Math.max(lo - 2, Math.min(hi + 2, s)), then Math.floor(w + 0.5). */
	double h = (double) (hi + 2), l = (double) (lo - 2);
	double t = (s <= h) ? s : h;
	double w = (l >= t) ? l : t;
	return (int) floor(w + 0.5);
}

/* ---- RowFit.plane: bands of rows at the same time ------------------------ */

typedef struct PlaneBand
{
	const int32_t *v, *ref;
	int xdim, radius, every, y0, y1, failed;
	int16_t *out;
	RowFitTimes *times;   /* NULL: not timed */
} PlaneBand;

/* How many points a strip has (RowFit_plane's bands are fitted a strip of
   columns at a time). */
#define ROWFIT_STRIP 64

static void plane_band(PlaneBand *b)
{
	RowFit f;
	if(RowFit_init(&f, b->v, b->ref, b->xdim, b->radius, b->every)) { b->failed = 1; return; }
	RowFitWork w;
	int xdim = b->xdim;
	if(b->times)
	{
		/* Timed in parts: a whole row at a time, moveTo, solveRow and the
		   predictions one after the other (the same results as below). */
		RowFit_start(&f, b->y0);
		for(int y = b->y0; y < b->y1; y++)
		{
			double t0 = DeltaMapper_seconds();
			RowFit_moveTo(&f, y);
			double t1 = DeltaMapper_seconds();
			RowFit_solveRow(&f, y, &w);
			double t2 = DeltaMapper_seconds();
			for(int x = 1; x < xdim - 1; x++) b->out[(size_t) y * xdim + x] = (int16_t) RowFit_predict(&f, y, x);
			double t3 = DeltaMapper_seconds();
			b->times->columns += t1 - t0; b->times->solves += t2 - t1; b->times->predictions += t3 - t2;
		}
	}
	else if(xdim > 2)
	{
		/* A strip of points at a time, all the band's rows: a column's sums
		   depend only on its own pixels, and a point needs only the columns
		   of its window, so each strip is fitted on its own, with the columns
		   its windows reach (r more each side, done again by the next strip).
		   Its sums then stay in this core's cache, rather than a whole row's
		   coming from memory for each row: the same results, faster when
		   all the cores run. */
		for(int p0 = 0; p0 < f.points; p0 += ROWFIT_STRIP)
		{
			int p1 = imin(p0 + ROWFIT_STRIP, f.points);
			int c0 = imax(1 + p0 * f.every - f.r, 1), c1 = imin(1 + (p1 - 1) * f.every + f.r, xdim - 2) + 1;
			int x0 = 1 + p0 * f.every, x1 = imin(1 + p1 * f.every, xdim - 1);   /* the pixels predicted from these points */
			start_columns(&f, b->y0, c0, c1);
			for(int y = b->y0; y < b->y1; y++)
			{
				if(y > b->y0) RowFit_addColumns(&f, y, c0, c1, &w);
				RowFit_solvePoints(&f, y, p0, p1, &w);
				for(int x = x0; x < x1; x++) b->out[(size_t) y * xdim + x] = (int16_t) RowFit_predict(&f, y, x);
			}
		}
	}
	RowFit_free(&f);
}

#ifdef _WIN32
static DWORD WINAPI plane_thread(LPVOID p) { plane_band((PlaneBand *) p); return 0; }
#else
static void *plane_thread(void *p) { plane_band((PlaneBand *) p); return NULL; }
#endif

int RowFit_plane(const int32_t *v, const int32_t *ref, int xdim, int ydim, int radius, int every, int16_t *out, int threads, RowFitTimes *times)
{
	memset(out, 0, (size_t) xdim * ydim * sizeof *out);
	if(ydim < 2) return 0;
	if(threads < 1) threads = 1;
	/* As the Java: bands of at least 4 * (radius + 1) rows, one per thread. */
	int band  = imax(4 * (radius + 1), (ydim - 1 + threads - 1) / threads);
	int bands = (ydim - 1 + band - 1) / band;
	PlaneBand *b = calloc((size_t) bands, sizeof *b);
	if(!b) return -1;
	for(int t = 0; t < bands; t++)
	{
		b[t].v = v; b[t].ref = ref; b[t].xdim = xdim; b[t].radius = radius; b[t].every = every; b[t].out = out;
		b[t].y0 = 1 + t * band; b[t].y1 = imin(ydim, b[t].y0 + band);
		b[t].times = (threads == 1) ? times : NULL;
	}
	if(threads == 1 || bands == 1)
		for(int t = 0; t < bands; t++) plane_band(&b[t]);
	else
	{
#ifdef _WIN32
		HANDLE *h = calloc((size_t) bands, sizeof *h);
		for(int t = 0; t < bands; t++) h[t] = CreateThread(NULL, 0, plane_thread, &b[t], 0, NULL);
		for(int t = 0; t < bands; t++) { WaitForSingleObject(h[t], INFINITE); CloseHandle(h[t]); }
		free(h);
#else
		pthread_t *h = calloc((size_t) bands, sizeof *h);
		for(int t = 0; t < bands; t++) pthread_create(&h[t], NULL, plane_thread, &b[t]);
		for(int t = 0; t < bands; t++) pthread_join(h[t], NULL);
		free(h);
#endif
	}
	int failed = 0;
	for(int t = 0; t < bands; t++) failed |= b[t].failed;
	free(b);
	return failed ? -1 : 0;
}

double DeltaMapper_seconds(void)
{
#ifdef _WIN32
	static LARGE_INTEGER freq;
	LARGE_INTEGER now;
	if(!freq.QuadPart) QueryPerformanceFrequency(&freq);
	QueryPerformanceCounter(&now);
	return (double) now.QuadPart / (double) freq.QuadPart;
#else
	struct timespec ts;
	clock_gettime(CLOCK_MONOTONIC, &ts);
	return ts.tv_sec + ts.tv_nsec * 1e-9;
#endif
}

/* ---- Threads and progress ------------------------------------------------- */

#include <limits.h>
#include <stdatomic.h>

/* A count that only rises, which threads wait on: set by one thread, waited
   for by another. Waiting spins briefly, then sleeps (the setter wakes it only
   when someone sleeps). */
typedef struct Progress
{
	atomic_long value;
	atomic_int  sleepers;
#ifdef _WIN32
	SRWLOCK lock;
	CONDITION_VARIABLE cond;
#else
	pthread_mutex_t lock;
	pthread_cond_t  cond;
#endif
} Progress;

static void progress_init(Progress *p)
{
	atomic_init(&p->value, 0);
	atomic_init(&p->sleepers, 0);
#ifdef _WIN32
	InitializeSRWLock(&p->lock);
	InitializeConditionVariable(&p->cond);
#else
	pthread_mutex_init(&p->lock, NULL);
	pthread_cond_init(&p->cond, NULL);
#endif
}

static void progress_destroy(Progress *p)
{
#ifndef _WIN32
	pthread_mutex_destroy(&p->lock);
	pthread_cond_destroy(&p->cond);
#else
	(void) p;
#endif
}

static void progress_set(Progress *p, long v)
{
	atomic_store(&p->value, v);
	if(atomic_load(&p->sleepers) > 0)
	{
#ifdef _WIN32
		AcquireSRWLockExclusive(&p->lock);
		WakeAllConditionVariable(&p->cond);
		ReleaseSRWLockExclusive(&p->lock);
#else
		pthread_mutex_lock(&p->lock);
		pthread_cond_broadcast(&p->cond);
		pthread_mutex_unlock(&p->lock);
#endif
	}
}

/* Waits until the count reaches v; if it has to sleep, until it reaches
   later (>= v): fewer sleeps, so fewer wake-ups for the setter to pay for,
   when the waiter can afford to fall a little behind. */
static void progress_wait_or_later(Progress *p, long v, long later)
{
	for(int spin = 0; spin < 2000; spin++) if(atomic_load(&p->value) >= v) return;
	v = later;
	atomic_fetch_add(&p->sleepers, 1);
#ifdef _WIN32
	AcquireSRWLockExclusive(&p->lock);
	while(atomic_load(&p->value) < v) SleepConditionVariableSRW(&p->cond, &p->lock, INFINITE, 0);
	ReleaseSRWLockExclusive(&p->lock);
#else
	pthread_mutex_lock(&p->lock);
	while(atomic_load(&p->value) < v) pthread_cond_wait(&p->cond, &p->lock);
	pthread_mutex_unlock(&p->lock);
#endif
	atomic_fetch_sub(&p->sleepers, 1);
}

static void progress_wait(Progress *p, long v) { progress_wait_or_later(p, v, v); }

typedef void (*ThreadBody)(void *);
typedef struct { ThreadBody body; void *arg; } ThreadStart;
#ifdef _WIN32
typedef HANDLE Thread;
static DWORD WINAPI thread_main(LPVOID p) { ThreadStart *s = p; s->body(s->arg); return 0; }
static int  thread_start(Thread *t, ThreadStart *s) { *t = CreateThread(NULL, 0, thread_main, s, 0, NULL); return (*t == NULL) ? -1 : 0; }
static void thread_join(Thread t) { WaitForSingleObject(t, INFINITE); CloseHandle(t); }
#else
typedef pthread_t Thread;
static void *thread_main(void *p) { ThreadStart *s = p; s->body(s->arg); return NULL; }
static int  thread_start(Thread *t, ThreadStart *s) { return pthread_create(t, NULL, thread_main, s) ? -1 : 0; }
static void thread_join(Thread t) { pthread_join(t, NULL); }
#endif

/* ---- Mixed context coding (MixedModels, packMixedDeltas) ----------------- */

/* DeltaMapper's constants of the same names. */
#define MIX_R_BITS         16
#define MIX_W_BITS         16
#define MIX_WMIN           256
#define MIX_RATE           32
#define MIX_OPINION_LEVELS 9
#define ACTIVITY_BUCKETS   12
#define CROSS_BUCKETS      5
#define CONTEXTS           (ACTIVITY_BUCKETS * CROSS_BUCKETS)

/* The buckets' lower limits: ACTIVITY_LIMIT {0, 1, 2, 3, 5, 7, 10, 14, 20, 28,
   40, 60}, CROSS_LIMIT {0, 1, 3, 6, 12}. */

/* MIX_ACTIVITY_TABLE (values 0 to 255) and MIX_CROSS_TABLE (0 to 63): each
   value's bucket, the last whose lower limit (ACTIVITY_LIMIT, CROSS_LIMIT)
   it reaches. Written out, from those limits. */
static const unsigned char activity_table[256] =
{
	0, 1, 2, 3, 3, 4, 4, 5, 5, 5, 6, 6, 6, 6, 7, 7, 7, 7, 7, 7, 8, 8, 8, 8, 8, 8, 8, 8, 9, 9, 9, 9,
	9, 9, 9, 9, 9, 9, 9, 9, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 11, 11, 11, 11,
	11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11,
	11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11,
	11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11,
	11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11,
	11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11,
	11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11
};
static const unsigned char cross_table[64] =
{
	0, 1, 1, 2, 2, 2, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4,
	4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4
};

static inline int iabs(int v) { return (v < 0) ? -v : v; }

/* DeltaMapper.gradientLevel: JPEG-LS's levels, -4 to 4 (0, then +-1 for
   1-2, +-2 for 3-6, +-3 for 7-20, +-4 beyond), by table. */
static const signed char LEVEL[43] =
{
	-4, -3, -3, -3, -3, -3, -3, -3, -3, -3, -3, -3, -3, -3, -3, -2, -2, -2, -2, -1, -1,
	0,
	1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4
};
static inline int gradientLevel(int g)
{
	if(g < -21) g = -21; else if(g > 21) g = 21;
	return LEVEL[g + 21];
}

/* DeltaMapper.gap: CALIC's gradient-adjusted predictor. (>> of a negative
   int is arithmetic in gcc, as in Java.) */
static inline int gap(int w, int ww, int n, int nn, int nw, int ne, int nne, int t1, int t2, int t3)
{
	int dh = iabs(w - ww) + iabs(n - nw) + iabs(n - ne);
	int dv = iabs(w - nw) + iabs(n - nn) + iabs(ne - nne);
	if(dv - dh > t1) return w;
	if(dh - dv > t1) return n;
	int p = (2 * (w + n) + ne - nw) >> 2;
	if(dv - dh > t2)      p = (p + w) >> 1;
	else if(dv - dh > t3) p = (3 * p + w) >> 2;
	else if(dh - dv > t2) p = (p + n) >> 1;
	else if(dh - dv > t3) p = (3 * p + n) >> 2;
	return p;
}

/* DeltaMapper.blockPredictor(11, ...): MED. */
static inline int med(int a, int b, int c)
{
	int mx = (a > b) ? a : b, mn = (a < b) ? a : b;
	if(c >= mx) return mn;
	if(c <= mn) return mx;
	return a + b - c;
}

/* DeltaMapper.MixedModels, for encoding. */
typedef struct MixedModels
{
	int m, n_symbols, xdim, n, contexts, opinions;
	int32_t *f;           /* counts by model, context and symbol: f[(j * contexts + c) * n_symbols + s] */
	int32_t *total;       /* each model's total per context: total[j * contexts + c] */
	int64_t  w[3], q[3];  /* the weights; each model's scaled count of the symbol just coded */
	int      ctx[3];      /* each model's context at the current pixel */
	unsigned char *cb, *c9b;   /* per pixel, from the earlier channels: the cross bucket, the 3x3 cross bucket */
	int32_t *fwd;              /* ... and the forward sum (E, SW, S, SE) */
	int      prediction;
	/* For decoding: the earlier channels' |deltas| summed, per pixel, and the
	   rows of it, and of cb, fwd and c9b, filled so far (earlierRows). */
	int32_t *cross;
	int      cross_rows, earlier_rows;
	int      earlier_end;      /* the pixel where the next row of cb, fwd and c9b is needed */
} MixedModels;

static void MixedModels_free(MixedModels *mm)
{
	free(mm->f); free(mm->total); free(mm->cb); free(mm->c9b); free(mm->fwd); free(mm->cross);
}

/* The MixedModels constructor, with earlierRows done for the whole channel
   at once (the encoder has all the earlier channels: the same values as
   row by row). Returns 0, or -1 if out of memory. */
static int MixedModels_init(MixedModels *mm, int n_symbols, int np, int xdim, int n, int opinions)
{
	memset(mm, 0, sizeof *mm);
	mm->n_symbols = n_symbols; mm->xdim = xdim; mm->n = n; mm->opinions = opinions;
	mm->contexts  = opinions ? CONTEXTS * MIX_OPINION_LEVELS : CONTEXTS;
	mm->m         = (np == 0) ? 2 : 3;
	size_t cells  = (size_t) mm->m * mm->contexts;
	mm->f     = malloc(cells * n_symbols * sizeof *mm->f);
	mm->total = malloc(cells * sizeof *mm->total);
	mm->cb    = calloc((size_t) n + 1, 1);
	mm->c9b   = calloc((size_t) n + 1, 1);
	mm->fwd   = calloc((size_t) n + 1, sizeof *mm->fwd);
	if(!mm->f || !mm->total || !mm->cb || !mm->c9b || !mm->fwd) { MixedModels_free(mm); return -1; }
	for(size_t i = 0; i < cells * n_symbols; i++) mm->f[i] = 1;
	for(size_t i = 0; i < cells; i++) mm->total[i] = n_symbols;
	for(int j = 0; j < mm->m; j++) mm->w[j] = ((int64_t) 1 << MIX_W_BITS) / mm->m;
	mm->w[0] += ((int64_t) 1 << MIX_W_BITS) - ((int64_t) 1 << MIX_W_BITS) / mm->m * mm->m;
	mm->earlier_end = (mm->m == 3) ? 0 : INT32_MAX;
	return 0;
}

/* For encoding: earlierRows for the whole channel at once (the encoder has
   all the earlier channels: the same values as row by row). Returns 0, or -1
   if out of memory. */
static int MixedModels_earlierAll(MixedModels *mm, const int32_t *const *previous, int np)
{
	int xdim = mm->xdim, n = mm->n;
	if(mm->m == 3)
	{
		/* cross = the earlier channels' |deltas| summed; then
		   per pixel its bucket, the 3x3 sum's bucket (/ 3), and the forward sum. */
		int ydim = n / xdim, top = 63;
		int32_t *cross = malloc((size_t) n * sizeof *cross);
		if(!cross) return -1;
		for(int k = 0; k < n; k++)
		{
			int t = 0;
			for(int p = 0; p < np; p++) t += iabs(previous[p][k]);
			cross[k] = t;
		}
		/* The 3x3 sums as row sums of three, then three rows of those (exact
		   integers: the same sums). */
		int32_t *row3 = malloc((size_t) n * sizeof *row3);
		if(!row3) { free(cross); return -1; }
		for(int y = 0; y < ydim; y++)
		{
			const int32_t *c = cross + (size_t) y * xdim;
			int32_t *r3 = row3 + (size_t) y * xdim;
			if(xdim == 1) { r3[0] = c[0]; continue; }
			r3[0] = c[0] + c[1];
			for(int x = 1; x < xdim - 1; x++) r3[x] = c[x - 1] + c[x] + c[x + 1];
			r3[xdim - 1] = c[xdim - 2] + c[xdim - 1];
		}
		for(int y = 0; y < ydim; y++)
		{
			const int32_t *c  = cross + (size_t) y * xdim, *cd = (y + 1 < ydim) ? c + xdim : NULL;
			const int32_t *r3 = row3 + (size_t) y * xdim;
			const int32_t *ru = (y > 0) ? r3 - xdim : NULL, *rd = (y + 1 < ydim) ? r3 + xdim : NULL;
			unsigned char *cb = mm->cb + (size_t) y * xdim, *c9b = mm->c9b + (size_t) y * xdim;
			int32_t *fwd = mm->fwd + (size_t) y * xdim;
			for(int x = 0; x < xdim; x++)
			{
				int s9 = r3[x] + (ru ? ru[x] : 0) + (rd ? rd[x] : 0), sum = 0;
				if(x + 1 < xdim) sum += c[x + 1];
				if(cd)
				{
					sum += cd[x];
					if(x > 0)        sum += cd[x - 1];
					if(x + 1 < xdim) sum += cd[x + 1];
				}
				cb[x]  = cross_table[(c[x] < top) ? c[x] : top];
				c9b[x] = cross_table[(s9 / 3 < top) ? s9 / 3 : top];
				fwd[x] = sum;
			}
		}
		free(row3);
		free(cross);
	}
	mm->earlier_end = INT32_MAX;
	return 0;
}

/* MixedModels.earlierRows, for decoding: fills cb, fwd and c9b from the
   earlier channels' deltas up to row y1 (not included), which needs those
   deltas up to row y1 (included). Returns 0, or -1 if out of memory. */
static int MixedModels_earlierRows(MixedModels *mm, const int32_t *const *previous, int np, int y1)
{
	int xdim = mm->xdim, ydim = mm->n / xdim, top = 63;
	if(mm->cross == NULL && (mm->cross = malloc((size_t) mm->n * sizeof *mm->cross)) == NULL) return -1;
	if(y1 > ydim) y1 = ydim;
	for(int c1 = (y1 + 1 < ydim) ? y1 + 1 : ydim; mm->cross_rows < c1; mm->cross_rows++)
		for(int k = mm->cross_rows * xdim, end = k + xdim; k < end; k++)
		{
			int t = 0;
			for(int p = 0; p < np; p++) t += iabs(previous[p][k]);
			mm->cross[k] = t;
		}
	const int32_t *cross = mm->cross;
	for(int y = mm->earlier_rows; y < y1; y++)
		for(int x = 0; x < xdim; x++)
		{
			int k = y * xdim + x, s9 = 0, sum = 0;
			int ya = (y > 0) ? y - 1 : 0, yb = (y + 2 < ydim) ? y + 2 : ydim;
			int xa = (x > 0) ? x - 1 : 0, xb = (x + 2 < xdim) ? x + 2 : xdim;
			for(int yy = ya; yy < yb; yy++)
				for(int xx = xa; xx < xb; xx++) s9 += cross[yy * xdim + xx];
			if(x + 1 < xdim) sum += cross[k + 1];
			if(y + 1 < ydim)
			{
				sum += cross[k + xdim];
				if(x > 0)        sum += cross[k + xdim - 1];
				if(x + 1 < xdim) sum += cross[k + xdim + 1];
			}
			mm->cb[k]  = cross_table[(cross[k] < top) ? cross[k] : top];
			mm->c9b[k] = cross_table[(s9 / 3 < top) ? s9 / 3 : top];
			mm->fwd[k] = sum;
		}
	if(y1 > mm->earlier_rows) mm->earlier_rows = y1;
	mm->earlier_end = (mm->earlier_rows >= ydim) ? INT32_MAX : mm->earlier_rows * xdim;
	return 0;
}

/* MixedModels.contexts: each model's context at pixel k. */
static inline void MixedModels_contexts(MixedModels *mm, int k, const int32_t *d, const int32_t *v)
{
	int xdim = mm->xdim, x = k % xdim, act = 0, g = 0, top = 255;
	if(x > 0) act += iabs(d[k - 1]);
	if(k >= xdim)
	{
		act += iabs(d[k - xdim]);
		if(x > 0)        act += iabs(d[k - xdim - 1]);
		if(x < xdim - 1) act += iabs(d[k - xdim + 1]);
	}
	if(x >= 2 && k >= 2 * xdim && x < xdim - 1)
	{
		int W = v[k - 1], N = v[k - xdim], NW = v[k - xdim - 1], NE = v[k - xdim + 1];
		g = iabs(W - v[k - 2]) + iabs(N - NW) + iabs(N - NE)
		  + iabs(W - NW) + iabs(N - v[k - 2 * xdim]) + iabs(NE - v[k - 2 * xdim + 1]);
	}
	int c = mm->cb[k], ag = (act + g) >> 1;
	mm->ctx[0] = activity_table[(ag < top) ? ag : top] * CROSS_BUCKETS + c;
	if(mm->m == 3)
	{
		int af = act + (mm->fwd[k] >> 1);
		mm->ctx[1] = activity_table[(af < top) ? af : top] * CROSS_BUCKETS + c;
		mm->ctx[2] = activity_table[(act < top) ? act : top] * CROSS_BUCKETS + mm->c9b[k];
	}
	else mm->ctx[1] = activity_table[(act < top) ? act : top] * CROSS_BUCKETS + c;
	if(mm->opinions)
	{
		int mid = MIX_OPINION_LEVELS / 2, o0 = mid, o1 = mid, o2 = mid;
		if(k >= xdim && x >= 1 && x < xdim - 1)
		{
			int a = v[k - 1], b = v[k - xdim], cc = v[k - xdim - 1], dd = v[k - xdim + 1];
			int up2 = k >= 2 * xdim;
			int aa = (x >= 2) ? v[k - 2] : a, bb = up2 ? v[k - 2 * xdim] : b, nne = up2 ? v[k - 2 * xdim + 1] : dd;
			o0 = gradientLevel(gap(a, aa, b, bb, cc, dd, nne, 10, 4, 1) - mm->prediction) + mid;
			o1 = gradientLevel(med(a, b, cc) - mm->prediction) + mid;
			o2 = gradientLevel(a - mm->prediction) + mid;
		}
		mm->ctx[0] = mm->ctx[0] * MIX_OPINION_LEVELS + o0;
		mm->ctx[1] = mm->ctx[1] * MIX_OPINION_LEVELS + o1;
		if(mm->m == 3) mm->ctx[2] = mm->ctx[2] * MIX_OPINION_LEVELS + o2;
	}
}

/* The contexts of row y's pixels, into ctx[j][x] (models j < m): what
   MixedModels_contexts gives at each, with the prediction values - d. The
   interior pixels (where nothing is clamped) are done without its tests,
   in a loop of their own; the rest by MixedModels_contexts. */
static void MixedModels_contextsRow(MixedModels *mm, int y, const int32_t *d, const int32_t *v, uint16_t *ctx[3])
{
	int xdim = mm->xdim, m = mm->m, opinions = mm->opinions;
	int i0 = (y >= 2) ? 2 : xdim, i1 = (y >= 2) ? xdim - 1 : xdim;   /* the interior: i0 <= x < i1 */
	if(i0 >= i1) i0 = i1 = xdim;   /* (none: also when it would be empty, as 3 wide, which the skip below would loop on) */
	for(int x = 0; x < xdim; x++)
	{
		if(x == i0) { x = i1 - 1; continue; }
		int k = y * xdim + x;
		mm->prediction = v[k] - d[k];
		MixedModels_contexts(mm, k, d, v);
		for(int j = 0; j < m; j++) ctx[j][x] = (uint16_t) mm->ctx[j];
	}
	const int32_t *dr = d + (size_t) y * xdim, *du = dr - xdim;
	const int32_t *vr = v + (size_t) y * xdim, *vu = vr - xdim, *vu2 = vu - xdim;
	const unsigned char *cb = mm->cb + (size_t) y * xdim, *c9b = mm->c9b + (size_t) y * xdim;
	const int32_t *fwd = mm->fwd + (size_t) y * xdim;
	for(int x = i0; x < i1; x++)
	{
		int act = iabs(dr[x - 1]) + iabs(du[x]) + iabs(du[x - 1]) + iabs(du[x + 1]);
		int W = vr[x - 1], N = vu[x], NW = vu[x - 1], NE = vu[x + 1], WW = vr[x - 2], NN = vu2[x], NNE = vu2[x + 1];
		int g  = iabs(W - WW) + iabs(N - NW) + iabs(N - NE) + iabs(W - NW) + iabs(N - NN) + iabs(NE - NNE);
		int ag = (act + g) >> 1, c = cb[x];
		int c0 = activity_table[(ag < 255) ? ag : 255] * CROSS_BUCKETS + c, c1, c2 = 0;
		if(m == 3)
		{
			int af = act + (fwd[x] >> 1);
			c1 = activity_table[(af < 255) ? af : 255] * CROSS_BUCKETS + c;
			c2 = activity_table[(act < 255) ? act : 255] * CROSS_BUCKETS + c9b[x];
		}
		else c1 = activity_table[(act < 255) ? act : 255] * CROSS_BUCKETS + c;
		if(opinions)
		{
			int pred = vr[x] - dr[x], mid = MIX_OPINION_LEVELS / 2;
			c0 = c0 * MIX_OPINION_LEVELS + gradientLevel(gap(W, WW, N, NN, NW, NE, NNE, 10, 4, 1) - pred) + mid;
			c1 = c1 * MIX_OPINION_LEVELS + gradientLevel(med(W, N, NW) - pred) + mid;
			c2 = c2 * MIX_OPINION_LEVELS + gradientLevel(W - pred) + mid;
		}
		ctx[0][x] = (uint16_t) c0;
		ctx[1][x] = (uint16_t) c1;
		if(m == 3) ctx[2][x] = (uint16_t) c2;
	}
}

/* MixedModels.update: after coding symbol s (with q set), moves the weights,
   then counts s. (Java's long division truncates towards zero, as C's.) */
static inline void MixedModels_update(MixedModels *mm, int s)
{
	int m = mm->m;
	int64_t qm = 0;
	for(int j = 0; j < m; j++) qm += mm->w[j] * mm->q[j];
	qm >>= MIX_W_BITS;
	if(qm < 1) qm = 1;
	int64_t t = 0;
	for(int j = 0; j < m; j++)
	{
		mm->w[j] += mm->w[j] * (mm->q[j] - qm) / (qm * MIX_RATE);
		if(mm->w[j] < MIX_WMIN) mm->w[j] = MIX_WMIN;
		t += mm->w[j];
	}
	int64_t t2 = 0;
	int big = 0;
	for(int j = 0; j < m; j++)
	{
		mm->w[j] = (mm->w[j] << MIX_W_BITS) / t;
		t2 += mm->w[j];
		if(mm->w[j] > mm->w[big]) big = j;
	}
	mm->w[big] += ((int64_t) 1 << MIX_W_BITS) - t2;
	for(int j = 0; j < m; j++)
	{
		size_t cell = (size_t) j * mm->contexts + mm->ctx[j];
		int32_t *fc = mm->f + cell * mm->n_symbols;
		fc[s] += CONTEXT_INCREMENT;
		mm->total[cell] += CONTEXT_INCREMENT;
		if(mm->total[cell] > CONTEXT_LIMIT)
		{
			int32_t u = 0;
			for(int i = 0; i < mm->n_symbols; i++) { fc[i] = (fc[i] + 1) >> 1; u += fc[i]; }
			mm->total[cell] = u;
		}
	}
}

/* MixedModels.encode: codes symbol s at the pixel whose contexts are in
   mm->ctx, and updates the models. */
static inline void MixedModels_encode(MixedModels *mm, RangeEncoder *enc, int s)
{
	int64_t a = 0, b = 0;
	for(int j = 0; j < mm->m; j++)
	{
		size_t cell = (size_t) j * mm->contexts + mm->ctx[j];
		const int32_t *fc = mm->f + cell * mm->n_symbols;
		int64_t cs = 0;
		for(int i = 0; i < s; i++) cs += fc[i];
		int64_t t  = mm->total[cell];
		int64_t c0 = (cs << MIX_R_BITS) / t, c1 = ((cs + fc[s]) << MIX_R_BITS) / t;
		a += mm->w[j] * c0;
		b += mm->w[j] * c1;
		mm->q[j] = c1 - c0;
	}
	int64_t lo = (a >> MIX_W_BITS) + s, hi = (b >> MIX_W_BITS) + s + 1;
	RangeEncoder_encode(enc, lo, hi - lo, ((int64_t) 1 << MIX_R_BITS) + mm->n_symbols);
	MixedModels_update(mm, s);
}

/* The encoder's contexts, worked out by a helper thread a row at a time
   into a ring of CONTEXT_RING rows: row y is ready when ready > y, and its
   slot is free again when done > y. The helper has a copy of the models'
   struct of its own (MixedModels_contextsRow writes its prediction and ctx;
   the rest it only reads), so the coder's models are untouched. */
#define CONTEXT_RING 64

typedef struct ContextRows
{
	MixedModels    mm;               /* the helper's copy */
	const int32_t *d, *v;
	int            rows, xdim, threaded;
	uint16_t      *buf;              /* CONTEXT_RING rows of 3 * xdim */
	uint16_t      *row[CONTEXT_RING][3];
	Progress       ready, done;
	Thread         thread;
	ThreadStart    start;
} ContextRows;

static void context_rows_body(void *arg)
{
	ContextRows *cr = arg;
	for(int y = 0; y < cr->rows; y++)
	{
		if(y >= CONTEXT_RING) progress_wait(&cr->done, y - CONTEXT_RING + 1);
		MixedModels_contextsRow(&cr->mm, y, cr->d, cr->v, cr->row[y % CONTEXT_RING]);
		progress_set(&cr->ready, y + 1);
	}
}

static int context_rows_start(ContextRows *cr, const MixedModels *mm, const int32_t *d, const int32_t *v, int rows)
{
	memset(cr, 0, sizeof *cr);
	cr->mm = *mm; cr->d = d; cr->v = v; cr->rows = rows; cr->xdim = mm->xdim;
	cr->buf = malloc((size_t) CONTEXT_RING * 3 * mm->xdim * sizeof *cr->buf);
	if(!cr->buf) return -1;
	for(int r = 0; r < CONTEXT_RING; r++)
		for(int j = 0; j < 3; j++) cr->row[r][j] = cr->buf + ((size_t) r * 3 + j) * mm->xdim;
	progress_init(&cr->ready); progress_init(&cr->done);
	cr->start.body = context_rows_body; cr->start.arg = cr;
	cr->threaded = rows > 1 && thread_start(&cr->thread, &cr->start) == 0;
	return 0;
}

/* Row y's contexts (waiting for the helper; without it, working them out). */
static uint16_t *const *context_rows_get(ContextRows *cr, int y)
{
	uint16_t **row = cr->row[y % CONTEXT_RING];
	if(cr->threaded) progress_wait(&cr->ready, y + 1);
	else MixedModels_contextsRow(&cr->mm, y, cr->d, cr->v, row);
	return (uint16_t *const *) row;
}

static void context_rows_done(ContextRows *cr, int y) { if(cr->threaded) progress_set(&cr->done, y + 1); }

static void context_rows_finish(ContextRows *cr)
{
	if(cr->threaded) thread_join(cr->thread);
	progress_destroy(&cr->ready); progress_destroy(&cr->done);
	free(cr->buf);
}

/* rankTable's order: by count, most first, then by value. */
typedef struct { int32_t count, value; } RankEntry;
static int rank_order(const void *pa, const void *pb)
{
	const RankEntry *a = pa, *b = pb;
	if(a->count != b->count) return (a->count > b->count) ? -1 : 1;
	return (a->value > b->value) - (a->value < b->value);
}

static void put32(uint8_t *p, int32_t v) { uint32_t u = (uint32_t) v; p[0] = (uint8_t) (u >> 24); p[1] = (uint8_t) (u >> 16); p[2] = (uint8_t) (u >> 8); p[3] = (uint8_t) u; }

int DeltaMapper_packMixedDeltas(const int32_t *delta, const int32_t *values, const int32_t *const *previous, int np,
                                int xdim, int n, int opinions, uint8_t **packed, size_t *length)
{
	*packed = NULL; *length = 0;
	if(n <= 0 || xdim <= 0 || n % xdim != 0) return -1;   /* (the Java then codes it) */
	/* rankTable: each value's rank, most frequent first. */
	int32_t lo = delta[0], hi = delta[0];
	for(int k = 1; k < n; k++) { if(delta[k] < lo) lo = delta[k]; if(delta[k] > hi) hi = delta[k]; }
	int span = (int) (hi - lo + 1);
	RankEntry *order = calloc((size_t) span, sizeof *order);
	int32_t   *rank  = malloc((size_t) span * sizeof *rank);
	if(!order || !rank) { free(order); free(rank); return -1; }
	for(int v = 0; v < span; v++) order[v].value = v;
	for(int k = 0; k < n; k++) order[delta[k] - lo].count++;
	qsort(order, (size_t) span, sizeof *order, rank_order);
	for(int r = 0; r < span; r++) rank[order[r].value] = r;
	free(order);

	MixedModels mm;
	RangeEncoder enc;
	if(MixedModels_init(&mm, span, np, xdim, n, opinions)) { free(rank); return -1; }
	if(MixedModels_earlierAll(&mm, previous, np)) { MixedModels_free(&mm); free(rank); return -1; }
	if(RangeEncoder_init(&enc, (size_t) n / 2)) { MixedModels_free(&mm); free(rank); return -1; }
	/* The contexts depend only on the deltas and values, all known: a helper
	   thread works them out a row at a time into a ring of rows, ahead of
	   this one, which codes the symbols (or, if the thread can't start, this
	   one does both, a row at a time). */
	ContextRows cr;
	if(context_rows_start(&cr, &mm, delta, values, n / xdim))
	{
		MixedModels_free(&mm); free(enc.out); free(rank); return -1;
	}
	for(int y = 0, k = 0; y < n / xdim; y++)
	{
		uint16_t *const *ctx = context_rows_get(&cr, y);
		for(int x = 0; x < xdim; x++, k++)
		{
			for(int j = 0; j < mm.m; j++) mm.ctx[j] = ctx[j][x];
			MixedModels_encode(&mm, &enc, rank[delta[k] - lo]);
		}
		context_rows_done(&cr, y);
	}
	context_rows_finish(&cr);
	MixedModels_free(&mm);
	if(RangeEncoder_finish(&enc)) { free(enc.out); free(rank); return -1; }

	/* As the Java writes it (DataOutputStream, big-endian): the minimum; the
	   rank table (writeTable: its length as a short, then a byte per entry if
	   at most 255, else a short); the coded length and bytes. */
	size_t table = 2 + (size_t) span * ((span <= 255) ? 1 : 2);
	size_t total = 4 + table + 4 + enc.size;
	uint8_t *out = malloc(total), *p = out;
	if(!out) { free(enc.out); free(rank); return -1; }
	put32(p, lo); p += 4;
	*p++ = (uint8_t) (span >> 8); *p++ = (uint8_t) span;
	for(int v = 0; v < span; v++)
	{
		if(span <= 255) *p++ = (uint8_t) rank[v];
		else { *p++ = (uint8_t) (rank[v] >> 8); *p++ = (uint8_t) rank[v]; }
	}
	put32(p, (int32_t) enc.size); p += 4;
	memcpy(p, enc.out, enc.size);
	free(enc.out);
	free(rank);
	*packed = out; *length = total;
	return 0;
}

/* ---- Decoding: MixedModels.decode, MixedDecoder ---------------------------- */

/* MixedModels.decode: the symbol at the pixel whose contexts are in mm->ctx,
   updating the models. The symbol s is the first whose interval's top
   hi(s) = (sum_j w_j floor(cum_j(s) 2^16 / tot_j) >> 16) + s + 1 is above
   the target t (or the last). The Java steps through the symbols working
   hi out exactly, a division per model per step. Here a cheap upper bound
   of hi (the sum without the floors, in double, a little rounded up) passes
   over the symbols it shows can't be the one (hi <= bound <= t), and the
   exact hi is worked out only from the first it can't rule out: the same
   symbol, and the same interval, as the Java's. */
static inline int MixedModels_decode(MixedModels *mm, RangeDecoder *dec)
{
	int m = mm->m, n = mm->n_symbols;
	int64_t t = RangeDecoder_target(dec, ((int64_t) 1 << MIX_R_BITS) + n);
	const int32_t *fc[3];
	int64_t tot[3], cum[3] = { 0, 0, 0 }, c1[3] = { 0, 0, 0 };
	double  scale[3];    /* w_j 2^16 / tot_j, so the bound is sum_j cum_j scale_j / 2^16 */
	for(int j = 0; j < m; j++)
	{
		size_t cell = (size_t) j * mm->contexts + mm->ctx[j];
		fc[j]    = mm->f + cell * n;
		tot[j]   = mm->total[cell];
		scale[j] = (double) mm->w[j] * (double) (1 << MIX_R_BITS) / (double) tot[j];
	}
	int s = 0;
	/* The pass: cum_j(s) summed exactly; the bound of a / 2^16 = sum_j w_j
	   c1_j / 2^16, where c1_j <= cum_j 2^16 / tot_j. Its rounding error is
	   far under the 1e-6 added (the sum is under 2^33, so its error is under
	   2^-19 of a unit, and divided by 2^16 under 2^-35). */
	for(;; s++)
	{
		double r = 0;
		for(int j = 0; j < m; j++) { cum[j] += fc[j][s]; r += (double) cum[j] * scale[j]; }
		int64_t bound = (int64_t) (r * (1.0 / (1 << MIX_W_BITS)) + 1e-6) + s + 1;
		if(bound > t || s == n - 1) break;
	}
	/* The exact hi from here on, as the Java's. */
	int64_t hi;
	for(;;)
	{
		int64_t a = 0;
		for(int j = 0; j < m; j++) { c1[j] = (cum[j] << MIX_R_BITS) / tot[j]; a += mm->w[j] * c1[j]; }
		hi = (a >> MIX_W_BITS) + s + 1;
		if(t < hi || s == n - 1) break;
		s++;
		for(int j = 0; j < m; j++) cum[j] += fc[j][s];
	}
	/* The symbol before's top, exactly (the interval's bottom), and q. */
	int64_t lo = 0;
	if(s > 0)
	{
		int64_t a = 0;
		for(int j = 0; j < m; j++)
		{
			int64_t c0 = ((cum[j] - fc[j][s]) << MIX_R_BITS) / tot[j];
			a += mm->w[j] * c0;
			mm->q[j] = c1[j] - c0;
		}
		lo = (a >> MIX_W_BITS) + s;
	}
	else
		for(int j = 0; j < m; j++) mm->q[j] = c1[j];
	RangeDecoder_decode(dec, lo, hi - lo);
	MixedModels_update(mm, s);
	return s;
}

/* ---- getValuesFromRowFitChannels ------------------------------------------- */

/* One channel's decoding: the decoder's thread (a row at a time, a chunk of
   columns at a time, as RowWave.row) and its helper's (the fit for the next
   row, a chunk behind the decoder, as RowWave's tasks). */
typedef struct ChannelDecode
{
	struct ChannelDecode *before;   /* the channel coded before this one, or NULL */
	int known;                      /* the deltas are given (rebuilding): nothing is decoded */
	DeltaSource source;             /* rebuilding: fills delta first, if not NULL */
	void *source_arg;
	int i, xdim, ydim, init, n_symbols;
	const int32_t *rank_value;      /* the delta value of each rank */
	const int32_t *const *previous; /* the deltas of the channels before */
	int32_t *delta, *value;
	RowFit fit;
	/* What the decoder writes at every pixel (the models, the range decoder)
	   and what the helpers write are kept on cache lines of their own, so
	   the threads don't keep taking lines from each other. */
	_Alignas(64) RowFitWork work;          /* the decoder's buffers */
	_Alignas(64) MixedModels mm;
	_Alignas(64) RangeDecoder dec;
	int chunks, *start, *first;     /* RowWave's chunks: columns start[t] to start[t + 1] - 1, points first[t] to first[t + 1] - 1 */
	int helpers;                    /* the helper threads fitting the rows ahead */
	struct FitHelper *helper;       /* their buffers */
	_Alignas(64) Progress rows;     /* rows decoded (all of them: for the next channel) */
	_Alignas(64) Progress decoded;  /* chunks decoded: y * chunks + t + 1 once row y's chunk t is */
	Progress *added;                /* per chunk: the row its columns have been moved to */
	Progress *solved;               /* per chunk: the row its fits have been solved for */
	_Alignas(64) atomic_long next_task;   /* the helpers' next task (see channel_helper) */
	_Alignas(64) int failed;
} ChannelDecode;

/* A helper thread's own buffers. */
typedef struct FitHelper
{
	ChannelDecode *c;
	_Alignas(64) RowFitWork work;
	int64_t *grp;                   /* its group sums (see solve_points) */
} FitHelper;

/* MixedDecoder.next: decodes the delta at pixel k (prediction: the fit's,
   for interior pixels). Rebuilding, the delta is already there. */
static inline void decode_next(ChannelDecode *c, int k, int prediction)
{
	if(c->known) return;
	MixedModels *mm = &c->mm;
	if(k >= mm->earlier_end && MixedModels_earlierRows(mm, c->previous, c->i, k / c->xdim + 1)) c->failed = 1;
	mm->prediction = prediction;
	MixedModels_contexts(mm, k, c->delta, c->value);
	c->delta[k] = c->rank_value[MixedModels_decode(mm, &c->dec)];
}

/* rowFitRow and RowWave.row: decodes row y (its fit solved). With chunks, it
   waits for each chunk's fits from the helper, and says when it has passed
   each chunk. */
static void decode_row(ChannelDecode *c, int y, int chunked)
{
	int xdim = c->xdim, k = y * xdim;
	int32_t *d = c->delta, *v = c->value;
	if(y == 0)
	{
		decode_next(c, 0, 0);
		v[0] = c->init;
		for(int x = 1; x < xdim; x++) { decode_next(c, x, 0); v[x] = v[x - 1] + d[x]; }
		return;
	}
	decode_next(c, k, 0);
	v[k] = v[k - xdim] + d[k];
	if(!chunked)
		for(int x = 1; x < xdim - 1; x++)
		{
			k++;
			int p = RowFit_predict(&c->fit, y, x);
			decode_next(c, k, p);
			v[k] = d[k] + p;
		}
	else
		for(int t = 0; t < c->chunks; t++)
		{
			progress_wait(&c->solved[t], y);
			for(int x = c->start[t]; x < c->start[t + 1]; x++)
			{
				k++;
				int p = RowFit_predict(&c->fit, y, x);
				decode_next(c, k, p);
				v[k] = d[k] + p;
			}
			progress_set(&c->decoded, (long) y * c->chunks + t + 1);
		}
	if(xdim > 1)   /* (a band 1 wide has only column 0) */
	{
		k++;
		decode_next(c, k, 0);
		v[k] = v[k - 1] + d[k];
	}
}

static void channel_decoder(void *arg)
{
	ChannelDecode *c = arg;
	/* With helpers, the rows' fits are theirs, a chunk at a time (rows 2 on);
	   without, this thread solves each row's fits itself before the row. */
	int ydim = c->ydim, chunked = c->helpers > 0 && c->xdim > 2 && c->fit.points > 0;
	/* (If the deltas can't be made, the rows are still rebuilt, from what
	   there is, so that nothing waiting on them waits for ever; the result
	   is then a failure.) */
	if(c->source && c->source(c->source_arg, c->delta)) c->failed = 1;
	for(int y = 0; y < ydim; y++)
	{
		/* The channel before must be two rows ahead (this row's fit and
		   contexts use its row y, and its row y + 1); rebuilding, one (the
		   fit uses only its row y). */
		int ahead = c->known ? 1 : 2;
		if(c->before) progress_wait(&c->before->rows, (y + ahead < ydim) ? y + ahead : ydim);
		if(y >= 1 && (!chunked || y == 1))
		{
			RowFit_moveTo(&c->fit, y);
			RowFit_solveRow(&c->fit, y, &c->work);
			if(chunked)
				for(int t = 0; t < c->chunks; t++) { progress_set(&c->added[t], 1); progress_set(&c->solved[t], 1); }
		}
		decode_row(c, y, chunked && y >= 1);
		progress_set(&c->rows, y + 1);
	}
}

/* The helpers: the fits of rows 2 on, in tasks taken in this order (as one
   helper would do them), each by whichever helper is free:

     row Y:  add 0, add 1, solve 0, add 2, solve 1, ..., add C - 1, solve C - 2, solve C - 1

   add t moves chunk t's columns down to row Y, once the decoder has passed
   chunk t of row Y - 1 and nothing still reads them (the solves of row
   Y - 1 for chunks t - 1 to t + 1); solve t solves chunk t's points for row
   Y, once chunks t - 1 to t + 1 have been added (its windows reach no
   further: a chunk is wider than the radius). Each task writes only its own
   columns or points, so the result doesn't depend on which helper did what;
   and a task waits only for earlier ones (or the decoder, which waits only
   for the solves), so the helpers always get on. */
static void channel_helper(void *arg)
{
	FitHelper *h = arg;
	ChannelDecode *c = h->c;
	RowFit *f = &c->fit;
	int C = c->chunks;
	long tasks = (long) (c->ydim - 2) * 2 * C;
	for(;;)
	{
		long task = atomic_fetch_add(&c->next_task, 1);
		if(task >= tasks) break;
		int Y = 2 + (int) (task / (2 * C)), k = (int) (task % (2 * C)), t, add;
		if(k == 2 * C - 1)  { add = 0; t = C - 1; }
		else if(k == 0)     { add = 1; t = 0; }
		else if(k % 2 == 1) { add = 1; t = (k + 1) / 2; }
		else                { add = 0; t = k / 2 - 1; }
		int lo = imax(0, t - 1), hi = imin(C - 1, t + 1);
		if(add)
		{
			/* If it has to sleep, it sleeps until the decoder is a few chunks
			   further on (at most to the row's end): the decoder needs this
			   chunk's fit only a row later. */
			long need = (long) (Y - 1) * C + t + 1, row_end = (long) Y * C;
			progress_wait_or_later(&c->decoded, need, (need + 4 < row_end) ? need + 4 : row_end);
			for(int s = lo; s <= hi; s++) progress_wait(&c->solved[s], Y - 1);
			RowFit_addColumns(f, Y, c->start[t], c->start[t + 1], &h->work);
			progress_set(&c->added[t], Y);
		}
		else
		{
			for(int s = lo; s <= hi; s++) progress_wait(&c->added[s], Y);
			solve_points(f, Y, c->first[t], c->first[t + 1], &h->work, h->grp);
			progress_set(&c->solved[t], Y);
		}
	}
}

/* The most helper threads a channel gets. */
#define MAX_FIT_HELPERS 8

/* Frees what row_fit_channels allocated for a channel (its counters aside). */
static void channel_free(ChannelDecode *c)
{
	if(c->helper) for(int j = 0; j < c->helpers; j++) free(c->helper[j].grp);
	free(c->helper); free(c->added); free(c->solved); free(c->start); free(c->first);
	MixedModels_free(&c->mm);
	RowFit_free(&c->fit);
	c->helper = NULL; c->added = c->solved = NULL; c->start = c->first = NULL; c->chunks = 0;
}

/* DeltaMapper_decodeRowFitChannels and DeltaMapper_rebuildRowFitChannels:
   coded NULL rebuilds from the deltas given, or made by source (no models,
   no range decoder). */
static int row_fit_channels(int channels, const uint8_t *const *coded, const size_t *length,
                            const int32_t *const *rank_value, const int *n_symbols,
                            int xdim, int ydim, const int *init, const int *radius, int every,
                            DeltaSource source, void *const *source_arg, int helpers,
                            int32_t **delta, int32_t **value)
{
	int known = (coded == NULL);
	if(channels < 1 || channels > 3 || xdim < 1 || ydim < 1) return -1;
	helpers = imax(0, imin(MAX_FIT_HELPERS, helpers));
	int n = xdim * ydim, result = -1;
	ChannelDecode c[3];
	memset(c, 0, sizeof c);
	int ready = 0;
	for(int i = 0; i < channels; i++, ready++)
	{
		ChannelDecode *ci = &c[i];
		ci->before = (i > 0) ? &c[i - 1] : NULL;
		ci->known = known;
		ci->source = source;
		ci->source_arg = source ? source_arg[i] : NULL;
		ci->i = i; ci->xdim = xdim; ci->ydim = ydim; ci->init = init[i];
		ci->previous = (const int32_t *const *) delta;
		ci->delta = delta[i]; ci->value = value[i];
		if(!known)
		{
			ci->n_symbols = n_symbols[i]; ci->rank_value = rank_value[i];
			if(n_symbols[i] < 1) goto done;
		}
		if(RowFit_init(&ci->fit, value[i], (i > 0) ? value[i - 1] : NULL, xdim, radius[i], every)) goto done;
		if(!known)
		{
			if(MixedModels_init(&ci->mm, n_symbols[i], i, xdim, n, 1)) { RowFit_free(&ci->fit); goto done; }
			RangeDecoder_init(&ci->dec, coded[i], length[i]);
		}
		/* RowWave's chunks: at least 128 columns, and more than the radius. */
		int inner = (xdim > 2) ? xdim - 2 : 0, width = imax(128, radius[i] + 1);
		ci->chunks  = imax(1, inner / width);
		ci->helpers = helpers;
		ci->start   = malloc((size_t) (ci->chunks + 1) * sizeof *ci->start);
		ci->first   = malloc((size_t) (ci->chunks + 1) * sizeof *ci->first);
		ci->added   = malloc((size_t) ci->chunks * sizeof *ci->added);
		ci->solved  = malloc((size_t) ci->chunks * sizeof *ci->solved);
		ci->helper  = calloc((size_t) helpers, sizeof *ci->helper);
		int grp_ok  = helpers == 0 || ci->helper != NULL;
		for(int j = 0; j < helpers && grp_ok; j++)
		{
			ci->helper[j].c = ci;
			ci->helper[j].grp = malloc(((size_t) xdim + 2 * (size_t) radius[i] + 2) * sizeof *ci->helper[j].grp);
			grp_ok = ci->helper[j].grp != NULL;
		}
		if(!ci->start || !ci->first || !ci->added || !ci->solved || !grp_ok)
		{
			channel_free(ci);
			goto done;
		}
		for(int t = 0; t <= ci->chunks; t++)
		{
			ci->start[t] = 1 + (int) ((long long) t * inner / ci->chunks);
			ci->first[t] = imin(ci->fit.points, (ci->start[t] - 1 + every - 1) / every);
		}
		progress_init(&ci->rows); progress_init(&ci->decoded);
		for(int t = 0; t < ci->chunks; t++) { progress_init(&ci->added[t]); progress_init(&ci->solved[t]); }
		atomic_init(&ci->next_task, 0);
	}
	{
		Thread th[3 * (1 + MAX_FIT_HELPERS)];
		ThreadStart ts[3 * (1 + MAX_FIT_HELPERS)];
		int started = 0, ok = 1;
		for(int i = 0; i < channels && ok; i++)
		{
			ts[started].body = channel_decoder; ts[started].arg = &c[i];
			ok = thread_start(&th[started], &ts[started]) == 0;
			if(ok) started++;
			if(xdim > 2 && c[i].fit.points > 0 && ydim > 2)
				for(int j = 0; j < helpers && ok; j++)
				{
					ts[started].body = channel_helper; ts[started].arg = &c[i].helper[j];
					ok = thread_start(&th[started], &ts[started]) == 0;
					if(ok) started++;
				}
		}
		/* If a thread couldn't start, nothing waits for it: every count is set
		   past the end, so the threads that did start run to the end (on
		   meaningless numbers) and the decode fails (the Java then does it). */
		if(!ok)
			for(int i = 0; i < channels; i++)
			{
				progress_set(&c[i].rows, LONG_MAX); progress_set(&c[i].decoded, LONG_MAX);
				for(int t = 0; t < c[i].chunks; t++) { progress_set(&c[i].added[t], LONG_MAX); progress_set(&c[i].solved[t], LONG_MAX); }
			}
		for(int t = 0; t < started; t++) thread_join(th[t]);
		result = ok ? 0 : -1;
		for(int i = 0; i < channels; i++) if(c[i].failed) result = -1;
	}
done:
	for(int i = 0; i < ready; i++)
	{
		progress_destroy(&c[i].rows); progress_destroy(&c[i].decoded);
		for(int t = 0; t < c[i].chunks; t++) { progress_destroy(&c[i].added[t]); progress_destroy(&c[i].solved[t]); }
		channel_free(&c[i]);
	}
	return result;
}

int DeltaMapper_decodeRowFitChannels(int channels, const uint8_t *const *coded, const size_t *length,
                                     const int32_t *const *rank_value, const int *n_symbols,
                                     int xdim, int ydim, const int *init, const int *radius, int every, int helpers,
                                     int32_t **delta, int32_t **value)
{
	if(coded == NULL) return -1;
	return row_fit_channels(channels, coded, length, rank_value, n_symbols, xdim, ydim, init, radius, every, NULL, NULL, helpers, delta, value);
}

int DeltaMapper_rebuildRowFitChannels(int channels, int xdim, int ydim, const int *init, const int *radius, int every, int helpers,
                                      DeltaSource source, void *const *source_arg, int32_t **delta, int32_t **value)
{
	return row_fit_channels(channels, NULL, NULL, NULL, NULL, xdim, ydim, init, radius, every, source, source_arg, helpers, delta, value);
}

/* ---- Rebuilding the image: getBlueGreenRed, ResizeMapper.resize2 or resize, getPixel ---- */

typedef struct PixelJob
{
	int set_id, w, h, xdim, ydim, pixel_shift;
	const int32_t *c[3];             /* the decoded channels (w * h) */
	int min[3];                      /* added to channel i's values (0 where nothing is added) */
	int32_t *bgr[3];                 /* blue, green, red (w * h) */
	const int *ca, *cb, *ra, *rb;    /* the resize's maps (NULL: no resizing) */
	int resize;                      /* how they're averaged (DELTAMAPPER_RESIZE2, ...) */
	int32_t *pixel;                  /* the result (xdim * ydim) */
	int pass, threads, part;         /* which pass; how many parts; this one */
} PixelJob;

/* Pass 0: rows of blue, green and red, as getBlueGreenRed (with the minimums
   added first, as the reader does); pass 1: rows of pixels, each colour the
   average of resize2's four source pixels (or the pixel itself), packed as
   getPixel, then masked to 24 bits, as a TYPE_INT_RGB image stores them
   (what setRGB stores). Java's int arithmetic wraps; so does this (unsigned). */
static void pixel_part(void *arg)
{
	PixelJob *j = arg;
	if(j->pass == 0)
	{
		size_t n = (size_t) j->w * j->h, k0 = n * j->part / j->threads, k1 = n * (j->part + 1) / j->threads;
		const int32_t *c0 = j->c[0], *c1 = j->c[1], *c2 = j->c[2];
		int m0 = j->min[0], m1 = j->min[1], m2 = j->min[2];
		int32_t *b = j->bgr[0], *g = j->bgr[1], *r = j->bgr[2];
		#define ADD(a, x) ((int32_t) ((uint32_t) (a) + (uint32_t) (x)))
		#define SUB(a, x) ((int32_t) ((uint32_t) (a) - (uint32_t) (x)))
		for(size_t k = k0; k < k1; k++)
		{
			int32_t v0 = ADD(c0[k], m0), v1 = ADD(c1[k], m1), v2 = ADD(c2[k], m2);
			switch(j->set_id)
			{
				case 0:  b[k] = v0; g[k] = v1; r[k] = v2; break;
				case 1:  b[k] = v0; r[k] = v1; g[k] = SUB(v1, v2); break;
				case 2:  b[k] = v0; r[k] = v1; g[k] = SUB(v0, v2); break;
				case 3:  b[k] = v0; g[k] = SUB(v0, v1); r[k] = ADD(v2, g[k]); break;
				case 4:  b[k] = v0; g[k] = SUB(v0, v1); r[k] = ADD(v0, v2); break;
				case 5:  g[k] = v0; r[k] = v1; b[k] = ADD(v2, v0); break;
				case 6:  r[k] = v0; g[k] = SUB(v0, v2); b[k] = ADD(v1, g[k]); break;
				case 7:  g[k] = v0; b[k] = ADD(v0, v1); r[k] = ADD(v0, v2); break;
				case 8:  g[k] = v0; r[k] = ADD(v0, v1); b[k] = SUB(r[k], v2); break;
				default: r[k] = v0; g[k] = SUB(v0, v1); b[k] = SUB(v0, v2); break;   /* 9 */
			}
		}
		return;
	}
	int y0 = (int) ((long long) j->ydim * j->part / j->threads), y1 = (int) ((long long) j->ydim * (j->part + 1) / j->threads);
	int bs = j->pixel_shift + 16, gs = j->pixel_shift + 8, rs = j->pixel_shift, w = j->w;
	const int32_t *B = j->bgr[0], *G = j->bgr[1], *R = j->bgr[2];
	for(int y = y0; y < y1; y++)
	{
		int32_t *out = j->pixel + (size_t) y * j->xdim;
		if(j->ca == NULL)
		{
			const int32_t *b = B + (size_t) y * w, *g = G + (size_t) y * w, *r = R + (size_t) y * w;
			for(int x = 0; x < j->xdim; x++)
				out[x] = (int32_t) ((((uint32_t) b[x] << bs) + ((uint32_t) g[x] << gs) + ((uint32_t) r[x] << rs)) & 0xFFFFFF);
			continue;
		}
		size_t s = (size_t) j->ra[y] * w, t = (size_t) j->rb[y] * w;
		for(int x = 0; x < j->xdim; x++)
		{
			size_t a = (size_t) j->ca[x], c = (size_t) j->cb[x];
			int32_t b, g, r;
			/* (Java's / truncates towards zero, as C's.) resize2 takes the
			   four pixels' average at once; resize averages two rows, then
			   two columns of those (or the other way round), rounding each
			   time. */
			if(j->resize == DELTAMAPPER_RESIZE2)
			{
				b = ADD(ADD(B[s + a], B[s + c]), ADD(B[t + a], B[t + c])) / 4;
				g = ADD(ADD(G[s + a], G[s + c]), ADD(G[t + a], G[t + c])) / 4;
				r = ADD(ADD(R[s + a], R[s + c]), ADD(R[t + a], R[t + c])) / 4;
			}
			else if(j->resize == DELTAMAPPER_RESIZE_ROWS_FIRST)
			{
				b = ADD(ADD(B[s + a], B[t + a]) / 2, ADD(B[s + c], B[t + c]) / 2) / 2;
				g = ADD(ADD(G[s + a], G[t + a]) / 2, ADD(G[s + c], G[t + c]) / 2) / 2;
				r = ADD(ADD(R[s + a], R[t + a]) / 2, ADD(R[s + c], R[t + c]) / 2) / 2;
			}
			else
			{
				b = ADD(ADD(B[s + a], B[s + c]) / 2, ADD(B[t + a], B[t + c]) / 2) / 2;
				g = ADD(ADD(G[s + a], G[s + c]) / 2, ADD(G[t + a], G[t + c]) / 2) / 2;
				r = ADD(ADD(R[s + a], R[s + c]) / 2, ADD(R[t + a], R[t + c]) / 2) / 2;
			}
			out[x] = (int32_t) ((((uint32_t) b << bs) + ((uint32_t) g << gs) + ((uint32_t) r << rs)) & 0xFFFFFF);
		}
	}
	#undef ADD
	#undef SUB
}

int DeltaMapper_getPixels(int set_id, const int32_t *const c[3], const int min[3], int w, int h,
                          const int *ca, const int *cb, const int *ra, const int *rb, int resize, int xdim, int ydim,
                          int pixel_shift, int32_t *pixel, int threads)
{
	if(set_id < 0 || set_id > 9 || w < 1 || h < 1) return -1;
	if(resize < DELTAMAPPER_RESIZE2 || resize > DELTAMAPPER_RESIZE_COLUMNS_FIRST) return -1;
	if(ca == NULL && (xdim != w || ydim != h)) return -1;
	if(threads < 1) threads = 1;
	if(threads > 64) threads = 64;
	size_t n = (size_t) w * h;
	int32_t *buf = malloc(3 * n * sizeof *buf);
	if(!buf) return -1;
	PixelJob job[64];
	Thread th[64];
	ThreadStart ts[64];
	int result = 0;
	for(int pass = 0; pass < 2 && result == 0; pass++)
	{
		int started = 0;
		for(int p = 0; p < threads; p++)
		{
			PixelJob *j = &job[p];
			j->set_id = set_id; j->w = w; j->h = h; j->xdim = xdim; j->ydim = ydim; j->pixel_shift = pixel_shift;
			for(int i = 0; i < 3; i++) { j->c[i] = c[i]; j->min[i] = min[i]; j->bgr[i] = buf + (size_t) i * n; }
			j->ca = ca; j->cb = cb; j->ra = ra; j->rb = rb; j->resize = resize; j->pixel = pixel;
			j->pass = pass; j->threads = threads; j->part = p;
			ts[p].body = pixel_part; ts[p].arg = j;
			/* The last part runs here; a part whose thread won't start, too. */
			if(p == threads - 1 || thread_start(&th[started], &ts[p]) != 0) pixel_part(j);
			else started++;
		}
		for(int t = 0; t < started; t++) thread_join(th[t]);
	}
	free(buf);
	return result;
}

/* ---- Running parts of a job on threads ------------------------------------- */

typedef struct PartsJob { void (*body)(void *arg, int part, int parts); void *arg; int part, parts; } PartsJob;
static void parts_main(void *p) { PartsJob *j = p; j->body(j->arg, j->part, j->parts); }

/* body(arg, part, parts) for part 0 to parts - 1, on threads (the last here;
   a part whose thread won't start runs here too). */
static void run_parts(void (*body)(void *, int, int), void *arg, int parts)
{
	if(parts < 1) parts = 1;
	if(parts > 64) parts = 64;
	PartsJob job[64];
	ThreadStart ts[64];
	Thread th[64];
	int started = 0;
	for(int p = 0; p < parts; p++)
	{
		job[p].body = body; job[p].arg = arg; job[p].part = p; job[p].parts = parts;
		ts[p].body = parts_main; ts[p].arg = &job[p];
		if(p == parts - 1 || thread_start(&th[started], &ts[p]) != 0) parts_main(&job[p]);
		else started++;
	}
	for(int t = 0; t < started; t++) thread_join(th[t]);
}

/* ---- Apply: quantizedChannels, getCandidateChannels, the preview ------------- */

#define ADD32(a, x) ((int32_t) ((uint32_t) (a) + (uint32_t) (x)))
#define SUB32(a, x) ((int32_t) ((uint32_t) (a) - (uint32_t) (x)))

typedef struct ApplyJob
{
	const int32_t *src[3];          /* blue, green, red at the image's size */
	int X, Y, w, h, shift, correction;
	const int *ca, *cb, *ra, *rb;   /* resize2's maps (NULL: none) */
	int32_t *q[3];                  /* the quantized blue, green, red (w * h) */
	int32_t *diff[3];               /* blue - green, red - green, red - blue, less their minimums */
	int32_t part_min[64][6];
	int32_t *pixel;                 /* the preview (X * Y) */
} ApplyJob;

/* quantizedChannels' rows: resize2 (the average of its four source pixels)
   to w x h, then quantizeChannel (min(v + half, 255) >> shift). */
static void apply_quantize(void *arg, int part, int parts)
{
	ApplyJob *j = arg;
	int y0 = (int) ((long long) j->h * part / parts), y1 = (int) ((long long) j->h * (part + 1) / parts);
	int half = (j->shift > 0) ? 1 << (j->shift - 1) : 0;
	for(int c = 0; c < 3; c++)
		for(int y = y0; y < y1; y++)
		{
			int32_t *out = j->q[c] + (size_t) y * j->w;
			const int32_t *S = j->src[c];
			for(int x = 0; x < j->w; x++)
			{
				int32_t v;
				if(j->ca)
				{
					size_t s = (size_t) j->ra[y] * j->X, t = (size_t) j->rb[y] * j->X, a = (size_t) j->ca[x], b = (size_t) j->cb[x];
					v = ADD32(ADD32(S[s + a], S[s + b]), ADD32(S[t + a], S[t + b])) / 4;
				}
				else v = S[(size_t) y * j->X + x];
				if(j->shift > 0) { v = ADD32(v, half); if(v > 255) v = 255; v >>= j->shift; }
				out[x] = v;
			}
		}
}

/* getCandidateChannels' differences and each part's minimums of all six. */
static void apply_candidates(void *arg, int part, int parts)
{
	ApplyJob *j = arg;
	size_t n = (size_t) j->w * j->h, k0 = n * part / parts, k1 = n * (part + 1) / parts;
	const int32_t *B = j->q[0], *G = j->q[1], *R = j->q[2];
	int32_t m[6] = { INT32_MAX, INT32_MAX, INT32_MAX, INT32_MAX, INT32_MAX, INT32_MAX };
	for(size_t k = k0; k < k1; k++)
	{
		int32_t v[6] = { B[k], G[k], R[k], SUB32(B[k], G[k]), SUB32(R[k], G[k]), SUB32(R[k], B[k]) };
		j->diff[0][k] = v[3]; j->diff[1][k] = v[4]; j->diff[2][k] = v[5];
		for(int i = 0; i < 6; i++) if(v[i] < m[i]) m[i] = v[i];
	}
	memcpy(j->part_min[part], m, sizeof m);
}

/* ... then each difference less its minimum. */
static void apply_subtract(void *arg, int part, int parts)
{
	ApplyJob *j = arg;
	size_t n = (size_t) j->w * j->h, k0 = n * part / parts, k1 = n * (part + 1) / parts;
	for(int i = 0; i < 3; i++)
	{
		int32_t m = j->part_min[0][3 + i], *d = j->diff[i];
		for(size_t k = k0; k < k1; k++) d[k] = SUB32(d[k], m);
	}
}

/* The preview's rows: each of q resized back to X x Y (resize2), shifted up,
   moved towards the source by correction / 10 (Error Correction), packed
   (blue << 16) + (green << 8) + red and masked to 24 bits, as a TYPE_INT_RGB
   image stores them (what setRGB stores). */
static void apply_preview(void *arg, int part, int parts)
{
	ApplyJob *j = arg;
	int y0 = (int) ((long long) j->Y * part / parts), y1 = (int) ((long long) j->Y * (part + 1) / parts);
	double f = j->correction / 10.0;
	for(int y = y0; y < y1; y++)
	{
		int32_t *out = j->pixel + (size_t) y * j->X;
		for(int x = 0; x < j->X; x++)
		{
			int32_t v[3];
			size_t k = (size_t) y * j->X + x;
			for(int c = 0; c < 3; c++)
			{
				const int32_t *Q = j->q[c];
				int32_t u;
				if(j->ca)
				{
					size_t s = (size_t) j->ra[y] * j->w, t = (size_t) j->rb[y] * j->w, a = (size_t) j->ca[x], b = (size_t) j->cb[x];
					u = ADD32(ADD32(Q[s + a], Q[s + b]), ADD32(Q[t + a], Q[t + b])) / 4;
				}
				else u = Q[k];
				if(j->shift != 0) u = (int32_t) ((uint32_t) u << j->shift);
				/* (Java's (int) of a double truncates towards zero, as C's.) */
				if(j->correction != 0) u = ADD32(u, (int32_t) ((double) SUB32(j->src[c][k], u) * f));
				v[c] = u;
			}
			out[x] = (int32_t) ((((uint32_t) v[0] << 16) + ((uint32_t) v[1] << 8) + (uint32_t) v[2]) & 0xFFFFFF);
		}
	}
}

int DeltaMapper_applyQuantize(const int32_t *const src[3], int X, int Y, int w, int h,
                              const int *ca, const int *cb, const int *ra, const int *rb, int shift,
                              int32_t *q[3], int32_t *diff[3], int32_t min[6], int threads)
{
	if(X < 1 || Y < 1 || w < 1 || h < 1 || shift < 0 || shift > 30 || (ca == NULL && (w != X || h != Y))) return -1;
	ApplyJob j;
	memset(&j, 0, sizeof j);
	for(int c = 0; c < 3; c++) { j.src[c] = src[c]; j.q[c] = q[c]; j.diff[c] = diff[c]; }
	j.X = X; j.Y = Y; j.w = w; j.h = h; j.shift = shift; j.ca = ca; j.cb = cb; j.ra = ra; j.rb = rb;
	if(threads < 1) threads = 1;
	if(threads > 64) threads = 64;
	run_parts(apply_quantize, &j, threads);
	run_parts(apply_candidates, &j, threads);
	for(int p = 1; p < threads; p++) for(int i = 0; i < 6; i++) if(j.part_min[p][i] < j.part_min[0][i]) j.part_min[0][i] = j.part_min[p][i];
	run_parts(apply_subtract, &j, threads);
	for(int i = 0; i < 6; i++) min[i] = j.part_min[0][i];
	return 0;
}

int DeltaMapper_applyPreview(const int32_t *const q[3], int w, int h, const int *ca, const int *cb, const int *ra, const int *rb,
                             int X, int Y, int shift, int correction, const int32_t *const src[3], int32_t *pixel, int threads)
{
	if(X < 1 || Y < 1 || w < 1 || h < 1 || shift < 0 || shift > 30 || (ca == NULL && (w != X || h != Y))) return -1;
	ApplyJob j;
	memset(&j, 0, sizeof j);
	for(int c = 0; c < 3; c++) { j.src[c] = src[c]; j.q[c] = (int32_t *) q[c]; }
	j.X = X; j.Y = Y; j.w = w; j.h = h; j.shift = shift; j.correction = correction; j.ca = ca; j.cb = cb; j.ra = ra; j.rb = rb; j.pixel = pixel;
	run_parts(apply_preview, &j, threads);
	return 0;
}

/* ---- Save's decode check: unpackMixedDeltas, compared ---------------------- */

static int32_t get_be32(const uint8_t *p) { return (int32_t) ((uint32_t) p[0] << 24 | (uint32_t) p[1] << 16 | (uint32_t) p[2] << 8 | p[3]); }

int DeltaMapper_checkMixedDeltas(const uint8_t *packed, size_t length, const int32_t *delta, const int32_t *values,
                                 const int32_t *const *previous, int np, int xdim, int n)
{
	if(n <= 0 || xdim <= 0 || n % xdim != 0) return -1;
	/* readMixedDeltas: the minimum, the rank table, the coded bytes. Anything
	   that doesn't fit is a failed check. */
	if(length < 6) return 0;
	int32_t lo = get_be32(packed);
	int span = packed[4] << 8 | packed[5];
	size_t pos = 6, entry = (span <= 255) ? 1 : 2;
	if(span < 1 || length < pos + (size_t) span * entry + 4) return 0;
	int32_t *rank_value = malloc((size_t) span * sizeof *rank_value);
	if(!rank_value) return -1;
	for(int i = 0; i < span; i++) rank_value[i] = INT32_MIN;
	for(int v = 0; v < span; v++, pos += entry)
	{
		int r = (entry == 1) ? packed[pos] : (packed[pos] << 8 | packed[pos + 1]);
		if(r < span) rank_value[r] = ADD32(v, lo);
	}
	int32_t coded = get_be32(packed + pos);
	pos += 4;
	if(coded < 0 || length < pos + (size_t) coded) { free(rank_value); return 0; }

	MixedModels mm;
	if(MixedModels_init(&mm, span, np, xdim, n, 1)) { free(rank_value); return -1; }
	if(MixedModels_earlierAll(&mm, previous, np)) { MixedModels_free(&mm); free(rank_value); return -1; }
	RangeDecoder dec;
	RangeDecoder_init(&dec, packed + pos, (size_t) coded);
	/* Up to the first wrong delta, decoding with the expected deltas'
	   contexts is decoding with its own, and it gets that delta wrong too:
	   so the contexts come ahead from a helper thread, as the encoder's do,
	   and the check stops at the first difference. */
	ContextRows cr;
	if(context_rows_start(&cr, &mm, delta, values, n / xdim)) { MixedModels_free(&mm); free(rank_value); return -1; }
	int same = 1;
	for(int y = 0, k = 0; y < n / xdim && same; y++)
	{
		uint16_t *const *ctx = context_rows_get(&cr, y);
		for(int x = 0; x < xdim; x++, k++)
		{
			for(int j = 0; j < mm.m; j++) mm.ctx[j] = ctx[j][x];
			if(rank_value[MixedModels_decode(&mm, &dec)] != delta[k]) { same = 0; break; }
		}
		context_rows_done(&cr, y);
	}
	/* (If it stopped early, the helper is let run to the end, unwaited-for.) */
	if(!same) for(int y = 0; y < n / xdim; y++) context_rows_done(&cr, y);
	context_rows_finish(&cr);
	MixedModels_free(&mm);
	free(rank_value);
	return same;
}
