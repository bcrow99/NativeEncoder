/*
 * DeltaMapper.h -- C versions of DeltaMapper.java's methods (NativeEncoder).
 *
 * So far: RowFit, the least-squares fit from the rows above (Simple 2
 * format), as in DeltaMapper.RowFit. The C gives the same predictions as the
 * Java, bit for bit: the window's sums are exact integers, and the solve and
 * the prediction do the same double operations in the same order (compile
 * without -ffast-math, and with -ffp-contract=off so no multiply-add is fused).
 * Its layout differs from the Java's for speed: the column sums are kept a
 * product at a time along the row, so they're updated a row at a time;
 * windows are summed from groups of columns; the points are solved
 * ROWFIT_LANES at a time, side by side; and RowFit_plane fits each band a
 * strip of columns at a time, all its rows, so the strip's sums stay in the
 * core's cache. None of that changes a result: the
 * sums are exact, and each point's solve does the Java's operations in the
 * Java's order.
 *
 * NativeSimpleWriter calls RowFit_plane through JNI (DeltaMapper_jni.c).
 */
#ifndef DELTA_MAPPER_H
#define DELTA_MAPPER_H

#include <stddef.h>
#include <stdint.h>

/* The version of the native methods (DeltaMapper.NATIVE_VERSION in the Java
   must be the same): raised whenever one is added or changed, so the Java
   can tell a library built from older C and not use it. */
#define DELTAMAPPER_NATIVE_VERSION 13

/* The most features a fit has: 6 neighbours, the previous channel's 3, the
   constant term and the value (m), their products (nt), the unknowns (n). */
#define ROWFIT_SPATIAL 6
#define ROWFIT_M_MAX   (ROWFIT_SPATIAL + 3 + 2)
#define ROWFIT_NT_MAX  (ROWFIT_M_MAX * (ROWFIT_M_MAX + 1) / 2)
#define ROWFIT_N_MAX   (ROWFIT_SPATIAL + 3 + 1)

/* How many points are solved side by side (DeltaMapper.c). */
#define ROWFIT_LANES   8

/* DeltaMapper.RowFit: a channel's fit from the rows above. */
typedef struct RowFit
{
	const int32_t *v, *ref;    /* the channel, and the previous one (NULL for the first) */
	int xdim, nf, m, nt, n;    /* width; features; with the constant and the value; their products; unknowns */
	int r, every, points;      /* window radius; solved at every every-th pixel; solved points per row */
	int row;                   /* the row the columns are at (-1: none yet) */
	int32_t *col;              /* the window rows' products: product t at column x is col[t * xdim + x] */
	int64_t *wsum, *grp;       /* each point's window sums (wsum[t * points + p]); a row's group sums */
	int32_t *fa, *fd;          /* a row's features (with 1 and the value): feature i at x is fa[i * xdim + x] */
	double *coef[2];           /* each solved point's coefficients, for rows y & 1 */
	unsigned char *valid[2];   /* whether each point could be solved */
} RowFit;

/* RowFit.Work: one task's buffers. */
typedef struct RowFitWork
{
	int32_t za[ROWFIT_M_MAX], zd[ROWFIT_M_MAX];
	int64_t win[ROWFIT_NT_MAX];
	double  a[ROWFIT_N_MAX][ROWFIT_N_MAX], b[ROWFIT_N_MAX], dg[ROWFIT_N_MAX];
} RowFitWork;

/* Time spent in each part of the fit (RowFit_plane, if asked), in seconds. */
typedef struct RowFitTimes { double columns, solves, predictions; } RowFitTimes;

int  RowFit_init(RowFit *f, const int32_t *v, const int32_t *ref, int xdim, int radius, int every);
void RowFit_free(RowFit *f);
void RowFit_start(RowFit *f, int y0);
void RowFit_moveTo(RowFit *f, int y);
void RowFit_addColumns(RowFit *f, int y, int c0, int c1, RowFitWork *w);
void RowFit_solveRow(RowFit *f, int y, RowFitWork *w);
void RowFit_solvePoints(RowFit *f, int y, int p0, int p1, RowFitWork *w);
int  RowFit_predict(const RowFit *f, int y, int x);

/* RowFit.plane: the prediction at each interior pixel (0 elsewhere), in
   bands of rows each started on its own, threads of them at a time (the
   result doesn't depend on threads). times, if not NULL, gets the time in
   each part, summed over the bands (threads 1 for it to mean much).
   Returns 0, or -1 if out of memory. */
int  RowFit_plane(const int32_t *v, const int32_t *ref, int xdim, int ydim, int radius, int every, int16_t *out, int threads, RowFitTimes *times);

/* DeltaMapper.packMixedDeltas: the deltas as ranks, mixed-context coded
   (with the second opinions if opinions), as the bytes the Java returns,
   into a new buffer (*packed, *length bytes; free() it). previous: the np
   channels coded before this one's deltas. Returns 0, or -1 if out of memory. */
int DeltaMapper_packMixedDeltas(const int32_t *delta, const int32_t *values, const int32_t *const *previous, int np,
                                int xdim, int n, int opinions, uint8_t **packed, size_t *length);

/* DeltaMapper.getValuesFromRowFitChannels, for coded bytes that have all
   arrived: decodes a band's channels (1 to 3) at the same time, each a couple
   of rows behind the one before, each with helpers threads (0 to 8) fitting
   the next row a chunk behind its decoder, as RowWave does (with more than
   one, they share the row's chunks; with none, each channel's thread solves
   its rows' fits itself: the same result). coded[i] (length[i]
   bytes): channel i's range-coded bytes; rank_value[i]: the delta value of
   each of its n_symbols[i] ranks; init[i]: its first value. Fills delta[i]
   and value[i] (xdim * ydim each). Returns 0, or -1 if out of memory or a
   thread couldn't start. */
int DeltaMapper_decodeRowFitChannels(int channels, const uint8_t *const *coded, const size_t *length,
                                     const int32_t *const *rank_value, const int *n_symbols,
                                     int xdim, int ydim, const int *init, const int *radius, int every, int helpers,
                                     int32_t **delta, int32_t **value);

/* DeltaMapper.getValuesFromAverageChannels, for coded bytes that have all
   arrived: as DeltaMapper_decodeRowFitChannels, for deltas from the average
   of the pixels left and above (getAverageDeltasFromValues) in place of the
   fit. Each channel is decoded in its own thread, two rows behind the one
   before. Fills delta[i] and value[i] (xdim * ydim each). Returns 0, or -1
   if out of memory or a thread couldn't start. */
int DeltaMapper_decodeAverageChannels(int channels, const uint8_t *const *coded, const size_t *length,
                                      const int32_t *const *rank_value, const int *n_symbols,
                                      int xdim, int ydim, const int *init, int32_t **delta, int32_t **value);

/* Where a channel's deltas come from when DeltaMapper_rebuildRowFitChannels
   isn't given them: fills delta (xdim * ydim) from arg. Returns 0, or -1 if
   it couldn't. */
typedef int (*DeltaSource)(void *arg, int32_t *delta);

/* DeltaMapper.getValuesFromRowFitDeltas: as DeltaMapper_decodeRowFitChannels,
   for deltas that are all known (NativeHuffmanReader's, Huffman decoded): rebuilds
   a band's channels (1 to 3) from delta[i] (delta[i][0] unused; init[i] is
   the first value) at the same time, each a row behind the one before, each
   with helpers threads fitting the next row a chunk behind it. With source
   (else NULL), channel i's thread first fills delta[i] with
   source(source_arg[i], delta[i]): so channel 0 starts while the others'
   deltas are still being made. Fills value[i] (xdim * ydim each). Returns 0,
   or -1 if out of memory, a thread couldn't start or a source failed. */
int DeltaMapper_rebuildRowFitChannels(int channels, int xdim, int ydim, const int *init, const int *radius, int every, int helpers,
                                      DeltaSource source, void *const *source_arg, int32_t **delta, int32_t **value);

/* How DeltaMapper_getPixels resizes (DeltaMapper.RESIZE2 and so on): each
   pixel from the source pixels in rows ra, rb and columns ca, cb, averaged
   at once (ResizeMapper.resize2), or the rows first and then the columns,
   or the columns first (ResizeMapper.resize growing, or shrinking the
   width), rounding at each step. */
#define DELTAMAPPER_RESIZE2               0
#define DELTAMAPPER_RESIZE_ROWS_FIRST     1
#define DELTAMAPPER_RESIZE_COLUMNS_FIRST  2

/* The reader's last steps, in one: adds min[i] to channel c[i] (0 to add
   nothing), rebuilds blue, green and red (getBlueGreenRed, set set_id),
   resizes each from w x h to xdim x ydim (with the maps ca, cb for the
   columns and ra, rb for the rows, as resize says; NULL: no resizing) and
   packs them into pixel (getPixel, masked to 24 bits as a TYPE_INT_RGB
   image stores them), on threads threads. The same image as the Java.
   Returns 0, or -1 if out of memory or the arguments don't fit. */
int DeltaMapper_getPixels(int set_id, const int32_t *const c[3], const int min[3], int w, int h,
                          const int *ca, const int *cb, const int *ra, const int *rb, int resize, int xdim, int ydim,
                          int pixel_shift, int32_t *pixel, int threads);

/* NativeSimpleWriter's Apply, its first steps: each of src (blue, green, red,
   X x Y) resized to w x h (ResizeMapper.resize2, maps ca, cb, ra, rb, or
   NULL) and quantized (quantizeChannel) into q; then getCandidateChannels:
   diff gets blue - green, red - green and red - blue, each less its minimum,
   and min the six channels' minimums. Returns 0, or -1. */
int DeltaMapper_applyQuantize(const int32_t *const src[3], int X, int Y, int w, int h,
                              const int *ca, const int *cb, const int *ra, const int *rb, int shift,
                              int32_t *q[3], int32_t *diff[3], int32_t min[6], int threads);

/* Apply's preview: each of q (w x h) resized back to X x Y (resize2, or
   none), shifted up, moved towards src by correction / 10, packed into pixel
   (masked to 24 bits, as a TYPE_INT_RGB image stores it). Returns 0, or -1. */
int DeltaMapper_applyPreview(const int32_t *const q[3], int w, int h, const int *ca, const int *cb, const int *ra, const int *rb,
                             int X, int Y, int shift, int correction, const int32_t *const src[3], int32_t *pixel, int threads);

/* Save's decode check: 1 if packed (packMixedDeltas' bytes) decodes back to
   delta (with values and the np earlier channels' deltas previous), as
   unpackMixedDeltas would; 0 if not; -1 if out of memory. */
int DeltaMapper_checkMixedDeltas(const uint8_t *packed, size_t length, const int32_t *delta, const int32_t *values,
                                 const int32_t *const *previous, int np, int xdim, int n);

/* A clock in seconds, for timing. */
double DeltaMapper_seconds(void);

#endif
