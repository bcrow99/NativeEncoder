#!/bin/bash
# How NativeWriter and NativeReader's speed grows with bands and cores, on
# one big frame (bench/ScaleBench.java): each coding in 1, 2, 4 ... 64 bands
# (as many as the frame allows), on all the logical processors, then, if the
# machine has more than one a core, again on one logical processor a core,
# then on one processor alone, in 1 and 4 bands only (the single-core times).
# First it records the machine: processor, cores, threads, clock, memory.
#   native/run_scale.sh image [tile quant shift runs]   (default 2 4 3 2)
# Tile 2 makes the frame 2 x 2 copies of the image (scrubjay.jpg, at
# Save's Pixel Resolution 4: 5630 x 4316 coded, enough for 64 bands).
# Results go to the window and to scale_results_<machine>.txt here, to
# send back.
set -e
cd "$(dirname "$0")"
[ -n "$1" ] || { echo "usage: native/run_scale.sh image [tile quant shift runs]"; exit 1; }
IMAGE="$(cd "$(dirname "$1")" && pwd)/$(basename "$1")"
[ -f "$IMAGE" ] || { echo "No image $IMAGE"; exit 1; }
ARGS="${2:-2} ${3:-4} ${4:-3} ${5:-2}"   # tile quant shift runs
command -v javac >/dev/null || { echo "No javac: install a JDK (e.g. sudo apt install openjdk-21-jdk)"; exit 1; }
command -v gcc >/dev/null && command -v make >/dev/null || { echo "No gcc or make: install them (e.g. sudo apt install build-essential)"; exit 1; }
# Java 17 and later warn when a library is loaded unless native access is
# enabled; Java 8 doesn't know the option, so it's only given if accepted.
NA=; java --enable-native-access=ALL-UNNAMED -version >/dev/null 2>&1 && NA=--enable-native-access=ALL-UNNAMED
# The heap: half the memory, at least 2 GB (a 2 x 2 scrubjay needs about 3).
MEM_MB=$(awk '/^MemTotal:/ { print int($2 / 1024) }' /proc/meminfo)
HEAP_MB=$(( MEM_MB / 2 )); [ $HEAP_MB -ge 2048 ] || HEAP_MB=2048
make -s
mkdir -p classes
javac --release 8 -nowarn -Xlint:-options -Xlint:-unchecked -encoding UTF-8 -d classes ../java/src/*.java ../java/bench/*.java
# One logical processor of each core: the first listed for each core.
PHYSICAL=$(lscpu -p=CPU,CORE,SOCKET | grep -v '^#' | awk -F, '!seen[$2 "," $3]++ { printf "%s%s", sep, $1; sep = "," }')
LOGICAL=$(nproc)
CORES=$(echo "$PHYSICAL" | tr ',' '\n' | wc -l)
OUT="scale_results_$(hostname -s).txt"
{
echo "Machine: $(hostname -s), $(uname -sr)"
lscpu | grep -E '^(Model name|Socket\(s\)|Core\(s\) per socket|Thread\(s\) per core|CPU\(s\)|CPU max MHz|CPU MHz|L2 cache|L3 cache):' | sed 's/  */ /g'
echo "Cores: $CORES physical, $LOGICAL logical; memory $MEM_MB MB (Java heap $HEAP_MB MB)"
echo "Java: $(java -version 2>&1 | grep -i version | head -1); gcc: $(gcc -dumpfullversion 2>/dev/null || gcc -dumpversion)"
echo
echo "=== All $LOGICAL logical processors ==="
java $NA -Xmx${HEAP_MB}m -cp classes ScaleBench "$IMAGE" $ARGS
if [ "$CORES" -lt "$LOGICAL" ]; then
	echo
	echo "=== One logical processor a core: $CORES (taskset -c $PHYSICAL) ==="
	taskset -c "$PHYSICAL" java $NA -Xmx${HEAP_MB}m -cp classes ScaleBench "$IMAGE" $ARGS
fi
if [ "$LOGICAL" -gt 1 ]; then
	echo
	echo "=== One processor (taskset -c 0), 1 and 4 bands ==="
	taskset -c 0 java $NA -Xmx${HEAP_MB}m -cp classes ScaleBench "$IMAGE" $ARGS 1,4
fi
} 2>&1 | grep -v "Picked up" | tee "$OUT"
echo
echo "Saved $(pwd)/$OUT"
