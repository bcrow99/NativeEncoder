/* ContextTables.c: the Context tables coding, ContextTables.java's code,
   TablesDecoder and decodeKnown in C (see there for the coding): the same
   bytes from the same deltas, and the same deltas from the same bytes. The
   contexts are DeltaMapper.c's (DeltaMapper_contextRows, and its decoders,
   which call TablesDecoder_next); the tables are written with
   LengthCoding's code lengths. Unlike the Java, which would throw, the
   tables are checked before they're used, so bytes that aren't code's give
   -1 (the Java then decodes them, and says what's wrong). */
#include "ContextTables.h"
#include "DeltaMapper.h"
#include "LengthCoding.h"

#include <string.h>

#include "BlockPool.h"   /* last: the library's malloc and free are the pool's */

/* The contexts: DeltaMapper.c's MixedModels' (ACTIVITY_BUCKETS 12 times
   CROSS_BUCKETS 5, times MIX_OPINION_LEVELS 9: (activity bucket * 5 + cross
   bucket) * 9 + opinion level); merged, without the cross bucket. */
#define CROSS_BUCKETS    5
#define OPINION_LEVELS   9
#define CONTEXTS         (12 * CROSS_BUCKETS * OPINION_LEVELS)
#define MERGED_CONTEXTS  (CONTEXTS / CROSS_BUCKETS)
#define MIN_PRECISION    12
#define MAX_PRECISION    16
#define LEVEL_RANGE      12
#define MAX_LEVEL        (2 * LEVEL_RANGE)

/* ContextTables.WEIGHT: each level's weight, for steps 1 and 2. */
static const int64_t WEIGHT[3][MAX_LEVEL + 1] =
{
	{0},
	{0, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384, 32768},
	{0, 16, 23, 32, 45, 64, 91, 128, 181, 256, 362, 512, 724, 1024, 1448, 2048, 2896, 4096, 5793, 8192, 11585, 16384, 23170, 32768, 46341}
};

static inline int merged(int c) { return c / (CROSS_BUCKETS * OPINION_LEVELS) * OPINION_LEVELS + c % OPINION_LEVELS; }

/* ContextTables.precision. */
static int precision(int symbols)
{
	int bits = MIN_PRECISION;
	while(bits < MAX_PRECISION && (1 << bits) < 2 * symbols) bits++;
	return bits;
}

/* ContextTables.normalize: a context's frequencies (f, n of them) from its levels. */
static void normalize(const uint8_t *level, int n, int steps, int prec, uint32_t *f)
{
	const int64_t *w = WEIGHT[steps];
	int64_t sum = 0, total = (int64_t) 1 << prec, given = 0;
	for(int s = 0; s < n; s++) sum += w[level[s]];
	int big = 0;
	for(int s = 0; s < n; s++)
	{
		f[s] = 0;
		if(level[s] == 0) continue;
		int64_t v = w[level[s]] * total / sum;
		f[s] = (uint32_t) ((v > 1) ? v : 1);
		given += f[s];
		if(f[s] > f[big]) big = s;
	}
	int64_t left = total - given;
	if((int64_t) f[big] + left >= 1) f[big] = (uint32_t) ((int64_t) f[big] + left);
	else
		while(left < 0)
			for(int s = 0; s < n && left < 0; s++)
				if(f[s] > 1) { f[s]--; left++; }
}

/* ContextTables.levels: a context's levels (last + 1 of them) from its counts. */
static void levels(const int32_t *count, int last, int steps, uint8_t *level)
{
	const int64_t *w = WEIGHT[steps];
	int top = LEVEL_RANGE * steps;
	int64_t most = 0;
	for(int s = 0; s <= last; s++) if(count[s] > most) most = count[s];
	for(int s = 0; s <= last; s++)
	{
		level[s] = 0;
		if(count[s] == 0) continue;
		int e = top;
		while(e > 1 && 2 * (int64_t) count[s] * w[top] < (w[e - 1] + w[e]) * most) e--;
		level[s] = (uint8_t) e;
	}
}

/* ContextTables.log2Fixed. */
static int64_t log2_fixed(int64_t f)
{
	int whole = 63 - __builtin_clzll((unsigned long long) f);
	int64_t y = (whole >= 30) ? f >> (whole - 30) : f << (30 - whole), r = (int64_t) whole << 16;
	for(int i = 15; i >= 0; i--)
	{
		y = (y * y) >> 30;
		if(y >= ((int64_t) 1 << 31)) { y >>= 1; r |= (int64_t) 1 << i; }
	}
	return r;
}

/* Writes v (at least 1) in Elias's gamma code (ContextTables.writeGamma). */
static void put_gamma(Writer *w, uint32_t v)
{
	int n = 32 - __builtin_clz(v);
	if(n > 1) put(w, 0, n - 1);
	put(w, v, n);
}

/* ---- The coding ---- */

/* ContextTables.Tables: the tables for counts (contexts by symbols): freq
   gets the frequencies (contexts by symbols), w the tables' bytes; returns
   the coded size in bits times 2^16 (ContextTables.Tables.size), or -1 if
   out of memory. */
static int64_t make_tables(const int32_t *count, int contexts, int symbols, int steps, int prec, uint32_t *freq, Writer *w)
{
	int top = LEVEL_RANGE * steps;
	uint8_t *level = malloc((size_t) contexts * symbols + 1), *chain = malloc((size_t) contexts * symbols + 1);
	int *length = calloc((size_t) contexts, sizeof *length);
	int64_t size = -1;
	if(!level || !chain || !length) goto done;
	memset(freq, 0, (size_t) contexts * symbols * sizeof *freq);
	size_t total = 0;
	for(int c = 0; c < contexts; c++)
	{
		const int32_t *cc = count + (size_t) c * symbols;
		int last = -1;
		for(int s = 0; s < symbols; s++) if(cc[s] > 0) last = s;
		put_gamma(w, (uint32_t) (last + 2));   /* (1: not used) */
		if(last < 0) continue;
		length[c] = last + 1;
		uint8_t *lv = level + total;
		levels(cc, last, steps, lv);
		normalize(lv, last + 1, steps, prec, freq + (size_t) c * symbols);
		/* ContextTables.chain. */
		for(int s = 0, before = top; s <= last; s++)
		{
			chain[total + s] = 0;
			if(lv[s] == 0) continue;
			int diff = lv[s] - before;
			chain[total + s] = (uint8_t) (1 + ((diff >= 0) ? 2 * diff : -2 * diff - 1));
			before = lv[s];
		}
		total += (size_t) last + 1;
	}
	if(LengthCoding_writeLengths(w, chain, total, 2 * top)) goto done;
	finish(w);
	if(w->failed) goto done;
	size = ((int64_t) 8 * (int64_t) w->size) << 16;
	int64_t whole = (int64_t) prec << 16;
	for(int c = 0; c < contexts; c++)
		for(int s = 0; s < length[c]; s++)
		{
			int32_t n = count[(size_t) c * symbols + s];
			if(n > 0) size += n * (whole - log2_fixed(freq[(size_t) c * symbols + s]));
		}
done:
	free(level); free(chain); free(length);
	return size;
}

/* The counting pass: each pixel's symbol counted in each model's context. */
typedef struct
{
	const int32_t *delta, *rank;
	int32_t lo;
	int xdim, symbols;
	int32_t *count[3];   /* each model's counts, by context and symbol */
} Counting;

static void count_row(void *arg, int y, const uint16_t *const *ctx, int m)
{
	Counting *c = arg;
	const int32_t *d = c->delta + (size_t) y * c->xdim;
	for(int x = 0; x < c->xdim; x++)
	{
		int s = c->rank[d[x] - c->lo];
		for(int j = 0; j < m; j++) c->count[j][(size_t) ctx[j][x] * c->symbols + s]++;
	}
}

/* The second pass: the chosen model's contexts kept. */
typedef struct
{
	int xdim, model, merged;
	uint16_t *ctx;
} Keeping;

static void keep_row(void *arg, int y, const uint16_t *const *ctx, int m)
{
	(void) m;
	Keeping *k = arg;
	uint16_t *out = k->ctx + (size_t) y * k->xdim;
	for(int x = 0; x < k->xdim; x++) out[x] = (uint16_t) (k->merged ? merged(ctx[k->model][x]) : ctx[k->model][x]);
}

static void put32(uint8_t *p, uint32_t v) { p[0] = (uint8_t) (v >> 24); p[1] = (uint8_t) (v >> 16); p[2] = (uint8_t) (v >> 8); p[3] = (uint8_t) v; }

int ContextTables_code(const int32_t *delta, const int32_t *values, const int32_t *const *previous, int np, int xdim, int n,
                       uint8_t **packed, size_t *length)
{
	*packed = NULL; *length = 0;
	if(n <= 0 || xdim <= 0 || n % xdim != 0 || np < 0 || np > 2) return -1;
	int32_t lo;
	int symbols, m = (np > 0) ? 3 : 2, result = -1;
	int32_t *rank = DeltaMapper_rankTable(delta, n, &lo, &symbols);
	if(!rank) return -1;
	int prec = precision(symbols);
	Counting cn = { delta, rank, lo, xdim, symbols, { NULL } };
	int32_t *merged_count = NULL;
	uint32_t *freq = NULL, *best_freq = NULL, *cum = NULL;
	uint16_t *ctx = NULL;
	uint8_t *buf = NULL, *out = NULL;
	Writer w = {0}, best = {0};
	for(int j = 0; j < m; j++) if(!(cn.count[j] = calloc((size_t) CONTEXTS * symbols, sizeof *cn.count[j]))) goto done;
	merged_count = malloc((size_t) MERGED_CONTEXTS * symbols * sizeof *merged_count);
	freq = malloc((size_t) CONTEXTS * symbols * sizeof *freq);
	best_freq = malloc((size_t) CONTEXTS * symbols * sizeof *best_freq);
	if(!merged_count || !freq || !best_freq) goto done;
	if(DeltaMapper_contextRows(delta, values, previous, np, xdim, n, count_row, &cn)) goto done;

	/* The smallest: each model, merged or not, and steps, in that order. */
	int model = 0, merge = 0, steps = 1;
	int64_t smallest = INT64_MAX;
	for(int j = 0; j < m; j++)
		for(int g = 0; g <= 1; g++)
		{
			const int32_t *count = cn.count[j];
			int contexts = CONTEXTS;
			if(g == 1)
			{
				memset(merged_count, 0, (size_t) MERGED_CONTEXTS * symbols * sizeof *merged_count);
				for(int c = 0; c < CONTEXTS; c++)
					for(int s = 0; s < symbols; s++) merged_count[(size_t) merged(c) * symbols + s] += count[(size_t) c * symbols + s];
				count = merged_count; contexts = MERGED_CONTEXTS;
			}
			for(int st = 1; st <= 2; st++)
			{
				w.size = 0; w.count = 0; w.bits = 0;
				if(!w.buffer) { w.capacity = 4096; if(!(w.buffer = malloc(w.capacity))) goto done; }
				int64_t size = make_tables(count, contexts, symbols, st, prec, freq, &w);
				if(size < 0) goto done;
				if(size < smallest)
				{
					smallest = size; model = j; merge = g; steps = st;
					uint32_t *t = best_freq; best_freq = freq; freq = t;
					Writer t2 = best; best = w; w = t2;
				}
			}
		}

	/* The chosen model's contexts again (kept), then the coding, from the
	   last. */
	ctx = malloc((size_t) n * sizeof *ctx);
	cum = malloc((size_t) CONTEXTS * symbols * sizeof *cum);
	size_t cap = 2 * (size_t) n + 16;
	buf = malloc(cap);
	if(!ctx || !cum || !buf) goto done;
	Keeping kp = { xdim, model, merge, ctx };
	if(DeltaMapper_contextRows(delta, values, previous, np, xdim, n, keep_row, &kp)) goto done;
	int contexts = merge ? MERGED_CONTEXTS : CONTEXTS;
	for(int c = 0; c < contexts; c++)
	{
		uint32_t t = 0;
		for(int s = 0; s < symbols; s++) { cum[(size_t) c * symbols + s] = t; t += best_freq[(size_t) c * symbols + s]; }
	}
	uint8_t *p = buf + cap;
	uint32_t x = CONTEXTTABLES_RANS_LOW;
	for(int k = n - 1; k >= 0; k--)
	{
		size_t at = (size_t) ctx[k] * symbols + (size_t) rank[delta[k] - lo];
		uint32_t f = best_freq[at];
		uint32_t x_max = ((CONTEXTTABLES_RANS_LOW >> prec) << 8) * f;
		while(x >= x_max) { *--p = (uint8_t) x; x >>= 8; }
		x = ((x / f) << prec) + (x % f) + cum[at];
	}
	for(int b = 3; b >= 0; b--) *--p = (uint8_t) (x >> (8 * b));
	size_t coded = (size_t) (buf + cap - p);

	/* As the Java writes it (big-endian): the minimum, the rank table
	   (writeTable), the model, merged, steps, precision, the tables' length
	   and bytes, the coded length and bytes. */
	size_t table = 2 + (size_t) symbols * ((symbols <= 255) ? 1 : 2);
	size_t total = 4 + table + 4 + 4 + best.size + 4 + coded;
	out = malloc(total);
	if(!out) goto done;
	uint8_t *o = out;
	put32(o, (uint32_t) lo); o += 4;
	*o++ = (uint8_t) (symbols >> 8); *o++ = (uint8_t) symbols;
	for(int v = 0; v < symbols; v++)
	{
		if(symbols <= 255) *o++ = (uint8_t) rank[v];
		else { *o++ = (uint8_t) (rank[v] >> 8); *o++ = (uint8_t) rank[v]; }
	}
	*o++ = (uint8_t) model; *o++ = (uint8_t) merge; *o++ = (uint8_t) steps; *o++ = (uint8_t) prec;
	put32(o, (uint32_t) best.size); o += 4;
	memcpy(o, best.buffer, best.size); o += best.size;
	put32(o, (uint32_t) coded); o += 4;
	memcpy(o, p, coded);
	*packed = out; *length = total;
	out = NULL;
	result = 0;
done:
	for(int j = 0; j < 3; j++) free(cn.count[j]);
	free(merged_count); free(freq); free(best_freq); free(cum); free(ctx); free(buf); free(out);
	free(w.buffer); free(best.buffer);
	free(rank);
	return result;
}

/* ---- The decoding ---- */

TablesDecoder *ContextTables_decoder(const uint8_t *tables, size_t tables_length, int model, int merged_, int steps, int prec,
                                     const int32_t *value, int symbols, const uint8_t *code, size_t code_length)
{
	if(model < 0 || model > 2 || merged_ < 0 || merged_ > 1 || steps < 1 || steps > 2 || prec < MIN_PRECISION || prec > MAX_PRECISION
	   || symbols < 1 || code_length < 4) return NULL;
	int contexts = merged_ ? MERGED_CONTEXTS : CONTEXTS, top = LEVEL_RANGE * steps;
	TablesDecoder *t = calloc(1, sizeof *t);
	int *length = calloc((size_t) contexts, sizeof *length), *row = malloc((size_t) contexts * sizeof *row);
	uint8_t *all = NULL;
	int ok = 0;
	if(!t || !length || !row) goto done;
	t->model = model; t->precision = prec; t->symbols = symbols;
	Bits b = { tables, tables_length, 0, 0, 0, 0 };
	size_t total = 0;
	int used = 0;
	for(int c = 0; c < contexts; c++)
	{
		int n = 1;
		while(read_bits(&b, 1) == 0) if(++n > 24) goto done;
		uint32_t v = (n == 1) ? 1 : ((1u << (n - 1)) | read_bits(&b, n - 1));
		length[c] = (int) v - 1;
		if(length[c] > symbols) goto done;
		row[c] = (length[c] > 0) ? used++ : -1;
		total += (size_t) length[c];
	}
	all = malloc(total + 1);
	if(!all || LengthCoding_readLengths(&b, all, total, 2 * top) || overrun(&b)) goto done;
	size_t rows = (size_t) (used > 0 ? used : 1);
	t->freq   = calloc(rows * symbols, sizeof *t->freq);
	t->cum    = calloc(rows * symbols, sizeof *t->cum);
	t->lookup = malloc((rows << prec) * sizeof *t->lookup);
	t->value  = malloc((size_t) symbols * sizeof *t->value);
	t->slot   = malloc((size_t) CONTEXTS * sizeof *t->slot);
	if(!t->freq || !t->cum || !t->lookup || !t->value || !t->slot) goto done;
	memcpy(t->value, value, (size_t) symbols * sizeof *t->value);
	size_t at = 0;
	for(int c = 0; c < contexts; c++)
	{
		if(length[c] == 0) continue;
		/* ContextTables.unchain. */
		uint8_t *lv = all + at;
		for(int s = 0, before = top; s < length[c]; s++)
		{
			if(lv[s] == 0) continue;
			int z = lv[s] - 1, e = before + (((z & 1) == 0) ? z / 2 : -(z + 1) / 2);
			if(e < 1 || e > top) goto done;
			lv[s] = (uint8_t) e; before = e;
		}
		if(lv[length[c] - 1] == 0) goto done;
		size_t r = (size_t) row[c];
		uint32_t *f = t->freq + r * symbols, *cu = t->cum + r * symbols;
		uint16_t *look = t->lookup + (r << prec);
		normalize(lv, length[c], steps, prec, f);
		uint32_t sum = 0;
		for(int s = 0; s < length[c]; s++)
		{
			cu[s] = sum;
			for(uint32_t i = 0; i < f[s]; i++) look[sum + i] = (uint16_t) s;
			sum += f[s];
		}
		at += (size_t) length[c];
	}
	for(int c = 0; c < CONTEXTS; c++) t->slot[c] = row[merged_ ? merged(c) : c];
	t->code = code; t->length = code_length;
	t->x = (uint32_t) code[0] | ((uint32_t) code[1] << 8) | ((uint32_t) code[2] << 16) | ((uint32_t) code[3] << 24);
	t->at = 4;
	ok = 1;
done:
	free(length); free(row); free(all);
	if(!ok) { ContextTables_free(t); return NULL; }
	return t;
}

int ContextTables_finish(const TablesDecoder *t)
{
	return (t->failed || t->at != t->length || t->x != CONTEXTTABLES_RANS_LOW) ? -1 : 0;
}

void ContextTables_free(TablesDecoder *t)
{
	if(!t) return;
	free(t->slot); free(t->freq); free(t->cum); free(t->lookup); free(t->value);
	free(t);
}

/* The check's pass: each delta decoded from its context (the values known)
   and compared. */
typedef struct
{
	TablesDecoder *t;
	const int32_t *delta;
	int xdim, same;
} Checking;

static void check_row(void *arg, int y, const uint16_t *const *ctx, int m)
{
	(void) m;
	Checking *ch = arg;
	const int32_t *d = ch->delta + (size_t) y * ch->xdim;
	for(int x = 0; x < ch->xdim; x++) if(TablesDecoder_next(ch->t, ctx[ch->t->model][x]) != d[x]) ch->same = 0;
}

static uint32_t get32(const uint8_t *p) { return ((uint32_t) p[0] << 24) | ((uint32_t) p[1] << 16) | ((uint32_t) p[2] << 8) | p[3]; }

int ContextTables_check(const uint8_t *packed, size_t length, const int32_t *delta, const int32_t *values,
                        const int32_t *const *previous, int np, int xdim, int n)
{
	/* code's layout (see ContextTables_code). */
	if(length < 6) return 0;
	int32_t lo = (int32_t) get32(packed);
	int symbols = (packed[4] << 8) | packed[5];
	size_t pos = 6 + (size_t) symbols * ((symbols <= 255) ? 1 : 2);
	if(symbols < 1 || pos + 8 > length) return 0;
	int32_t *value = malloc((size_t) symbols * sizeof *value);
	if(!value) return -1;
	for(int v = 0; v < symbols; v++)
	{
		int r = (symbols <= 255) ? packed[6 + v] : ((packed[6 + 2 * v] << 8) | packed[7 + 2 * v]);
		if(r >= symbols) { free(value); return 0; }
		value[r] = v + lo;
	}
	int model = packed[pos], merge = packed[pos + 1], steps = packed[pos + 2], prec = packed[pos + 3];
	size_t tables = get32(packed + pos + 4);
	pos += 8;
	if(pos + tables + 4 > length) { free(value); return 0; }
	const uint8_t *table_bytes = packed + pos;
	pos += tables;
	size_t coded = get32(packed + pos);
	pos += 4;
	if(pos + coded != length) { free(value); return 0; }
	TablesDecoder *t = ContextTables_decoder(table_bytes, tables, model, merge, steps, prec, value, symbols, packed + pos, coded);
	free(value);
	if(!t) return 0;
	Checking ch = { t, delta, xdim, 1 };
	int result = DeltaMapper_contextRows(delta, values, previous, np, xdim, n, check_row, &ch) ? -1
	             : (ch.same && ContextTables_finish(t) == 0) ? 1 : 0;
	ContextTables_free(t);
	return result;
}
