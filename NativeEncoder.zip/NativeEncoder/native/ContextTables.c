/* ContextTables.c: the Context tables coding, ContextTables.java's code,
   TablesDecoder, average and decodeKnown in C (see there for the coding):
   the same bytes from the same deltas, and the same deltas from the same
   bytes. Version 2's contexts are the channel's own
   (ContextTables_ownContext); version 1's, decoded only, DeltaMapper.c's
   (its decoders, which call TablesDecoder_next). The tables are written
   with LengthCoding's code lengths. Unlike the Java, which would throw, the
   tables are checked before they're used, so bytes that aren't code's give
   -1 (the Java then decodes them, and says what's wrong). */
#include "ContextTables.h"
#include "DeltaMapper.h"
#include "LengthCoding.h"

#include <string.h>

#include "BlockPool.h"   /* last: the library's malloc and free are the pool's */

/* The contexts: version 2's, the channel's own (activity bucket * 9 +
   opinion level); version 1's, DeltaMapper.c's MixedModels' (ACTIVITY_BUCKETS
   12 times CROSS_BUCKETS 5, times MIX_OPINION_LEVELS 9: (activity bucket * 5
   + cross bucket) * 9 + opinion level), merged without the cross bucket. */
#define CROSS_BUCKETS    5
#define OPINION_LEVELS   9
#define OWN_CONTEXTS     (12 * OPINION_LEVELS)
#define CONTEXTS         (12 * CROSS_BUCKETS * OPINION_LEVELS)
#define MERGED_CONTEXTS  (CONTEXTS / CROSS_BUCKETS)
#define MIN_PRECISION    12
#define MAX_PRECISION    16
#define LEVEL_RANGE      12
#define MAX_LEVEL        (2 * LEVEL_RANGE)

/* ContextTables.WEIGHT: each level's weight, for steps 1 and 2. */
static const int64_t WEIGHT[3][MAX_LEVEL + 1] =
{
	{0},
	{0, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384, 32768},
	{0, 16, 23, 32, 45, 64, 91, 128, 181, 256, 362, 512, 724, 1024, 1448, 2048, 2896, 4096, 5793, 8192, 11585, 16384, 23170, 32768, 46341}
};

static inline int merged(int c) { return c / (CROSS_BUCKETS * OPINION_LEVELS) * OPINION_LEVELS + c % OPINION_LEVELS; }

/* ContextTables.precision. */
static int precision(int symbols)
{
	int bits = MIN_PRECISION;
	while(bits < MAX_PRECISION && (1 << bits) < 2 * symbols) bits++;
	return bits;
}

/* ContextTables.normalize: a context's frequencies (f, n of them) from its levels. */
static void normalize(const uint8_t *level, int n, int steps, int prec, uint32_t *f)
{
	const int64_t *w = WEIGHT[steps];
	int64_t sum = 0, total = (int64_t) 1 << prec, given = 0;
	for(int s = 0; s < n; s++) sum += w[level[s]];
	int big = 0;
	for(int s = 0; s < n; s++)
	{
		f[s] = 0;
		if(level[s] == 0) continue;
		int64_t v = w[level[s]] * total / sum;
		f[s] = (uint32_t) ((v > 1) ? v : 1);
		given += f[s];
		if(f[s] > f[big]) big = s;
	}
	int64_t left = total - given;
	if((int64_t) f[big] + left >= 1) f[big] = (uint32_t) ((int64_t) f[big] + left);
	else
		while(left < 0)
			for(int s = 0; s < n && left < 0; s++)
				if(f[s] > 1) { f[s]--; left++; }
}

/* ContextTables.levels: a context's levels (last + 1 of them) from its counts. */
static void levels(const int32_t *count, int last, int steps, uint8_t *level)
{
	const int64_t *w = WEIGHT[steps];
	int top = LEVEL_RANGE * steps;
	int64_t most = 0;
	for(int s = 0; s <= last; s++) if(count[s] > most) most = count[s];
	for(int s = 0; s <= last; s++)
	{
		level[s] = 0;
		if(count[s] == 0) continue;
		int e = top;
		while(e > 1 && 2 * (int64_t) count[s] * w[top] < (w[e - 1] + w[e]) * most) e--;
		level[s] = (uint8_t) e;
	}
}

/* ContextTables.log2Fixed. */
static int64_t log2_fixed(int64_t f)
{
	int whole = 63 - __builtin_clzll((unsigned long long) f);
	int64_t y = (whole >= 30) ? f >> (whole - 30) : f << (30 - whole), r = (int64_t) whole << 16;
	for(int i = 15; i >= 0; i--)
	{
		y = (y * y) >> 30;
		if(y >= ((int64_t) 1 << 31)) { y >>= 1; r |= (int64_t) 1 << i; }
	}
	return r;
}

/* Writes v (at least 1) in Elias's gamma code (ContextTables.writeGamma). */
static void put_gamma(Writer *w, uint32_t v)
{
	int n = 32 - __builtin_clz(v);
	if(n > 1) put(w, 0, n - 1);
	put(w, v, n);
}

/* ---- The coding ---- */

/* ContextTables.Tables: the tables for counts (contexts by symbols): freq
   gets the frequencies (contexts by symbols), w the tables' bytes; returns
   the coded size in bits times 2^16 (ContextTables.Tables.size), or -1 if
   out of memory. */
static int64_t make_tables(const int32_t *count, int contexts, int symbols, int steps, int prec, uint32_t *freq, Writer *w)
{
	int top = LEVEL_RANGE * steps;
	uint8_t *level = malloc((size_t) contexts * symbols + 1), *chain = malloc((size_t) contexts * symbols + 1);
	int *length = calloc((size_t) contexts, sizeof *length);
	int64_t size = -1;
	if(!level || !chain || !length) goto done;
	memset(freq, 0, (size_t) contexts * symbols * sizeof *freq);
	size_t total = 0;
	for(int c = 0; c < contexts; c++)
	{
		const int32_t *cc = count + (size_t) c * symbols;
		int last = -1;
		for(int s = 0; s < symbols; s++) if(cc[s] > 0) last = s;
		put_gamma(w, (uint32_t) (last + 2));   /* (1: not used) */
		if(last < 0) continue;
		length[c] = last + 1;
		uint8_t *lv = level + total;
		levels(cc, last, steps, lv);
		normalize(lv, last + 1, steps, prec, freq + (size_t) c * symbols);
		/* ContextTables.chain. */
		for(int s = 0, before = top; s <= last; s++)
		{
			chain[total + s] = 0;
			if(lv[s] == 0) continue;
			int diff = lv[s] - before;
			chain[total + s] = (uint8_t) (1 + ((diff >= 0) ? 2 * diff : -2 * diff - 1));
			before = lv[s];
		}
		total += (size_t) last + 1;
	}
	if(LengthCoding_writeLengths(w, chain, total, 2 * top)) goto done;
	finish(w);
	if(w->failed) goto done;
	size = ((int64_t) 8 * (int64_t) w->size) << 16;
	int64_t whole = (int64_t) prec << 16;
	for(int c = 0; c < contexts; c++)
		for(int s = 0; s < length[c]; s++)
		{
			int32_t n = count[(size_t) c * symbols + s];
			if(n > 0) size += n * (whole - log2_fixed(freq[(size_t) c * symbols + s]));
		}
done:
	free(level); free(chain); free(length);
	return size;
}

static void put32(uint8_t *p, uint32_t v) { p[0] = (uint8_t) (v >> 24); p[1] = (uint8_t) (v >> 16); p[2] = (uint8_t) (v >> 8); p[3] = (uint8_t) v; }

int ContextTables_code(const int32_t *delta, const int32_t *values, int xdim, int n, uint8_t **packed, size_t *length)
{
	*packed = NULL; *length = 0;
	if(n <= 0 || xdim <= 0 || n % xdim != 0) return -1;
	int32_t lo;
	int symbols, result = -1;
	int32_t *rank = DeltaMapper_rankTable(delta, n, &lo, &symbols);
	if(!rank) return -1;
	int prec = precision(symbols);
	int32_t *count = calloc((size_t) OWN_CONTEXTS * symbols, sizeof *count);
	uint32_t *freq = malloc((size_t) OWN_CONTEXTS * symbols * sizeof *freq), *best_freq = malloc((size_t) OWN_CONTEXTS * symbols * sizeof *best_freq), *cum = NULL;
	uint8_t *ctx = malloc((size_t) n), *buf = NULL, *out = NULL;
	Writer w = {0}, best = {0};
	if(!count || !freq || !best_freq || !ctx) goto done;

	/* The contexts (each pixel's own, from the values and the predictions,
	   value - delta) and the counts. */
	for(int y = 0, k = 0; k < n; y++)
		for(int x = 0; x < xdim; x++, k++)
		{
			ctx[k] = (uint8_t) ContextTables_ownContext(delta, values, k, x, y, xdim, values[k] - delta[k]);
			count[(size_t) ctx[k] * symbols + rank[delta[k] - lo]]++;
		}

	/* The smaller: steps 1 or 2. */
	int steps = 1;
	int64_t smallest = INT64_MAX;
	for(int st = 1; st <= 2; st++)
	{
		w.size = 0; w.count = 0; w.bits = 0;
		if(!w.buffer) { w.capacity = 4096; if(!(w.buffer = malloc(w.capacity))) goto done; }
		int64_t size = make_tables(count, OWN_CONTEXTS, symbols, st, prec, freq, &w);
		if(size < 0) goto done;
		if(size < smallest)
		{
			smallest = size; steps = st;
			uint32_t *t = best_freq; best_freq = freq; freq = t;
			Writer t2 = best; best = w; w = t2;
		}
	}

	/* The coding, from the last. */
	cum = malloc((size_t) OWN_CONTEXTS * symbols * sizeof *cum);
	size_t cap = 2 * (size_t) n + 16;
	buf = malloc(cap);
	if(!cum || !buf) goto done;
	for(int c = 0; c < OWN_CONTEXTS; c++)
	{
		uint32_t t = 0;
		for(int s = 0; s < symbols; s++) { cum[(size_t) c * symbols + s] = t; t += best_freq[(size_t) c * symbols + s]; }
	}
	uint8_t *p = buf + cap;
	uint32_t x = CONTEXTTABLES_RANS_LOW;
	for(int k = n - 1; k >= 0; k--)
	{
		size_t at = (size_t) ctx[k] * symbols + (size_t) rank[delta[k] - lo];
		uint32_t f = best_freq[at];
		uint32_t x_max = ((CONTEXTTABLES_RANS_LOW >> prec) << 8) * f;
		while(x >= x_max) { *--p = (uint8_t) x; x >>= 8; }
		x = ((x / f) << prec) + (x % f) + cum[at];
	}
	for(int b = 3; b >= 0; b--) *--p = (uint8_t) (x >> (8 * b));
	size_t coded = (size_t) (buf + cap - p);

	/* As the Java writes it (big-endian): the minimum, the rank table
	   (writeTable), the model (own), merged (0), steps, precision, the
	   tables' length and bytes, the coded length and bytes. */
	size_t table = 2 + (size_t) symbols * ((symbols <= 255) ? 1 : 2);
	size_t total = 4 + table + 4 + 4 + best.size + 4 + coded;
	out = malloc(total);
	if(!out) goto done;
	uint8_t *o = out;
	put32(o, (uint32_t) lo); o += 4;
	*o++ = (uint8_t) (symbols >> 8); *o++ = (uint8_t) symbols;
	for(int v = 0; v < symbols; v++)
	{
		if(symbols <= 255) *o++ = (uint8_t) rank[v];
		else { *o++ = (uint8_t) (rank[v] >> 8); *o++ = (uint8_t) rank[v]; }
	}
	*o++ = (uint8_t) CONTEXTTABLES_OWN; *o++ = 0; *o++ = (uint8_t) steps; *o++ = (uint8_t) prec;
	put32(o, (uint32_t) best.size); o += 4;
	memcpy(o, best.buffer, best.size); o += best.size;
	put32(o, (uint32_t) coded); o += 4;
	memcpy(o, p, coded);
	*packed = out; *length = total;
	out = NULL;
	result = 0;
done:
	free(count); free(freq); free(best_freq); free(cum); free(ctx); free(buf); free(out);
	free(w.buffer); free(best.buffer);
	free(rank);
	return result;
}

/* ---- The decoding ---- */

TablesDecoder *ContextTables_decoder(const uint8_t *tables, size_t tables_length, int model, int merged_, int steps, int prec,
                                     const int32_t *value, int symbols, const uint8_t *code, size_t code_length, int xdim)
{
	int own = model == CONTEXTTABLES_OWN;
	if(model < 0 || model > CONTEXTTABLES_OWN || merged_ < 0 || merged_ > (own ? 0 : 1) || xdim < 1 || steps < 1 || steps > 2 || prec < MIN_PRECISION || prec > MAX_PRECISION
	   || symbols < 1 || code_length < 4) return NULL;
	int contexts = own ? OWN_CONTEXTS : merged_ ? MERGED_CONTEXTS : CONTEXTS, top = LEVEL_RANGE * steps;
	TablesDecoder *t = calloc(1, sizeof *t);
	int *length = calloc((size_t) contexts, sizeof *length), *row = malloc((size_t) contexts * sizeof *row);
	uint8_t *all = NULL;
	int ok = 0;
	if(!t || !length || !row) goto done;
	t->model = model; t->precision = prec; t->symbols = symbols; t->xdim = xdim;
	Bits b = { tables, tables_length, 0, 0, 0, 0 };
	size_t total = 0;
	int used = 0;
	for(int c = 0; c < contexts; c++)
	{
		int n = 1;
		while(read_bits(&b, 1) == 0) if(++n > 24) goto done;
		uint32_t v = (n == 1) ? 1 : ((1u << (n - 1)) | read_bits(&b, n - 1));
		length[c] = (int) v - 1;
		if(length[c] > symbols) goto done;
		row[c] = (length[c] > 0) ? used++ : -1;
		total += (size_t) length[c];
	}
	all = malloc(total + 1);
	if(!all || LengthCoding_readLengths(&b, all, total, 2 * top) || overrun(&b)) goto done;
	int fits = own && symbols <= 256 && prec <= 13;
	for(int s = 0; s < symbols && fits; s++) fits = value[s] >= INT16_MIN && value[s] <= INT16_MAX;
	if(fits)
	{   /* Version 2's own_ tables (see TablesDecoder), the contexts with no table one symbol's. */
		t->own_symbol = calloc((size_t) OWN_CONTEXTS << prec, sizeof *t->own_symbol);
		t->own_value  = malloc(((size_t) OWN_CONTEXTS << prec) * sizeof *t->own_value);
		t->own_freq   = calloc((size_t) OWN_CONTEXTS * symbols, sizeof *t->own_freq);
		t->own_cum    = calloc((size_t) OWN_CONTEXTS * symbols, sizeof *t->own_cum);
		if(!t->own_symbol || !t->own_value || !t->own_freq || !t->own_cum) goto done;
	}
	size_t rows = (size_t) (used > 0 ? used : 1);
	t->freq   = calloc(rows * symbols, sizeof *t->freq);
	t->cum    = calloc(rows * symbols, sizeof *t->cum);
	t->lookup = fits ? NULL : malloc((rows << prec) * sizeof *t->lookup);   /* (the own_ tables in its place) */
	t->value  = malloc((size_t) symbols * sizeof *t->value);
	t->slot   = malloc((size_t) CONTEXTS * sizeof *t->slot);
	if(!t->freq || !t->cum || (!fits && !t->lookup) || !t->value || !t->slot) goto done;
	memcpy(t->value, value, (size_t) symbols * sizeof *t->value);
	size_t at = 0;
	for(int c = 0; c < contexts; c++)
	{
		if(length[c] == 0) continue;
		/* ContextTables.unchain. */
		uint8_t *lv = all + at;
		for(int s = 0, before = top; s < length[c]; s++)
		{
			if(lv[s] == 0) continue;
			int z = lv[s] - 1, e = before + (((z & 1) == 0) ? z / 2 : -(z + 1) / 2);
			if(e < 1 || e > top) goto done;
			lv[s] = (uint8_t) e; before = e;
		}
		if(lv[length[c] - 1] == 0) goto done;
		size_t r = (size_t) row[c];
		uint32_t *f = t->freq + r * symbols, *cu = t->cum + r * symbols;
		normalize(lv, length[c], steps, prec, f);
		uint32_t sum = 0;
		for(int s = 0; s < length[c]; s++)
		{
			cu[s] = sum;
			if(fits)
			{
				uint8_t *sy = t->own_symbol + ((size_t) c << prec) + sum;
				int16_t *va = t->own_value + ((size_t) c << prec) + sum;
				for(uint32_t i = 0; i < f[s]; i++) { sy[i] = (uint8_t) s; va[i] = (int16_t) value[s]; }
			}
			else
				for(uint32_t i = 0; i < f[s]; i++) t->lookup[(r << prec) + sum + i] = (uint16_t) s;
			sum += f[s];
		}
		if(fits)
		{
			memcpy(t->own_freq + (size_t) c * symbols, f, (size_t) symbols * sizeof *f);
			memcpy(t->own_cum + (size_t) c * symbols, cu, (size_t) symbols * sizeof *cu);
		}
		at += (size_t) length[c];
	}
	if(fits)
		for(int c = 0; c < OWN_CONTEXTS; c++)
			if(length[c] == 0)
			{
				t->own_bad[c] = 1;
				t->own_freq[(size_t) c * symbols] = 1u << prec;   /* (symbol 0 alone: own_symbol 0, own_cum 0) */
				for(size_t i = 0; i < ((size_t) 1 << prec); i++) t->own_value[((size_t) c << prec) + i] = 0;
			}
	for(int c = 0; c < CONTEXTS; c++) t->slot[c] = own ? ((c < OWN_CONTEXTS) ? row[c] : -1) : row[merged_ ? merged(c) : c];
	t->code = code; t->length = code_length;
	t->x = (uint32_t) code[0] | ((uint32_t) code[1] << 8) | ((uint32_t) code[2] << 16) | ((uint32_t) code[3] << 24);
	t->at = 4;
	ok = 1;
done:
	free(length); free(row); free(all);
	if(!ok) { ContextTables_free(t); return NULL; }
	return t;
}

int ContextTables_finish(const TablesDecoder *t)
{
	return (t->failed || t->at != t->length || t->x != CONTEXTTABLES_RANS_LOW) ? -1 : 0;
}

void ContextTables_free(TablesDecoder *t)
{
	if(!t) return;
	free(t->slot); free(t->freq); free(t->cum); free(t->lookup); free(t->value);
	free(t->own_symbol); free(t->own_value); free(t->own_freq); free(t->own_cum);
	free(t);
}

int ContextTables_pixel(void *arg, int k, int32_t *delta, const int32_t *value, int prediction)
{
	TablesDecoder *t = arg;
	int c = ContextTables_ownContext(delta, value, k, t->column, t->row, t->xdim, prediction);
	delta[k] = t->own_symbol ? TablesDecoder_nextOwn(t, c) : TablesDecoder_next(t, c);
	if(++t->column == t->xdim) { t->column = 0; t->row++; }
	return t->failed ? -1 : 0;
}

/* ContextTables_average with the own_ tables: the decoder's state in locals
   (not written back after each delta, as it would be through t, since the
   stores to the deltas and values could be to it), the interior's context
   worked out from the left value and delta carried in locals. */
static int average_own(TablesDecoder *t, int xdim, int ydim, int init, int32_t *restrict d, int32_t *restrict v)
{
	const uint8_t  *restrict symbol = t->own_symbol;
	const int16_t  *restrict val    = t->own_value;
	const uint32_t *restrict freq   = t->own_freq, *restrict cum = t->own_cum;
	const uint8_t  *restrict bad    = t->own_bad, *restrict code = t->code;
	int prec = t->precision, failed = 0;
	size_t symbols = (size_t) t->symbols, length = t->length, at = t->at;
	uint32_t mask = (1u << prec) - 1, x = t->x;
	/* The delta whose context is C into OUT (TablesDecoder_nextOwn). */
#define NEXT_OWN(C, OUT) do { int c_ = (C); failed |= bad[c_]; uint32_t low_ = x & mask; \
		size_t i_ = ((size_t) c_ << prec) + low_, a_ = (size_t) c_ * symbols + symbol[i_]; \
		x = freq[a_] * (x >> prec) + low_ - cum[a_]; \
		while(x < CONTEXTTABLES_RANS_LOW) x = (x << 8) | ((at < length) ? code[at++] : 0); \
		OUT = val[i_]; } while(0)
	NEXT_OWN(ContextTables_ownContext(d, v, 0, 0, 0, xdim, init), d[0]);
	v[0] = init;
	for(int c = 1; c < xdim; c++)
	{
		NEXT_OWN(ContextTables_ownContext(d, v, c, c, 0, xdim, v[c - 1]), d[c]);
		v[c] = v[c - 1] + d[c];
	}
	for(int y = 1, k = xdim; y < ydim; y++)
	{
		NEXT_OWN(ContextTables_ownContext(d, v, k, 0, y, xdim, v[k - xdim]), d[k]);
		v[k] = v[k - xdim] + d[k];
		k++;
		int c = 1;
		int32_t W = v[k - 1], dW = d[k - 1];
		for(; c < xdim - 1; c++, k++)
		{
			int32_t N = v[k - xdim], p = (W + N) / 2, dk;
			int a = ContextTables_abs(dW) + ContextTables_abs(d[k - xdim]) + ContextTables_abs(d[k - xdim - 1]) + ContextTables_abs(d[k - xdim + 1]);
			NEXT_OWN(activity_table[(a < 255) ? a : 255] * 9 + gradientLevel(med(W, N, v[k - xdim - 1]) - p) + 4, dk);
			d[k] = dW = dk;
			v[k] = W = p + dk;
		}
		if(c < xdim)
		{
			int32_t p = (v[k - 1] + v[k - xdim]) / 2;
			NEXT_OWN(ContextTables_ownContext(d, v, k, c, y, xdim, p), d[k]);
			v[k] = p + d[k];
			k++;
		}
	}
#undef NEXT_OWN
	t->x = x; t->at = at; t->failed |= failed;
	return ContextTables_finish(t);
}

int ContextTables_average(TablesDecoder *t, int xdim, int ydim, int init, int32_t *delta, int32_t *value)
{
	if(t->own_symbol) return average_own(t, xdim, ydim, init, delta, value);
	int32_t *d = delta, *v = value;
	/* Row 0, from the left. */
	d[0] = TablesDecoder_next(t, ContextTables_ownContext(d, v, 0, 0, 0, xdim, init));
	v[0] = init;
	for(int x = 1; x < xdim; x++)
	{
		d[x] = TablesDecoder_next(t, ContextTables_ownContext(d, v, x, x, 0, xdim, v[x - 1]));
		v[x] = v[x - 1] + d[x];
	}
	for(int y = 1, k = xdim; y < ydim; y++)
	{
		/* The first column, from above; the interior, from (left + above) / 2;
		   the last column (as the interior's prediction, not its context). */
		d[k] = TablesDecoder_next(t, ContextTables_ownContext(d, v, k, 0, y, xdim, v[k - xdim]));
		v[k] = v[k - xdim] + d[k];
		k++;
		int x = 1;
		for(; x < xdim - 1; x++, k++)
		{
			int p = (v[k - 1] + v[k - xdim]) / 2;
			d[k] = TablesDecoder_next(t, ContextTables_ownInterior(d, v, k, xdim, p));
			v[k] = p + d[k];
		}
		if(x < xdim)
		{
			int p = (v[k - 1] + v[k - xdim]) / 2;
			d[k] = TablesDecoder_next(t, ContextTables_ownContext(d, v, k, x, y, xdim, p));
			v[k] = p + d[k];
			k++;
		}
	}
	return ContextTables_finish(t);
}

static uint32_t get32(const uint8_t *p) { return ((uint32_t) p[0] << 24) | ((uint32_t) p[1] << 16) | ((uint32_t) p[2] << 8) | p[3]; }

int ContextTables_check(const uint8_t *packed, size_t length, const int32_t *delta, const int32_t *values, int xdim, int n)
{
	/* code's layout (see ContextTables_code). */
	if(length < 6) return 0;
	int32_t lo = (int32_t) get32(packed);
	int symbols = (packed[4] << 8) | packed[5];
	size_t pos = 6 + (size_t) symbols * ((symbols <= 255) ? 1 : 2);
	if(symbols < 1 || pos + 8 > length) return 0;
	int32_t *value = malloc((size_t) symbols * sizeof *value);
	if(!value) return -1;
	for(int v = 0; v < symbols; v++)
	{
		int r = (symbols <= 255) ? packed[6 + v] : ((packed[6 + 2 * v] << 8) | packed[7 + 2 * v]);
		if(r >= symbols) { free(value); return 0; }
		value[r] = v + lo;
	}
	int model = packed[pos], merge = packed[pos + 1], steps = packed[pos + 2], prec = packed[pos + 3];
	size_t tables = get32(packed + pos + 4);
	pos += 8;
	if(pos + tables + 4 > length) { free(value); return 0; }
	const uint8_t *table_bytes = packed + pos;
	pos += tables;
	size_t coded = get32(packed + pos);
	pos += 4;
	if(pos + coded != length) { free(value); return 0; }
	TablesDecoder *t = (model == CONTEXTTABLES_OWN && n > 0 && xdim > 0 && n % xdim == 0)
	                   ? ContextTables_decoder(table_bytes, tables, model, merge, steps, prec, value, symbols, packed + pos, coded, xdim) : NULL;
	free(value);
	if(!t) return 0;
	int same = 1;
	for(int y = 0, k = 0; k < n; y++)
		for(int x = 0; x < xdim; x++, k++)
		{
			int c = ContextTables_ownContext(delta, values, k, x, y, xdim, values[k] - delta[k]);
			if((t->own_symbol ? TablesDecoder_nextOwn(t, c) : TablesDecoder_next(t, c)) != delta[k]) same = 0;
		}
	int result = (same && ContextTables_finish(t) == 0) ? 1 : 0;
	ContextTables_free(t);
	return result;
}
