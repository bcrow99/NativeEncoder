#!/bin/sh
# On Linux: makes the C project's Eclipse file the Linux one, with only the
# Linux configuration (make), so there's nothing to switch. Run it once
# after unzipping (and again after unzipping a newer zip over this one),
# before importing or refreshing the project in Eclipse.
cd "$(dirname "$0")" && cp eclipse-linux/.cproject .cproject && echo "native/.cproject is now the Linux one (configuration Linux: make)."
