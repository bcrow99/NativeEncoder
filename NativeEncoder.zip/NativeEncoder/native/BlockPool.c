/*
 * BlockPool.c -- the library's memory, kept for reuse (see BlockPool.h).
 *
 * Each block has a header before it with its capacity (the bytes it can
 * hold), so free knows its size. A freed block of at least POOL_MIN bytes
 * goes into kept (if the pool's limit allows), and malloc takes the smallest
 * kept block that holds the request, as long as it's at most twice the size
 * asked for (so a big block isn't tied up by a small request); if none
 * fits, it asks the system for a new one. calloc clears a kept block itself,
 * as the system's would be.
 */
#define BLOCKPOOL_IMPLEMENTATION
#include "BlockPool.h"

#include <stdint.h>
#include <string.h>

#ifdef _WIN32
#include <windows.h>
#else
#include <pthread.h>
#include <unistd.h>
#endif

#define POOL_MIN    ((size_t) 1 << 20)            /* blocks kept: at least 1 MB */
#define POOL_MOST   ((size_t) 2048 << 20)         /* kept at most: 2 GB (or a quarter of the memory) */
#define KEPT_SLOTS  1024
#define HEADER      64                            /* (keeps the system's alignment, and a cache line apart) */

typedef struct { size_t capacity; } Header;

static void   *kept[KEPT_SLOTS];      /* the kept blocks (their headers) */
static size_t  kept_count, kept_bytes, limit;

#ifdef _WIN32
static SRWLOCK lock = SRWLOCK_INIT;
static void lock_pool(void)   { AcquireSRWLockExclusive(&lock); }
static void unlock_pool(void) { ReleaseSRWLockExclusive(&lock); }
#else
static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
static void lock_pool(void)   { pthread_mutex_lock(&lock); }
static void unlock_pool(void) { pthread_mutex_unlock(&lock); }
#endif

/* The most the pool keeps: a quarter of the memory, at most POOL_MOST.
   (Called with the lock held.) */
static size_t pool_limit(void)
{
	if(limit == 0)
	{
		unsigned long long memory = 0;
#ifdef _WIN32
		MEMORYSTATUSEX m;
		m.dwLength = sizeof m;
		if(GlobalMemoryStatusEx(&m)) memory = m.ullTotalPhys;
#else
		long pages = sysconf(_SC_PHYS_PAGES), page = sysconf(_SC_PAGESIZE);
		if(pages > 0 && page > 0) memory = (unsigned long long) pages * (unsigned long long) page;
#endif
		limit = (memory == 0 || memory / 4 > POOL_MOST) ? POOL_MOST : (size_t) (memory / 4);
	}
	return limit;
}

/* Gives kept block k back to the system. (Called with the lock held.) */
static void drop(size_t k)
{
	Header *h = kept[k];
	kept_bytes -= h->capacity;
	kept[k] = kept[--kept_count];
	free(h);
}

/* The kept block for n bytes, taken out of the pool: the smallest that holds
   n and is at most twice n; NULL if there's none. */
static Header *take(size_t n)
{
	Header *found = NULL;
	lock_pool();
	size_t best = KEPT_SLOTS;
	for(size_t k = 0; k < kept_count; k++)
	{
		size_t c = ((Header *) kept[k])->capacity;
		if(c >= n && c / 2 <= n && (best == KEPT_SLOTS || c < ((Header *) kept[best])->capacity)) best = k;
	}
	if(best != KEPT_SLOTS)
	{
		found = kept[best];
		kept_bytes -= found->capacity;
		kept[best] = kept[--kept_count];
	}
	unlock_pool();
	return found;
}

void *BlockPool_malloc(size_t n)
{
	if(n > SIZE_MAX - HEADER) return NULL;
	Header *h = (n >= POOL_MIN) ? take(n) : NULL;
	if(h == NULL)
	{
		h = malloc(HEADER + n);
		if(h == NULL) return NULL;
		h->capacity = n;
	}
	return (char *) h + HEADER;
}

void *BlockPool_calloc(size_t count, size_t size)
{
	if(size != 0 && count > SIZE_MAX / size) return NULL;
	size_t n = count * size;
	if(n > SIZE_MAX - HEADER) return NULL;
	Header *h = (n >= POOL_MIN) ? take(n) : NULL;
	if(h != NULL) memset((char *) h + HEADER, 0, n);   /* (a kept block isn't cleared) */
	else
	{
		h = calloc(1, HEADER + n);
		if(h == NULL) return NULL;
		h->capacity = n;
	}
	return (char *) h + HEADER;
}

void *BlockPool_realloc(void *p, size_t n)
{
	if(p == NULL) return BlockPool_malloc(n);
	Header *h = (Header *) ((char *) p - HEADER);
	if(n <= h->capacity) return p;
	void *q = BlockPool_malloc(n);
	if(q == NULL) return NULL;
	memcpy(q, p, h->capacity);
	BlockPool_free(p);
	return q;
}

void BlockPool_free(void *p)
{
	if(p == NULL) return;
	Header *h = (Header *) ((char *) p - HEADER);
	if(h->capacity >= POOL_MIN)
	{
		lock_pool();
		size_t most = pool_limit();
		if(h->capacity <= most)
		{
			/* Room for it: the smallest kept blocks given back until there is. */
			while(kept_count > 0 && (kept_count == KEPT_SLOTS || kept_bytes + h->capacity > most))
			{
				size_t smallest = 0;
				for(size_t k = 1; k < kept_count; k++)
					if(((Header *) kept[k])->capacity < ((Header *) kept[smallest])->capacity) smallest = k;
				drop(smallest);
			}
			kept[kept_count++] = h;
			kept_bytes += h->capacity;
			h = NULL;
		}
		unlock_pool();
		if(h == NULL) return;
	}
	free(h);
}

void BlockPool_release(void)
{
	lock_pool();
	while(kept_count > 0) drop(kept_count - 1);
	unlock_pool();
}
