/*
 * DeltaMapper_jni.c -- the JNI side of the C: the native methods
 * DeltaMapper.java, NativeWriter.java and NativePacketWriter.java
 * declare, built with the C into the library DeltaMapper (DeltaMapper.dll on
 * Windows, libDeltaMapper.so on Linux).
 */
#include <jni.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include "DeltaMapper.h"
#include "StringMapper.h"
#include "CodeMapper.h"
#include "SegmentMapper.h"
#include "BlockPool.h"   /* last: the library's malloc and free are the pool's */

/* DeltaMapper.nativeVersion: DELTAMAPPER_NATIVE_VERSION, for the Java to
   check the library is as new as it is. */
JNIEXPORT jint JNICALL Java_DeltaMapper_nativeVersion(JNIEnv *env, jclass cls)
{
	(void) env; (void) cls;
	return DELTAMAPPER_NATIVE_VERSION;
}

/* DeltaMapper.rowFitPlane: RowFit.plane in C (RowFit_plane), into out.
   Returns 0, or -1 if the C ran out of memory (the Java then does it). The
   arrays are held still while the C's threads work on them (no JNI calls
   meanwhile, as GetPrimitiveArrayCritical asks). */
JNIEXPORT jint JNICALL Java_DeltaMapper_rowFitPlane(JNIEnv *env, jclass cls, jintArray v, jintArray ref,
	jint xdim, jint ydim, jint radius, jint every, jshortArray out, jint threads)
{
	(void) cls;
	jint   *pv   = (*env)->GetPrimitiveArrayCritical(env, v, NULL);
	jint   *pref = (ref != NULL) ? (*env)->GetPrimitiveArrayCritical(env, ref, NULL) : NULL;
	jshort *pout = (*env)->GetPrimitiveArrayCritical(env, out, NULL);
	int result = -1;
	if(pv != NULL && pout != NULL && (ref == NULL || pref != NULL))
		result = RowFit_plane((const int32_t *) pv, (const int32_t *) pref, xdim, ydim, radius, every, (int16_t *) pout, threads, NULL);
	if(pout != NULL) (*env)->ReleasePrimitiveArrayCritical(env, out, pout, 0);
	if(pref != NULL) (*env)->ReleasePrimitiveArrayCritical(env, ref, pref, JNI_ABORT);
	if(pv != NULL)   (*env)->ReleasePrimitiveArrayCritical(env, v, pv, JNI_ABORT);
	return result;
}

/* DeltaMapper.packMixedDeltasNative: packMixedDeltas in C
   (DeltaMapper_packMixedDeltas): the same bytes, or null if the C ran out
   of memory (the Java then does it). The values are delta's length from
   offset on (a band of the whole channel, without the Java copying it out).
   The arrays are copied in, so the coding can run as long as it takes
   without holding them. */
JNIEXPORT jbyteArray JNICALL Java_DeltaMapper_packMixedDeltasNative(JNIEnv *env, jclass cls, jintArray delta, jintArray values,
	jint offset, jobjectArray previous, jint xdim, jboolean opinions)
{
	(void) cls;
	jsize n  = (*env)->GetArrayLength(env, delta);
	jsize np = (previous != NULL) ? (*env)->GetArrayLength(env, previous) : 0;
	if(np > 8 || offset < 0 || (*env)->GetArrayLength(env, values) - offset < n) return NULL;
	jbyteArray result = NULL;
	int32_t *d = malloc((size_t) n * sizeof *d), *v = malloc((size_t) n * sizeof *v);
	int32_t *p[8] = { NULL };
	int ok = d != NULL && v != NULL;
	for(jsize i = 0; i < np && ok; i++) ok = (p[i] = malloc((size_t) n * sizeof *p[i])) != NULL;
	if(ok)
	{
		(*env)->GetIntArrayRegion(env, delta, 0, n, (jint *) d);
		(*env)->GetIntArrayRegion(env, values, offset, n, (jint *) v);
		for(jsize i = 0; i < np; i++)
		{
			jintArray a = (jintArray) (*env)->GetObjectArrayElement(env, previous, i);
			(*env)->GetIntArrayRegion(env, a, 0, n, (jint *) p[i]);
			(*env)->DeleteLocalRef(env, a);
		}
		uint8_t *packed;
		size_t   length;
		if(DeltaMapper_packMixedDeltas(d, v, (const int32_t *const *) p, (int) np, xdim, (int) n, opinions != JNI_FALSE, &packed, &length) == 0)
		{
			result = (*env)->NewByteArray(env, (jsize) length);
			if(result != NULL) (*env)->SetByteArrayRegion(env, result, 0, (jsize) length, (const jbyte *) packed);
			free(packed);
		}
	}
	free(d); free(v);
	for(int i = 0; i < 8; i++) free(p[i]);
	return result;
}

/* decodeRowFitChannelsNative and decodeAverageChannelsNative: the coded
   channels decoded with the fit (radius not NULL) or the average deltas
   (radius NULL), filling delta[i] (unless delta is NULL) and value[i] from
   offset on (so a band can go straight into the whole channel). Returns 0,
   or -1 if the C couldn't (the Java then does it). The arrays are copied in
   and out. */
static jint decode_channels(JNIEnv *env, jobjectArray coded, jobjectArray rank_value,
	jint xdim, jint ydim, jintArray init, jintArray radius, jint every, jint helpers, jobjectArray delta, jobjectArray value, jint offset)
{
	jsize channels = (*env)->GetArrayLength(env, coded);
	if(channels < 1 || channels > 3 || xdim < 1 || ydim < 1 || offset < 0) return -1;
	size_t n = (size_t) xdim * ydim;
	for(jsize i = 0; i < channels; i++)
	{
		/* (Room for the values from offset on, and the deltas.) */
		jintArray a = (jintArray) (*env)->GetObjectArrayElement(env, value, i);
		int room = (size_t) (*env)->GetArrayLength(env, a) >= (size_t) offset + n;
		(*env)->DeleteLocalRef(env, a);
		if(room && delta != NULL)
		{
			a = (jintArray) (*env)->GetObjectArrayElement(env, delta, i);
			room = (size_t) (*env)->GetArrayLength(env, a) >= n;
			(*env)->DeleteLocalRef(env, a);
		}
		if(!room) return -1;
	}
	uint8_t *in[3] = { NULL }; size_t length[3] = { 0 };
	int32_t *rv[3] = { NULL }, *d[3] = { NULL }, *v[3] = { NULL };
	int ns[3], ini[3], rad[3] = { 0 }, ok = 1, result = -1;
	(*env)->GetIntArrayRegion(env, init, 0, channels, (jint *) ini);
	if(radius) (*env)->GetIntArrayRegion(env, radius, 0, channels, (jint *) rad);
	for(jsize i = 0; i < channels && ok; i++)
	{
		jbyteArray b = (jbyteArray) (*env)->GetObjectArrayElement(env, coded, i);
		jintArray  r = (jintArray) (*env)->GetObjectArrayElement(env, rank_value, i);
		length[i] = (size_t) (*env)->GetArrayLength(env, b);
		ns[i]     = (*env)->GetArrayLength(env, r);
		in[i] = malloc(length[i] + 1); rv[i] = malloc((size_t) ns[i] * sizeof *rv[i] + 1);
		d[i]  = malloc(n * sizeof *d[i]); v[i] = malloc(n * sizeof *v[i]);
		ok = in[i] && rv[i] && d[i] && v[i];
		if(ok)
		{
			(*env)->GetByteArrayRegion(env, b, 0, (jsize) length[i], (jbyte *) in[i]);
			(*env)->GetIntArrayRegion(env, r, 0, ns[i], (jint *) rv[i]);
		}
		(*env)->DeleteLocalRef(env, b); (*env)->DeleteLocalRef(env, r);
	}
	if(ok) ok = (radius != NULL)
		? DeltaMapper_decodeRowFitChannels(channels, (const uint8_t *const *) in, length, (const int32_t *const *) rv, ns,
		                                   xdim, ydim, ini, rad, every, helpers, d, v) == 0
		: DeltaMapper_decodeAverageChannels(channels, (const uint8_t *const *) in, length, (const int32_t *const *) rv, ns,
		                                    xdim, ydim, ini, d, v) == 0;
	if(ok)
	{
		for(jsize i = 0; i < channels; i++)
		{
			jintArray a;
			if(delta != NULL)
			{
				a = (jintArray) (*env)->GetObjectArrayElement(env, delta, i);
				(*env)->SetIntArrayRegion(env, a, 0, (jsize) n, (const jint *) d[i]);
				(*env)->DeleteLocalRef(env, a);
			}
			a = (jintArray) (*env)->GetObjectArrayElement(env, value, i);
			(*env)->SetIntArrayRegion(env, a, offset, (jsize) n, (const jint *) v[i]);
			(*env)->DeleteLocalRef(env, a);
		}
		result = 0;
	}
	for(int i = 0; i < 3; i++) { free(in[i]); free(rv[i]); free(d[i]); free(v[i]); }
	return result;
}

/* DeltaMapper.decodeRowFitChannelsNative: getValuesFromRowFitChannels in C
   (DeltaMapper_decodeRowFitChannels) for coded bytes that have all arrived. */
JNIEXPORT jint JNICALL Java_DeltaMapper_decodeRowFitChannelsNative(JNIEnv *env, jclass cls, jobjectArray coded, jobjectArray rank_value,
	jint xdim, jint ydim, jintArray init, jintArray radius, jint every, jint helpers, jobjectArray delta, jobjectArray value, jint offset)
{
	(void) cls;
	if(radius == NULL) return -1;
	return decode_channels(env, coded, rank_value, xdim, ydim, init, radius, every, helpers, delta, value, offset);
}

/* DeltaMapper.decodeAverageChannelsNative: getValuesFromAverageChannels in C
   (DeltaMapper_decodeAverageChannels) for coded bytes that have all arrived. */
JNIEXPORT jint JNICALL Java_DeltaMapper_decodeAverageChannelsNative(JNIEnv *env, jclass cls, jobjectArray coded, jobjectArray rank_value,
	jint xdim, jint ydim, jintArray init, jobjectArray delta, jobjectArray value, jint offset)
{
	(void) cls;
	return decode_channels(env, coded, rank_value, xdim, ydim, init, NULL, 0, 0, delta, value, offset);
}

/* DeltaMapper.rebuildRowFitChannelsNative: getValuesFromRowFitDeltas in C
   (DeltaMapper_rebuildRowFitChannels): fills value[i] from delta[i]. Returns
   0, or -1 if the C couldn't (the Java then does it). The arrays are copied
   in and out. */
JNIEXPORT jint JNICALL Java_DeltaMapper_rebuildRowFitChannelsNative(JNIEnv *env, jclass cls, jobjectArray delta,
	jint xdim, jint ydim, jintArray init, jintArray radius, jint every, jint helpers, jobjectArray value)
{
	(void) cls;
	jsize channels = (*env)->GetArrayLength(env, delta);
	if(channels < 1 || channels > 3 || xdim < 1 || ydim < 1) return -1;
	size_t n = (size_t) xdim * ydim;
	int32_t *d[3] = { NULL }, *v[3] = { NULL };
	int ini[3], rad[3], ok = 1, result = -1;
	(*env)->GetIntArrayRegion(env, init, 0, channels, (jint *) ini);
	(*env)->GetIntArrayRegion(env, radius, 0, channels, (jint *) rad);
	for(jsize i = 0; i < channels && ok; i++)
	{
		jintArray a = (jintArray) (*env)->GetObjectArrayElement(env, delta, i);
		d[i] = malloc(n * sizeof *d[i]); v[i] = malloc(n * sizeof *v[i]);
		ok = d[i] && v[i] && (size_t) (*env)->GetArrayLength(env, a) == n;
		if(ok) (*env)->GetIntArrayRegion(env, a, 0, (jsize) n, (jint *) d[i]);
		(*env)->DeleteLocalRef(env, a);
	}
	if(ok && DeltaMapper_rebuildRowFitChannels(channels, xdim, ydim, ini, rad, every, helpers, NULL, NULL, d, v) == 0)
	{
		for(jsize i = 0; i < channels; i++)
		{
			jintArray a = (jintArray) (*env)->GetObjectArrayElement(env, value, i);
			(*env)->SetIntArrayRegion(env, a, 0, (jsize) n, (const jint *) v[i]);
			(*env)->DeleteLocalRef(env, a);
		}
		result = 0;
	}
	for(int i = 0; i < 3; i++) { free(d[i]); free(v[i]); }
	return result;
}

/* DeltaMapper.getPixelsNative: the reader's last steps in C
   (DeltaMapper_getPixels), into pixel. Returns 0, or -1 if the C couldn't
   (the Java then does them). The channels and pixel are held still while
   the C's threads work on them (they aren't changed: the minimums are added
   as they're read). */
JNIEXPORT jint JNICALL Java_DeltaMapper_getPixelsNative(JNIEnv *env, jclass cls, jint set_id, jobjectArray channel, jintArray min,
	jint w, jint h, jintArray ca, jintArray cb, jintArray ra, jintArray rb, jint how, jint xdim, jint ydim, jint pixel_shift, jintArray pixel, jint threads)
{
	(void) cls;
	if((*env)->GetArrayLength(env, channel) != 3) return -1;
	int mn[3];
	(*env)->GetIntArrayRegion(env, min, 0, 3, (jint *) mn);
	int *map[4] = { NULL, NULL, NULL, NULL };
	jintArray maps[4] = { ca, cb, ra, rb };
	int resize = ca != NULL, ok = 1, result = -1;
	if(resize)
		for(int i = 0; i < 4 && ok; i++)
		{
			jsize len = (*env)->GetArrayLength(env, maps[i]);
			ok = (map[i] = malloc((size_t) len * sizeof *map[i] + 1)) != NULL;
			if(ok) (*env)->GetIntArrayRegion(env, maps[i], 0, len, (jint *) map[i]);
		}
	jintArray a[3];
	for(int i = 0; i < 3; i++) a[i] = (jintArray) (*env)->GetObjectArrayElement(env, channel, i);
	if(ok)
	{
		jint *c[3] = { NULL, NULL, NULL };
		for(int i = 0; i < 3 && ok; i++) ok = (c[i] = (*env)->GetPrimitiveArrayCritical(env, a[i], NULL)) != NULL;
		jint *px = ok ? (*env)->GetPrimitiveArrayCritical(env, pixel, NULL) : NULL;
		if(px != NULL)
		{
			result = DeltaMapper_getPixels(set_id, (const int32_t *const *) c, mn, w, h, map[0], map[1], map[2], map[3], how, xdim, ydim, pixel_shift, (int32_t *) px, threads);
			(*env)->ReleasePrimitiveArrayCritical(env, pixel, px, 0);
		}
		for(int i = 2; i >= 0; i--) if(c[i] != NULL) (*env)->ReleasePrimitiveArrayCritical(env, a[i], c[i], JNI_ABORT);
	}
	for(int i = 0; i < 3; i++) (*env)->DeleteLocalRef(env, a[i]);
	for(int i = 0; i < 4; i++) free(map[i]);
	return result;
}

/* ---- Apply and the decode check -------------------------------------------- */

/* Holds the int arrays a[0..n-1] still (GetPrimitiveArrayCritical) into p;
   returns how many it got (all n, or fewer if one failed). */
static int hold_ints(JNIEnv *env, jobjectArray arrays, int n, jintArray *a, jint **p)
{
	int got = 0;
	for(int i = 0; i < n; i++) { a[i] = (jintArray) (*env)->GetObjectArrayElement(env, arrays, i); p[i] = NULL; }
	for(int i = 0; i < n; i++, got++) if((p[i] = (*env)->GetPrimitiveArrayCritical(env, a[i], NULL)) == NULL) break;
	return got;
}

static void let_go_ints(JNIEnv *env, int n, jintArray *a, jint **p, int got, int changed)
{
	for(int i = got - 1; i >= 0; i--) (*env)->ReleasePrimitiveArrayCritical(env, a[i], p[i], changed ? 0 : JNI_ABORT);
	for(int i = 0; i < n; i++) (*env)->DeleteLocalRef(env, a[i]);
}

/* resize2's four maps, copied (all NULL if ca is). Returns 0, or -1. */
static int copy_maps(JNIEnv *env, jintArray ca, jintArray cb, jintArray ra, jintArray rb, int *map[4])
{
	jintArray maps[4] = { ca, cb, ra, rb };
	for(int i = 0; i < 4; i++) map[i] = NULL;
	if(ca == NULL) return 0;
	for(int i = 0; i < 4; i++)
	{
		jsize len = (*env)->GetArrayLength(env, maps[i]);
		if((map[i] = malloc((size_t) len * sizeof *map[i] + 1)) == NULL) return -1;
		(*env)->GetIntArrayRegion(env, maps[i], 0, len, (jint *) map[i]);
	}
	return 0;
}

/* DeltaMapper.applyQuantizeNative: Apply's quantizedChannels and
   getCandidateChannels in C (DeltaMapper_applyQuantize). */
JNIEXPORT jint JNICALL Java_DeltaMapper_applyQuantizeNative(JNIEnv *env, jclass cls, jobjectArray src, jint X, jint Y, jint w, jint h,
	jintArray ca, jintArray cb, jintArray ra, jintArray rb, jint shift, jobjectArray q, jobjectArray diff, jintArray min, jint threads)
{
	(void) cls;
	int *map[4], result = -1;
	if(copy_maps(env, ca, cb, ra, rb, map) == 0)
	{
		jintArray as[3], aq[3], ad[3];
		jint *ps[3], *pq[3], *pd[3];
		int gs = hold_ints(env, src, 3, as, ps);
		int gq = (gs == 3) ? hold_ints(env, q, 3, aq, pq) : 0;
		int gd = (gq == 3) ? hold_ints(env, diff, 3, ad, pd) : 0;
		int32_t mn[6];
		if(gd == 3)
			result = DeltaMapper_applyQuantize((const int32_t *const *) ps, X, Y, w, h, map[0], map[1], map[2], map[3], shift,
			                                   (int32_t **) pq, (int32_t **) pd, mn, threads);
		if(gq == 3) let_go_ints(env, 3, ad, pd, gd, 1);
		if(gs == 3) let_go_ints(env, 3, aq, pq, gq, 1);
		let_go_ints(env, 3, as, ps, gs, 0);
		if(result == 0) (*env)->SetIntArrayRegion(env, min, 0, 6, (const jint *) mn);
	}
	for(int i = 0; i < 4; i++) free(map[i]);
	return result;
}

/* DeltaMapper.applyPreviewNative: Apply's preview in C (DeltaMapper_applyPreview). */
JNIEXPORT jint JNICALL Java_DeltaMapper_applyPreviewNative(JNIEnv *env, jclass cls, jobjectArray q, jint w, jint h,
	jintArray ca, jintArray cb, jintArray ra, jintArray rb, jint X, jint Y, jint shift, jint correction, jobjectArray src, jintArray pixel, jint threads)
{
	(void) cls;
	int *map[4], result = -1;
	if(copy_maps(env, ca, cb, ra, rb, map) == 0)
	{
		jintArray aq[3], as[3];
		jint *pq[3], *ps[3];
		int gq = hold_ints(env, q, 3, aq, pq);
		int gs = (gq == 3) ? hold_ints(env, src, 3, as, ps) : 0;
		jint *px = (gs == 3) ? (*env)->GetPrimitiveArrayCritical(env, pixel, NULL) : NULL;
		if(px != NULL)
		{
			result = DeltaMapper_applyPreview((const int32_t *const *) pq, w, h, map[0], map[1], map[2], map[3], X, Y, shift, correction,
			                                  (const int32_t *const *) ps, (int32_t *) px, threads);
			(*env)->ReleasePrimitiveArrayCritical(env, pixel, px, 0);
		}
		if(gq == 3) let_go_ints(env, 3, as, ps, gs, 0);
		let_go_ints(env, 3, aq, pq, gq, 0);
	}
	for(int i = 0; i < 4; i++) free(map[i]);
	return result;
}

/* DeltaMapper.checkMixedDeltasNative: whether packed decodes back to delta
   (DeltaMapper_checkMixedDeltas): 1 if it does, 0 if not, -1 if the C
   couldn't tell (the Java then checks). The values are delta's length from
   offset on. The arrays are copied in. */
JNIEXPORT jint JNICALL Java_DeltaMapper_checkMixedDeltasNative(JNIEnv *env, jclass cls, jbyteArray packed, jintArray delta, jintArray values,
	jint offset, jobjectArray previous, jint xdim)
{
	(void) cls;
	jsize n = (*env)->GetArrayLength(env, delta), np = (previous != NULL) ? (*env)->GetArrayLength(env, previous) : 0;
	jsize len = (*env)->GetArrayLength(env, packed);
	if(np > 8 || offset < 0 || (*env)->GetArrayLength(env, values) - offset < n) return -1;
	uint8_t *b = malloc((size_t) len + 1);
	int32_t *d = malloc((size_t) n * sizeof *d + 1), *v = malloc((size_t) n * sizeof *v + 1), *p[8] = { NULL };
	int ok = b && d && v, result = -1;
	for(jsize i = 0; i < np && ok; i++) ok = (p[i] = malloc((size_t) n * sizeof *p[i] + 1)) != NULL;
	if(ok)
	{
		(*env)->GetByteArrayRegion(env, packed, 0, len, (jbyte *) b);
		(*env)->GetIntArrayRegion(env, delta, 0, n, (jint *) d);
		(*env)->GetIntArrayRegion(env, values, offset, n, (jint *) v);
		for(jsize i = 0; i < np; i++)
		{
			jintArray a = (jintArray) (*env)->GetObjectArrayElement(env, previous, i);
			(*env)->GetIntArrayRegion(env, a, 0, n, (jint *) p[i]);
			(*env)->DeleteLocalRef(env, a);
		}
		result = DeltaMapper_checkMixedDeltas(b, (size_t) len, d, v, (const int32_t *const *) p, (int) np, xdim, (int) n);
	}
	free(b); free(d); free(v);
	for(int i = 0; i < 8; i++) free(p[i]);
	return result;
}

/* ---- NativeWriter and NativeReader's Huffman coding ---- */

/* NativeWriter.stringListNative: StringMapper.getStringList(delta, true) in
   C (StringMapper_getStringList; delta isn't changed). Returns the string,
   with info[0] the minimum and info[1] the untransformed string's bits, and
   table[0] the rank table; or NULL if the C couldn't (the Java then does it). */
JNIEXPORT jbyteArray JNICALL Java_NativeWriter_stringListNative(JNIEnv *env, jclass cls, jintArray delta, jintArray info, jobjectArray table)
{
	(void) cls;
	jsize n = (*env)->GetArrayLength(env, delta);
	if(n < 1) return NULL;
	int32_t *d = malloc((size_t) n * sizeof *d), min, bitlength, *rank = NULL;
	uint8_t *string = NULL;
	size_t length;
	int range;
	jbyteArray result = NULL;
	if(!d) return NULL;
	(*env)->GetIntArrayRegion(env, delta, 0, n, (jint *) d);
	if(StringMapper_getStringList(d, n, &min, &bitlength, &rank, &range, &string, &length) == 0)
	{
		jintArray t = (*env)->NewIntArray(env, range);
		result = (*env)->NewByteArray(env, (jsize) length);
		if(t && result)
		{
			(*env)->SetIntArrayRegion(env, t, 0, range, (const jint *) rank);
			(*env)->SetByteArrayRegion(env, result, 0, (jsize) length, (const jbyte *) string);
			(*env)->SetObjectArrayElement(env, table, 0, t);
			jint in[2] = { min, bitlength };
			(*env)->SetIntArrayRegion(env, info, 0, 2, in);
		}
		else result = NULL;
	}
	free(d); free(rank); free(string);
	return result;
}

/* NativeWriter.packRegularCodeNative: CodeMapper.packRegularCode in C
   (CodeMapper_packRegularCode). Returns the code, or NULL if the C couldn't
   (the Java then does it). */
JNIEXPORT jbyteArray JNICALL Java_NativeWriter_packRegularCodeNative(JNIEnv *env, jclass cls, jbyteArray data, jbyteArray length)
{
	(void) cls;
	jsize n = (*env)->GetArrayLength(env, data);
	if((*env)->GetArrayLength(env, length) != 256) return NULL;
	uint8_t len[256], *d = malloc((size_t) n + 1), *code = NULL;
	size_t code_length;
	jbyteArray result = NULL;
	if(!d) return NULL;
	(*env)->GetByteArrayRegion(env, data, 0, n, (jbyte *) d);
	(*env)->GetByteArrayRegion(env, length, 0, 256, (jbyte *) len);
	if(CodeMapper_packRegularCode(d, (size_t) n, len, &code, &code_length) == 0)
	{
		result = (*env)->NewByteArray(env, (jsize) code_length);
		if(result) (*env)->SetByteArrayRegion(env, result, 0, (jsize) code_length, (const jbyte *) code);
	}
	free(d); free(code);
	return result;
}

/* A channel's Huffman-coded deltas, as huffmanCode wrote them (with the code
   lengths already inflated). */
typedef struct
{
	uint8_t *code;      size_t code_length;
	uint8_t  lengths[256];
	int      length;    /* the string's bytes */
	int32_t *table;     int range;
	int      bits, min;
	int      n;         /* how many deltas */
} HuffmanChannel;

/* huffmanDecode's decoding, from the code lengths on: CodeMapper_unpackRegularCode
   (h->length bytes of string), StringMapper_decompressStrings,
   StringMapper_unpackStrings (with the table and bits), then delta[0] = 0
   and the minimum added to the rest. A DeltaSource. Returns 0, or -1 if out
   of memory or the bytes aren't what huffmanCode writes. */
static int huffman_decode(void *arg, int32_t *delta)
{
	HuffmanChannel *h = arg;
	if(h->length < 1 || h->range < 1 || h->n < 1) return -1;
	for(int i = 0; i < h->range; i++) if(h->table[i] < 0 || h->table[i] >= h->range) return -1;
	uint8_t *string = malloc((size_t) h->length), *raw = NULL;
	size_t raw_length;
	int result = -1;
	if(string && CodeMapper_unpackRegularCode(h->code, h->code_length, h->lengths, (size_t) h->length, string) == 0
	          && StringMapper_decompressStrings(string, (size_t) h->length, &raw, &raw_length) == 0
	          && StringMapper_unpackStrings(raw, raw_length, h->table, h->range, h->n, h->bits, delta) == 0)
	{
		delta[0] = 0;
		for(int k = 1; k < h->n; k++) delta[k] = (int32_t) ((uint32_t) delta[k] + (uint32_t) h->min);
		result = 0;
	}
	free(string); free(raw);
	return result;
}

/* Copies a channel's Huffman coding in from the Java's arrays. Returns 0, or
   -1 if out of memory or the arrays aren't the right sizes (h is then still
   safe to free). */
static int huffman_channel(JNIEnv *env, HuffmanChannel *h, jbyteArray code, jbyteArray lengths, jint length,
                           jintArray table, jint bits, jint min, int n)
{
	memset(h, 0, sizeof *h);
	if((*env)->GetArrayLength(env, lengths) != 256) return -1;
	h->code_length = (size_t) (*env)->GetArrayLength(env, code);
	h->range = (*env)->GetArrayLength(env, table);
	h->length = length; h->bits = bits; h->min = min; h->n = n;
	h->code  = malloc(h->code_length + 1);
	h->table = malloc((size_t) h->range * sizeof *h->table + 1);
	if(!h->code || !h->table) return -1;
	(*env)->GetByteArrayRegion(env, code, 0, (jsize) h->code_length, (jbyte *) h->code);
	(*env)->GetByteArrayRegion(env, lengths, 0, 256, (jbyte *) h->lengths);
	(*env)->GetIntArrayRegion(env, table, 0, h->range, (jint *) h->table);
	return 0;
}

static void huffman_channel_free(HuffmanChannel *h) { free(h->code); free(h->table); }

/* NativeWriter.huffmanDecodeNative: huffmanDecode's decoding in C, from the
   code-length table on (huffman_decode). Returns 0, or -1 if the C couldn't
   (the Java then does it, and says what's wrong). */
JNIEXPORT jint JNICALL Java_NativeWriter_huffmanDecodeNative(JNIEnv *env, jclass cls, jbyteArray code, jbyteArray lengths,
	jint length, jintArray table, jint bits, jint min, jintArray delta)
{
	(void) cls;
	jsize n = (*env)->GetArrayLength(env, delta);
	HuffmanChannel h;
	memset(&h, 0, sizeof h);
	int32_t *d = malloc((size_t) n * sizeof *d + 1);
	int result = -1;
	if(d && huffman_channel(env, &h, code, lengths, length, table, bits, min, n) == 0 && huffman_decode(&h, d) == 0)
	{
		(*env)->SetIntArrayRegion(env, delta, 0, n, (const jint *) d);
		result = 0;
	}
	huffman_channel_free(&h);
	free(d);
	return result;
}

/* NativeWriter.huffmanAverageNative: a band's channel decoded (huffman_decode)
   and rebuilt from its average deltas (DeltaMapper_valuesFromAverageDeltas)
   in C, its values into value from offset on (its place in the whole
   channel). Returns 0, or -1 if the C couldn't (the Java then does it). */
JNIEXPORT jint JNICALL Java_NativeWriter_huffmanAverageNative(JNIEnv *env, jclass cls, jbyteArray code, jbyteArray lengths,
	jint length, jintArray table, jint bits, jint min, jint xdim, jint ydim, jint init, jintArray value, jint offset)
{
	(void) cls;
	if(xdim < 1 || ydim < 1 || offset < 0) return -1;
	size_t n = (size_t) xdim * ydim;
	if(n > (size_t) INT32_MAX || (size_t) (*env)->GetArrayLength(env, value) < (size_t) offset + n) return -1;
	HuffmanChannel h;
	memset(&h, 0, sizeof h);   /* (so it's safe to free if malloc fails first) */
	int32_t *v = malloc(n * sizeof *v + 1);
	int result = -1;
	if(v && huffman_channel(env, &h, code, lengths, length, table, bits, min, (int) n) == 0 && huffman_decode(&h, v) == 0)
	{
		DeltaMapper_valuesFromAverageDeltas(v, xdim, ydim, init);
		(*env)->SetIntArrayRegion(env, value, offset, (jsize) n, (const jint *) v);
		result = 0;
	}
	huffman_channel_free(&h);
	free(v);
	return result;
}

/* NativeWriter.rebuildHuffmanChannelsNative: a band's channels decoded and
   rebuilt in C at once (DeltaMapper_rebuildRowFitChannels with huffman_decode
   as the deltas' source): each channel's thread decodes its deltas, then
   rebuilds it, so channel 0 starts while the others are still decoding.
   Fills value[i]. Returns 0, or -1 if the C couldn't (the Java then does it). */
JNIEXPORT jint JNICALL Java_NativeWriter_rebuildHuffmanChannelsNative(JNIEnv *env, jclass cls, jobjectArray code, jobjectArray lengths,
	jintArray length, jobjectArray table, jintArray bits, jintArray min, jint xdim, jint ydim, jintArray init, jintArray radius,
	jint every, jint helpers, jobjectArray value)
{
	(void) cls;
	jsize channels = (*env)->GetArrayLength(env, code);
	if(channels < 1 || channels > 3 || xdim < 1 || ydim < 1) return -1;
	size_t n = (size_t) xdim * ydim;
	HuffmanChannel h[3];
	void *arg[3];
	int32_t *d[3] = { NULL }, *v[3] = { NULL };
	int len[3], bit[3], mn[3], ini[3], rad[3], ok = 1, ready = 0, result = -1;
	(*env)->GetIntArrayRegion(env, length, 0, channels, (jint *) len);
	(*env)->GetIntArrayRegion(env, bits, 0, channels, (jint *) bit);
	(*env)->GetIntArrayRegion(env, min, 0, channels, (jint *) mn);
	(*env)->GetIntArrayRegion(env, init, 0, channels, (jint *) ini);
	(*env)->GetIntArrayRegion(env, radius, 0, channels, (jint *) rad);
	for(jsize i = 0; i < channels && ok; i++, ready++)
	{
		jbyteArray c = (jbyteArray) (*env)->GetObjectArrayElement(env, code, i);
		jbyteArray l = (jbyteArray) (*env)->GetObjectArrayElement(env, lengths, i);
		jintArray  t = (jintArray) (*env)->GetObjectArrayElement(env, table, i);
		ok = huffman_channel(env, &h[i], c, l, len[i], t, bit[i], mn[i], (int) n) == 0;
		(*env)->DeleteLocalRef(env, c); (*env)->DeleteLocalRef(env, l); (*env)->DeleteLocalRef(env, t);
		arg[i] = &h[i];
		d[i] = malloc(n * sizeof *d[i]); v[i] = malloc(n * sizeof *v[i]);
		ok = ok && d[i] && v[i];
	}
	if(ok && DeltaMapper_rebuildRowFitChannels(channels, xdim, ydim, ini, rad, every, helpers, huffman_decode, arg, d, v) == 0)
	{
		for(jsize i = 0; i < channels; i++)
		{
			jintArray a = (jintArray) (*env)->GetObjectArrayElement(env, value, i);
			(*env)->SetIntArrayRegion(env, a, 0, (jsize) n, (const jint *) v[i]);
			(*env)->DeleteLocalRef(env, a);
		}
		result = 0;
	}
	for(int i = 0; i < ready; i++) huffman_channel_free(&h[i]);
	for(int i = 0; i < 3; i++) { free(d[i]); free(v[i]); }
	return result;
}

/* ---- NativePacketWriter and NativePacketReader's segmentation ---- */

/* A Java byte array's bytes, copied (with a spare byte, so none is empty).
   NULL if out of memory. */
static uint8_t *copyBytes(JNIEnv *env, jbyteArray array, size_t *length)
{
	*length = (size_t) (*env)->GetArrayLength(env, array);
	uint8_t *bytes = malloc(*length + 1);
	if(bytes) (*env)->GetByteArrayRegion(env, array, 0, (jsize) *length, (jbyte *) bytes);
	return bytes;
}

/* NativePacketWriter.segmentNative: SegmentMapper.getSegmentedData3(string,
   ...).get(0) in C (SegmentMapper_getSegmentedData3), compressing on threads
   threads. Returns the segments; none if the Java returns no segments; NULL
   if the C couldn't (the Java then does it). */
JNIEXPORT jobjectArray JNICALL Java_NativePacketWriter_segmentNative(JNIEnv *env, jclass cls, jbyteArray string, jint minimum_bitlength,
	jint segment_type, jint merge_type, jdouble bin, jint maximum_bitlength, jint threads)
{
	(void) cls;
	size_t length;
	uint8_t *s = copyBytes(env, string, &length);
	if(!s) return NULL;
	Segment *segment = NULL;
	int count = 0;
	int status = SegmentMapper_getSegmentedData3(s, length, minimum_bitlength, segment_type, merge_type, bin, maximum_bitlength, threads, &segment, &count);
	free(s);
	if(status < 0) return NULL;
	jclass byte_array = (*env)->FindClass(env, "[B");
	jobjectArray result = byte_array ? (*env)->NewObjectArray(env, count, byte_array, NULL) : NULL;
	for(int i = 0; result && i < count; i++)
	{
		jbyteArray b = (*env)->NewByteArray(env, (jsize) segment[i].length);
		if(!b) { result = NULL; break; }
		(*env)->SetByteArrayRegion(env, b, 0, (jsize) segment[i].length, (const jbyte *) segment[i].bytes);
		(*env)->SetObjectArrayElement(env, result, i, b);
		(*env)->DeleteLocalRef(env, b);
	}
	SegmentMapper_freeSegments(segment, count);
	return result;
}

/* NativePacketWriter.packSegmentsNative: SegmentMapper.packSegments3(segments).get(0)
   in C (SegmentMapper_packSegments3). Returns the packed bits, or NULL if the
   C couldn't (the Java then does it). */
JNIEXPORT jbyteArray JNICALL Java_NativePacketWriter_packSegmentsNative(JNIEnv *env, jclass cls, jobjectArray segments)
{
	(void) cls;
	jsize count = (*env)->GetArrayLength(env, segments);
	Segment *segment = calloc((size_t) count + 1, sizeof *segment);
	jbyteArray result = NULL;
	uint8_t *packed = NULL;
	size_t packed_length;
	int ok = (segment != NULL);
	for(jsize i = 0; ok && i < count; i++)
	{
		jbyteArray b = (jbyteArray) (*env)->GetObjectArrayElement(env, segments, i);
		ok = b && (segment[i].bytes = copyBytes(env, b, &segment[i].length)) && segment[i].length > 0;
		if(b) (*env)->DeleteLocalRef(env, b);
	}
	if(ok && SegmentMapper_packSegments3(segment, count, &packed, &packed_length) == 0)
	{
		result = (*env)->NewByteArray(env, (jsize) packed_length);
		if(result) (*env)->SetByteArrayRegion(env, result, 0, (jsize) packed_length, (const jbyte *) packed);
	}
	free(packed);
	SegmentMapper_freeSegments(segment, count);
	return result;
}

/* NativePacketWriter.restoreNative: SegmentMapper.restore2(SegmentMapper.unpackSegments3(
   packed, bytelength, data), string_data) in C (SegmentMapper_restore),
   decompressing on threads threads. Returns the string, or NULL if the C
   couldn't (the Java then does it, and says what's wrong). */
JNIEXPORT jbyteArray JNICALL Java_NativePacketWriter_restoreNative(JNIEnv *env, jclass cls, jbyteArray packed, jintArray bytelength,
	jbyteArray data, jbyte string_data, jint threads)
{
	(void) cls;
	jsize count = (*env)->GetArrayLength(env, data);
	if((*env)->GetArrayLength(env, bytelength) != count) return NULL;
	size_t packed_length, data_length;
	uint8_t *p = copyBytes(env, packed, &packed_length), *d = copyBytes(env, data, &data_length), *string = NULL;
	int32_t *b = malloc((size_t) count * sizeof *b + 1);
	size_t string_length;
	jbyteArray result = NULL;
	if(p && d && b)
	{
		(*env)->GetIntArrayRegion(env, bytelength, 0, count, (jint *) b);
		if(SegmentMapper_restore(p, packed_length, b, d, count, (uint8_t) string_data, threads, &string, &string_length) == 0)
		{
			result = (*env)->NewByteArray(env, (jsize) string_length);
			if(result) (*env)->SetByteArrayRegion(env, result, 0, (jsize) string_length, (const jbyte *) string);
		}
	}
	free(p); free(d); free(b); free(string);
	return result;
}

/* NativePacketWriter.restoreDeltasNative: NativePacketReader's deltas from a
   channel's packet: SegmentMapper_restore, then StringMapper_unpackStrings
   (with the table and bits), then delta[0] = 0 and the minimum added to the
   rest. Returns 0, or -1 if the C couldn't (the Java then does it, and says
   what's wrong). */
JNIEXPORT jint JNICALL Java_NativePacketWriter_restoreDeltasNative(JNIEnv *env, jclass cls, jbyteArray packed, jintArray bytelength,
	jbyteArray data, jbyte string_data, jintArray table, jint bits, jint min, jint threads, jintArray delta)
{
	(void) cls;
	jsize count = (*env)->GetArrayLength(env, data), range = (*env)->GetArrayLength(env, table), n = (*env)->GetArrayLength(env, delta);
	if((*env)->GetArrayLength(env, bytelength) != count || range < 1 || n < 1) return -1;
	size_t packed_length, data_length, string_length;
	uint8_t *p = copyBytes(env, packed, &packed_length), *d = copyBytes(env, data, &data_length), *string = NULL;
	int32_t *b = malloc((size_t) count * sizeof *b + 1), *t = malloc((size_t) range * sizeof *t), *out = malloc((size_t) n * sizeof *out);
	int result = -1;
	if(p && d && b && t && out)
	{
		(*env)->GetIntArrayRegion(env, bytelength, 0, count, (jint *) b);
		(*env)->GetIntArrayRegion(env, table, 0, range, (jint *) t);
		int table_ok = 1;
		for(int i = 0; i < range; i++) if(t[i] < 0 || t[i] >= range) table_ok = 0;
		if(table_ok && SegmentMapper_restore(p, packed_length, b, d, count, (uint8_t) string_data, threads, &string, &string_length) == 0
		            && StringMapper_unpackStrings(string, string_length, t, range, n, bits, out) == 0)
		{
			out[0] = 0;
			for(int k = 1; k < n; k++) out[k] = (int32_t) ((uint32_t) out[k] + (uint32_t) min);
			(*env)->SetIntArrayRegion(env, delta, 0, n, (const jint *) out);
			result = 0;
		}
	}
	free(p); free(d); free(b); free(t); free(out); free(string);
	return result;
}
