/*
 * DeltaMapper_jni.c -- the JNI side of DeltaMapper.c: the native methods
 * DeltaMapper.java declares, built with DeltaMapper.c into the library
 * DeltaMapper (DeltaMapper.dll on Windows, libDeltaMapper.so on Linux).
 */
#include <jni.h>
#include <stdint.h>
#include <stdlib.h>

#include "DeltaMapper.h"

/* DeltaMapper.nativeVersion: DELTAMAPPER_NATIVE_VERSION, for the Java to
   check the library is as new as it is. */
JNIEXPORT jint JNICALL Java_DeltaMapper_nativeVersion(JNIEnv *env, jclass cls)
{
	(void) env; (void) cls;
	return DELTAMAPPER_NATIVE_VERSION;
}

/* DeltaMapper.rowFitPlane: RowFit.plane in C (RowFit_plane), into out.
   Returns 0, or -1 if the C ran out of memory (the Java then does it). The
   arrays are held still while the C's threads work on them (no JNI calls
   meanwhile, as GetPrimitiveArrayCritical asks). */
JNIEXPORT jint JNICALL Java_DeltaMapper_rowFitPlane(JNIEnv *env, jclass cls, jintArray v, jintArray ref,
	jint xdim, jint ydim, jint radius, jint every, jshortArray out, jint threads)
{
	(void) cls;
	jint   *pv   = (*env)->GetPrimitiveArrayCritical(env, v, NULL);
	jint   *pref = (ref != NULL) ? (*env)->GetPrimitiveArrayCritical(env, ref, NULL) : NULL;
	jshort *pout = (*env)->GetPrimitiveArrayCritical(env, out, NULL);
	int result = -1;
	if(pv != NULL && pout != NULL && (ref == NULL || pref != NULL))
		result = RowFit_plane((const int32_t *) pv, (const int32_t *) pref, xdim, ydim, radius, every, (int16_t *) pout, threads, NULL);
	if(pout != NULL) (*env)->ReleasePrimitiveArrayCritical(env, out, pout, 0);
	if(pref != NULL) (*env)->ReleasePrimitiveArrayCritical(env, ref, pref, JNI_ABORT);
	if(pv != NULL)   (*env)->ReleasePrimitiveArrayCritical(env, v, pv, JNI_ABORT);
	return result;
}

/* DeltaMapper.packMixedDeltasNative: packMixedDeltas in C
   (DeltaMapper_packMixedDeltas): the same bytes, or null if the C ran out
   of memory (the Java then does it). The arrays are copied in, so the
   coding can run as long as it takes without holding them. */
JNIEXPORT jbyteArray JNICALL Java_DeltaMapper_packMixedDeltasNative(JNIEnv *env, jclass cls, jintArray delta, jintArray values,
	jobjectArray previous, jint xdim, jboolean opinions)
{
	(void) cls;
	jsize n  = (*env)->GetArrayLength(env, delta);
	jsize np = (previous != NULL) ? (*env)->GetArrayLength(env, previous) : 0;
	if(np > 8) return NULL;
	jbyteArray result = NULL;
	int32_t *d = malloc((size_t) n * sizeof *d), *v = malloc((size_t) n * sizeof *v);
	int32_t *p[8] = { NULL };
	int ok = d != NULL && v != NULL;
	for(jsize i = 0; i < np && ok; i++) ok = (p[i] = malloc((size_t) n * sizeof *p[i])) != NULL;
	if(ok)
	{
		(*env)->GetIntArrayRegion(env, delta, 0, n, (jint *) d);
		(*env)->GetIntArrayRegion(env, values, 0, n, (jint *) v);
		for(jsize i = 0; i < np; i++)
		{
			jintArray a = (jintArray) (*env)->GetObjectArrayElement(env, previous, i);
			(*env)->GetIntArrayRegion(env, a, 0, n, (jint *) p[i]);
			(*env)->DeleteLocalRef(env, a);
		}
		uint8_t *packed;
		size_t   length;
		if(DeltaMapper_packMixedDeltas(d, v, (const int32_t *const *) p, (int) np, xdim, (int) n, opinions != JNI_FALSE, &packed, &length) == 0)
		{
			result = (*env)->NewByteArray(env, (jsize) length);
			if(result != NULL) (*env)->SetByteArrayRegion(env, result, 0, (jsize) length, (const jbyte *) packed);
			free(packed);
		}
	}
	free(d); free(v);
	for(int i = 0; i < 8; i++) free(p[i]);
	return result;
}

/* DeltaMapper.decodeRowFitChannelsNative: getValuesFromRowFitChannels in C
   (DeltaMapper_decodeRowFitChannels) for coded bytes that have all arrived:
   fills delta[i] and value[i]. Returns 0, or -1 if the C couldn't (the Java
   then does it). The arrays are copied in and out. */
JNIEXPORT jint JNICALL Java_DeltaMapper_decodeRowFitChannelsNative(JNIEnv *env, jclass cls, jobjectArray coded, jobjectArray rank_value,
	jint xdim, jint ydim, jintArray init, jintArray radius, jint every, jobjectArray delta, jobjectArray value)
{
	(void) cls;
	jsize channels = (*env)->GetArrayLength(env, coded);
	if(channels < 1 || channels > 3 || xdim < 1 || ydim < 1) return -1;
	size_t n = (size_t) xdim * ydim;
	uint8_t *in[3] = { NULL }; size_t length[3] = { 0 };
	int32_t *rv[3] = { NULL }, *d[3] = { NULL }, *v[3] = { NULL };
	int ns[3], ini[3], rad[3], ok = 1, result = -1;
	(*env)->GetIntArrayRegion(env, init, 0, channels, (jint *) ini);
	(*env)->GetIntArrayRegion(env, radius, 0, channels, (jint *) rad);
	for(jsize i = 0; i < channels && ok; i++)
	{
		jbyteArray b = (jbyteArray) (*env)->GetObjectArrayElement(env, coded, i);
		jintArray  r = (jintArray) (*env)->GetObjectArrayElement(env, rank_value, i);
		length[i] = (size_t) (*env)->GetArrayLength(env, b);
		ns[i]     = (*env)->GetArrayLength(env, r);
		in[i] = malloc(length[i] + 1); rv[i] = malloc((size_t) ns[i] * sizeof *rv[i] + 1);
		d[i]  = malloc(n * sizeof *d[i]); v[i] = malloc(n * sizeof *v[i]);
		ok = in[i] && rv[i] && d[i] && v[i];
		if(ok)
		{
			(*env)->GetByteArrayRegion(env, b, 0, (jsize) length[i], (jbyte *) in[i]);
			(*env)->GetIntArrayRegion(env, r, 0, ns[i], (jint *) rv[i]);
		}
		(*env)->DeleteLocalRef(env, b); (*env)->DeleteLocalRef(env, r);
	}
	if(ok && DeltaMapper_decodeRowFitChannels(channels, (const uint8_t *const *) in, length, (const int32_t *const *) rv, ns,
	                                          xdim, ydim, ini, rad, every, d, v) == 0)
	{
		for(jsize i = 0; i < channels; i++)
		{
			jintArray a = (jintArray) (*env)->GetObjectArrayElement(env, delta, i);
			(*env)->SetIntArrayRegion(env, a, 0, (jsize) n, (const jint *) d[i]);
			(*env)->DeleteLocalRef(env, a);
			a = (jintArray) (*env)->GetObjectArrayElement(env, value, i);
			(*env)->SetIntArrayRegion(env, a, 0, (jsize) n, (const jint *) v[i]);
			(*env)->DeleteLocalRef(env, a);
		}
		result = 0;
	}
	for(int i = 0; i < 3; i++) { free(in[i]); free(rv[i]); free(d[i]); free(v[i]); }
	return result;
}

/* DeltaMapper.getPixelsNative: the reader's last steps in C
   (DeltaMapper_getPixels), into pixel. Returns 0, or -1 if the C couldn't
   (the Java then does them). The channels and pixel are held still while
   the C's threads work on them (they aren't changed: the minimums are added
   as they're read). */
JNIEXPORT jint JNICALL Java_DeltaMapper_getPixelsNative(JNIEnv *env, jclass cls, jint set_id, jobjectArray channel, jintArray min,
	jint w, jint h, jintArray ca, jintArray cb, jintArray ra, jintArray rb, jint xdim, jint ydim, jint pixel_shift, jintArray pixel, jint threads)
{
	(void) cls;
	if((*env)->GetArrayLength(env, channel) != 3) return -1;
	int mn[3];
	(*env)->GetIntArrayRegion(env, min, 0, 3, (jint *) mn);
	int *map[4] = { NULL, NULL, NULL, NULL };
	jintArray maps[4] = { ca, cb, ra, rb };
	int resize = ca != NULL, ok = 1, result = -1;
	if(resize)
		for(int i = 0; i < 4 && ok; i++)
		{
			jsize len = (*env)->GetArrayLength(env, maps[i]);
			ok = (map[i] = malloc((size_t) len * sizeof *map[i] + 1)) != NULL;
			if(ok) (*env)->GetIntArrayRegion(env, maps[i], 0, len, (jint *) map[i]);
		}
	jintArray a[3];
	for(int i = 0; i < 3; i++) a[i] = (jintArray) (*env)->GetObjectArrayElement(env, channel, i);
	if(ok)
	{
		jint *c[3] = { NULL, NULL, NULL };
		for(int i = 0; i < 3 && ok; i++) ok = (c[i] = (*env)->GetPrimitiveArrayCritical(env, a[i], NULL)) != NULL;
		jint *px = ok ? (*env)->GetPrimitiveArrayCritical(env, pixel, NULL) : NULL;
		if(px != NULL)
		{
			result = DeltaMapper_getPixels(set_id, (const int32_t *const *) c, mn, w, h, map[0], map[1], map[2], map[3], xdim, ydim, pixel_shift, (int32_t *) px, threads);
			(*env)->ReleasePrimitiveArrayCritical(env, pixel, px, 0);
		}
		for(int i = 2; i >= 0; i--) if(c[i] != NULL) (*env)->ReleasePrimitiveArrayCritical(env, a[i], c[i], JNI_ABORT);
	}
	for(int i = 0; i < 3; i++) (*env)->DeleteLocalRef(env, a[i]);
	for(int i = 0; i < 4; i++) free(map[i]);
	return result;
}

/* ---- Apply and the decode check -------------------------------------------- */

/* Holds the int arrays a[0..n-1] still (GetPrimitiveArrayCritical) into p;
   returns how many it got (all n, or fewer if one failed). */
static int hold_ints(JNIEnv *env, jobjectArray arrays, int n, jintArray *a, jint **p)
{
	int got = 0;
	for(int i = 0; i < n; i++) { a[i] = (jintArray) (*env)->GetObjectArrayElement(env, arrays, i); p[i] = NULL; }
	for(int i = 0; i < n; i++, got++) if((p[i] = (*env)->GetPrimitiveArrayCritical(env, a[i], NULL)) == NULL) break;
	return got;
}

static void let_go_ints(JNIEnv *env, int n, jintArray *a, jint **p, int got, int changed)
{
	for(int i = got - 1; i >= 0; i--) (*env)->ReleasePrimitiveArrayCritical(env, a[i], p[i], changed ? 0 : JNI_ABORT);
	for(int i = 0; i < n; i++) (*env)->DeleteLocalRef(env, a[i]);
}

/* resize2's four maps, copied (all NULL if ca is). Returns 0, or -1. */
static int copy_maps(JNIEnv *env, jintArray ca, jintArray cb, jintArray ra, jintArray rb, int *map[4])
{
	jintArray maps[4] = { ca, cb, ra, rb };
	for(int i = 0; i < 4; i++) map[i] = NULL;
	if(ca == NULL) return 0;
	for(int i = 0; i < 4; i++)
	{
		jsize len = (*env)->GetArrayLength(env, maps[i]);
		if((map[i] = malloc((size_t) len * sizeof *map[i] + 1)) == NULL) return -1;
		(*env)->GetIntArrayRegion(env, maps[i], 0, len, (jint *) map[i]);
	}
	return 0;
}

/* DeltaMapper.applyQuantizeNative: Apply's quantizedChannels and
   getCandidateChannels in C (DeltaMapper_applyQuantize). */
JNIEXPORT jint JNICALL Java_DeltaMapper_applyQuantizeNative(JNIEnv *env, jclass cls, jobjectArray src, jint X, jint Y, jint w, jint h,
	jintArray ca, jintArray cb, jintArray ra, jintArray rb, jint shift, jobjectArray q, jobjectArray diff, jintArray min, jint threads)
{
	(void) cls;
	int *map[4], result = -1;
	if(copy_maps(env, ca, cb, ra, rb, map) == 0)
	{
		jintArray as[3], aq[3], ad[3];
		jint *ps[3], *pq[3], *pd[3];
		int gs = hold_ints(env, src, 3, as, ps);
		int gq = (gs == 3) ? hold_ints(env, q, 3, aq, pq) : 0;
		int gd = (gq == 3) ? hold_ints(env, diff, 3, ad, pd) : 0;
		int32_t mn[6];
		if(gd == 3)
			result = DeltaMapper_applyQuantize((const int32_t *const *) ps, X, Y, w, h, map[0], map[1], map[2], map[3], shift,
			                                   (int32_t **) pq, (int32_t **) pd, mn, threads);
		if(gq == 3) let_go_ints(env, 3, ad, pd, gd, 1);
		if(gs == 3) let_go_ints(env, 3, aq, pq, gq, 1);
		let_go_ints(env, 3, as, ps, gs, 0);
		if(result == 0) (*env)->SetIntArrayRegion(env, min, 0, 6, (const jint *) mn);
	}
	for(int i = 0; i < 4; i++) free(map[i]);
	return result;
}

/* DeltaMapper.applyPreviewNative: Apply's preview in C (DeltaMapper_applyPreview). */
JNIEXPORT jint JNICALL Java_DeltaMapper_applyPreviewNative(JNIEnv *env, jclass cls, jobjectArray q, jint w, jint h,
	jintArray ca, jintArray cb, jintArray ra, jintArray rb, jint X, jint Y, jint shift, jint correction, jobjectArray src, jintArray pixel, jint threads)
{
	(void) cls;
	int *map[4], result = -1;
	if(copy_maps(env, ca, cb, ra, rb, map) == 0)
	{
		jintArray aq[3], as[3];
		jint *pq[3], *ps[3];
		int gq = hold_ints(env, q, 3, aq, pq);
		int gs = (gq == 3) ? hold_ints(env, src, 3, as, ps) : 0;
		jint *px = (gs == 3) ? (*env)->GetPrimitiveArrayCritical(env, pixel, NULL) : NULL;
		if(px != NULL)
		{
			result = DeltaMapper_applyPreview((const int32_t *const *) pq, w, h, map[0], map[1], map[2], map[3], X, Y, shift, correction,
			                                  (const int32_t *const *) ps, (int32_t *) px, threads);
			(*env)->ReleasePrimitiveArrayCritical(env, pixel, px, 0);
		}
		if(gq == 3) let_go_ints(env, 3, as, ps, gs, 0);
		let_go_ints(env, 3, aq, pq, gq, 0);
	}
	for(int i = 0; i < 4; i++) free(map[i]);
	return result;
}

/* DeltaMapper.checkMixedDeltasNative: whether packed decodes back to delta
   (DeltaMapper_checkMixedDeltas): 1 if it does, 0 if not, -1 if the C
   couldn't tell (the Java then checks). The arrays are copied in. */
JNIEXPORT jint JNICALL Java_DeltaMapper_checkMixedDeltasNative(JNIEnv *env, jclass cls, jbyteArray packed, jintArray delta, jintArray values,
	jobjectArray previous, jint xdim)
{
	(void) cls;
	jsize n = (*env)->GetArrayLength(env, delta), np = (previous != NULL) ? (*env)->GetArrayLength(env, previous) : 0;
	jsize len = (*env)->GetArrayLength(env, packed);
	if(np > 8 || (*env)->GetArrayLength(env, values) != n) return -1;
	uint8_t *b = malloc((size_t) len + 1);
	int32_t *d = malloc((size_t) n * sizeof *d + 1), *v = malloc((size_t) n * sizeof *v + 1), *p[8] = { NULL };
	int ok = b && d && v, result = -1;
	for(jsize i = 0; i < np && ok; i++) ok = (p[i] = malloc((size_t) n * sizeof *p[i] + 1)) != NULL;
	if(ok)
	{
		(*env)->GetByteArrayRegion(env, packed, 0, len, (jbyte *) b);
		(*env)->GetIntArrayRegion(env, delta, 0, n, (jint *) d);
		(*env)->GetIntArrayRegion(env, values, 0, n, (jint *) v);
		for(jsize i = 0; i < np; i++)
		{
			jintArray a = (jintArray) (*env)->GetObjectArrayElement(env, previous, i);
			(*env)->GetIntArrayRegion(env, a, 0, n, (jint *) p[i]);
			(*env)->DeleteLocalRef(env, a);
		}
		result = DeltaMapper_checkMixedDeltas(b, (size_t) len, d, v, (const int32_t *const *) p, (int) np, xdim, (int) n);
	}
	free(b); free(d); free(v);
	for(int i = 0; i < 8; i++) free(p[i]);
	return result;
}
