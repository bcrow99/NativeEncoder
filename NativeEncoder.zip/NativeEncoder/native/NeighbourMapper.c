/* NeighbourMapper.c: the neighbour Huffman coding and decoding,
   NeighbourMapper.java's neighbourCode and neighbourDecode in C (see there
   for the coding): the same bytes from the same deltas, and the same deltas
   from the same bytes. The constants are the Java's. Unlike the Java, which would throw, the tables' code lengths are
   checked before they're used (none too long, and no more codes of a length
   than there's room for), so bytes that aren't neighbourCode's can't make
   the lookup tables overflow: they give -1, and the Java then decodes and
   says what's wrong. */
#include "NeighbourMapper.h"

#include <stdlib.h>
#include <string.h>

#include "BlockPool.h"   /* last: the library's malloc and free are the pool's */

#define CONTEXTS               16
#define PAIR_CONTEXTS          6
#define PAIR_RANGE             3
#define PAIR_ESCAPE            (2 * PAIR_RANGE + 1)
#define PAIR_WIDTH             (PAIR_ESCAPE + 1)
#define RUN_SYMBOLS            18
#define RUN_TABLE              0
#define PAIR_TABLE             (CONTEXTS - 1)
#define STOP_TABLE             (PAIR_TABLE + PAIR_CONTEXTS + 1)
#define ESCAPE_TABLE           (STOP_TABLE + 1)
#define TABLES                 (ESCAPE_TABLE + 1)
#define MAX_CODE_LENGTH        20
#define LENGTH_REPEAT          (MAX_CODE_LENGTH + 1)
#define LENGTH_ZEROS           (LENGTH_REPEAT + 1)
#define LENGTH_MANY_ZEROS      (LENGTH_ZEROS + 1)
#define LENGTH_SYMBOLS         (LENGTH_MANY_ZEROS + 1)
#define LOOKUP_BITS            10

static const int ACTIVITY_STEPS[] = {2, 3, 4, 6, 8, 12, 16, 23, 32, 46, 64, 91, 128, 181};
#define STEPS ((int) (sizeof ACTIVITY_STEPS / sizeof ACTIVITY_STEPS[0]))

/* ---- Bits, most significant first; past the end, 0 bits ---- */

typedef struct
{
	const uint8_t *buffer;
	size_t   length, at;
	uint64_t bits;       /* bits read in and not used: the low count of them */
	int      count;
	size_t   past_end;   /* 0 bytes made up past the end */
} Bits;

static inline uint32_t peek(Bits *b, int n)
{
	while(b->count < n)
	{
		uint32_t x;
		if(b->at < b->length) x = b->buffer[b->at++];
		else { x = 0; b->past_end++; }
		b->bits = (b->bits << 8) | x;
		b->count += 8;
	}
	return (uint32_t) (b->bits >> (b->count - n)) & ((1u << n) - 1);
}

static inline void skip(Bits *b, int n) { b->count -= n; }

static inline uint32_t read_bits(Bits *b, int n)
{
	if(n == 0) return 0;
	uint32_t v = peek(b, n);
	b->count -= n;
	return v;
}

static int overrun(const Bits *b) { return 8 * (uint64_t) b->past_end > (uint64_t) b->count; }

/* ---- Canonical Huffman tables (NeighbourMapper.Table) ---- */

typedef struct
{
	int      longest;
	int      first[MAX_CODE_LENGTH + 2], count[MAX_CODE_LENGTH + 2], start[MAX_CODE_LENGTH + 2];
	int32_t *sorted;                    /* the symbols in code order */
	int32_t  lookup[1 << LOOKUP_BITS];  /* (symbol << 5) | length, or 0 for a longer code */
} Table;

/* Makes a table from its code lengths. Returns 0, or -1 if out of memory or
   the lengths aren't a code's. */
static int make_table(Table *t, const uint8_t *length, int size)
{
	memset(t->count, 0, sizeof t->count);
	t->sorted = NULL;
	int max = 0;
	for(int s = 0; s < size; s++)
	{
		if(length[s] > MAX_CODE_LENGTH) return -1;
		if(length[s] > max) max = length[s];
		if(length[s] > 0) t->count[length[s]]++;
	}
	t->longest = max;
	int next = 0, at = 0;
	for(int l = 1; l <= max; l++)
	{
		next = (next + t->count[l - 1]) << 1;
		t->first[l] = next;
		t->start[l] = at;
		at += t->count[l];
		if((int64_t) next + t->count[l] > ((int64_t) 1 << l)) return -1;   /* more codes than there's room for */
	}
	t->sorted = malloc((size_t) at * sizeof *t->sorted + 1);
	if(!t->sorted) return -1;
	int fill[MAX_CODE_LENGTH + 2], place[MAX_CODE_LENGTH + 2];
	memcpy(fill, t->first, sizeof fill);
	memcpy(place, t->start, sizeof place);
	memset(t->lookup, 0, sizeof t->lookup);
	for(int s = 0; s < size; s++)
	{
		int l = length[s];
		if(l == 0) continue;
		int code = fill[l]++;
		t->sorted[place[l]++] = s;
		if(l <= LOOKUP_BITS)
		{
			int from = code << (LOOKUP_BITS - l), to = from + (1 << (LOOKUP_BITS - l));
			for(int i = from; i < to; i++) t->lookup[i] = (s << 5) | l;
		}
	}
	return 0;
}

/* Reads a symbol. Returns it, or -1 if the bits are no code of the table's. */
static inline int read_symbol(const Table *t, Bits *b)
{
	int32_t e = t->lookup[peek(b, LOOKUP_BITS)];
	if(e != 0) { skip(b, e & 31); return e >> 5; }
	uint32_t all = peek(b, MAX_CODE_LENGTH);
	for(int l = LOOKUP_BITS + 1; l <= t->longest; l++)
	{
		int c = (int) (all >> (MAX_CODE_LENGTH - l)), i = c - t->first[l];
		if(i >= 0 && i < t->count[l]) { skip(b, l); return t->sorted[t->start[l] + i]; }
	}
	return -1;
}

/* ---- The tables' code lengths (NeighbourMapper.readLengths) ---- */

static int table_size(int t, int values)
{
	if(t == RUN_TABLE) return RUN_SYMBOLS;
	if(t > PAIR_TABLE && t <= PAIR_TABLE + PAIR_CONTEXTS) return PAIR_WIDTH * PAIR_WIDTH;
	return values;
}

/* Reads all the tables' code lengths into all (their sizes summed). Returns
   0, or -1 if they aren't what writeLengths writes. */
static int read_lengths(Bits *b, uint8_t *all, size_t total)
{
	uint8_t code_length[LENGTH_SYMBOLS];
	for(int s = 0; s < LENGTH_SYMBOLS; s++) code_length[s] = (uint8_t) read_bits(b, 4);
	Table *t = malloc(sizeof *t);
	if(!t) return -1;
	int result = -1;
	if(make_table(t, code_length, LENGTH_SYMBOLS) == 0)
	{
		int last = -1;
		size_t i = 0;
		result = 0;
		while(i < total)
		{
			int s = read_symbol(t, b), value;
			size_t run;
			if(s < 0) { result = -1; break; }
			if(s <= MAX_CODE_LENGTH) { all[i++] = (uint8_t) s; last = s; continue; }
			if(s == LENGTH_REPEAT)
			{
				if(last < 0) { result = -1; break; }
				run = 3 + read_bits(b, 2); value = last;
			}
			else if(s == LENGTH_ZEROS) { run = 3 + read_bits(b, 3); value = 0; last = 0; }
			else                       { run = 11 + read_bits(b, 7); value = 0; last = 0; }
			if(i + run > total || overrun(b)) { result = -1; break; }
			memset(all + i, value, run);
			i += run;
		}
	}
	free(t->sorted);
	free(t);
	return result;
}

/* ---- The decoding ---- */

static inline int iabs(int v) { return v < 0 ? -v : v; }

/* NeighbourMapper.activity. */
static inline int activity(const int32_t *d, int k, int x, int y, int xdim)
{
	if(y == 0) return 8 * iabs(d[k - 1]);
	if(x == 0) return 8 * iabs(d[k - xdim]);
	if(x == 1 || x == xdim - 1) return 4 * (iabs(d[k - 1]) + iabs(d[k - xdim]));
	int two_above = (y >= 2) ? d[k - 2 * xdim] : d[k - xdim];
	return 2 * iabs(d[k - 1]) + 2 * iabs(d[k - xdim]) + iabs(d[k - xdim - 1]) + iabs(d[k - xdim + 1]) + iabs(d[k - 2]) + iabs(two_above);
}

/* NeighbourMapper.context: CONTEXT_OF[a] for activities up to the last
   step (made from ACTIVITY_STEPS: 1 plus the steps a reaches, 0 for 0), the
   last context from it on. */
static const uint8_t CONTEXT_OF[182] =
{
	0, 1, 2, 3, 4, 4, 5, 5, 6, 6, 6, 6, 7, 7, 7, 7, 8, 8, 8, 8, 8, 8, 8, 9, 9, 9,
	9, 9, 9, 9, 9, 9, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 11, 11, 11, 11, 11, 11,
	11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12,
	12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13,
	13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 14, 14,
	14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14,
	14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 15
};

/* NeighbourMapper.flipped: whether a single delta's sign is flipped in the
   coding (version 2): if its neighbours', left + above (0 for one off the
   image), is negative. */
static inline int flipped(const int32_t *d, int k, int x, int y, int xdim)
{
	return ((x > 0) ? d[k - 1] : 0) + ((y > 0) ? d[k - xdim] : 0) < 0;
}

static inline int context(int a)
{
	return (a >= ACTIVITY_STEPS[STEPS - 1]) ? CONTEXTS - 1 : CONTEXT_OF[a];
}

int NeighbourMapper_decode(const uint8_t *code, size_t code_length, int lo, int values, int flip, int xdim, int ydim, int32_t *delta)
{
	if(values < 1 || xdim < 1 || ydim < 1) return -1;
	int64_t n64 = (int64_t) xdim * ydim;
	if(n64 > INT32_MAX) return -1;
	int n = (int) n64;
	Bits b = { code, code_length, 0, 0, 0, 0 };

	size_t total = 0;
	for(int t = 0; t < TABLES; t++) total += (size_t) table_size(t, values);
	uint8_t *all = malloc(total + 1);
	Table   *table = calloc(TABLES, sizeof *table);
	int result = -1, made = 0;
	if(!all || !table || read_lengths(&b, all, total) != 0) goto done;
	for(size_t at = 0; made < TABLES; made++)
	{
		int size = table_size(made, values);
		if(make_table(&table[made], all + at, size) != 0) { made++; goto done; }
		at += (size_t) size;
	}

	memset(delta, 0, (size_t) n * sizeof *delta);
	for(int y = 0; y < ydim; y++)
	for(int row = y * xdim, end = row + xdim, k = (y == 0) ? 1 : row; k < end; )
	{
		int x = k - row;
		int a = activity(delta, k, x, y, xdim);
		if(a == 0)
		{
			/* Run mode: zeros (there already), then the delta that stopped them. */
			int size = read_symbol(&table[RUN_TABLE], &b);
			if(size < 0) goto done;
			int r = (size <= 1) ? size : (int) ((1u << (size - 1)) | read_bits(&b, size - 1));
			if(r > end - k) goto done;
			k += r;
			if(k < end)
			{
				int s = read_symbol(&table[STOP_TABLE], &b);
				if(s < 0) goto done;
				delta[k++] = s + lo;
			}
			continue;
		}
		int c = context(a);
		if(c <= PAIR_CONTEXTS && k + 1 < end)
		{
			int s = read_symbol(&table[PAIR_TABLE + c], &b);
			if(s < 0) goto done;
			int u = s / PAIR_WIDTH, v = s - u * PAIR_WIDTH;
			if(u == PAIR_ESCAPE) { int e = read_symbol(&table[ESCAPE_TABLE], &b); if(e < 0) goto done; delta[k] = e + lo; }
			else delta[k] = u - PAIR_RANGE;
			if(v == PAIR_ESCAPE) { int e = read_symbol(&table[ESCAPE_TABLE], &b); if(e < 0) goto done; delta[k + 1] = e + lo; }
			else delta[k + 1] = v - PAIR_RANGE;
			k += 2;
			continue;
		}
		int s = read_symbol(&table[c], &b);
		if(s < 0) goto done;
		int e = s + lo;
		delta[k] = (flip && flipped(delta, k, x, y, xdim)) ? -e : e;
		k++;
	}
	if(!overrun(&b)) result = 0;

done:
	if(table) for(int t = 0; t < made; t++) free(table[t].sorted);
	free(table);
	free(all);
	return result;
}

/* =========================================================================
   The coding: NeighbourMapper.neighbourCode in C, the same bytes
   ========================================================================= */

/* ---- Bits written, most significant first, into a growing buffer ---- */

typedef struct
{
	uint8_t *buffer;
	size_t   size, capacity;
	uint64_t bits;    /* not yet written out: the low count of them */
	int      count;
	int      failed;  /* out of memory */
} Writer;

static void put(Writer *w, uint32_t value, int count)
{
	w->bits = (w->bits << count) | (value & (((uint64_t) 1 << count) - 1));
	w->count += count;
	while(w->count >= 8)
	{
		w->count -= 8;
		if(w->size == w->capacity)
		{
			size_t c = 2 * w->capacity;
			uint8_t *b = realloc(w->buffer, c);
			if(!b) { w->failed = 1; return; }
			w->buffer = b; w->capacity = c;
		}
		w->buffer[w->size++] = (uint8_t) (w->bits >> w->count);
	}
}

/* The last byte filled out with 0 bits (BitWriter.toByteArray). */
static void finish(Writer *w) { if(w->count > 0) put(w, 0, 8 - w->count); }

/* ---- Code lengths (NeighbourMapper.codeLengths) ---- */

static int compare_keys(const void *a, const void *b)
{
	uint64_t x = *(const uint64_t *) a, y = *(const uint64_t *) b;
	return (x > y) - (x < y);
}

/* Huffman code lengths for these counts, none longer than limit: as the
   Java makes them (the same tie-breaking, the same limiting), so the same
   lengths. Returns 0, or -1 if out of memory. */
static int code_lengths(const int32_t *frequency, int size, int limit, uint8_t *length)
{
	memset(length, 0, (size_t) size);
	int used = 0;
	for(int s = 0; s < size; s++) if(frequency[s] > 0) used++;
	if(used == 0) return 0;
	if(used == 1)
	{
		for(int s = 0; s < size; s++) if(frequency[s] > 0) length[s] = 1;
		return 0;
	}
	int nodes = 2 * used - 1, result = -1;
	uint64_t *key = malloc((size_t) used * sizeof *key);
	uint64_t *weight = malloc((size_t) nodes * sizeof *weight);
	int      *parent = malloc((size_t) nodes * sizeof *parent);
	int      *depth = malloc((size_t) nodes * sizeof *depth);
	if(!key || !weight || !parent || !depth) goto done;

	/* The symbols by count, then value; then the merging from two queues. */
	for(int s = 0, j = 0; s < size; s++) if(frequency[s] > 0) key[j++] = ((uint64_t) (uint32_t) frequency[s] << 32) | (uint32_t) s;
	qsort(key, (size_t) used, sizeof *key, compare_keys);
	for(int j = 0; j < used; j++) weight[j] = key[j] >> 32;
	int leaf = 0, merged = used;
	for(int next = used; next < nodes; next++)
	{
		int two[2];
		for(int m = 0; m < 2; m++)
		{
			if(leaf < used && (merged >= next || weight[leaf] <= weight[merged])) two[m] = leaf++;
			else two[m] = merged++;
		}
		weight[next] = weight[two[0]] + weight[two[1]];
		parent[two[0]] = parent[two[1]] = next;
	}
	depth[nodes - 1] = 0;
	int longest = 0;
	for(int v = nodes - 2; v >= 0; v--)
	{
		depth[v] = depth[parent[v]] + 1;
		if(v < used && depth[v] > longest) longest = depth[v];
	}
	for(int j = 0; j < used; j++) length[(int) (key[j] & 0xffffffffu)] = (uint8_t) (depth[j] < 255 ? depth[j] : 255);
	if(longest > limit)
	{
		/* JPEG's Annex K.3, then the lengths given out again, shortest first,
		   in the order of the first lengths (then of value). */
		int *count = calloc((size_t) longest + 1, sizeof *count);
		if(!count) goto done;
		for(int j = 0; j < used; j++) count[depth[j]]++;
		for(int i = longest; i > limit; i--)
			while(count[i] > 0)
			{
				int j = i - 2;
				while(count[j] == 0) j--;
				count[i] -= 2;
				count[i - 1]++;
				count[j + 1] += 2;
				count[j]--;
			}
		/* (key reused: (first length << 32) | symbol) */
		for(int j = 0; j < used; j++) key[j] = ((uint64_t) (uint32_t) depth[j] << 32) | (key[j] & 0xffffffffu);
		qsort(key, (size_t) used, sizeof *key, compare_keys);
		for(int j = 0, l = 1; j < used; j++)
		{
			while(count[l] == 0) l++;
			length[(int) (key[j] & 0xffffffffu)] = (uint8_t) l;
			count[l]--;
		}
		free(count);
	}
	result = 0;
done:
	free(key); free(weight); free(parent); free(depth);
	return result;
}

/* The canonical codes for these lengths (NeighbourMapper.Table's). */
static void canonical_codes(const uint8_t *length, int size, uint32_t *code)
{
	int count[MAX_CODE_LENGTH + 2] = {0}, max = 0;
	uint32_t fill[MAX_CODE_LENGTH + 2];
	for(int s = 0; s < size; s++)
	{
		if(length[s] > max) max = length[s];
		if(length[s] > 0) count[length[s]]++;
	}
	uint32_t next = 0;
	for(int l = 1; l <= max; l++)
	{
		next = (next + (uint32_t) count[l - 1]) << 1;
		fill[l] = next;
	}
	for(int s = 0; s < size; s++) code[s] = length[s] ? fill[length[s]]++ : 0;
}

/* ---- The tables' code lengths written (NeighbourMapper.writeLengths) ---- */

static int write_lengths(Writer *w, const uint8_t *all, size_t total)
{
	int *symbol = malloc((total + 1) * sizeof *symbol), *extra = malloc((total + 1) * sizeof *extra);
	int result = -1;
	if(!symbol || !extra) goto done;
	size_t m = 0;
	for(size_t i = 0; i < total; )
	{
		int v = all[i];
		size_t run = 1;
		while(i + run < total && all[i + run] == v) run++;
		i += run;
		if(v == 0)
		{
			while(run >= 11) { size_t r = run < 138 ? run : 138; symbol[m] = LENGTH_MANY_ZEROS; extra[m++] = (int) (r - 11); run -= r; }
			if(run >= 3)     { symbol[m] = LENGTH_ZEROS; extra[m++] = (int) (run - 3); run = 0; }
			while(run > 0)   { symbol[m++] = 0; run--; }
		}
		else
		{
			symbol[m++] = v;
			run--;
			while(run >= 3) { size_t r = run < 6 ? run : 6; symbol[m] = LENGTH_REPEAT; extra[m++] = (int) (r - 3); run -= r; }
			while(run > 0)  { symbol[m++] = v; run--; }
		}
	}
	int32_t frequency[LENGTH_SYMBOLS] = {0};
	for(size_t j = 0; j < m; j++) frequency[symbol[j]]++;
	uint8_t  length[LENGTH_SYMBOLS];
	uint32_t code[LENGTH_SYMBOLS];
	if(code_lengths(frequency, LENGTH_SYMBOLS, 15, length) != 0) goto done;
	canonical_codes(length, LENGTH_SYMBOLS, code);
	for(int s = 0; s < LENGTH_SYMBOLS; s++) put(w, length[s], 4);
	for(size_t j = 0; j < m; j++)
	{
		put(w, code[symbol[j]], length[symbol[j]]);
		if(symbol[j] == LENGTH_REPEAT)          put(w, (uint32_t) extra[j], 2);
		else if(symbol[j] == LENGTH_ZEROS)      put(w, (uint32_t) extra[j], 3);
		else if(symbol[j] == LENGTH_MANY_ZEROS) put(w, (uint32_t) extra[j], 7);
	}
	result = 0;
done:
	free(symbol); free(extra);
	return result;
}

/* ---- The walk (NeighbourMapper.walk) ---- */

static inline int pair_value(int delta) { return (delta >= -PAIR_RANGE && delta <= PAIR_RANGE) ? delta + PAIR_RANGE : PAIR_ESCAPE; }

/* The walk through the deltas, once: each symbol counted into frequency and
   recorded, (table << 24) | symbol, in order into record (at most 2 a
   delta: a run of none and the delta that stops it); a run length's bits
   below its top bit go into extra, one a run. Returns the number of
   records; *runs gets the number of extras. Then the records are coded
   (code_records): the same symbols in the same order as the Java's two
   walks. */
static size_t walk(const int32_t *d, int n, int xdim, int lo, int32_t **frequency, uint32_t *record, uint32_t *extra, size_t *runs)
{
#define SYMBOL(t, s) do { int t_ = (t), s_ = (s); frequency[t_][s_]++; record[m++] = ((uint32_t) t_ << 24) | (uint32_t) s_; } while(0)
	size_t m = 0, e = 0;
	int ydim = n / xdim;
	for(int y = 0; y < ydim; y++)
	for(int row = y * xdim, end = row + xdim, k = (y == 0) ? 1 : row; k < end; )
	{
		int x = k - row;
		int a = activity(d, k, x, y, xdim);
		if(a == 0)
		{
			int r = 0;
			while(k + r < end && d[k + r] == 0) r++;
			int size = 0;
			for(uint32_t v = (uint32_t) r; v; v >>= 1) size++;
			SYMBOL(RUN_TABLE, size);
			if(size > 1) extra[e++] = (uint32_t) r & ((1u << (size - 1)) - 1);
			k += r;
			if(k < end) { SYMBOL(STOP_TABLE, d[k] - lo); k++; }
			continue;
		}
		int c = context(a);
		if(c <= PAIR_CONTEXTS && k + 1 < end)
		{
			int u = pair_value(d[k]), v = pair_value(d[k + 1]);
			SYMBOL(PAIR_TABLE + c, u * PAIR_WIDTH + v);
			if(u == PAIR_ESCAPE) SYMBOL(ESCAPE_TABLE, d[k] - lo);
			if(v == PAIR_ESCAPE) SYMBOL(ESCAPE_TABLE, d[k + 1] - lo);
			k += 2;
			continue;
		}
		SYMBOL(c, (flipped(d, k, x, y, xdim) ? -d[k] : d[k]) - lo);
		k++;
	}
#undef SYMBOL
	*runs = e;
	return m;
}

/* Codes the walk's records with the tables' lengths and codes, each run
   length's size class followed by its extra bits. */
static void code_records(const uint32_t *record, size_t m, const uint32_t *extra, uint8_t **length, uint32_t **code, Writer *w)
{
	size_t e = 0;
	for(size_t j = 0; j < m; j++)
	{
		int t = (int) (record[j] >> 24), s = (int) (record[j] & 0xffffff);
		put(w, code[t][s], length[t][s]);
		if(t == RUN_TABLE && s > 1) put(w, extra[e++], s - 1);
	}
}

int NeighbourMapper_code(const int32_t *delta, int n, int xdim, int *lo_out, int *values_out, uint8_t **code_out, size_t *code_length)
{
	*code_out = NULL; *code_length = 0;
	if(n < 1 || xdim < 1 || n % xdim != 0) return -1;
	int result = -1;
	int32_t *d = malloc((size_t) n * sizeof *d);
	int32_t *frequency[TABLES] = {0};
	uint8_t *length[TABLES] = {0};
	uint32_t *codes[TABLES] = {0};
	uint8_t *all = NULL;
	uint32_t *record = NULL, *extra = NULL;
	Writer w = {0};
	if(!d) goto done;
	memcpy(d, delta, (size_t) n * sizeof *d);
	d[0] = 0;
	int64_t lo = 0, hi = 0;
	if(n > 1)
	{
		lo = hi = d[1];
		for(int k = 2; k < n; k++) { if(d[k] < lo) lo = d[k]; else if(d[k] > hi) hi = d[k]; }
	}
	/* Either way round: a flipped delta is in range too. */
	if(-lo > hi) hi = -lo;
	lo = -hi;
	if(hi - lo + 1 > (1 << 24) - 1) goto done;   /* (a record holds a symbol in 24 bits) */   /* (the decoder's lookup entries hold symbol << 5) */
	int values = (int) (hi - lo + 1);

	/* The symbols counted, the tables made, then the symbols coded. */
	size_t total = 0;
	for(int t = 0; t < TABLES; t++)
	{
		int size = table_size(t, values);
		total += (size_t) size;
		frequency[t] = calloc((size_t) size, sizeof *frequency[t]);
		length[t] = malloc((size_t) size);
		codes[t] = malloc((size_t) size * sizeof *codes[t]);
		if(!frequency[t] || !length[t] || !codes[t]) goto done;
	}
	record = malloc((2 * (size_t) n + 1) * sizeof *record);
	extra  = malloc(((size_t) n + 1) * sizeof *extra);
	if(!record || !extra) goto done;
	size_t runs, m = walk(d, n, xdim, (int) lo, frequency, record, extra, &runs);
	(void) runs;
	all = malloc(total + 1);
	if(!all) goto done;
	size_t at = 0;
	for(int t = 0; t < TABLES; t++)
	{
		int size = table_size(t, values);
		if(code_lengths(frequency[t], size, MAX_CODE_LENGTH, length[t]) != 0) goto done;
		canonical_codes(length[t], size, codes[t]);
		memcpy(all + at, length[t], (size_t) size);
		at += (size_t) size;
	}
	w.capacity = (size_t) n / 2 + 1024;
	w.buffer = malloc(w.capacity);
	if(!w.buffer) goto done;
	if(write_lengths(&w, all, total) != 0) goto done;
	code_records(record, m, extra, length, codes, &w);
	finish(&w);
	if(w.failed) goto done;
	*lo_out = (int) lo; *values_out = values;
	*code_out = w.buffer; *code_length = w.size;
	w.buffer = NULL;
	result = 0;
done:
	free(w.buffer);
	free(all);
	free(record); free(extra);
	for(int t = 0; t < TABLES; t++) { free(frequency[t]); free(length[t]); free(codes[t]); }
	free(d);
	return result;
}
