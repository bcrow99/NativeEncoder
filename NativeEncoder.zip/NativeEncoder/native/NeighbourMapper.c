/* NeighbourMapper.c: the neighbour Huffman coding and decoding,
   NeighbourMapper.java's neighbourCode, neighbourDecode (versions 1 and 2)
   and NeighbourDecoder (version 3) in C (see there for the coding): the
   same bytes from the same deltas, and the same deltas from the same bytes.
   The constants are the Java's. Unlike the Java, which would throw, the tables' code lengths are
   checked before they're used (none too long, and no more codes of a length
   than there's room for), so bytes that aren't neighbourCode's can't make
   the lookup tables overflow: they give -1, and the Java then decodes and
   says what's wrong. */
#include "NeighbourMapper.h"
#include "DeltaMapper.h"   /* med, gradientLevel: the second opinions */
#include "LengthCoding.h"

#include <stdlib.h>
#include <string.h>

#include "BlockPool.h"   /* last: the library's malloc and free are the pool's */

#define CONTEXTS               16
#define PAIR_CONTEXTS          6
#define PAIR_RANGE             3
#define PAIR_ESCAPE            (2 * PAIR_RANGE + 1)
#define PAIR_WIDTH             (PAIR_ESCAPE + 1)
#define RUN_SYMBOLS            18
#define RUN_TABLE              0
#define OPINION_LEVELS         5

static const int ACTIVITY_STEPS[] = {2, 3, 4, 6, 8, 12, 16, 23, 32, 46, 64, 91, 128, 181};
#define STEPS ((int) (sizeof ACTIVITY_STEPS / sizeof ACTIVITY_STEPS[0]))

/* The tables (NeighbourMapper.singleTable and so on), levels the number of
   opinion levels they're split by (1 in versions 1 and 2, OPINION_LEVELS in
   3): the run lengths' size classes, the single deltas' (context c, 1 to
   CONTEXTS - 1, at opinion level l), the pairs' (c 1 to PAIR_CONTEXTS), the
   delta that stops a run, the pairs' escaped deltas. */
static inline int single_table(int c, int l)             { return 1 + l * (CONTEXTS - 1) + c - 1; }
static inline int pair_table(int c, int l, int levels)   { return 1 + levels * (CONTEXTS - 1) + l * PAIR_CONTEXTS + c - 1; }
static inline int stop_table(int levels)                 { return 1 + levels * (CONTEXTS - 1 + PAIR_CONTEXTS); }
static inline int escape_table(int levels)               { return stop_table(levels) + 1; }
static inline int tables(int levels)                     { return stop_table(levels) + 2; }
#define MAX_TABLES (1 + OPINION_LEVELS * (CONTEXTS - 1 + PAIR_CONTEXTS) + 2)

/* ---- The tables' code lengths (NeighbourMapper.readLengths) ---- */

static int table_size(int t, int values, int levels)
{
	if(t == RUN_TABLE) return RUN_SYMBOLS;
	if(t >= pair_table(1, 0, levels) && t < stop_table(levels)) return PAIR_WIDTH * PAIR_WIDTH;
	return values;
}


/* ---- The decoding ---- */

static inline int iabs(int v) { return v < 0 ? -v : v; }

/* NeighbourMapper.activity. */
static inline int activity(const int32_t *d, int k, int x, int y, int xdim)
{
	if(y == 0) return 8 * iabs(d[k - 1]);
	if(x == 0) return 8 * iabs(d[k - xdim]);
	if(x == 1 || x == xdim - 1) return 4 * (iabs(d[k - 1]) + iabs(d[k - xdim]));
	int two_above = (y >= 2) ? d[k - 2 * xdim] : d[k - xdim];
	return 2 * iabs(d[k - 1]) + 2 * iabs(d[k - xdim]) + iabs(d[k - xdim - 1]) + iabs(d[k - xdim + 1]) + iabs(d[k - 2]) + iabs(two_above);
}

/* NeighbourMapper.context: CONTEXT_OF[a] for activities up to the last
   step (made from ACTIVITY_STEPS: 1 plus the steps a reaches, 0 for 0), the
   last context from it on. */
static const uint8_t CONTEXT_OF[182] =
{
	0, 1, 2, 3, 4, 4, 5, 5, 6, 6, 6, 6, 7, 7, 7, 7, 8, 8, 8, 8, 8, 8, 8, 9, 9, 9,
	9, 9, 9, 9, 9, 9, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 11, 11, 11, 11, 11, 11,
	11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12,
	12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13,
	13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 14, 14,
	14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14,
	14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 15
};

/* NeighbourMapper.flipped: whether a single delta's sign is flipped in the
   coding (version 2): if its neighbours', left + above (0 for one off the
   image), is negative. */
static inline int flipped(const int32_t *d, int k, int x, int y, int xdim)
{
	return ((x > 0) ? d[k - 1] : 0) + ((y > 0) ? d[k - xdim] : 0) < 0;
}

static inline int context(int a)
{
	return (a >= ACTIVITY_STEPS[STEPS - 1]) ? CONTEXTS - 1 : CONTEXT_OF[a];
}

/* NeighbourMapper.opinion: a pixel's second opinion (version 3), how far
   the median edge detector is from the rebuilding's prediction p, as a
   gradient level; 0 off the inside of the image (row 0, the first and last
   columns). v is the values, at the band's first. */
static inline int opinion(const int32_t *v, int k, int x, int y, int xdim, int p)
{
	if(y < 1 || x < 1 || x > xdim - 2) return 0;
	return gradientLevel(med(v[k - 1], v[k - xdim], v[k - xdim - 1]) - p);
}

/* Reads the tables' code lengths and makes them (table, tables(levels) of
   them). Returns the number made: tables(levels) if all were, fewer if the
   bytes aren't a coding's (or out of memory). */
static int read_tables(Bits *b, int values, int levels, Table *table)
{
	int count = tables(levels), made = 0;
	size_t total = 0;
	for(int t = 0; t < count; t++) total += (size_t) table_size(t, values, levels);
	uint8_t *all = malloc(total + 1);
	if(all && LengthCoding_readLengths(b, all, total, MAX_CODE_LENGTH) == 0)
		for(size_t at = 0; made < count; made++)
		{
			int size = table_size(made, values, levels);
			if(LengthCoding_makeTable(&table[made], all + at, size) != 0) { free(table[made].sorted); break; }
			at += (size_t) size;
		}
	free(all);
	return made;
}

int NeighbourMapper_decode(const uint8_t *code, size_t code_length, int lo, int values, int flip, int xdim, int ydim, int32_t *delta)
{
	if(values < 1 || xdim < 1 || ydim < 1) return -1;
	int64_t n64 = (int64_t) xdim * ydim;
	if(n64 > INT32_MAX) return -1;
	int n = (int) n64;
	Bits b = { code, code_length, 0, 0, 0, 0 };

	/* Versions 1 and 2: the tables not split by opinion. */
	const int TABLES = tables(1), STOP_TABLE = stop_table(1), ESCAPE_TABLE = escape_table(1);
	Table *table = calloc((size_t) TABLES, sizeof *table);
	int result = -1, made = 0;
	if(!table) goto done;
	made = read_tables(&b, values, 1, table);
	if(made < TABLES) goto done;

	memset(delta, 0, (size_t) n * sizeof *delta);
	for(int y = 0; y < ydim; y++)
	for(int row = y * xdim, end = row + xdim, k = (y == 0) ? 1 : row; k < end; )
	{
		int x = k - row;
		int a = activity(delta, k, x, y, xdim);
		if(a == 0)
		{
			/* Run mode: zeros (there already), then the delta that stopped them. */
			int size = read_symbol(&table[RUN_TABLE], &b);
			if(size < 0) goto done;
			int r = (size <= 1) ? size : (int) ((1u << (size - 1)) | read_bits(&b, size - 1));
			if(r > end - k) goto done;
			k += r;
			if(k < end)
			{
				int s = read_symbol(&table[STOP_TABLE], &b);
				if(s < 0) goto done;
				delta[k++] = s + lo;
			}
			continue;
		}
		int c = context(a);
		if(c <= PAIR_CONTEXTS && k + 1 < end)
		{
			int s = read_symbol(&table[pair_table(c, 0, 1)], &b);
			if(s < 0) goto done;
			int u = s / PAIR_WIDTH, v = s - u * PAIR_WIDTH;
			if(u == PAIR_ESCAPE) { int e = read_symbol(&table[ESCAPE_TABLE], &b); if(e < 0) goto done; delta[k] = e + lo; }
			else delta[k] = u - PAIR_RANGE;
			if(v == PAIR_ESCAPE) { int e = read_symbol(&table[ESCAPE_TABLE], &b); if(e < 0) goto done; delta[k + 1] = e + lo; }
			else delta[k + 1] = v - PAIR_RANGE;
			k += 2;
			continue;
		}
		int s = read_symbol(&table[single_table(c, 0)], &b);
		if(s < 0) goto done;
		int e = s + lo;
		delta[k] = (flip && flipped(delta, k, x, y, xdim)) ? -e : e;
		k++;
	}
	if(!overrun(&b)) result = 0;

done:
	if(table) for(int t = 0; t < made; t++) free(table[t].sorted);
	free(table);
	return result;
}

/* ---- Version 3: a pixel at a time (NeighbourMapper.NeighbourDecoder) ---- */

struct NeighbourDecoder
{
	Bits   b;
	Table *table;                  /* tables(OPINION_LEVELS) of them */
	int    made;                   /* how many were made */
	int    xdim, lo;
	int    zeros;                  /* the zeros still to come of a run */
	int    stop_at;                /* the pixel where a run's stop comes, or -1 */
	int    second_at, second;      /* the pixel where a pair's second delta comes (or -1), and it */
	int    failed;                 /* a code that's none of its table's */
};

NeighbourDecoder *NeighbourDecoder_new(const uint8_t *code, size_t code_length, int lo, int values, int xdim)
{
	if(values < 1 || xdim < 1) return NULL;
	NeighbourDecoder *nd = calloc(1, sizeof *nd);
	if(!nd) return NULL;
	nd->b = (Bits) { code, code_length, 0, 0, 0, 0 };
	nd->xdim = xdim; nd->lo = lo;
	nd->stop_at = nd->second_at = -1;
	nd->table = calloc(MAX_TABLES, sizeof *nd->table);
	if(nd->table) nd->made = read_tables(&nd->b, values, OPINION_LEVELS, nd->table);
	if(nd->made < tables(OPINION_LEVELS)) { NeighbourDecoder_free(nd); return NULL; }
	return nd;
}

void NeighbourDecoder_free(NeighbourDecoder *nd)
{
	if(!nd) return;
	if(nd->table) for(int t = 0; t < nd->made; t++) free(nd->table[t].sorted);
	free(nd->table);
	free(nd);
}

/* A symbol of table t, or (a bad code) 0 and failed set. */
static inline int symbol(NeighbourDecoder *nd, int t)
{
	int s = read_symbol(&nd->table[t], &nd->b);
	if(s < 0) { nd->failed = 1; return 0; }
	return s;
}

int NeighbourDecoder_next(void *arg, int k, int32_t *d, const int32_t *v, int p)
{
	NeighbourDecoder *nd = arg;
	if(k == 0)              { d[0] = 0; return nd->failed ? -1 : 0; }
	if(k == nd->second_at)  { d[k] = nd->second; nd->second_at = -1; return 0; }
	if(nd->zeros > 0)       { d[k] = 0; nd->zeros--; return 0; }
	int lo = nd->lo, xdim = nd->xdim;
	if(k == nd->stop_at)    { d[k] = symbol(nd, stop_table(OPINION_LEVELS)) + lo; nd->stop_at = -1; return nd->failed ? -1 : 0; }
	int y = k / xdim, x = k - y * xdim, end = (y + 1) * xdim;
	int a = activity(d, k, x, y, xdim), o = opinion(v, k, x, y, xdim, p);
	if(a == 0 && o == 0)
	{
		/* Run mode: the zeros given out at the pixels after, then the stop. */
		int size = symbol(nd, RUN_TABLE);
		int r = (size <= 1) ? size : (int) ((1u << (size - 1)) | read_bits(&nd->b, size - 1));
		if(r > end - k) { r = end - k; nd->failed = 1; }
		if(r == 0) d[k] = symbol(nd, stop_table(OPINION_LEVELS)) + lo;
		else
		{
			d[k] = 0;
			nd->zeros = r - 1;
			nd->stop_at = (k + r < end) ? k + r : -1;
		}
		return nd->failed ? -1 : 0;
	}
	int c = (a == 0) ? 1 : context(a), l = iabs(o);
	if(c <= PAIR_CONTEXTS && k + 1 < end)
	{
		/* A pair: the second delta given out at the next pixel. */
		int s = symbol(nd, pair_table(c, l, OPINION_LEVELS));
		int u = s / PAIR_WIDTH, w = s - u * PAIR_WIDTH;
		int d0 = (u == PAIR_ESCAPE) ? symbol(nd, escape_table(OPINION_LEVELS)) + lo : u - PAIR_RANGE;
		int d1 = (w == PAIR_ESCAPE) ? symbol(nd, escape_table(OPINION_LEVELS)) + lo : w - PAIR_RANGE;
		d[k]          = (o < 0) ? -d0 : d0;
		nd->second    = (o < 0) ? -d1 : d1;
		nd->second_at = k + 1;
		return nd->failed ? -1 : 0;
	}
	int e = symbol(nd, single_table(c, l)) + lo;
	int flip = (o != 0) ? o < 0 : flipped(d, k, x, y, xdim);
	d[k] = flip ? -e : e;
	return nd->failed ? -1 : 0;
}

int NeighbourDecoder_finish(const NeighbourDecoder *nd)
{
	return (nd->failed || overrun(&nd->b)) ? -1 : 0;
}

int NeighbourMapper_average(const uint8_t *code, size_t code_length, int lo, int values, int xdim, int ydim, int init, int32_t *value)
{
	if(xdim < 1 || ydim < 1 || (int64_t) xdim * ydim > INT32_MAX) return -1;
	NeighbourDecoder *nd = NeighbourDecoder_new(code, code_length, lo, values, xdim);
	/* (The deltas a row and a half at a time would do; the whole band is simpler.) */
	int32_t *d = malloc((size_t) xdim * ydim * sizeof *d);
	int result = -1;
	if(!nd || !d) goto done;
	for(int y = 0, k = 0; y < ydim; y++)
		for(int x = 0; x < xdim; x++, k++)
		{
			/* DeltaMapper.getAverageDeltasFromValues' prediction. */
			int p;
			if(k == 0)      p = init;
			else if(y == 0) p = value[k - 1];
			else if(x == 0) p = value[k - xdim];
			else            p = (value[k - 1] + value[k - xdim]) / 2;
			NeighbourDecoder_next(nd, k, d, value, p);
			value[k] = (k == 0) ? init : p + d[k];
		}
	result = NeighbourDecoder_finish(nd);
done:
	NeighbourDecoder_free(nd);
	free(d);
	return result;
}

int NeighbourMapper_decodeKnown(const uint8_t *code, size_t code_length, int lo, int values, int xdim, int ydim,
                                const int32_t *value, const int32_t *delta, int32_t *out)
{
	if(xdim < 1 || ydim < 1 || (int64_t) xdim * ydim > INT32_MAX) return -1;
	NeighbourDecoder *nd = NeighbourDecoder_new(code, code_length, lo, values, xdim);
	if(!nd) return -1;
	for(int k = 0, n = xdim * ydim; k < n; k++) NeighbourDecoder_next(nd, k, out, value, value[k] - delta[k]);
	int result = NeighbourDecoder_finish(nd);
	NeighbourDecoder_free(nd);
	return result;
}

/* =========================================================================
   The coding: NeighbourMapper.neighbourCode in C, the same bytes
   ========================================================================= */

/* ---- The walk (NeighbourMapper.walk) ---- */

static inline int pair_value(int delta) { return (delta >= -PAIR_RANGE && delta <= PAIR_RANGE) ? delta + PAIR_RANGE : PAIR_ESCAPE; }

/* The walk through the deltas, once: each symbol counted into frequency and
   recorded, (table << 24) | symbol, in order into record (at most 2 a
   delta: a run of none and the delta that stops it); a run length's bits
   below its top bit go into extra, one a run. Returns the number of
   records; *runs gets the number of extras. Then the records are coded
   (code_records): the same symbols in the same order as the Java's two
   walks. */
static size_t walk(const int32_t *d, const int32_t *value, int n, int xdim, int lo, int32_t **frequency, uint32_t *record, uint32_t *extra, size_t *runs)
{
	const int STOP_TABLE = stop_table(OPINION_LEVELS), ESCAPE_TABLE = escape_table(OPINION_LEVELS);
#define SYMBOL(t, s) do { int t_ = (t), s_ = (s); frequency[t_][s_]++; record[m++] = ((uint32_t) t_ << 24) | (uint32_t) s_; } while(0)
	size_t m = 0, e = 0;
	int ydim = n / xdim;
	for(int y = 0; y < ydim; y++)
	for(int row = y * xdim, end = row + xdim, k = (y == 0) ? 1 : row; k < end; )
	{
		int x = k - row;
		int a = activity(d, k, x, y, xdim), o = opinion(value, k, x, y, xdim, value[k] - d[k]);
		if(a == 0 && o == 0)
		{
			int r = 0;
			while(k + r < end && d[k + r] == 0) r++;
			int size = 0;
			for(uint32_t v = (uint32_t) r; v; v >>= 1) size++;
			SYMBOL(RUN_TABLE, size);
			if(size > 1) extra[e++] = (uint32_t) r & ((1u << (size - 1)) - 1);
			k += r;
			if(k < end) { SYMBOL(STOP_TABLE, d[k] - lo); k++; }
			continue;
		}
		int c = (a == 0) ? 1 : context(a), l = iabs(o);
		if(c <= PAIR_CONTEXTS && k + 1 < end)
		{
			/* (Flipped if the opinion is negative.) */
			int d0 = (o < 0) ? -d[k] : d[k], d1 = (o < 0) ? -d[k + 1] : d[k + 1];
			int u = pair_value(d0), v = pair_value(d1);
			SYMBOL(pair_table(c, l, OPINION_LEVELS), u * PAIR_WIDTH + v);
			if(u == PAIR_ESCAPE) SYMBOL(ESCAPE_TABLE, d0 - lo);
			if(v == PAIR_ESCAPE) SYMBOL(ESCAPE_TABLE, d1 - lo);
			k += 2;
			continue;
		}
		int flip = (o != 0) ? o < 0 : flipped(d, k, x, y, xdim);
		SYMBOL(single_table(c, l), (flip ? -d[k] : d[k]) - lo);
		k++;
	}
#undef SYMBOL
	*runs = e;
	return m;
}

/* Codes the walk's records with the tables' lengths and codes, each run
   length's size class followed by its extra bits. */
static void code_records(const uint32_t *record, size_t m, const uint32_t *extra, uint8_t **length, uint32_t **code, Writer *w)
{
	size_t e = 0;
	for(size_t j = 0; j < m; j++)
	{
		int t = (int) (record[j] >> 24), s = (int) (record[j] & 0xffffff);
		put(w, code[t][s], length[t][s]);
		if(t == RUN_TABLE && s > 1) put(w, extra[e++], s - 1);
	}
}

int NeighbourMapper_code(const int32_t *delta, const int32_t *value, int n, int xdim, int *lo_out, int *values_out, uint8_t **code_out, size_t *code_length)
{
	const int TABLES = tables(OPINION_LEVELS);
	*code_out = NULL; *code_length = 0;
	if(n < 1 || xdim < 1 || n % xdim != 0) return -1;
	int result = -1;
	int32_t *d = malloc((size_t) n * sizeof *d);
	int32_t *frequency[MAX_TABLES] = {0};
	uint8_t *length[MAX_TABLES] = {0};
	uint32_t *codes[MAX_TABLES] = {0};
	uint8_t *all = NULL;
	uint32_t *record = NULL, *extra = NULL;
	Writer w = {0};
	if(!d) goto done;
	memcpy(d, delta, (size_t) n * sizeof *d);
	d[0] = 0;
	int64_t lo = 0, hi = 0;
	if(n > 1)
	{
		lo = hi = d[1];
		for(int k = 2; k < n; k++) { if(d[k] < lo) lo = d[k]; else if(d[k] > hi) hi = d[k]; }
	}
	/* Either way round: a flipped delta is in range too. */
	if(-lo > hi) hi = -lo;
	lo = -hi;
	if(hi - lo + 1 > (1 << 24) - 1) goto done;   /* (a record holds a symbol in 24 bits) */   /* (the decoder's lookup entries hold symbol << 5) */
	int values = (int) (hi - lo + 1);

	/* The symbols counted, the tables made, then the symbols coded. */
	size_t total = 0;
	for(int t = 0; t < TABLES; t++)
	{
		int size = table_size(t, values, OPINION_LEVELS);
		total += (size_t) size;
		frequency[t] = calloc((size_t) size, sizeof *frequency[t]);
		length[t] = malloc((size_t) size);
		codes[t] = malloc((size_t) size * sizeof *codes[t]);
		if(!frequency[t] || !length[t] || !codes[t]) goto done;
	}
	record = malloc((2 * (size_t) n + 1) * sizeof *record);
	extra  = malloc(((size_t) n + 1) * sizeof *extra);
	if(!record || !extra) goto done;
	size_t runs, m = walk(d, value, n, xdim, (int) lo, frequency, record, extra, &runs);
	(void) runs;
	all = malloc(total + 1);
	if(!all) goto done;
	size_t at = 0;
	for(int t = 0; t < TABLES; t++)
	{
		int size = table_size(t, values, OPINION_LEVELS);
		if(LengthCoding_codeLengths(frequency[t], size, MAX_CODE_LENGTH, length[t]) != 0) goto done;
		LengthCoding_canonicalCodes(length[t], size, codes[t]);
		memcpy(all + at, length[t], (size_t) size);
		at += (size_t) size;
	}
	w.capacity = (size_t) n / 2 + 1024;
	w.buffer = malloc(w.capacity);
	if(!w.buffer) goto done;
	if(LengthCoding_writeLengths(&w, all, total, MAX_CODE_LENGTH) != 0) goto done;
	code_records(record, m, extra, length, codes, &w);
	finish(&w);
	if(w.failed) goto done;
	*lo_out = (int) lo; *values_out = values;
	*code_out = w.buffer; *code_length = w.size;
	w.buffer = NULL;
	result = 0;
done:
	free(w.buffer);
	free(all);
	free(record); free(extra);
	for(int t = 0; t < MAX_TABLES; t++) { free(frequency[t]); free(length[t]); free(codes[t]); }
	free(d);
	return result;
}
