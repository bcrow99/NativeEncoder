/* ContextTables: the Context tables coding (ContextTables.java) in C, for
   NativeWriter and NativeReader: the same bytes from the same deltas, and
   the same deltas from the same bytes. Fixed tables chosen by each delta's
   context, rANS coded: version 2's contexts, the channel's own (activity
   bucket and second opinion: ContextTables_ownContext); version 1's, the
   context aware coding's (DeltaMapper.c's MixedModels), still decoded. */
#ifndef CONTEXTTABLES_H
#define CONTEXTTABLES_H

#include <stddef.h>
#include <stdint.h>

#include "DeltaMapper.h"   /* activity_table, med, gradientLevel */

/* rANS's state is kept from CONTEXTTABLES_RANS_LOW to 256 times it. */
#define CONTEXTTABLES_RANS_LOW (1u << 23)

/* The model byte of version 2: the channel's own contexts (version 1's are
   the context aware coding's models, 0 to 2), and their number. */
#define CONTEXTTABLES_OWN 3
#define CONTEXTTABLES_OWN_CONTEXTS 108
/* The own_ frequencies' row length (the most symbols they're made for). */
#define CONTEXTTABLES_OWN_STRIDE 256

/* A channel's decoder (ContextTables.TablesDecoder), a delta at a time. */
typedef struct TablesDecoder
{
	int       model;      /* the model whose contexts are used: CONTEXTTABLES_OWN, or the context aware coding's (0 to 2) */
	int       precision;  /* the frequencies are out of 2^precision */
	int       symbols;    /* the number of symbols (ranks) */
	int       failed;     /* a context with no table was met */
	int       xdim;       /* the width (the own contexts') */
	int       column, row;/* the next pixel's (ContextTables_pixel's) */
	int32_t  *slot;       /* by context (the model's): its table's row, or -1 */
	uint32_t *freq, *cum; /* by row and symbol: the frequencies, and the sums of those before */
	uint16_t *lookup;     /* by row and count (2^precision of them): the symbol */
	int32_t  *value;      /* the delta value of each rank */
	const uint8_t *code;  /* the coded bytes (the caller's: kept till the decoding ends) */
	size_t    length, at; /* their number, and the next */
	uint32_t  x;          /* rANS's state */
	/* Version 2's tables, when they fit (256 symbols at most, values that fit
	   16 bits, precision 13 at most), by context itself (no slot) and in
	   fewer bytes, so that fewer reads miss the caches: by context and count,
	   the symbol and its delta value; by context and symbol, the
	   frequencies and the sums of those before (in place of slot, lookup,
	   freq, cum and value; NULL if they don't fit), the frequencies in rows
	   of CONTEXTTABLES_OWN_STRIDE. A context with no table has own_bad set
	   (and frequencies that keep the state sound till the decoding stops). */
	uint8_t  *own_symbol;
	int16_t  *own_value;
	uint32_t *own_freq, *own_cum;
	uint8_t   own_bad[CONTEXTTABLES_OWN_CONTEXTS];
} TablesDecoder;

/* The delta at the next pixel, whose context (the model's) is c: its
   symbol from the context's lookup, then rANS's state moved on (and
   renormalized, a byte at a time). */
static inline int32_t TablesDecoder_next(TablesDecoder *t, int c)
{
	int32_t r = t->slot[c];
	if(r < 0) { t->failed = 1; return 0; }
	uint32_t mask = (1u << t->precision) - 1, low = t->x & mask;
	int s = t->lookup[((size_t) r << t->precision) + low];
	size_t at = (size_t) r * (size_t) t->symbols + (size_t) s;
	uint32_t x = t->freq[at] * (t->x >> t->precision) + low - t->cum[at];
	while(x < CONTEXTTABLES_RANS_LOW) x = (x << 8) | ((t->at < t->length) ? t->code[t->at++] : 0);
	t->x = x;
	return t->value[s];
}

/* As TablesDecoder_next, from version 2's own_ tables. */
static inline int32_t TablesDecoder_nextOwn(TablesDecoder *t, int c)
{
	t->failed |= t->own_bad[c];
	uint32_t low = t->x & ((1u << t->precision) - 1);
	size_t i = ((size_t) c << t->precision) + low, at = (size_t) c * CONTEXTTABLES_OWN_STRIDE + t->own_symbol[i];
	uint32_t x = t->own_freq[at] * (t->x >> t->precision) + low - t->own_cum[at];
	while(x < CONTEXTTABLES_RANS_LOW) x = (x << 8) | ((t->at < t->length) ? t->code[t->at++] : 0);
	t->x = x;
	return t->own_value[i];
}

static inline int ContextTables_abs(int v) { return (v < 0) ? -v : v; }

/* ContextTables.ownContext, inside the image (row 1 on, but the first and
   last columns): the activity bucket of the deltas left, above, above left
   and above right, times the 9 opinion levels, plus the gradient level of
   the median edge detector's prediction less the rebuilding's. */
static inline int ContextTables_ownInterior(const int32_t *d, const int32_t *v, int k, int xdim, int prediction)
{
	int a = ContextTables_abs(d[k - 1]) + ContextTables_abs(d[k - xdim]) + ContextTables_abs(d[k - xdim - 1]) + ContextTables_abs(d[k - xdim + 1]);
	return activity_table[(a < 255) ? a : 255] * 9 + gradientLevel(med(v[k - 1], v[k - xdim], v[k - xdim - 1]) - prediction) + 4;
}

/* ContextTables.ownContext: a delta's own context at column x of row y. */
static inline int ContextTables_ownContext(const int32_t *d, const int32_t *v, int k, int x, int y, int xdim, int prediction)
{
	if(y >= 1 && x >= 1 && x < xdim - 1) return ContextTables_ownInterior(d, v, k, xdim, prediction);
	int a = (x > 0) ? ContextTables_abs(d[k - 1]) : 0;
	if(y > 0)
	{
		a += ContextTables_abs(d[k - xdim]);
		if(x > 0) a += ContextTables_abs(d[k - xdim - 1]);
		if(x < xdim - 1) a += ContextTables_abs(d[k - xdim + 1]);
	}
	return activity_table[(a < 255) ? a : 255] * 9 + 4;
}

/* A decoder at the start of a channel's coding, from what ContextTables.read
   reads (the tables' bytes, the model, merged (1 or 0), the steps and the
   precision; value, the delta value of each of symbols ranks; the coded
   bytes, which must stay there till the decoding ends), for a band xdim
   wide. NULL if out of memory or the tables aren't what ContextTables.code
   writes. */
TablesDecoder *ContextTables_decoder(const uint8_t *tables, size_t tables_length, int model, int merged, int steps, int precision,
                                     const int32_t *value, int symbols, const uint8_t *code, size_t code_length, int xdim);

/* After the last delta: 0, or -1 if the coding was bad or didn't end where
   it should. */
int ContextTables_finish(const TablesDecoder *t);

void ContextTables_free(TablesDecoder *t);

/* Version 2's decoder a pixel at a time (DeltaMapper.h's PixelDecoder; arg
   the TablesDecoder): delta[k] from its own context, the pixels in turn
   (for DeltaMapper_decodeRowFitChannelsWith). */
int ContextTables_pixel(void *arg, int k, int32_t *delta, const int32_t *value, int prediction);

/* ContextTables.average: a version 2 channel decoded and rebuilt from its
   average deltas (xdim by ydim, init its first value) into value (and its
   deltas into delta). 0, or -1 if the coding was bad. */
int ContextTables_average(TablesDecoder *t, int xdim, int ydim, int init, int32_t *delta, int32_t *value);

/* A channel's deltas Context tables coded, version 2 (ContextTables.code: n
   deltas, xdim wide; values, the band's values as the decoder rebuilds
   them): *packed gets the bytes code returns (malloc'd: free them with the
   library's free), *length their number. Returns 0, or -1 if out of
   memory. */
int ContextTables_code(const int32_t *delta, const int32_t *values, int xdim, int n, uint8_t **packed, size_t *length);

/* The writer's check (ContextTables.decodeKnown): 1 if packed (code's bytes)
   decodes back to delta, given the values; 0 if not; -1 if out of memory. */
int ContextTables_check(const uint8_t *packed, size_t length, const int32_t *delta, const int32_t *values, int xdim, int n);

#endif
