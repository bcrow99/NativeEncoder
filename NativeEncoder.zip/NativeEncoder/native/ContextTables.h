/* ContextTables: the Context tables coding (ContextTables.java) in C, for
   NativeWriter and NativeReader: the same bytes from the same deltas, and
   the same deltas from the same bytes. The context aware coding's contexts
   (DeltaMapper.c's MixedModels) with fixed tables, rANS coded. */
#ifndef CONTEXTTABLES_H
#define CONTEXTTABLES_H

#include <stddef.h>
#include <stdint.h>

/* rANS's state is kept from CONTEXTTABLES_RANS_LOW to 256 times it. */
#define CONTEXTTABLES_RANS_LOW (1u << 23)

/* A channel's decoder (ContextTables.TablesDecoder), a delta at a time. */
typedef struct TablesDecoder
{
	int       model;      /* the model whose contexts are used (0 to 2) */
	int       precision;  /* the frequencies are out of 2^precision */
	int       symbols;    /* the number of symbols (ranks) */
	int       failed;     /* a context with no table was met */
	int32_t  *slot;       /* by context (the model's, as DeltaMapper.c's MixedModels gives it): its table's row, or -1 */
	uint32_t *freq, *cum; /* by row and symbol: the frequencies, and the sums of those before */
	uint16_t *lookup;     /* by row and count (2^precision of them): the symbol */
	int32_t  *value;      /* the delta value of each rank */
	const uint8_t *code;  /* the coded bytes (the caller's: kept till the decoding ends) */
	size_t    length, at; /* their number, and the next */
	uint32_t  x;          /* rANS's state */
} TablesDecoder;

/* The delta at the next pixel, whose context (the model's) is c: its
   symbol from the context's lookup, then rANS's state moved on (and
   renormalized, a byte at a time). */
static inline int32_t TablesDecoder_next(TablesDecoder *t, int c)
{
	int32_t r = t->slot[c];
	if(r < 0) { t->failed = 1; return 0; }
	uint32_t mask = (1u << t->precision) - 1, low = t->x & mask;
	int s = t->lookup[((size_t) r << t->precision) + low];
	size_t at = (size_t) r * (size_t) t->symbols + (size_t) s;
	uint32_t x = t->freq[at] * (t->x >> t->precision) + low - t->cum[at];
	while(x < CONTEXTTABLES_RANS_LOW) x = (x << 8) | ((t->at < t->length) ? t->code[t->at++] : 0);
	t->x = x;
	return t->value[s];
}

/* A decoder at the start of a channel's coding, from what ContextTables.read
   reads (the tables' bytes, the model, merged (1 or 0), the steps and the
   precision; value, the delta value of each of symbols ranks; the coded
   bytes, which must stay there till the decoding ends). NULL if out of
   memory or the tables aren't what ContextTables.code writes. */
TablesDecoder *ContextTables_decoder(const uint8_t *tables, size_t tables_length, int model, int merged, int steps, int precision,
                                     const int32_t *value, int symbols, const uint8_t *code, size_t code_length);

/* After the last delta: 0, or -1 if the coding was bad or didn't end where
   it should. */
int ContextTables_finish(const TablesDecoder *t);

void ContextTables_free(TablesDecoder *t);

/* A channel's deltas Context tables coded (ContextTables.code: n deltas,
   xdim wide; values, the band's values as the decoder rebuilds them;
   previous, the np channels coded before this one's deltas): *packed gets
   the bytes code returns (malloc'd: free them with the library's free),
   *length their number. Returns 0, or -1 if out of memory. */
int ContextTables_code(const int32_t *delta, const int32_t *values, const int32_t *const *previous, int np, int xdim, int n,
                       uint8_t **packed, size_t *length);

/* The writer's check (ContextTables.decodeKnown): 1 if packed (code's bytes)
   decodes back to delta, given the values and the earlier channels' deltas;
   0 if not; -1 if out of memory. */
int ContextTables_check(const uint8_t *packed, size_t length, const int32_t *delta, const int32_t *values,
                        const int32_t *const *previous, int np, int xdim, int n);

#endif
