/*
 * SegmentMapper.h -- SegmentMapper's segmentation of unary strings in C: the
 * parts of SegmentMapper.java that NativePacketWriter and NativePacketReader
 * use, under the same names, giving the same bytes as the Java.
 *
 * A string (StringMapper's format) is its bits, from the low bit of each byte
 * up, then one data byte: the unused bits in the last byte (top 3 bits) and
 * the bit-pair transform's type and passes (low 5 bits). A segment is a
 * string of its own.
 */
#ifndef SEGMENTMAPPER_H
#define SEGMENTMAPPER_H

#include <stddef.h>
#include <stdint.h>

/* One segment: length bytes, its data byte last. */
typedef struct
{
	uint8_t *bytes;
	size_t   length;
} Segment;

/* SegmentMapper.getSegmentedData3's segments: the string (length bytes, data
   byte included) cut into segments of minimum_bitlength bits, neighbours with
   similar zero-bit ratios merged (runs of at most maximum_bitlength bits) and
   compressed (StringMapper.compressStrings, on threads threads), then runs
   that didn't compress combined (at most maximum_bitlength bits each).
   segment_type 0 stops after cutting, 1 after merging, 2 combines too;
   merge_type is the similarity rule (0 to 3) and bin the bin width for the
   zero-bit ratios. Sets *segments (*count of them; free them with
   SegmentMapper_freeSegments). Returns 0; 1 if the Java returns no segments
   (minimum_bitlength not a positive multiple of 8, or segment_type not 0 to
   2); -1 if out of memory or threads. */
int SegmentMapper_getSegmentedData3(const uint8_t *string, size_t length, int minimum_bitlength, int segment_type,
                                    int merge_type, double bin, int maximum_bitlength, int threads,
                                    Segment **segments, int *count);

/* Frees count segments and the array. */
void SegmentMapper_freeSegments(Segment *segments, int count);

/* SegmentMapper.packSegments3: the segments' bits back to back, without data
   bytes or padding, into *packed (*packed_length bytes, malloc'd: the caller
   frees it). Returns 0, or -1 if out of memory. */
int SegmentMapper_packSegments3(const Segment *segments, int count, uint8_t **packed, size_t *packed_length);

/* SegmentMapper.restore2(SegmentMapper.unpackSegments3(packed, bytelength,
   data), string_data): the count segments in packed (packed_length bytes;
   segment k has bytelength[k] bytes and data byte data[k]), the compressed
   ones decompressed (on threads threads), joined, with string_data as the
   data byte, into *string (*string_length bytes, malloc'd: the caller frees
   it). Returns 0, or -1 if out of memory or threads, or if the segments
   don't fit where the Java would throw. */
int SegmentMapper_restore(const uint8_t *packed, size_t packed_length, const int32_t *bytelength, const uint8_t *data,
                          int count, uint8_t string_data, int threads, uint8_t **string, size_t *string_length);

#endif
