/*
 * CodeMapper.c -- CodeMapper's regular (canonical) Huffman code in C (see
 * CodeMapper.h), following the Java methods of the same names. The decoding
 * looks the codes up LOOKUP_BITS bits at a time (the longer ones bit by bit).
 */
#include <stdlib.h>
#include <string.h>

#include "CodeMapper.h"
#include "BlockPool.h"   /* last: the library's malloc and free are the pool's */

/* countUsedValues: how many byte values have a code. */
static int countUsedValues(const uint8_t length[256])
{
	int used = 0;
	for(int s = 0; s < 256; s++) if(length[s] > 0) used++;
	return used;
}

/* getRegularCanonicalCode: the codes, shortest first, in byte order within
   a length. */
static void getRegularCanonicalCode(const uint8_t length[256], uint32_t code[256])
{
	uint32_t next = 0;
	memset(code, 0, 256 * sizeof *code);
	for(int len = 1; len <= CODEMAPPER_MAX_CODE_LENGTH; len++)
	{
		for(int s = 0; s < 256; s++) if(length[s] == len) code[s] = next++;
		next <<= 1;
	}
}

int CodeMapper_packRegularCode(const uint8_t *data, size_t n, const uint8_t length[256], uint8_t **code, size_t *code_length)
{
	*code = NULL; *code_length = 0;
	if(countUsedValues(length) <= 1) { *code = malloc(1); return *code ? 0 : -1; }
	uint32_t word[256];
	getRegularCanonicalCode(length, word);
	uint64_t bits = 0;
	for(size_t i = 0; i < n; i++) bits += length[data[i]];
	size_t bytes = (size_t) ((bits + 7) / 8);
	uint8_t *dst = calloc(bytes + 1, 1);
	if(!dst) return -1;
	/* The codes go in from the high bit of each byte down, gathered 64 bits
	   at a time (a code is at most 24 bits, so 32 waiting bits never
	   overflow it). */
	uint64_t acc = 0;
	int held = 0;
	size_t out = 0;
	for(size_t i = 0; i < n; i++)
	{
		int len = length[data[i]];
		acc = (acc << len) | word[data[i]];
		held += len;
		while(held >= 8) { held -= 8; dst[out++] = (uint8_t) (acc >> held); }
	}
	if(held > 0) dst[out] = (uint8_t) (acc << (8 - held));
	*code = dst; *code_length = bytes;
	return 0;
}

/* The first LOOKUP_BITS bits of the code looked up at once (unpackRegularCode). */
#define LOOKUP_BITS 11

/* The next 32 bits of src (length bytes) from bit position, the first in the
   high bit (0s past the end). */
static inline uint32_t peek_bits(const uint8_t *src, size_t length, uint64_t position)
{
	size_t byte = (size_t) (position >> 3);
	uint64_t x = 0;
	if(byte + 8 <= length)
	{
		memcpy(&x, src + byte, 8);
		x = __builtin_bswap64(x);   /* (the bytes read little-endian, as x86 and ARM run) */
	}
	else for(size_t j = 0; j < 8; j++) x = (x << 8) | ((byte + j < length) ? src[byte + j] : 0);
	return (uint32_t) ((x << (position & 7)) >> 32);
}

int CodeMapper_unpackRegularCode(const uint8_t *src, size_t src_length, const uint8_t length[256], size_t n, uint8_t *dst)
{
	if(countUsedValues(length) <= 1)
	{
		uint8_t only = 0;
		for(int s = 0; s < 256; s++) if(length[s] > 0) only = (uint8_t) s;
		memset(dst, only, n);
		return 0;
	}
	/* Per length: how many codes, the first code, and where its byte values
	   start in the canonical order. */
	int count[CODEMAPPER_MAX_CODE_LENGTH + 1] = { 0 }, first_index[CODEMAPPER_MAX_CODE_LENGTH + 1];
	int32_t first_code[CODEMAPPER_MAX_CODE_LENGTH + 1];
	uint8_t order[256];
	for(int s = 0; s < 256; s++) if(length[s] > 0) count[length[s]]++;
	int32_t code_word = 0;
	int index = 0;
	for(int len = 1; len <= CODEMAPPER_MAX_CODE_LENGTH; len++)
	{
		first_code[len] = code_word;
		first_index[len] = index;
		for(int s = 0; s < 256; s++) if(length[s] == len) order[index++] = (uint8_t) s;
		code_word = (code_word + count[len]) << 1;
	}
	/* What the Java's bit-by-bit decoding (below, for the longer codes) does
	   with each LOOKUP_BITS-bit start: the byte value and its code's length
	   (value | length << 8), 0 if the code is longer, or 0xffff if it isn't
	   a code (the Java throws). */
	uint16_t lookup[1 << LOOKUP_BITS];
	for(int p = 0; p < (1 << LOOKUP_BITS); p++)
	{
		int32_t c = 0;
		lookup[p] = 0;
		for(int len = 1; len <= LOOKUP_BITS; len++)
		{
			c = (c << 1) | ((p >> (LOOKUP_BITS - len)) & 1);
			int32_t offset = c - first_code[len];
			if(offset < count[len])
			{
				lookup[p] = (first_index[len] + offset < 0) ? 0xffff : (uint16_t) (order[first_index[len] + offset] | (len << 8));
				break;
			}
		}
	}
	/* Each code from the lookup, or, if longer, bit by bit (as the Java). A
	   code that would read past the end fails: the bits past it are read as
	   0s, and the position checked after the code. */
	uint64_t position = 0, end = (uint64_t) src_length * 8;
	for(size_t k = 0; k < n; k++)
	{
		uint32_t x = peek_bits(src, src_length, position);
		uint16_t e = lookup[x >> (32 - LOOKUP_BITS)];
		if(e == 0xffff) return -1;
		if(e != 0)
		{
			dst[k] = (uint8_t) e;
			position += e >> 8;
		}
		else
		{
			int32_t c = 0;
			for(int len = 1; ; len++)
			{
				if(len > CODEMAPPER_MAX_CODE_LENGTH) return -1;
				c = (c << 1) | (int32_t) ((x >> (32 - len)) & 1);
				int32_t offset = c - first_code[len];
				if(offset < count[len])
				{
					if(first_index[len] + offset < 0) return -1;   /* (not a code: the Java throws) */
					dst[k] = order[first_index[len] + offset];
					position += (uint64_t) len;
					break;
				}
			}
		}
		if(position > end) return -1;
	}
	return 0;
}
