@echo off
rem How NativeWriter and NativeReader's speed grows with bands and cores, on
rem one big frame (bench\ScaleBench.java): each coding in 1, 2, 4 ... 64 bands
rem (as many as the frame allows), on all the logical processors, then, if the
rem machine has two a core, again on one logical processor a core, then on
rem one processor alone, in 1 and 4 bands only (the single-core times).
rem First it records the machine: processor, cores, threads, clock, memory.
rem   native\run_scale.bat image [tile quant shift runs]   (default 2 4 3 2)
rem Other Java options can be given in JAVA_OPTS, e.g.
rem   set JAVA_OPTS=-XX:+UseParallelGC
rem   native\run_scale.bat scrubjay.jpg
rem Tile 2 makes the frame 2 x 2 copies of the image (scrubjay.jpg, at
rem Save's Pixel Resolution 4: 5630 x 4316 coded, enough for 64 bands).
rem Results go to the window and to scale_results_<machine>.txt here, to
rem send back.
rem Uses MSYS2's ucrt64 (gcc, mingw32-make) in C:\msys64\ucrt64; set MINGW
rem first if it's elsewhere, e.g. set MINGW=D:\msys64\ucrt64
setlocal
cd /d "%~dp0"
if "%~1"=="" (
	echo usage: native\run_scale.bat ^<image^> [tile quant shift runs]
	echo Run it from a command prompt, with the image's path: opened from
	echo Explorer it has no image to work on.
	pause
	exit /b 1
)
if not exist "%~f1" (echo No image %~f1 & exit /b 1)
set IMAGE=%~f1
rem tile quant shift runs
set TILE=%2& set QUANT=%3& set SHIFTS=%4& set RUNS=%5
if "%TILE%"=="" set TILE=2
if "%QUANT%"=="" set QUANT=4
if "%SHIFTS%"=="" set SHIFTS=3
if "%RUNS%"=="" set RUNS=2
set ARGS=%TILE% %QUANT% %SHIFTS% %RUNS%
rem Java 17 and later warn when a library is loaded unless native access is
rem enabled; Java 8 doesn't know the option, so it's only given if accepted.
set NA=
java --enable-native-access=ALL-UNNAMED -version >nul 2>&1 && set NA=--enable-native-access=ALL-UNNAMED
if "%MINGW%"=="" set MINGW=C:\msys64\ucrt64
if not exist "%MINGW%\bin\gcc.exe" (echo No gcc in %MINGW%\bin: install MSYS2's ucrt64 gcc, or set MINGW & exit /b 1)
rem gcc's own programs (cc1, as, ld) need the DLLs in ucrt64\bin.
set PATH=%MINGW%\bin;%PATH%
rem The library DeltaMapper needs the JDK's headers: JAVA_HOME, or else the
rem JDK the java command runs.
if not defined JAVA_HOME for /f "tokens=2 delims==" %%h in ('java -XshowSettings:properties -version 2^>^&1 ^| findstr /c:"java.home ="') do set "JAVA_HOME=%%h"
for /f "tokens=* delims= " %%h in ("%JAVA_HOME%") do set "JAVA_HOME=%%h"
if not exist "%JAVA_HOME%\include\jni.h" (echo No JDK headers in "%JAVA_HOME%\include": set JAVA_HOME to a JDK's folder & exit /b 1)
"%MINGW%\bin\mingw32-make.exe" -s MINGW="%MINGW:\=/%" || exit /b 1
if not exist classes mkdir classes
javac --release 8 -nowarn -Xlint:-options -Xlint:-unchecked -encoding UTF-8 -d classes ..\java\src\*.java ..\java\bench\*.java || exit /b 1

rem The machine: cores, memory, and (on a machine with two logical processors
rem a core, which Windows numbers side by side: 0 and 1 share a core) the
rem affinity mask of one logical processor a core: 1, 4, 16 ... (hex 5555...).
rem The runs on fewer processors tell Java how many it has, with
rem -XX:ActiveProcessorCount: Java doesn't always see an affinity limit (on
rem some machines it still sees them all), and the writer and reader make
rem their threads for the number it sees.
set LOGICAL=%NUMBER_OF_PROCESSORS%
for /f "usebackq" %%a in (`powershell -NoProfile -Command "(Get-CimInstance Win32_Processor | Measure-Object -Property NumberOfCores -Sum).Sum"`) do set CORES=%%a
for /f "usebackq" %%a in (`powershell -NoProfile -Command "[int]((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1MB)"`) do set MEM_MB=%%a
rem The heap: half the memory, at least 2 GB (a 2 x 2 scrubjay needs about 3).
set /a HEAP_MB=MEM_MB/2
if %HEAP_MB% lss 2048 set HEAP_MB=2048
rem All of it taken and touched at the start (-Xms, AlwaysPreTouch), as a
rem program that keeps running would have it: so the times don't include the
rem system supplying the heap's memory, page by page, as it grows.
set HEAP=-Xms%HEAP_MB%m -Xmx%HEAP_MB%m -XX:+AlwaysPreTouch
rem Other Java options, from JAVA_OPTS if it's set (e.g. set
rem JAVA_OPTS=-XX:+UseParallelGC for the parallel garbage collector).
set HEAP=%HEAP% %JAVA_OPTS%
set /a TWICE=2*CORES
set MASK=
if %TWICE%==%LOGICAL% if %LOGICAL% leq 64 for /f "usebackq" %%a in (`powershell -NoProfile -Command "$m = [uint64]0; for($i = 0; $i -lt %CORES%; $i++) { $m = $m -bor ([uint64]1 -shl (2 * $i)) }; '{0:X}' -f $m"`) do set MASK=%%a
set OUT=scale_results_%COMPUTERNAME%.txt
(
echo Machine: %COMPUTERNAME%
powershell -NoProfile -Command "Get-CimInstance Win32_Processor | ForEach-Object { 'Model name: ' + $_.Name; 'Cores: ' + $_.NumberOfCores + ', logical: ' + $_.NumberOfLogicalProcessors + ', max MHz: ' + $_.MaxClockSpeed + ', L2 KB: ' + $_.L2CacheSize + ', L3 KB: ' + $_.L3CacheSize }; (Get-CimInstance Win32_OperatingSystem).Caption"
echo Cores: %CORES% physical, %LOGICAL% logical; memory %MEM_MB% MB ^(Java heap %HEAP_MB% MB^)
java -version 2>&1 | findstr /i version
gcc -dumpfullversion
echo Java options: %HEAP%
echo.
echo === All %LOGICAL% logical processors ===
java %NA% %HEAP% -cp classes ScaleBench "%IMAGE%" %ARGS%
if defined MASK (
	echo.
	echo === One logical processor a core: %CORES% ^(affinity %MASK%^) ===
	start "" /b /wait /affinity %MASK% java %NA% -XX:ActiveProcessorCount=%CORES% %HEAP% -cp classes ScaleBench "%IMAGE%" %ARGS%
)
if %LOGICAL% gtr 1 (
	echo.
	echo === One processor ^(affinity 1^), 1 and 4 bands ===
	start "" /b /wait /affinity 1 java %NA% -XX:ActiveProcessorCount=1 %HEAP% -cp classes ScaleBench "%IMAGE%" %ARGS% "1,4"
)
) > "%OUT%" 2>&1
type "%OUT%"
echo.
echo Saved %CD%\%OUT%
