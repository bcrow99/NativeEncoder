/* LengthCoding: the bit streams and canonical Huffman codes the neighbour
   Huffman coding (NeighbourMapper.c) and the Context tables coding
   (ContextTables.c) share: NeighbourMapper.java's BitReader, BitWriter and
   Table, and its code lengths written compactly (writeLengthSymbols,
   readLengthSymbols). Internal to the library. */
#ifndef LENGTHCODING_H
#define LENGTHCODING_H

#include <stddef.h>
#include <stdint.h>

#define MAX_CODE_LENGTH        20
#define LOOKUP_BITS            10

/* ---- Bits, most significant first; past the end, 0 bits ---- */

typedef struct
{
	const uint8_t *buffer;
	size_t   length, at;
	uint64_t bits;       /* bits read in and not used: the low count of them */
	int      count;
	size_t   past_end;   /* 0 bytes made up past the end */
} Bits;

static inline uint32_t peek(Bits *b, int n)
{
	while(b->count < n)
	{
		uint32_t x;
		if(b->at < b->length) x = b->buffer[b->at++];
		else { x = 0; b->past_end++; }
		b->bits = (b->bits << 8) | x;
		b->count += 8;
	}
	return (uint32_t) (b->bits >> (b->count - n)) & ((1u << n) - 1);
}

static inline void skip(Bits *b, int n) { b->count -= n; }

static inline uint32_t read_bits(Bits *b, int n)
{
	if(n == 0) return 0;
	uint32_t v = peek(b, n);
	b->count -= n;
	return v;
}

static inline int overrun(const Bits *b) { return 8 * (uint64_t) b->past_end > (uint64_t) b->count; }

/* ---- Canonical Huffman tables (NeighbourMapper.Table) ---- */

typedef struct
{
	int      longest;
	int      first[MAX_CODE_LENGTH + 2], count[MAX_CODE_LENGTH + 2], start[MAX_CODE_LENGTH + 2];
	int32_t *sorted;                    /* the symbols in code order */
	int32_t  lookup[1 << LOOKUP_BITS];  /* (symbol << 5) | length, or 0 for a longer code */
} Table;

/* Makes a table from its code lengths (size of them). Returns 0, or -1 if
   out of memory or the lengths aren't a code's (its sorted is then NULL or
   to be freed). */
int LengthCoding_makeTable(Table *t, const uint8_t *length, int size);

/* Reads a symbol. Returns it, or -1 if the bits are no code of the table's. */
static inline int read_symbol(const Table *t, Bits *b)
{
	int32_t e = t->lookup[peek(b, LOOKUP_BITS)];
	if(e != 0) { skip(b, e & 31); return e >> 5; }
	uint32_t all = peek(b, MAX_CODE_LENGTH);
	for(int l = LOOKUP_BITS + 1; l <= t->longest; l++)
	{
		int c = (int) (all >> (MAX_CODE_LENGTH - l)), i = c - t->first[l];
		if(i >= 0 && i < t->count[l]) { skip(b, l); return t->sorted[t->start[l] + i]; }
	}
	return -1;
}

/* Reads total code lengths (0 to max_length) that LengthCoding_writeLengths
   wrote into all (NeighbourMapper.readLengthSymbols). Returns 0, or -1 if
   they aren't what it writes. */
int LengthCoding_readLengths(Bits *b, uint8_t *all, size_t total, int max_length);

/* ---- Bits written, most significant first, into a growing buffer ---- */

typedef struct
{
	uint8_t *buffer;
	size_t   size, capacity;
	uint64_t bits;    /* not yet written out: the low count of them */
	int      count;
	int      failed;  /* out of memory */
} Writer;

/* Makes room for another byte: 0, or -1 if out of memory (failed is set). */
int LengthCoding_grow(Writer *w);

static inline void put(Writer *w, uint32_t value, int count)
{
	w->bits = (w->bits << count) | (value & (((uint64_t) 1 << count) - 1));
	w->count += count;
	while(w->count >= 8)
	{
		w->count -= 8;
		if(w->size == w->capacity && LengthCoding_grow(w)) return;
		w->buffer[w->size++] = (uint8_t) (w->bits >> w->count);
	}
}

/* The last byte filled out with 0 bits (BitWriter.toByteArray). */
static inline void finish(Writer *w) { if(w->count > 0) put(w, 0, 8 - w->count); }

/* Huffman code lengths for these counts, none longer than limit, as
   NeighbourMapper.codeLengths makes them (the same lengths). Returns 0, or -1
   if out of memory. */
int LengthCoding_codeLengths(const int32_t *frequency, int size, int limit, uint8_t *length);

/* The canonical codes for these lengths (NeighbourMapper.Table's). */
void LengthCoding_canonicalCodes(const uint8_t *length, int size, uint32_t *code);

/* Writes total code lengths (0 to max_length) compactly
   (NeighbourMapper.writeLengthSymbols). Returns 0, or -1 if out of memory. */
int LengthCoding_writeLengths(Writer *w, const uint8_t *all, size_t total, int max_length);

#endif
