/* LengthCoding.c: see LengthCoding.h. */
#include "LengthCoding.h"

#include <stdlib.h>
#include <string.h>

#include "BlockPool.h"   /* last: the library's malloc and free are the pool's */

/* ---- Canonical Huffman tables (NeighbourMapper.Table) ---- */

int LengthCoding_makeTable(Table *t, const uint8_t *length, int size)
{
	memset(t->count, 0, sizeof t->count);
	t->sorted = NULL;
	int max = 0;
	for(int s = 0; s < size; s++)
	{
		if(length[s] > MAX_CODE_LENGTH) return -1;
		if(length[s] > max) max = length[s];
		if(length[s] > 0) t->count[length[s]]++;
	}
	t->longest = max;
	int next = 0, at = 0;
	for(int l = 1; l <= max; l++)
	{
		next = (next + t->count[l - 1]) << 1;
		t->first[l] = next;
		t->start[l] = at;
		at += t->count[l];
		if((int64_t) next + t->count[l] > ((int64_t) 1 << l)) return -1;   /* more codes than there's room for */
	}
	t->sorted = malloc((size_t) at * sizeof *t->sorted + 1);
	if(!t->sorted) return -1;
	int fill[MAX_CODE_LENGTH + 2], place[MAX_CODE_LENGTH + 2];
	memcpy(fill, t->first, sizeof fill);
	memcpy(place, t->start, sizeof place);
	memset(t->lookup, 0, sizeof t->lookup);
	for(int s = 0; s < size; s++)
	{
		int l = length[s];
		if(l == 0) continue;
		int code = fill[l]++;
		t->sorted[place[l]++] = s;
		if(l <= LOOKUP_BITS)
		{
			int from = code << (LOOKUP_BITS - l), to = from + (1 << (LOOKUP_BITS - l));
			for(int i = from; i < to; i++) t->lookup[i] = (s << 5) | l;
		}
	}
	return 0;
}


/* ---- Code lengths read (NeighbourMapper.readLengthSymbols) ---- */

int LengthCoding_readLengths(Bits *b, uint8_t *all, size_t total, int max_length)
{
	/* The symbols: lengths 0 to max_length, then the last length again, 3
	   to 6 times; 3 to 10 zeros; 11 to 138 zeros. */
	const int repeat = max_length + 1, zeros = repeat + 1, symbols = zeros + 2;
	uint8_t code_length[MAX_CODE_LENGTH * 4 + 4];
	if(symbols > (int) sizeof code_length) return -1;
	for(int s = 0; s < symbols; s++) code_length[s] = (uint8_t) read_bits(b, 4);
	Table *t = malloc(sizeof *t);
	if(!t) return -1;
	t->sorted = NULL;
	int result = -1;
	if(LengthCoding_makeTable(t, code_length, symbols) == 0)
	{
		int last = -1;
		size_t i = 0;
		result = 0;
		while(i < total)
		{
			int s = read_symbol(t, b), value;
			size_t run;
			if(s < 0) { result = -1; break; }
			if(s <= max_length) { all[i++] = (uint8_t) s; last = s; continue; }
			if(s == repeat)
			{
				if(last < 0) { result = -1; break; }
				run = 3 + read_bits(b, 2); value = last;
			}
			else if(s == zeros) { run = 3 + read_bits(b, 3); value = 0; last = 0; }
			else                       { run = 11 + read_bits(b, 7); value = 0; last = 0; }
			if(i + run > total || overrun(b)) { result = -1; break; }
			memset(all + i, value, run);
			i += run;
		}
	}
	free(t->sorted);
	free(t);
	return result;
}

/* ---- Bits written ---- */

int LengthCoding_grow(Writer *w)
{
	size_t c = 2 * w->capacity + 16;
	uint8_t *b = realloc(w->buffer, c);
	if(!b) { w->failed = 1; return -1; }
	w->buffer = b; w->capacity = c;
	return 0;
}

/* ---- Code lengths (NeighbourMapper.codeLengths) ---- */

static int compare_keys(const void *a, const void *b)
{
	uint64_t x = *(const uint64_t *) a, y = *(const uint64_t *) b;
	return (x > y) - (x < y);
}

/* Huffman code lengths for these counts, none longer than limit: as the
   Java makes them (the same tie-breaking, the same limiting), so the same
   lengths. Returns 0, or -1 if out of memory. */
int LengthCoding_codeLengths(const int32_t *frequency, int size, int limit, uint8_t *length)
{
	memset(length, 0, (size_t) size);
	int used = 0;
	for(int s = 0; s < size; s++) if(frequency[s] > 0) used++;
	if(used == 0) return 0;
	if(used == 1)
	{
		for(int s = 0; s < size; s++) if(frequency[s] > 0) length[s] = 1;
		return 0;
	}
	int nodes = 2 * used - 1, result = -1;
	uint64_t *key = malloc((size_t) used * sizeof *key);
	uint64_t *weight = malloc((size_t) nodes * sizeof *weight);
	int      *parent = malloc((size_t) nodes * sizeof *parent);
	int      *depth = malloc((size_t) nodes * sizeof *depth);
	if(!key || !weight || !parent || !depth) goto done;

	/* The symbols by count, then value; then the merging from two queues. */
	for(int s = 0, j = 0; s < size; s++) if(frequency[s] > 0) key[j++] = ((uint64_t) (uint32_t) frequency[s] << 32) | (uint32_t) s;
	qsort(key, (size_t) used, sizeof *key, compare_keys);
	for(int j = 0; j < used; j++) weight[j] = key[j] >> 32;
	int leaf = 0, merged = used;
	for(int next = used; next < nodes; next++)
	{
		int two[2];
		for(int m = 0; m < 2; m++)
		{
			if(leaf < used && (merged >= next || weight[leaf] <= weight[merged])) two[m] = leaf++;
			else two[m] = merged++;
		}
		weight[next] = weight[two[0]] + weight[two[1]];
		parent[two[0]] = parent[two[1]] = next;
	}
	depth[nodes - 1] = 0;
	int longest = 0;
	for(int v = nodes - 2; v >= 0; v--)
	{
		depth[v] = depth[parent[v]] + 1;
		if(v < used && depth[v] > longest) longest = depth[v];
	}
	for(int j = 0; j < used; j++) length[(int) (key[j] & 0xffffffffu)] = (uint8_t) (depth[j] < 255 ? depth[j] : 255);
	if(longest > limit)
	{
		/* JPEG's Annex K.3, then the lengths given out again, shortest first,
		   in the order of the first lengths (then of value). */
		int *count = calloc((size_t) longest + 1, sizeof *count);
		if(!count) goto done;
		for(int j = 0; j < used; j++) count[depth[j]]++;
		for(int i = longest; i > limit; i--)
			while(count[i] > 0)
			{
				int j = i - 2;
				while(count[j] == 0) j--;
				count[i] -= 2;
				count[i - 1]++;
				count[j + 1] += 2;
				count[j]--;
			}
		/* (key reused: (first length << 32) | symbol) */
		for(int j = 0; j < used; j++) key[j] = ((uint64_t) (uint32_t) depth[j] << 32) | (key[j] & 0xffffffffu);
		qsort(key, (size_t) used, sizeof *key, compare_keys);
		for(int j = 0, l = 1; j < used; j++)
		{
			while(count[l] == 0) l++;
			length[(int) (key[j] & 0xffffffffu)] = (uint8_t) l;
			count[l]--;
		}
		free(count);
	}
	result = 0;
done:
	free(key); free(weight); free(parent); free(depth);
	return result;
}

/* The canonical codes for these lengths (NeighbourMapper.Table's). */
void LengthCoding_canonicalCodes(const uint8_t *length, int size, uint32_t *code)
{
	int count[MAX_CODE_LENGTH + 2] = {0}, max = 0;
	uint32_t fill[MAX_CODE_LENGTH + 2];
	for(int s = 0; s < size; s++)
	{
		if(length[s] > max) max = length[s];
		if(length[s] > 0) count[length[s]]++;
	}
	uint32_t next = 0;
	for(int l = 1; l <= max; l++)
	{
		next = (next + (uint32_t) count[l - 1]) << 1;
		fill[l] = next;
	}
	for(int s = 0; s < size; s++) code[s] = length[s] ? fill[length[s]]++ : 0;
}



int LengthCoding_writeLengths(Writer *w, const uint8_t *all, size_t total, int max_length)
{
	const int repeat = max_length + 1, zeros = repeat + 1, many_zeros = zeros + 1, symbols = many_zeros + 1;
	if(symbols > MAX_CODE_LENGTH * 4 + 4) return -1;
	int *symbol = malloc((total + 1) * sizeof *symbol), *extra = malloc((total + 1) * sizeof *extra);
	int result = -1;
	if(!symbol || !extra) goto done;
	size_t m = 0;
	for(size_t i = 0; i < total; )
	{
		int v = all[i];
		size_t run = 1;
		while(i + run < total && all[i + run] == v) run++;
		i += run;
		if(v == 0)
		{
			while(run >= 11) { size_t r = run < 138 ? run : 138; symbol[m] = many_zeros; extra[m++] = (int) (r - 11); run -= r; }
			if(run >= 3)     { symbol[m] = zeros; extra[m++] = (int) (run - 3); run = 0; }
			while(run > 0)   { symbol[m++] = 0; run--; }
		}
		else
		{
			symbol[m++] = v;
			run--;
			while(run >= 3) { size_t r = run < 6 ? run : 6; symbol[m] = repeat; extra[m++] = (int) (r - 3); run -= r; }
			while(run > 0)  { symbol[m++] = v; run--; }
		}
	}
	int32_t frequency[MAX_CODE_LENGTH * 4 + 4] = {0};
	for(size_t j = 0; j < m; j++) frequency[symbol[j]]++;
	uint8_t  length[MAX_CODE_LENGTH * 4 + 4];
	uint32_t code[MAX_CODE_LENGTH * 4 + 4];
	if(LengthCoding_codeLengths(frequency, symbols, 15, length) != 0) goto done;
	LengthCoding_canonicalCodes(length, symbols, code);
	for(int s = 0; s < symbols; s++) put(w, length[s], 4);
	for(size_t j = 0; j < m; j++)
	{
		put(w, code[symbol[j]], length[symbol[j]]);
		if(symbol[j] == repeat)          put(w, (uint32_t) extra[j], 2);
		else if(symbol[j] == zeros)      put(w, (uint32_t) extra[j], 3);
		else if(symbol[j] == many_zeros) put(w, (uint32_t) extra[j], 7);
	}
	result = 0;
done:
	free(symbol); free(extra);
	return result;
}

