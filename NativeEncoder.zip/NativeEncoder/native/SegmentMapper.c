/*
 * SegmentMapper.c -- SegmentMapper's segmentation in C (see SegmentMapper.h),
 * following the Java methods of the same names: segment, merge3 and combine3
 * (the chain getSegmentedData3 runs), packSegments3, unpackSegments3 and
 * restore2.
 *
 * Where the Java copies each regular segment out of the string, here a
 * segment is first only a range of the string's bytes: the segments that
 * merge3 joins are neighbours, so a run of them is again one range. Each
 * range is copied once, to be compressed.
 */
#include <stdatomic.h>
#include <stdlib.h>
#include <string.h>

#ifdef _WIN32
#include <windows.h>
#else
#include <pthread.h>
#endif

#include "SegmentMapper.h"
#include "StringMapper.h"

/* ---- Strings ---- */

/* StringMapper.getBitlength: the string's bits, from its data byte. */
static int getBitlength(const uint8_t *string, size_t length)
{
	return (int) (length - 1) * 8 - ((string[length - 1] >> 5) & 7);
}

/* StringMapper.getIterations: the data byte's low 5 bits (the passes, plus
   16 for the one-bit transform). 0 or 16: not compressed. */
static int getIterations(const Segment *s) { return s->bytes[s->length - 1] & 31; }

static int isUncompressed(int iterations) { return iterations == 0 || iterations == 16; }

/* StringMapper.getZeroRatio: the share of zero bits in the first bit_length
   bits (NaN for none, as the Java). */
static double getZeroRatio(const uint8_t *string, int bit_length)
{
	int byte_length = bit_length / 8, ones = 0;
	for(int i = 0; i < byte_length; i++) ones += __builtin_popcount(string[i]);
	for(int i = 0; i < bit_length % 8; i++) ones += (string[byte_length] >> i) & 1;
	int zeros = bit_length - ones;
	return (double) zeros / (zeros + ones);
}

/* getBinNumber: the bin a zero-bit ratio falls in, (k * bin, (k + 1) * bin],
   with the bin's edges added up as the Java adds them. */
static int getBinNumber(double ratio, double bin)
{
	int number = 0;
	double total = bin;
	while(ratio > total) { number++; total += bin; }
	return number;
}

/* isSimilarBin: the merge rules (see the Java). */
static int isSimilarBin(int merge_type, int current_bin, int next_bin, int bin_divider, int difference)
{
	if(merge_type == 0)
		return (current_bin < bin_divider && next_bin < bin_divider) || (current_bin >= bin_divider && next_bin >= bin_divider);
	if(merge_type == 1)
		return (current_bin < bin_divider - 1 && next_bin < bin_divider - 1) || (current_bin > bin_divider + 1 && next_bin > bin_divider + 1);
	if(merge_type == 2)
		return (current_bin < bin_divider && next_bin < bin_divider && abs(current_bin - next_bin) < difference)
		    || (current_bin >= bin_divider && next_bin >= bin_divider && abs(current_bin - next_bin) < difference);
	if(merge_type == 3)
		return current_bin == next_bin;
	return 0;
}

/* The data byte of a segment cut or joined from the string: the unused-bit
   count if it ends the string, and the transform bit (16) when zeros are
   less than half its bits. */
static uint8_t dataByte(const uint8_t *bytes, size_t byte_length, int is_last, uint8_t extra_bits)
{
	uint8_t data = is_last ? extra_bits : 0;
	int bitlength = (int) byte_length * 8 - (is_last ? (extra_bits >> 5) & 7 : 0);
	if(getZeroRatio(bytes, bitlength) < .5) data |= 16;
	return data;
}

void SegmentMapper_freeSegments(Segment *segments, int count)
{
	if(!segments) return;
	for(int i = 0; i < count; i++) free(segments[i].bytes);
	free(segments);
}

/* A copy of byte_length bytes with data after them, as a segment. Returns 0,
   or -1 if out of memory. */
static int makeSegment(Segment *s, const uint8_t *bytes, size_t byte_length, uint8_t data)
{
	s->length = byte_length + 1;
	s->bytes  = malloc(s->length);
	if(!s->bytes) return -1;
	memcpy(s->bytes, bytes, byte_length);
	s->bytes[byte_length] = data;
	return 0;
}

/* ---- Running a job on several threads ---- */

/* job(arg, k) for k from 0 to count - 1, on up to threads threads (this one
   included), each taking the next k. Returns 0, or -1 if a job failed or a
   thread couldn't start (the jobs it would have done are done by the
   others). */
typedef int (*Job)(void *arg, int k);

typedef struct
{
	Job         job;
	void       *arg;
	int         count;
	atomic_int  next;
	atomic_int  failed;
} Jobs;

static void runJobs(Jobs *j)
{
	for(int k; (k = atomic_fetch_add(&j->next, 1)) < j->count; )
		if(j->job(j->arg, k)) atomic_store(&j->failed, 1);
}

#ifdef _WIN32
typedef HANDLE Thread;
static DWORD WINAPI threadMain(LPVOID p) { runJobs(p); return 0; }
static int  threadStart(Thread *t, Jobs *j) { *t = CreateThread(NULL, 0, threadMain, j, 0, NULL); return (*t == NULL) ? -1 : 0; }
static void threadJoin(Thread t) { WaitForSingleObject(t, INFINITE); CloseHandle(t); }
#else
typedef pthread_t Thread;
static void *threadMain(void *p) { runJobs(p); return NULL; }
static int  threadStart(Thread *t, Jobs *j) { return pthread_create(t, NULL, threadMain, j) ? -1 : 0; }
static void threadJoin(Thread t) { pthread_join(t, NULL); }
#endif

static int parallel(Job job, void *arg, int count, int threads)
{
	Jobs j = { job, arg, count, 0, 0 };
	if(threads > count) threads = count;
	if(threads < 1) threads = 1;
	Thread *helper = (threads > 1) ? malloc((size_t) (threads - 1) * sizeof *helper) : NULL;
	int started = 0;
	if(helper)
		while(started < threads - 1 && threadStart(&helper[started], &j) == 0) started++;
	runJobs(&j);
	for(int t = 0; t < started; t++) threadJoin(helper[t]);
	free(helper);
	return atomic_load(&j.failed) ? -1 : 0;
}

/* ---- segment, merge3 and combine3 ---- */

/* A run of the string's bytes: the segments merge3 makes before compressing
   them. */
typedef struct
{
	size_t  start, byte_length;
	uint8_t data;
} Range;

typedef struct
{
	const uint8_t *string;
	const Range   *range;
	Segment       *out;
} CompressJob;

/* merge3's compressing: the range with its data byte, compressed. */
static int compressRange(void *arg, int k)
{
	CompressJob *c = arg;
	const Range *r = &c->range[k];
	uint8_t *s = malloc(r->byte_length + 1);
	if(!s) return -1;
	memcpy(s, c->string + r->start, r->byte_length);
	s[r->byte_length] = r->data;
	int result = StringMapper_compressStrings(s, r->byte_length + 1, &c->out[k].bytes, &c->out[k].length);
	free(s);
	return result;
}

/* combine3: runs of neighbouring segments that didn't compress joined, each
   at most max_packet_bytes data bytes. Takes over the segments (*segments,
   *count of them), replacing them. Returns 0, or -1 if out of memory. */
static int combine3(Segment **segments, int *count, uint8_t extra_bits, int max_packet_bytes)
{
	Segment *in = *segments;
	int n = *count, m = 0, i;
	Segment *out = calloc((size_t) n, sizeof *out);
	if(!out) return -1;
	for(i = 0; i < n - 1; i++)
	{
		Segment *current = &in[i], *next = &in[i + 1];
		int current_iterations = getIterations(current), next_iterations = getIterations(next);
		if(isUncompressed(current_iterations) && isUncompressed(next_iterations)
		   && (long) current->length + (long) next->length - 2 <= max_packet_bytes)
		{
			int  j = 1;
			long run_bytes = (long) current->length + (long) next->length - 2;
			while(isUncompressed(next_iterations) && i + j + 1 < n)
			{
				next = &in[i + j + 1];
				next_iterations = getIterations(next);
				if(isUncompressed(next_iterations) && run_bytes + (long) next->length - 1 <= max_packet_bytes)
				{ j++; run_bytes += (long) next->length - 1; }
				else break;
			}

			size_t combined_length = 0;
			for(int k = 0; k <= j; k++) combined_length += in[i + k].length - 1;
			uint8_t *combined = malloc(combined_length + 1);
			if(!combined) { SegmentMapper_freeSegments(out, m); return -1; }
			size_t at = 0;
			for(int k = 0; k <= j; k++)
			{
				memcpy(combined + at, in[i + k].bytes, in[i + k].length - 1);
				at += in[i + k].length - 1;
				free(in[i + k].bytes); in[i + k].bytes = NULL;
			}
			combined[combined_length] = dataByte(combined, combined_length, i + j == n - 1, extra_bits);
			out[m].bytes = combined; out[m].length = combined_length + 1; m++;
			i += j;
		}
		else
		{
			out[m++] = *current;
			current->bytes = NULL;
		}
	}
	if(i == n - 1) { out[m++] = in[i]; in[i].bytes = NULL; }
	SegmentMapper_freeSegments(in, n);
	*segments = out; *count = m;
	return 0;
}

int SegmentMapper_getSegmentedData3(const uint8_t *string, size_t length, int minimum_bitlength, int segment_type,
                                    int merge_type, double bin, int maximum_bitlength, int threads,
                                    Segment **segments, int *count)
{
	*segments = NULL; *count = 0;
	if(minimum_bitlength <= 0 || minimum_bitlength % 8 != 0 || segment_type < 0 || segment_type > 2 || length < 1)
		return 1;
	int max_run = maximum_bitlength / minimum_bitlength;
	if(max_run < 1) max_run = 1;
	int max_packet_bytes = maximum_bitlength / 8;

	/* segment: the regular segments, each segment_bytes bytes, the last
	   taking the remainder (all of the string's bits when it's shorter than
	   one segment). */
	int string_bitlength = getBitlength(string, length);
	int number_of_segments = string_bitlength / minimum_bitlength;
	uint8_t extra_bits = (string_bitlength % 8 != 0) ? (uint8_t) ((8 - string_bitlength % 8) << 5) : 0;
	size_t segment_bytes = (size_t) (minimum_bitlength / 8);
	size_t string_bytes  = (size_t) (string_bitlength / 8 + (string_bitlength % 8 != 0));
	int n = (number_of_segments == 0) ? 1 : number_of_segments;
	Range *range = malloc((size_t) n * sizeof *range);
	int   *bin_number = malloc((size_t) n * sizeof *bin_number);
	if(!range || !bin_number) { free(range); free(bin_number); return -1; }
	for(int i = 0; i < n; i++)
	{
		int is_last = (i == n - 1);
		range[i].start       = (size_t) i * segment_bytes;
		range[i].byte_length = is_last ? string_bytes - range[i].start : segment_bytes;
		int bitlength = is_last ? string_bitlength - (int) range[i].start * 8 : minimum_bitlength;
		double ratio = getZeroRatio(string + range[i].start, bitlength);
		bin_number[i] = getBinNumber(ratio, bin);
		range[i].data = (uint8_t) ((is_last ? extra_bits : 0) | ((ratio < .5) ? 16 : 0));
	}

	Segment *out;
	int m = 0;
	if(segment_type == 0)
	{
		out = calloc((size_t) n, sizeof *out);
		if(!out) { free(range); free(bin_number); return -1; }
		for(int i = 0; i < n; i++)
			if(makeSegment(&out[m++], string + range[i].start, range[i].byte_length, range[i].data))
			{ SegmentMapper_freeSegments(out, m); free(range); free(bin_number); return -1; }
		free(range); free(bin_number);
		*segments = out; *count = m;
		return 0;
	}

	/* merge3: each run of neighbours whose bins are similar to its first's
	   (at most max_run of them) becomes one range. */
	int number_of_bins = (int) (1. / bin), bin_divider = number_of_bins / 2, difference = bin_divider / 2;
	Range *merged = malloc((size_t) n * sizeof *merged);
	if(!merged) { free(range); free(bin_number); return -1; }
	int i;
	for(i = 0; i < n - 1; i++)
	{
		int current_bin = bin_number[i], j = 1;
		int similar = max_run > 1 && isSimilarBin(merge_type, current_bin, bin_number[i + 1], bin_divider, difference);
		if(similar)
		{
			while(similar && i + j < n - 1 && j + 1 < max_run)
			{
				similar = isSimilarBin(merge_type, current_bin, bin_number[i + j + 1], bin_divider, difference);
				if(similar) j++;
			}
			Range *r = &merged[m++];
			r->start       = range[i].start;
			r->byte_length = range[i + j].start + range[i + j].byte_length - r->start;
			r->data        = dataByte(string + r->start, r->byte_length, i + j == n - 1, extra_bits);
			i += j;
		}
		else merged[m++] = range[i];
	}
	if(i == n - 1) merged[m++] = range[i];
	free(range); free(bin_number);

	/* ... and every merged segment compressed. */
	out = calloc((size_t) m, sizeof *out);
	if(!out) { free(merged); return -1; }
	CompressJob c = { string, merged, out };
	int failed = parallel(compressRange, &c, m, threads);
	free(merged);
	if(failed) { SegmentMapper_freeSegments(out, m); return -1; }

	/* combine3, if asked for and two segments in a row didn't compress. */
	int adjacent = 0, previous_iterations = 1;
	for(int k = 0; k < m; k++)
	{
		int iterations = getIterations(&out[k]);
		if(isUncompressed(previous_iterations) && isUncompressed(iterations)) adjacent++;
		previous_iterations = iterations;
	}
	if(m > 1 && segment_type == 2 && adjacent > 0 && combine3(&out, &m, extra_bits, max_packet_bytes))
	{ SegmentMapper_freeSegments(out, m); return -1; }
	*segments = out; *count = m;
	return 0;
}

/* ---- packSegments3, unpackSegments3 and restore2 ---- */

int SegmentMapper_packSegments3(const Segment *segments, int count, uint8_t **packed, size_t *packed_length)
{
	int total_bitlength = 0;
	for(int i = 0; i < count; i++) total_bitlength += getBitlength(segments[i].bytes, segments[i].length);
	int total_bytelength = total_bitlength / 8 + (total_bitlength % 8 != 0);
	uint8_t *string = calloc((size_t) total_bytelength + 1, 1);
	if(!string) return -1;
	int bit_offset = 0;
	for(int i = 0; i < count; i++)
	{
		const uint8_t *segment = segments[i].bytes;
		int length = getBitlength(segment, segments[i].length), nbytes = (length + 7) / 8;
		for(int b = 0; b < nbytes; b++)
		{
			unsigned value = segment[b];
			if(b == nbytes - 1 && length % 8 != 0) value &= (1u << (length % 8)) - 1;   /* only this segment's bits */
			int pos = bit_offset + 8 * b, index = pos >> 3, shift = pos & 7;
			string[index] |= (uint8_t) (value << shift);
			if(shift != 0 && index + 1 < total_bytelength) string[index + 1] |= (uint8_t) (value >> (8 - shift));
		}
		bit_offset += length;
	}
	*packed = string; *packed_length = (size_t) total_bytelength;
	return 0;
}

typedef struct
{
	Segment *segment;
	Segment *decompressed;
} RestoreJob;

/* restore2's decompressing: the segment decompressed, unless it isn't
   compressed (then it's used as it is). */
static int decompressSegment(void *arg, int k)
{
	RestoreJob *r = arg;
	Segment *s = &r->segment[k], *d = &r->decompressed[k];
	if(isUncompressed(getIterations(s))) { *d = *s; return 0; }
	return StringMapper_decompressStrings(s->bytes, s->length, &d->bytes, &d->length);
}

int SegmentMapper_restore(const uint8_t *packed, size_t packed_length, const int32_t *bytelength, const uint8_t *data,
                          int count, uint8_t string_data, int threads, uint8_t **string, size_t *string_length)
{
	*string = NULL; *string_length = 0;
	Segment *segment = calloc((size_t) count + 1, sizeof *segment), *decompressed = calloc((size_t) count + 1, sizeof *decompressed);
	int result = -1;
	if(!segment || !decompressed) goto done;

	/* unpackSegments3: each segment's bits, from its byte length and its data
	   byte's unused-bit count, with its data byte. */
	int bit_offset = 0;
	for(int i = 0; i < count; i++)
	{
		if(bytelength[i] < 0) goto done;
		int bitlength = bytelength[i] * 8 - ((data[i] >> 5) & 7), nbytes = (bitlength + 7) / 8;
		segment[i].length = (size_t) bytelength[i] + 1;
		segment[i].bytes  = calloc(segment[i].length, 1);
		if(!segment[i].bytes) goto done;
		for(int b = 0; b < nbytes; b++)
		{
			int pos = bit_offset + 8 * b, index = pos >> 3, shift = pos & 7;
			if(index < 0 || (size_t) index >= packed_length) goto done;   /* (the Java throws) */
			unsigned value = (unsigned) packed[index] >> shift;
			if(shift != 0 && (size_t) index + 1 < packed_length) value |= (unsigned) packed[index + 1] << (8 - shift);
			if(b == nbytes - 1 && bitlength % 8 != 0) value &= (1u << (bitlength % 8)) - 1;   /* only this segment's bits */
			segment[i].bytes[b] = (uint8_t) value;
		}
		segment[i].bytes[bytelength[i]] = data[i];
		bit_offset += bitlength;
	}

	/* restore2: the compressed segments decompressed, then all joined at
	   their bit offsets, as the Java joins them (the first byte of each ORed
	   in, the rest written over). */
	RestoreJob r = { segment, decompressed };
	if(parallel(decompressSegment, &r, count, threads)) goto done;
	long total_bitlength = 0;
	for(int i = 0; i < count; i++) total_bitlength += getBitlength(decompressed[i].bytes, decompressed[i].length);
	if(total_bitlength < 0 || total_bitlength > 0x7fffffffL) goto done;
	size_t length = (size_t) (total_bitlength / 8 + (total_bitlength % 8 != 0)) + 1;
	uint8_t *dst = calloc(length, 1);
	if(!dst) goto done;
	long offset = 0;
	for(int i = 0; i < count; i++)
	{
		const uint8_t *s = decompressed[i].bytes;
		size_t bytes = decompressed[i].length - 1, byte_offset = (size_t) (offset / 8);
		int shift = (int) (offset % 8);
		if(shift == 0)
		{
			if(byte_offset + bytes > length) { free(dst); goto done; }
			memcpy(dst + byte_offset, s, bytes);
		}
		else
		{
			/* SegmentMapper.shiftLeft: bytes + 1 of them, the first ORed in. */
			if(byte_offset + bytes + 1 > length) { free(dst); goto done; }
			unsigned mask = (1u << shift) - 1;
			if(bytes > 0) dst[byte_offset] |= (uint8_t) (s[0] << shift);
			for(size_t j = 1; j <= bytes; j++)
			{
				unsigned value = (s[j - 1] >> (8 - shift)) & mask;
				if(j < bytes) value |= (unsigned) s[j] << shift;
				dst[byte_offset + j] = (uint8_t) value;
			}
		}
		offset += getBitlength(s, decompressed[i].length);
	}
	dst[length - 1] = string_data;
	*string = dst; *string_length = length;
	result = 0;

done:
	if(decompressed)
		for(int i = 0; i < count; i++)
			if(segment && decompressed[i].bytes != segment[i].bytes) free(decompressed[i].bytes);
	SegmentMapper_freeSegments(segment, count);
	free(decompressed);
	return result;
}
