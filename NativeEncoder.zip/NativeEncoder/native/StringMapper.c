/*
 * StringMapper.c -- StringMapper's unary strings and bit-pair transform in C
 * (see StringMapper.h). Each function gives the same bits as the Java method
 * of the same name, edge cases included.
 *
 * The Java goes a bit at a time. Here the bit-pair transforms and their
 * measure (getCompressionAmount) are small state machines, run a byte at a
 * time through tables made from the same rules (the state carried from one
 * byte to the next), and the unary strings are written and read a run of
 * ones at a time.
 */
#include <stdlib.h>
#include <string.h>

#include "StringMapper.h"

/* The Java's StringMapper.compress_threshold: the transform is kept only if
   it saves more than this share of the bits. */
#define COMPRESS_THRESHOLD 0.10

/* The transform is applied at most this many times (compressStrings' limit). */
#define ITERATION_LIMIT 15

static inline int bit_at(const uint8_t *s, long i) { return (s[i >> 3] >> (i & 7)) & 1; }

/* getBytelength: the bytes a string of bitlength bits takes, data byte included. */
static size_t getBytelength(long bitlength)
{
	return (size_t) (bitlength / 8 + ((bitlength % 8 != 0) ? 1 : 0) + 1);
}

/* getBitlength: the string's bits, from its data byte. */
static long getBitlength(const uint8_t *string, size_t length)
{
	return (long) (length - 1) * 8 - ((string[length - 1] >> 5) & 7);
}

/* setData: the string's data byte (its last). */
static void setData(int type, int iterations, long bitlength, uint8_t *string, size_t length)
{
	if(type == 1) iterations += 16;
	int odd_bits = (int) (bitlength % 8), extra_bits = (odd_bits != 0) ? 8 - odd_bits : 0;
	string[length - 1] = (uint8_t) (iterations | (extra_bits << 5));
}

/* ---- Writing bits, from the low bit of each byte up ---- */

typedef struct
{
	uint8_t *dst;    /* zeroed beforehand */
	size_t   byte;   /* the next byte to write */
	uint64_t acc;    /* bits waiting (held of them) */
	int      held;
} BitWriter;

/* count (at most 32) bits, the first in pattern's low bit. */
static inline void put(BitWriter *w, uint32_t pattern, int count)
{
	w->acc |= (uint64_t) pattern << w->held;
	w->held += count;
	while(w->held >= 8) { w->dst[w->byte++] = (uint8_t) w->acc; w->acc >>= 8; w->held -= 8; }
}

/* The bits written so far. */
static inline long written(const BitWriter *w) { return (long) w->byte * 8 + w->held; }

/* The waiting bits written out (a last, partial byte): the end of the
   writing (written() still counts them). */
static inline void flush(BitWriter *w) { if(w->held > 0) w->dst[w->byte] = (uint8_t) w->acc; }

/* ---- Unary strings: values coded by frequency rank ---- */

typedef struct { int32_t count; int bin; } Bin;

/* getRankTable's order: largest count first; equal counts, the later bin first. */
static int rank_compare(const void *pa, const void *pb)
{
	const Bin *a = pa, *b = pb;
	if(a->count != b->count) return (b->count > a->count) ? 1 : -1;
	return (b->bin > a->bin) ? 1 : (b->bin < a->bin) ? -1 : 0;
}

/* packStrings: each value v as rank k = table[v]: k 1s and a 0, except the
   last rank, which has no 0. The type in its data byte says which bit is
   the commoner (the Java's zero ratio under .5: ones). dst (bitlength bits
   and the data byte) is calloc'd. */
static uint8_t *packStrings(const int32_t *src, int n, const int32_t *table, int range, long *bitlength_out, size_t *length_out)
{
	int max_length = range - 1;
	long bitlength = 0;
	for(int i = 0; i < n; i++)
		bitlength += (table[src[i]] != max_length) ? table[src[i]] + 1 : max_length;
	size_t length = getBytelength(bitlength);
	uint8_t *dst = calloc(length, 1);
	if(!dst) return NULL;
	BitWriter w = { dst, 0, 0, 0 };
	for(int i = 0; i < n; i++)
	{
		int k = table[src[i]];
		for(; k > 24; k -= 24) put(&w, 0xFFFFFF, 24);   /* (long ones, a part at a time) */
		put(&w, (1u << k) - 1, k + ((table[src[i]] != max_length) ? 1 : 0));
	}
	flush(&w);
	long ones = 0;
	for(long i = 0; i < bitlength / 8; i++) ones += __builtin_popcount(dst[i]);
	for(long i = bitlength / 8 * 8; i < bitlength; i++) ones += bit_at(dst, i);
	int type = (bitlength > 0 && 2 * (bitlength - ones) < bitlength) ? 1 : 0;
	setData(type, 0, bitlength, dst, length);
	*bitlength_out = bitlength;
	*length_out = length;
	return dst;
}

int StringMapper_getStringList(const int32_t *value, int n, int32_t *min, int32_t *bitlength,
                               int32_t **table, int *range, uint8_t **string, size_t *length)
{
	*table = NULL; *string = NULL;
	/* getHistogram */
	int32_t lo = value[0], hi = value[0];
	for(int i = 0; i < n; i++) { if(value[i] > hi) hi = value[i]; if(value[i] < lo) lo = value[i]; }
	int r = (int) ((int64_t) hi - lo + 1);
	int32_t *histogram = calloc((size_t) r, sizeof *histogram);
	Bin *order = malloc((size_t) r * sizeof *order);
	int32_t *rank = malloc((size_t) r * sizeof *rank);
	int32_t *v = malloc((size_t) n * sizeof *v);
	if(!histogram || !order || !rank || !v) { free(histogram); free(order); free(rank); free(v); return -1; }
	for(int i = 0; i < n; i++) histogram[value[i] - lo]++;
	/* getRankTable */
	for(int i = 0; i < r; i++) { order[i].count = histogram[i]; order[i].bin = i; }
	qsort(order, (size_t) r, sizeof *order, rank_compare);
	for(int k = 0; k < r; k++) rank[order[k].bin] = k;
	free(order); free(histogram);
	/* value[0] becomes range / 2, the rest have the minimum taken off */
	v[0] = r / 2;
	for(int i = 1; i < n; i++) v[i] = value[i] - lo;
	long bits;
	size_t packed_length;
	uint8_t *packed = packStrings(v, n, rank, r, &bits, &packed_length);
	free(v);
	if(!packed) { free(rank); return -1; }
	uint8_t *compressed;
	size_t compressed_length;
	if(StringMapper_compressStrings(packed, packed_length, &compressed, &compressed_length)) { free(packed); free(rank); return -1; }
	free(packed);
	*min = lo; *bitlength = (int32_t) bits; *table = rank; *range = r;
	*string = compressed; *length = compressed_length;
	return 0;
}

/* ---- Bit-pair compression: the zero-bit and one-bit transforms ----

   Each transform, and each undoing of one, is a machine with two states:
   0 at the start of a pair, 1 halfway through one (its first bit read).
   step() says what one bit does: the bits it writes and the next state. A
   string ending halfway through a pair finishes with end_bits (the Java's
   "lone bit at the end"). The four (TRANSFORMS):

     compressZeroBits    "00" -> "0", "01" -> "11", "1" -> "10", a lone "0" -> "1"
     compressOneBits     "11" -> "1", "10" -> "01", "0" -> "00", a lone "1" -> "0"
     decompressZeroBits  "0" -> "00", "11" -> "01", "10" -> "1", a lone "1" -> "0"
     decompressOneBits   "1" -> "11", "00" -> "0", "01" -> "10", a lone "0" -> "1"

   (Bits read and written left to right; in the bytes, from the low bit up.) */

enum { COMPRESS_ZERO, COMPRESS_ONE, DECOMPRESS_ZERO, DECOMPRESS_ONE, TRANSFORMS };

/* One input bit: in state *state, bit b: writes *count bits (*pattern, the
   first in its low bit), and moves *state on. */
static void step(int transform, int *state, int b, uint32_t *pattern, int *count)
{
	/* The bit that starts a pair (rather than standing alone) */
	static const int pair_start[TRANSFORMS] = { 0, 1, 1, 0 };
	*pattern = 0; *count = 0;
	if(*state == 0)
	{
		if(b == pair_start[transform]) { *state = 1; return; }
		switch(transform)
		{
			case COMPRESS_ZERO:   *pattern = 1; *count = 2; break;   /* "1"  -> "10" */
			case COMPRESS_ONE:    *pattern = 0; *count = 2; break;   /* "0"  -> "00" */
			case DECOMPRESS_ZERO: *pattern = 0; *count = 2; break;   /* "0"  -> "00" */
			default:              *pattern = 3; *count = 2; break;   /* "1"  -> "11" */
		}
		return;
	}
	*state = 0;
	switch(transform)
	{
		case COMPRESS_ZERO:   if(b) { *pattern = 3; *count = 2; } else { *pattern = 0; *count = 1; } break;   /* "01" -> "11", "00" -> "0" */
		case COMPRESS_ONE:    if(b) { *pattern = 1; *count = 1; } else { *pattern = 2; *count = 2; } break;   /* "11" -> "1",  "10" -> "01" */
		case DECOMPRESS_ZERO: if(b) { *pattern = 2; *count = 2; } else { *pattern = 1; *count = 1; } break;   /* "11" -> "01", "10" -> "1" */
		default:              if(b) { *pattern = 1; *count = 2; } else { *pattern = 0; *count = 1; } break;   /* "01" -> "10", "00" -> "0" */
	}
}

/* What a string ending halfway through a pair finishes with: its lone bit's. */
static void end_bits(int transform, uint32_t *pattern, int *count)
{
	static const uint32_t end_pattern[TRANSFORMS] = { 1, 0, 0, 1 };
	*pattern = end_pattern[transform]; *count = 1;
}

/* A whole byte through step(), from each state. */
typedef struct { uint16_t pattern; uint8_t count, state; } ByteStep;

static void byte_steps(int transform, ByteStep table[2][256])
{
	for(int s0 = 0; s0 < 2; s0++)
		for(int byte = 0; byte < 256; byte++)
		{
			int state = s0, count = 0;
			uint32_t pattern = 0;
			for(int j = 0; j < 8; j++)
			{
				uint32_t p; int c;
				step(transform, &state, (byte >> j) & 1, &p, &c);
				pattern |= p << count;
				count += c;
			}
			table[s0][byte].pattern = (uint16_t) pattern;
			table[s0][byte].count = (uint8_t) count;
			table[s0][byte].state = (uint8_t) state;
		}
}

/* Each transform's byte_steps, and getCompressionAmount's tables (below), made
   once, when the library is loaded (makeTables): a string's segments are
   compressed one by one, and most are only 32 bytes, so making the tables
   for each would take longer than the transforms. */
static ByteStep byte_table[TRANSFORMS][2][256];
static int8_t   amount_table[2][2][256];
static uint8_t  next_table[2][2][256];

/* Runs a transform over size bits of src into dst (dst_length bytes, zeroed
   first). As the Java, the undoing ones stop early rather than write a 1
   into dst's last byte (in practice the buffers are big enough that they
   never do). Returns the bits written. */
static long transform_bits(int transform, const uint8_t *src, long size, uint8_t *dst, size_t dst_length)
{
	const ByteStep (*table)[256] = byte_table[transform];
	memset(dst, 0, dst_length);
	BitWriter w = { dst, 0, 0, 0 };
	int undoing = (transform == DECOMPRESS_ZERO || transform == DECOMPRESS_ONE);
	long limit = (long) dst_length - 1;   /* the Java's "current_byte >= dst.length - 1" */
	int state = 0;
	long i = 0;
	/* Whole bytes, while no stop could come in one (a byte writes at most 2). */
	for(; i + 8 <= size && (!undoing || (long) w.byte + 3 < limit); i += 8)
	{
		const ByteStep *t = &table[state][src[i >> 3]];
		put(&w, t->pattern, t->count);
		state = t->state;
	}
	/* The rest a bit at a time, checking for the stop before each 1. */
	for(; i < size; i++)
	{
		uint32_t p; int c;
		step(transform, &state, bit_at(src, i), &p, &c);
		for(int j = 0; j < c; j++)
		{
			int one = (p >> j) & 1;
			if(undoing && one && (long) w.byte >= limit) { flush(&w); return written(&w); }
			put(&w, (uint32_t) one, 1);
		}
	}
	if(state == 1)
	{
		uint32_t p; int c;
		end_bits(transform, &p, &c);
		if(!(undoing && p && (long) w.byte >= limit)) put(&w, p, c);
	}
	flush(&w);
	return written(&w);
}

/* getCompressionAmount: the bits one pass of the transform would save (the
   pairs it shortens less the bits it lengthens), counted as the Java counts
   them: amount_step is its four cases for one bit (type 0: the zero-bit
   transform, "previous" starting at 1; type 1: the one-bit, starting at 0),
   run here a byte at a time through a table. */
static int amount_step(int type, int *previous, int k)
{
	if(type == 0)
	{
		if(k && *previous) return 1;
		if(k) { *previous = 1; return 0; }
		if(*previous) { *previous = 0; return 0; }
		*previous = 1; return -1;
	}
	if(!k && !*previous) return 1;
	if(!k) { *previous = 0; return 0; }
	if(!*previous) { *previous = 1; return 0; }
	*previous = 0; return -1;
}

/* Each byte's amount and next "previous", from each "previous", for a type. */
static void amount_steps(int type, int8_t amount[2][256], uint8_t next[2][256])
{
	for(int p0 = 0; p0 < 2; p0++)
		for(int byte = 0; byte < 256; byte++)
		{
			int previous = p0, sum = 0;
			for(int j = 0; j < 8; j++) sum += amount_step(type, &previous, (byte >> j) & 1);
			amount[p0][byte] = (int8_t) sum;
			next[p0][byte] = (uint8_t) previous;
		}
}

/* Makes the tables, when the library is loaded (before any thread can use
   them). */
__attribute__((constructor)) static void makeTables(void)
{
	for(int transform = 0; transform < TRANSFORMS; transform++) byte_steps(transform, byte_table[transform]);
	for(int type = 0; type < 2; type++) amount_steps(type, amount_table[type], next_table[type]);
}

static long getCompressionAmount(const uint8_t *string, long bit_length, int type)
{
	const int8_t  (*amount)[256] = amount_table[type];
	const uint8_t (*next)[256]   = next_table[type];
	int previous = (type == 0) ? 1 : 0;
	long total = 0, bytes = bit_length / 8;
	for(long i = 0; i < bytes; i++)
	{
		uint8_t b = string[i];
		total += amount[previous][b];
		previous = next[previous][b];
	}
	for(long i = bytes * 8; i < bit_length; i++) total += amount_step(type, &previous, bit_at(string, i));
	return total;
}

static uint8_t *copy_of(const uint8_t *src, size_t length)
{
	uint8_t *dst = malloc(length);
	if(dst) memcpy(dst, src, length);
	return dst;
}

/* StringMapper.compressStrings (see StringMapper.h): the transform that would
   save bits (zero-bit or one-bit), repeated while it does (at most
   ITERATION_LIMIT times), kept if it saves more than COMPRESS_THRESHOLD of
   the bits; else a copy. */
int StringMapper_compressStrings(const uint8_t *src, size_t length, uint8_t **out, size_t *out_length)
{
	long bit_length = getBitlength(src, length);
	long zero_amount = getCompressionAmount(src, bit_length, 0);
	long one_amount  = getCompressionAmount(src, bit_length, 1);
	int  transform_type = (zero_amount <= one_amount) ? 0 : 1;
	if((transform_type == 0 && zero_amount >= 0) || (transform_type == 1 && one_amount >= 0))
	{
		*out = copy_of(src, length); *out_length = length;
		return *out ? 0 : -1;
	}

	size_t buffer_length = length * 2 + 16;
	uint8_t *buffer1 = malloc(buffer_length), *buffer2 = malloc(buffer_length);
	if(!buffer1 || !buffer2) { free(buffer1); free(buffer2); return -1; }
	int transform = (transform_type == 0) ? COMPRESS_ZERO : COMPRESS_ONE;

	long compressed_length = transform_bits(transform, src, bit_length, buffer1, buffer_length);
	long amount = getCompressionAmount(buffer1, compressed_length, transform_type);
	int iterations = 1;
	while(amount < 0 && iterations < ITERATION_LIMIT)
	{
		/* odd iterations go from buffer1 to buffer2, even ones back */
		uint8_t *from = (iterations % 2 == 1) ? buffer1 : buffer2, *to = (iterations % 2 == 1) ? buffer2 : buffer1;
		compressed_length = transform_bits(transform, from, compressed_length, to, buffer_length);
		iterations++;
		amount = getCompressionAmount(to, compressed_length, transform_type);
	}

	if(compressed_length < bit_length - (long) (bit_length * COMPRESS_THRESHOLD))
	{
		size_t dst_length = getBytelength(compressed_length);
		uint8_t *dst = malloc(dst_length);
		if(dst)
		{
			memcpy(dst, (iterations % 2 == 0) ? buffer2 : buffer1, dst_length - 1);
			setData(transform_type, iterations, compressed_length, dst, dst_length);
		}
		*out = dst; *out_length = dst_length;
	}
	else
	{
		*out = copy_of(src, length); *out_length = length;
	}
	free(buffer1); free(buffer2);
	return *out ? 0 : -1;
}

int StringMapper_decompressStrings(const uint8_t *string, size_t length, uint8_t **out, size_t *out_length)
{
	int iterations = string[length - 1] & 31;
	if(iterations == 0 || iterations == 16)
	{
		*out = copy_of(string, length); *out_length = length;
		return *out ? 0 : -1;
	}
	long bitlength = getBitlength(string, length);
	int  type = (iterations > 15) ? 1 : 0;
	int  transform = (type == 0) ? DECOMPRESS_ZERO : DECOMPRESS_ONE;
	iterations &= 15;

	/* As the Java: two buffers, each grown (to a new, zeroed one) when the
	   next pass might need more; the passes go back and forth between them. */
	size_t length1 = getBytelength(bitlength) * 2 + 16, length2 = length1;
	uint8_t *buffer1 = malloc(length1), *buffer2 = malloc(length2);
	if(!buffer1 || !buffer2) { free(buffer1); free(buffer2); return -1; }
	long uncompressed_length = transform_bits(transform, string, bitlength, buffer1, length1);
	int in_buffer1 = 1;
	for(iterations--; iterations > 0; iterations--)
	{
		size_t need = getBytelength(uncompressed_length * 2 + 16);
		uint8_t **to = in_buffer1 ? &buffer2 : &buffer1;
		size_t *to_length = in_buffer1 ? &length2 : &length1;
		if(*to_length < need)
		{
			uint8_t *grown = malloc(need);
			if(!grown) { free(buffer1); free(buffer2); return -1; }
			free(*to); *to = grown; *to_length = need;
		}
		uncompressed_length = transform_bits(transform, in_buffer1 ? buffer1 : buffer2, uncompressed_length, *to, *to_length);
		in_buffer1 = !in_buffer1;
	}
	size_t dst_length = getBytelength(uncompressed_length);
	uint8_t *dst = malloc(dst_length);
	if(dst)
	{
		memcpy(dst, in_buffer1 ? buffer1 : buffer2, dst_length - 1);
		setData(type, 0, uncompressed_length, dst, dst_length);
	}
	free(buffer1); free(buffer2);
	*out = dst; *out_length = dst_length;
	return dst ? 0 : -1;
}

/* Up to 64 bits of src (length bytes) from bit i, the first in the low bit
   (0s past the end). */
static inline uint64_t bits_from(const uint8_t *src, size_t length, long i)
{
	size_t byte = (size_t) (i >> 3);
	uint64_t x = 0;
	if(byte + 9 <= length) memcpy(&x, src + byte, 8);   /* (little-endian, as x86 and ARM run) */
	else for(size_t j = 0; j < 8 && byte + j < length; j++) x |= (uint64_t) src[byte + j] << (8 * j);
	x >>= (i & 7);
	if((i & 7) && byte + 8 < length) x |= (uint64_t) src[byte + 8] << (64 - (i & 7));
	return x;
}

int StringMapper_unpackStrings(const uint8_t *src, size_t length, const int32_t *table, int n,
                               int size, int bitlength, int32_t *dst)
{
	int max_length = n - 1;
	int32_t *inverse_table = malloc((size_t) n * sizeof *inverse_table);
	if(!inverse_table) return -1;
	for(int i = 0; i < n; i++) inverse_table[table[i]] = i;
	memset(dst, 0, (size_t) size * sizeof *dst);
	long bits = getBitlength(src, length);
	if(bitlength > bits) bitlength = (int) bits;

	/* As the Java, bit by bit: "run" counts from 1; a 1 adds to it (up to
	   max_length), a 0 ends the value (rank run - 1), and a 1 when it's
	   already max_length ends the last rank's value. Here the bits are taken
	   up to 56 at a time, and each run of 0s or 1s in them at once. */
	int run = 1, k = 0;
	long i = 0;
	while(k < size && i < bitlength)
	{
		uint64_t x = bits_from(src, length, i);
		int avail = (bitlength - i < 56) ? (int) (bitlength - i) : 56, used = 0;
		while(used < avail && k < size)
		{
			if((x & 1) == 0)
			{
				/* z 0s: the first ends the value under way, each other one a rank 0 */
				int z = (x == 0) ? avail - used : __builtin_ctzll(x);
				if(z > avail - used) z = avail - used;
				dst[k++] = inverse_table[run - 1];
				run = 1;
				for(int j = 1; j < z && k < size; j++) dst[k++] = inverse_table[0];
				x >>= z; used += z;
			}
			else
			{
				int ones = (~x == 0) ? avail - used : __builtin_ctzll(~x);
				if(ones > avail - used) ones = avail - used;
				x >>= ones; used += ones;
				if(max_length < 1) continue;   /* (one value: 1s mean nothing) */
				while(ones > 0 && k < size)
				{
					if(run < max_length)
					{
						int m = max_length - run;
						if(m > ones) m = ones;
						run += m; ones -= m;
					}
					else
					{
						dst[k++] = inverse_table[run];
						run = 1; ones--;
					}
				}
			}
		}
		i += used;
	}
	free(inverse_table);
	return 0;
}
