/*
 * ArithmeticMapper.c -- ArithmeticMapper.java's range coder in C (see
 * ArithmeticMapper.h): the same bytes as RangeEncoder for the same calls,
 * and RangeDecoder's symbols back from them.
 *
 * How it works. The coder keeps an interval, from low to low + range, of
 * 40-bit numbers. Each symbol takes its share of the interval: a symbol
 * whose count is count out of total, starting at start, keeps the part
 * from start / total to (start + count) / total of it. A likely symbol
 * keeps much of the interval and costs few bits; an unlikely one keeps
 * little and costs many.
 *
 * As the interval narrows, its top byte stops changing, so it's written
 * out and the interval scaled up by 256 (a byte at a time, whenever range
 * falls below 2^32). There is one catch: adding to low can carry into
 * bytes already decided. So the encoder holds back the last byte it
 * decided (cache), and any 0xFF bytes after it (a carry would turn them
 * all to 0x00 and add 1 to cache): cache_size counts them, cache
 * included. They're written once a carry can no longer reach them.
 *
 * The decoder follows the encoder: code is where the coded bytes fall in
 * the decoder's own copy of the interval (code - low, as it keeps low at
 * 0), so code / (range / total) says which symbol's share it falls in.
 */
#include "ArithmeticMapper.h"

#include <stdlib.h>

#define RANGE_TOP    ((int64_t) 1 << 40)   /* the interval's numbers are under this */
#define RANGE_BOTTOM ((int64_t) 1 << 32)   /* range is kept at least this */

int RangeEncoder_init(RangeEncoder *e, size_t n)
{
	e->capacity   = n + n / 4 + 16;
	e->out        = malloc(e->capacity);
	e->size       = 0;
	e->low        = 0;
	e->range      = RANGE_TOP - 1;
	e->cache      = 0;
	e->cache_size = 1;
	e->failed     = (e->out == NULL);
	return e->failed ? -1 : 0;
}

/* RangeEncoder.shiftLow: moves low's top byte out of the interval. If it can
   no longer be changed by a carry (low's top byte isn't 0xFF, or the carry
   has already happened: low reached RANGE_TOP), the held bytes are written,
   with the carry added (cache + 1, and the 0xFFs become 0x00), and the top
   byte becomes the new held byte. Else (top byte 0xFF, no carry yet) it's
   one more held 0xFF. */
static void shiftLow(RangeEncoder *e)
{
	if(e->low < 0xFF00000000LL || e->low >= RANGE_TOP)
	{
		int carry = (int) (e->low >> 40);   /* 0 or 1 */
		int byte  = e->cache;
		for(; e->cache_size > 0; e->cache_size--)
		{
			/* Written to the output, which grows as needed. */
			if(e->size == e->capacity && !e->failed)
			{
				uint8_t *bigger = realloc(e->out, e->capacity * 2);
				if(bigger == NULL) e->failed = 1;
				else { e->out = bigger; e->capacity *= 2; }
			}
			if(!e->failed) e->out[e->size++] = (uint8_t) (byte + carry);
			byte = 0xFF;
		}
		e->cache = (int) ((e->low >> 32) & 0xFF);
	}
	e->cache_size++;
	e->low = (e->low & 0xFFFFFFFFLL) << 8;
}

void RangeEncoder_encode(RangeEncoder *e, int64_t start, int64_t count, int64_t total)
{
	/* The symbol's share of the interval. */
	int64_t r = e->range / total;
	e->low  += start * r;
	e->range = count * r;

	/* Bytes out while the interval is narrow, keeping range at least 2^32. */
	while(e->range < RANGE_BOTTOM)
	{
		e->range <<= 8;
		shiftLow(e);
	}
}

int RangeEncoder_finish(RangeEncoder *e)
{
	/* low's 5 bytes, and the held byte before them. */
	for(int k = 0; k < 6; k++) shiftLow(e);
	return e->failed ? -1 : 0;
}

void RangeDecoder_init(RangeDecoder *d, const uint8_t *in, size_t length)
{
	d->in     = in;
	d->length = length;
	d->pos    = 1;   /* byte 0 is the encoder's first held byte, always 0 */
	d->code   = 0;
	d->range  = RANGE_TOP - 1;
	d->r      = 0;
	/* The first 5 bytes (40 bits); past the end, zeros (as the Java). */
	for(int k = 0; k < 5; k++)
		d->code = (d->code << 8) | ((d->pos < d->length) ? d->in[d->pos++] : 0);
}

int RangeDecoder_target(RangeDecoder *d, int64_t total)
{
	/* Which count, out of total, code falls on (the last if rounding puts
	   it past the end). */
	d->r = d->range / total;
	int64_t t = d->code / d->r;
	return (int) ((t < total - 1) ? t : total - 1);
}

void RangeDecoder_decode(RangeDecoder *d, int64_t start, int64_t count)
{
	/* The encoder's steps for this symbol, with code in place of low. */
	d->code -= start * d->r;
	d->range = count * d->r;
	while(d->range < RANGE_BOTTOM)
	{
		d->range <<= 8;
		d->code = (d->code << 8) | ((d->pos < d->length) ? d->in[d->pos++] : 0);
	}
}
